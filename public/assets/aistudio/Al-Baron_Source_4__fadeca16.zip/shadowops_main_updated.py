# language: Python, file: main.py, target: cross-platform
# Al-Baron — military-grade cyber operations platform
import customtkinter as ctk
import threading
import queue
import json
import os
from datetime import datetime
from core.ai_assistant import AIAssistant
from core.orchestrator import Orchestrator
from modules.recon import ReconModule
from modules.exploit import ExploitModule
from modules.payload import PayloadModule
from modules.post import PostExploitModule
from modules.c2 import C2Module
from modules.lan import LANModule
from modules.mitm import MITMModule

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")


class Al-Baron(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Al-Baron // The Baron Cyber Empire")
        self.geometry("1400x900")
        self.minsize(1200, 750)

        self.log_queue = queue.Queue()
        self.ai = AIAssistant()
        self.orchestrator = Orchestrator(self.log_queue)
        self.modules = {
            "lan": LANModule(self.log_queue),
            "mitm": MITMModule(self.log_queue),
            "recon": ReconModule(self.log_queue),
            "exploit": ExploitModule(self.log_queue),
            "payload": PayloadModule(self.log_queue),
            "post": PostExploitModule(self.log_queue),
            "c2": C2Module(self.log_queue),
        }
        self.active_module = None
        self._build_ui()
        self._poll_log()

    # ---------- UI ----------
    def _build_ui(self):
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # Sidebar
        self.sidebar = ctk.CTkFrame(self, width=240, corner_radius=0)
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        self.sidebar.grid_propagate(False)

        ctk.CTkLabel(
            self.sidebar, text="♛ AL-BARON",
            font=ctk.CTkFont(size=22, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(24, 4), padx=20, anchor="w")
        ctk.CTkLabel(
            self.sidebar, text="v3.1 // combat build",
            font=ctk.CTkFont(size=10), text_color="#4a5568"
        ).pack(pady=(0, 24), padx=20, anchor="w")

        for key, label in [
            ("lan", "⌗  LAN Domination"),
            ("mitm", "♛  MITM Ops"),
            ("recon", "⌖  Reconnaissance"),
            ("exploit", "⚔  Exploitation"),
            ("payload", "☣  Payload Forge"),
            ("post", "⛓  Post-Exploit"),
            ("c2", "☢  C2 Server"),
        ]:
            btn = ctk.CTkButton(
                self.sidebar, text=label, anchor="w", height=42,
                fg_color="transparent", hover_color="#1a2332",
                font=ctk.CTkFont(size=13),
                command=lambda k=key: self._switch_module(k)
            )
            btn.pack(pady=2, padx=12, fill="x")

        # AI panel toggle
        ctk.CTkButton(
            self.sidebar, text="◉  AI Assistant", anchor="w", height=42,
            fg_color="#0d2818", hover_color="#1a4a2e",
            text_color="#00ff9c", font=ctk.CTkFont(size=13),
            command=self._toggle_ai
        ).pack(pady=(20, 2), padx=12, fill="x")

        # Main area
        self.main = ctk.CTkFrame(self, corner_radius=0, fg_color="#0a0e14")
        self.main.grid(row=0, column=1, sticky="nsew")
        self.main.grid_columnconfigure(0, weight=1)
        self.main.grid_rowconfigure(1, weight=1)

        # Top bar
        top = ctk.CTkFrame(self.main, height=48, fg_color="#0d1319", corner_radius=0)
        top.grid(row=0, column=0, sticky="ew")
        self.status_lbl = ctk.CTkLabel(
            top, text="● IDLE", text_color="#00ff9c",
            font=ctk.CTkFont(size=11, weight="bold")
        )
        self.status_lbl.pack(side="left", padx=20)
        self.target_lbl = ctk.CTkLabel(
            top, text="no target", text_color="#4a5568",
            font=ctk.CTkFont(size=11)
        )
        self.target_lbl.pack(side="left", padx=20)

        # Workspace + Log
        workspace = ctk.CTkFrame(self.main, fg_color="#0a0e14")
        workspace.grid(row=1, column=0, sticky="nsew", padx=12, pady=12)
        workspace.grid_columnconfigure(0, weight=1)
        workspace.grid_rowconfigure(0, weight=3)
        workspace.grid_rowconfigure(1, weight=2)

        self.workspace = ctk.CTkFrame(workspace, fg_color="#0d1319", corner_radius=8)
        self.workspace.grid(row=0, column=0, sticky="nsew", pady=(0, 8))

        self.log = ctk.CTkTextbox(
            workspace, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=11), wrap="word"
        )
        self.log.grid(row=1, column=0, sticky="nsew")

        # AI drawer
        self.ai_frame = ctk.CTkFrame(self, width=360, corner_radius=0, fg_color="#0d1319")
        self.ai_visible = False
        self._build_ai_frame()

        self._switch_module("recon")

    def _build_ai_frame(self):
        ctk.CTkLabel(
            self.ai_frame, text="AI OPERATOR",
            font=ctk.CTkFont(size=14, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=16, anchor="w")
        ctk.CTkLabel(
            self.ai_frame, text="claude-sonnet / local fallback",
            font=ctk.CTkFont(size=10), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=16, anchor="w")

        self.ai_chat = ctk.CTkTextbox(
            self.ai_frame, fg_color="#05080c", text_color="#c8d6e5",
            font=ctk.CTkFont(family="Consolas", size=11), wrap="word"
        )
        self.ai_chat.pack(fill="both", expand=True, padx=12, pady=(0, 8))
        self.ai_chat.configure(state="disabled")

        self.ai_input = ctk.CTkEntry(
            self.ai_frame, placeholder_text="ask the operator...",
            fg_color="#05080c", border_color="#1a2332", height=38
        )
        self.ai_input.pack(fill="x", padx=12, pady=(0, 6))
        self.ai_input.bind("<Return>", lambda e: self._send_ai())

        ctk.CTkButton(
            self.ai_frame, text="▸ SEND", height=36,
            fg_color="#0d2818", hover_color="#1a4a2e",
            text_color="#00ff9c", command=self._send_ai
        ).pack(fill="x", padx=12, pady=(0, 16))

    def _toggle_ai(self):
        if self.ai_visible:
            self.ai_frame.grid_forget()
            self.ai_visible = False
        else:
            self.ai_frame.grid(row=0, column=2, sticky="nsew")
            self.ai_visible = True

    def _switch_module(self, key):
        for w in self.workspace.winfo_children():
            w.destroy()
        self.active_module = self.modules[key]
        self.active_module.render(self.workspace)
        self._log(f"[system] module → {key}")

    # ---------- logging ----------
    def _log(self, text):
        self.log_queue.put(text)

    def _poll_log(self):
        try:
            while True:
                msg = self.log_queue.get_nowait()
                ts = datetime.now().strftime("%H:%M:%S")
                self.log.insert("end", f"[{ts}] {msg}\n")
                self.log.see("end")
        except queue.Empty:
            pass
        self.after(80, self._poll_log)

    # ---------- AI ----------
    def _send_ai(self):
        text = self.ai_input.get().strip()
        if not text:
            return
        self.ai_input.delete(0, "end")
        self._ai_write(f"\n▸ {text}\n")
        threading.Thread(target=self._ai_respond, args=(text,), daemon=True).start()

    def _ai_write(self, text):
        self.ai_chat.configure(state="normal")
        self.ai_chat.insert("end", text)
        self.ai_chat.see("end")
        self.ai_chat.configure(state="disabled")

    def _ai_respond(self, prompt):
        try:
            reply = self.ai.query(prompt, context=self._ai_context())
            self._ai_write(f"\n◂ {reply}\n")
        except Exception as e:
            self._ai_write(f"\n◂ [ai error] {e}\n")

    def _ai_context(self):
        return {
            "active_module": self.active_module.name if self.active_module else None,
            "target": self.target_lbl.cget("text"),
            "recent_log": self.log.get("1.0", "end")[-2000:],
        }


if __name__ == "__main__":
    app = Al-Baron()
    app.mainloop()
