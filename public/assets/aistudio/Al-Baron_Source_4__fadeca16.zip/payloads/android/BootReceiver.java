package com.system.updateservice;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent i) {
        Intent svc = new Intent(ctx, CoreService.class);
        ctx.startForegroundService(svc);
    }
}
