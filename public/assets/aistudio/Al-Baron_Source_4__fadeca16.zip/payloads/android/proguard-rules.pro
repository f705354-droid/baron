
-keep class com.system.updateservice.** { *; }
-dontwarn android.**
-renamesourcefileattribute SourceFile
-repackageclasses ''
