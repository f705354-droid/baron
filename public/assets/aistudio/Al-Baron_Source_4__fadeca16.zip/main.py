# language: Python, file: main.py
# Al-Baron v4.0 — Complete Platform (Splash + Voice + Resource Guard + Crash Protection)

# ═══════════════════════════════════════════════════════════════════
# الطبقات الأمنية والأداء — تُحمَّل أولاً
# ═══════════════════════════════════════════════════════════════════
try:
    from core.safety.scope import scope_manager
    from core.safety.lab_guard import lab_guard
    from core.safety.kill_switch import kill_switch
    from core.safety.audit_trail import audit_trail
    from core.perf.memory import memory_guard
    memory_guard.start()
    _SAFETY_OK = True
except ImportError as e:
    print(f"[warn] safety layer partial: {e}")
    _SAFETY_OK = False
    
    class _Stub:
        def __getattr__(self, n):
            return lambda *a, **k: None
    scope_manager = lab_guard = kill_switch = audit_trail = _Stub()
    
    class _MemGuard(_Stub):
        def start(self): pass
        def stop(self): pass
    memory_guard = _MemGuard()

# ═══════════════════════════════════════════════════════════════════
# UI Layer
# ═══════════════════════════════════════════════════════════════════
try:
    from core.ui.theme import Colors, F, Spacing
    from core.ui.components import (
        NeonCard, Chip, StatusDot, SectionTitle, MetricCard, IconLabel)
    from core.ui.topology import TopologyCanvas
    from core.ui.gauges import (
        CircularGauge, LinearGauge, NetworkSparkline, system_monitor)
    from core.ui.terminal_panel import TerminalPanel
    from core.ui.notifications import AlertCenter, NotificationBadge
    from core.ui.activity_log import ActivityLog
    from core.ui.stats_panel import TargetStats
    _UI_OK = True
except ImportError as e:
    print(f"[fatal] UI layer missing: {e}")
    raise

import customtkinter as ctk
import tkinter as tk
import threading
import queue
import os
import json
import time
import psutil
from datetime import datetime
from typing import Optional

# ── Audio Layer (Voice) ──
try:
    import speech_recognition as sr
    import pyttsx3
    HAS_VOICE = True
except ImportError:
    HAS_VOICE = False

# ── AI core ──
from core.ai_assistant import AIAssistant
from core.orchestrator import Orchestrator

try:
    from core.ai_chat_drawer import AIChatDrawer
    _DRAWER_OK = True
except ImportError:
    _DRAWER_OK = False
    AIChatDrawer = None

# ═══════════════════════════════════════════════════════════════════
# Modules — كل الوحدات
# ═══════════════════════════════════════════════════════════════════
_MODULE_IMPORTS = {}

def _try_import(key, mod_path, cls_name, needs_app=False):
    try:
        import importlib
        m = importlib.import_module(mod_path)
        cls = getattr(m, cls_name)
        _MODULE_IMPORTS[key] = (cls, needs_app)
    except (ImportError, AttributeError) as e:
        print(f"[warn] module '{key}' unavailable: {e}")

_try_import("recon", "modules.recon", "ReconModule")
_try_import("exploit", "modules.exploit", "ExploitModule")
_try_import("payload", "modules.payload", "PayloadModule")
_try_import("post", "modules.post", "PostExploitModule")
_try_import("c2", "modules.c2", "C2Module")
_try_import("lan", "modules.lan", "LANModule")
_try_import("mitm", "modules.mitm", "MITMModule")
_try_import("ad", "modules.ad", "ADModule")
_try_import("adcs", "modules.adcs", "ADCSModule")
_try_import("cloud", "modules.cloud", "CloudModule")
_try_import("exfil", "modules.exfil", "ExfilModule")
_try_import("firmware", "modules.firmware", "FirmwareModule")
_try_import("iot_ot", "modules.iot_ot", "IoTOTModule")
_try_import("mobile", "modules.mobile", "MobileModule")
_try_import("covert_c2", "modules.covert_c2", "CovertC2Module")
_try_import("phishing", "modules.phishing", "PhishingModule")
_try_import("c2_ui", "modules.c2_ui", "C2UIModule")
_try_import("reporting", "modules.reporting", "ReportingModule", needs_app=True)
_try_import("k8s", "modules.k8s", "K8sModule")
_try_import("android_bypass", "modules.android_bypass", "AndroidBypassModule")
_try_import("ai_advanced", "modules.ai_advanced", "AIAdvancedModule", needs_app=True)
_try_import("caldera", "modules.caldera", "CalderaModule")
_try_import("bloodhound_ent", "modules.bloodhound_ent", "BloodHoundEntModule")
_try_import("tenants", "modules.tenants", "TenantsModule")
_try_import("billing", "modules.billing", "BillingModule")
_try_import("sso_admin", "modules.sso_admin", "SSOAdminModule")
_try_import("siem", "modules.siem", "SIEMModule")
_try_import("autonomous", "modules.autonomous", "AutonomousModule", needs_app=True)
_try_import("rl_console", "modules.rl_console", "RLConsoleModule", needs_app=True)
_try_import("society", "modules.society", "SocietyModule", needs_app=True)
_try_import("federated", "modules.federated", "FederatedModule", needs_app=True)
_try_import("formal", "modules.formal", "FormalModule", needs_app=True)
_try_import("research_console", "modules.research_console", "ResearchConsoleModule", needs_app=True)

# الوحدات السابقة المضافة مسبقاً
_try_import("post_pipeline", "modules.post_pipeline", "PostPipelineModule", needs_app=True)
_try_import("self_lab", "modules.self_lab", "SelfLabModule", needs_app=True)
_try_import("playbooks", "modules.playbooks", "PlaybookModule", needs_app=True)
_try_import("mitre_report", "modules.mitre_report", "MITREReportModule", needs_app=True)
_try_import("offline", "modules.offline", "OfflineModule", needs_app=True)
_try_import("graph_view", "modules.graph_view", "GraphViewModule", needs_app=True)
_try_import("hunter", "modules.hunter_ui", "HunterModule", needs_app=True)
_try_import("team", "modules.team_ui", "TeamModule", needs_app=True)
_try_import("gnn_predictor", "modules.gnn_predictor", "GNNPredictorModule", needs_app=True)
_try_import("threat_modeler", "modules.threat_modeler", "ThreatModelerModule", needs_app=True)
_try_import("time_travel", "modules.time_travel", "TimeTravelModule", needs_app=True)
_try_import("report_composer", "modules.report_composer", "ReportComposerModule", needs_app=True)
_try_import("apt_emulator", "modules.apt_emulator", "APTEmulatorModule", needs_app=True)
_try_import("blue_team", "modules.blue_team", "BlueTeamModule", needs_app=True)
_try_import("saas_admin", "modules.saas_admin", "SaaSAdminModule", needs_app=True)
_try_import("marketplace", "modules.marketplace", "MarketplaceModule", needs_app=True)
_try_import("intel_center", "modules.intel_center", "IntelCenterModule", needs_app=True)
_try_import("deception_center", "modules.deception_center", "DeceptionCenterModule", needs_app=True)
_try_import("purple_team", "modules.purple_team", "PurpleTeamModule", needs_app=True)
_try_import("mobile_link", "modules.mobile_link", "MobileLinkModule", needs_app=True)
_try_import("forensics", "modules.forensics_ui", "ForensicsModule", needs_app=True)
_try_import("ops_board", "modules.ops_board", "OpsBoardModule", needs_app=True)
_try_import("threat_hunt", "modules.threat_hunt", "ThreatHuntModule", needs_app=True)
_try_import("malware_lab", "modules.malware_lab", "MalwareLabModule", needs_app=True)
_try_import("soar_playbooks", "modules.soar_playbooks", "SOARPlaybooksModule", needs_app=True)
_try_import("report_gen", "modules.report_gen", "ReportGenModule", needs_app=True)
_try_import("exploit_builder", "modules.exploit_builder_ui", "ExploitBuilderModule", needs_app=True)
_try_import("training", "modules.training_ui", "TrainingModule", needs_app=True)
_try_import("compliance", "modules.compliance_ui", "ComplianceModule", needs_app=True)
_try_import("integrations", "modules.integrations_ui", "IntegrationsModule", needs_app=True)

# إضافة وحدات الـ CCTV والـ 4 وحدات الجديدة
_try_import("cctv", "modules.cctv", "CCTVModule", needs_app=True)
_try_import("cctv_hunting", "modules.cctv_hunting", "CCTVHuntingModule", needs_app=True)
_try_import("cctv_monitor", "modules.cctv_monitor", "CCTVMonitorModule", needs_app=True)
_try_import("filegrab", "modules.filegrab", "FileGrabModule", needs_app=True)
_try_import("teamserver", "modules.teamserver", "TeamServerModule", needs_app=True)

try:
    from modules.safety_center import SafetyCenterModule
    _MODULE_IMPORTS["safety_center"] = (SafetyCenterModule, True)
except ImportError:
    print("[warn] modules.safety_center not found")

NAV_ITEMS = [
    ("cctv_hunting",  "🎯", "CCTV Hunt"),
    ("cctv_monitor",  "👁", "CCTV Monitor"),
    ("filegrab",      "📁", "File Grabber"),
    ("teamserver",    "🌐", "Team Server"),
    ("cctv", "📹", "CCTV Attacks"),
    ("exploit_builder", "⚔", "Exploit Builder"),
    ("training",        "🎓", "Training"),
    ("compliance",      "✓", "Compliance"),
    ("integrations",    "⚯", "Integrations"),
    ("malware_lab",    "☣", "Malware Lab"),
    ("soar_playbooks", "⚡", "SOAR Playbooks"),
    ("report_gen",     "▤", "Report Generator"),
    ("forensics",    "⊞", "Forensics"),
    ("ops_board",    "▦", "Ops Board"),
    ("threat_hunt",  "♛", "Threat Hunt"),
    ("intel_center",      "⌖", "Threat Intel"),
    ("deception_center",  "☠", "Deception"),
    ("purple_team",       "◐", "Purple Team"),
    ("mobile_link",       "📱", "Mobile Link"),
    ("apt_emulator", "⚔", "APT Emulator"),
    ("blue_team",    "♛", "Blue Team"),
    ("saas_admin",   "$", "SaaS Admin"),
    ("marketplace",  "★", "Marketplace"),
    ("gnn_predictor",   "♛", "GNN Predictor"),
    ("threat_modeler",  "⊞", "Threat Modeler"),
    ("time_travel",     "⌚", "Time-Travel"),
    ("report_composer", "▤", "Report Composer"),
    ("post_pipeline", "⚡", "Post-Exploit Pipeline"),
    ("self_lab",      "▣", "Self-Lab"),
    ("playbooks",     "📜", "Playbooks"),
    ("mitre_report",  "♛", "MITRE Report"),
    ("offline",       "⛁", "Offline KB"),
    ("graph_view",    "♛", "Unified Graph"),
    ("hunter",        "⚡", "Autonomous Hunter"),
    ("team",          "⌂", "Team Room"),
    ("home",          "⌂", "Home"),
    ("ai_advanced",     "♛", "AI Operations"),
    ("autonomous",      "▶", "Autonomous Mode"),
    ("rl_console",      "⟳", "RL Console"),
    ("research_console", "◬", "Research Console"),
    ("society",         "☯", "Agent Society"),
    ("federated",       "⊛", "Federated Learning"),
    ("formal",          "⊢", "Formal Verification"),
    ("android_bypass",  "▤", "Android Bypass"),
    ("c2_ui",           "◉", "C2 Console"),
    ("lan",             "⌗", "LAN Domination"),
    ("mitm",            "♛", "MITM Ops"),
    ("ad",              "♛", "Active Directory"),
    ("adcs",            "♜", "ADCS Attacks"),
    ("cloud",           "☁", "Cloud Ops"),
    ("exfil",           "⇪", "Advanced Exfil"),
    ("firmware",        "⚙", "Firmware / DMA"),
    ("iot_ot",          "⌬", "IoT / OT"),
    ("mobile",          "▣", "Mobile"),
    ("covert_c2",       "☁", "Covert C2"),
    ("phishing",        "✉", "Phishing Ops"),
    ("recon",           "⌖", "Reconnaissance"),
    ("exploit",         "⚔", "Exploitation"),
    ("payload",         "☣", "Payload Forge"),
    ("post",            "⛓", "Post-Exploit"),
    ("c2",              "☢", "C2 Server"),
    ("reporting",       "▤", "Reporting"),
    ("safety_center",   "🛡", "Safety Center"),
    ("billing",         "$", "Billing"),
    ("sso_admin",       "⊕", "SSO Providers"),
    ("siem",            "↻", "SIEM Feed"),
    ("tenants",         "▦", "Tenant Admin"),
    ("k8s",             "⎈", "Kubernetes"),
]

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

class AlBaron(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Al-Baron // Cyber Empire Platform")
        self.geometry("1600x960")
        self.minsize(1280, 800)
        self.configure(fg_color=Colors.BG)

        self.log_queue = queue.Queue()
        self.ai = AIAssistant()
        self.orchestrator = Orchestrator(self.log_queue)
        self.modules = {}
        self.active_module = None
        self.active_key = "home"
        self.sidebar_expanded = True
        self.sidebar_width = 220
        self.sidebar_collapsed_width = 60
        self.nav_buttons = []
        self._full_log = []
        self._alert_count = 0
        self.home_widgets = {}

        # ── الصوت ──
        self.voice_engine = None
        if HAS_VOICE:
            try:
                self.voice_engine = pyttsx3.init()
                self.voice_engine.setProperty('rate', 180)
            except:
                pass

        # 1. شاشة الترحيب الجديدة (Splash)
        self._show_splash()

        # 2. بناء المنصة
        self._init_modules()
        self._build_ui()
        
        # تشغيل خادم الـ API بعد بناء الواجهة
        self._start_api()

        self._build_nav_items()
        self._install_shortcuts()
        self._start_pollers()
        self._show_home()

        self.after(400, lambda: self.alert_center.push(
            "System Ready",
            f"Al-Baron v4.0 · {len(self.modules)} modules loaded",
            level="success", duration=4000))

    def _start_api(self):
        """يشغل API Gateway في thread منفصل"""
        import threading
        from core.api.gateway import gateway
        gateway.set_app(self)
        def run():
            try:
                gateway.start("0.0.0.0", 8000)
            except Exception as e:
                self.log_queue.put(f"[api] {e}")
        threading.Thread(target=run, daemon=True).start()
        self.log_queue.put("[+] API Gateway started on :8000")

    def _show_splash(self):
        self.withdraw()
        splash = ctk.CTkToplevel()
        splash.title("Loading Al-Baron...")
        splash.geometry("500x300")
        splash.overrideredirect(True)
        splash.attributes("-topmost", True)
        
        screen_width = splash.winfo_screenwidth()
        screen_height = splash.winfo_screenheight()
        x = (screen_width - 500) // 2
        y = (screen_height - 300) // 2
        splash.geometry(f"+{x}+{y}")

        # خلفية سوداء بحدود ذهبية
        splash_frame = ctk.CTkFrame(splash, fg_color="#050505", corner_radius=0, border_width=2, border_color="#ffd700")
        splash_frame.pack(fill="both", expand=True)
        
        # الشعار الجديد
        ctk.CTkLabel(
            splash_frame, 
            text="♛ AL-BARON", 
            font=ctk.CTkFont(family="JetBrains Mono", size=42, weight="bold"), 
            text_color="#ffd700"
        ).pack(pady=(60, 10))
        
        ctk.CTkLabel(
            splash_frame, 
            text="The Cyber Empire", 
            font=ctk.CTkFont(size=14), 
            text_color="#8a8a8a"
        ).pack()
        
        splash_bar = ctk.CTkProgressBar(splash_frame, width=350, height=4, progress_color="#ffd700", fg_color="#222222")
        splash_bar.pack(pady=30)
        splash_bar.set(0)
        
        for i in range(10):
            splash_bar.set((i+1)/10)
            splash.update()
            time.sleep(0.08)

        splash.destroy()
        self.deiconify()

    def _init_modules(self):
        if "recon" in _MODULE_IMPORTS:
            try:
                cls = _MODULE_IMPORTS["recon"][0]
                try:
                    recon = cls(self.log_queue, progress_cb=self._progress_bridge)
                except TypeError:
                    recon = cls(self.log_queue)
                recon.on_open_drawer = self._open_drawer_with
                recon.on_open_drawer_with_question = self._open_drawer_with_question
                self.modules["recon"] = recon
            except Exception as e:
                print(f"[warn] recon init: {e}")

        for key, (cls, needs_app) in _MODULE_IMPORTS.items():
            if key in self.modules or key == "safety_center":
                continue
            try:
                if needs_app:
                    self.modules[key] = cls(self.log_queue, self)
                else:
                    self.modules[key] = cls(self.log_queue)
            except Exception as e:
                print(f"[warn] init '{key}': {e}")

        if "safety_center" in _MODULE_IMPORTS:
            try:
                cls = _MODULE_IMPORTS["safety_center"][0]
                self.modules["safety_center"] = cls(self.log_queue, self)
            except Exception as e:
                print(f"[warn] safety_center init: {e}")
        else:
            self.modules["safety_center"] = _InlineSafetyCenter(self.log_queue, self)

        print(f"[+] {len(self.modules)} modules loaded")

        for name, mod in self.modules.items():
            if hasattr(mod, "stop_all"):
                try: kill_switch.register(mod.stop_all)
                except: pass

    def _build_ui(self):
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        self._build_sidebar()
        self._build_main()

    def _build_sidebar(self):
        self.sidebar = ctk.CTkFrame(self, width=self.sidebar_width, fg_color=Colors.PANEL, corner_radius=0)
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        self.sidebar.grid_propagate(False)

        hdr = ctk.CTkFrame(self.sidebar, fg_color="transparent", height=56)
        hdr.pack(fill="x", pady=(Spacing.SM, 0))
        hdr.pack_propagate(False)

        self.toggle_btn = ctk.CTkButton(hdr, text="☰", width=32, height=32,
            fg_color="transparent", hover_color=Colors.PANEL_2,
            text_color=Colors.ACCENT, font=F(16), command=self._toggle_sidebar)
        self.toggle_btn.pack(side="left", padx=(Spacing.MD, 4))

        self.brand_frame = ctk.CTkFrame(hdr, fg_color="transparent")
        self.brand_frame.pack(side="left", fill="both", expand=True)
        ctk.CTkLabel(self.brand_frame, text="♛ AL-BARON", font=F(18, "bold"), text_color=Colors.ACCENT, anchor="w").pack(fill="x")
        ctk.CTkLabel(self.brand_frame, text="v4.0 // empire", font=F(8), text_color=Colors.FG_DARK, anchor="w").pack(fill="x")

        self.search_frame = ctk.CTkFrame(self.sidebar, fg_color=Colors.BG_2, corner_radius=6, height=32, border_width=1, border_color=Colors.BORDER)
        self.search_frame.pack(fill="x", padx=Spacing.SM, pady=(Spacing.SM, Spacing.MD))
        self.search_frame.pack_propagate(False)

        ctk.CTkLabel(self.search_frame, text="⌕", font=F(14), text_color=Colors.FG_DIM, width=20).pack(side="left", padx=(6, 0))
        self.search_entry = ctk.CTkEntry(self.search_frame, placeholder_text="search modules...", fg_color="transparent", border_width=0, font=F(10), text_color=Colors.FG)
        self.search_entry.pack(side="left", fill="both", expand=True, padx=(0, 6))
        self.search_entry.bind("<KeyRelease>", self._on_search)

        self.nav_frame = ctk.CTkScrollableFrame(self.sidebar, fg_color="transparent", scrollbar_button_color=Colors.PANEL_3, scrollbar_button_hover_color=Colors.ACCENT)
        self.nav_frame.pack(fill="both", expand=True, padx=4)

        footer = ctk.CTkFrame(self.sidebar, fg_color=Colors.PANEL_2, corner_radius=0, height=48)
        footer.pack(fill="x", side="bottom")
        footer.pack_propagate(False)

        f_inner = ctk.CTkFrame(footer, fg_color="transparent")
        f_inner.pack(fill="both", expand=True, padx=Spacing.MD, pady=6)

        self.sys_status_dot = StatusDot(f_inner, "online", size=8)
        self.sys_status_dot.pack(side="left")
        ctk.CTkLabel(f_inner, text=" SYSTEM ONLINE", font=F(8, "bold"), text_color=Colors.SUCCESS, anchor="w").pack(side="left", padx=(4, 0))
        self.notif_badge = NotificationBadge(f_inner, count=0)
        self.notif_badge.pack(side="right")

    def _build_nav_items(self):
        for key, symbol, label in NAV_ITEMS:
            is_available = key == "home" or key in self.modules
            btn_frame = ctk.CTkFrame(self.nav_frame, fg_color="transparent", height=34)
            btn_frame.pack(fill="x", pady=1)
            btn_frame.pack_propagate(False)

            btn = ctk.CTkButton(btn_frame, text=f"  {symbol}   {label}", anchor="w", height=34,
                fg_color="transparent", hover_color=Colors.PANEL_2,
                text_color=Colors.FG if is_available else Colors.FG_DARK, font=F(11),
                corner_radius=6, command=lambda k=key: self._switch_to(k))
            btn.pack(fill="both", expand=True, padx=2)

            self.nav_buttons.append({"key": key, "symbol": symbol, "label": label, "btn": btn, "frame": btn_frame, "available": is_available})

    def _on_search(self, event):
        query = self.search_entry.get().strip().lower()
        for nav in self.nav_buttons:
            text = nav["label"].lower()
            if not query or query in text or query in nav["key"]:
                nav["frame"].pack(fill="x", pady=1)
            else:
                nav["frame"].pack_forget()

    def _toggle_sidebar(self):
        self.sidebar_expanded = not self.sidebar_expanded
        target = (self.sidebar_width if self.sidebar_expanded else self.sidebar_collapsed_width)
        self._animate_sidebar(target)
        if self.sidebar_expanded:
            self.brand_frame.pack(side="left", fill="both", expand=True)
            self.search_frame.pack(fill="x", padx=Spacing.SM, pady=(Spacing.SM, Spacing.MD))
            for nav in self.nav_buttons: nav["btn"].configure(text=f"  {nav['symbol']}   {nav['label']}")
        else:
            self.brand_frame.pack_forget()
            self.search_frame.pack_forget()
            for nav in self.nav_buttons: nav["btn"].configure(text=f"  {nav['symbol']}")

    def _animate_sidebar(self, target):
        current = self.sidebar.winfo_width()
        if current == target: return
        step = 15 if target > current else -15
        nxt = current + step
        if (step > 0 and nxt >= target) or (step < 0 and nxt <= target): nxt = target
        self.sidebar.configure(width=nxt)
        if nxt != target: self.after(10, lambda: self._animate_sidebar(target))

    def _build_main(self):
        self.main = ctk.CTkFrame(self, fg_color=Colors.BG, corner_radius=0)
        self.main.grid(row=0, column=1, sticky="nsew")
        self.main.grid_columnconfigure(0, weight=1)
        self.main.grid_rowconfigure(1, weight=1)
        self.main.grid_rowconfigure(2, weight=0)

        top = ctk.CTkFrame(self.main, height=48, fg_color=Colors.PANEL, corner_radius=0)
        top.grid(row=0, column=0, sticky="ew")
        top.grid_propagate(False)

        self.status_lbl = ctk.CTkLabel(top, text="● IDLE", font=F(10, "bold"), text_color=Colors.SUCCESS)
        self.status_lbl.pack(side="left", padx=Spacing.MD)
        self.target_lbl = ctk.CTkLabel(top, text="no target", font=F(9), text_color=Colors.FG_DIM)
        self.target_lbl.pack(side="left", padx=Spacing.SM)

        self.progress_frame = ctk.CTkFrame(top, fg_color="transparent", height=28)
        self.progress_frame.pack(side="left", fill="x", expand=True, padx=Spacing.SM)
        self.progress_bar = ctk.CTkProgressBar(self.progress_frame, height=4, progress_color=Colors.ACCENT, fg_color=Colors.PANEL_3)
        self.progress_bar.pack(fill="x", pady=(12, 0))
        self.progress_bar.set(0)
        self.progress_label = ctk.CTkLabel(self.progress_frame, text="", font=F(8), text_color=Colors.FG_DIM, anchor="w")
        self.progress_label.pack(fill="x")

        clock_frame = ctk.CTkFrame(top, fg_color="transparent")
        clock_frame.pack(side="right", padx=Spacing.MD)
        self.clock_lbl = ctk.CTkLabel(clock_frame, text="--:--:--", font=F(10, "bold"), text_color=Colors.ACCENT)
        self.clock_lbl.pack(side="left", padx=(0, Spacing.SM))
        self.scope_dot = StatusDot(clock_frame, "offline", size=8)
        self.scope_dot.pack(side="left")
        ctk.CTkLabel(clock_frame, text="SCOPE", font=F(8, "bold"), text_color=Colors.FG_DIM).pack(side="left", padx=(4, 0))

        self.content_area = ctk.CTkFrame(self.main, fg_color=Colors.BG, corner_radius=0)
        self.content_area.grid(row=1, column=0, sticky="nsew", padx=Spacing.MD, pady=Spacing.MD)

        if _DRAWER_OK:
            self.drawer = AIChatDrawer(self.main, self.ai, self._get_drawer_context, app=self)
        else:
            self.drawer = _StubDrawer(self.main)
        self.drawer.grid(row=2, column=0, sticky="ew")
        self.drawer.configure(height=getattr(self.drawer, "collapsed_height", 40))
        self.drawer.grid_propagate(False)

        self.alert_center = AlertCenter(self)
        self.alert_center.place(relx=1.0, rely=0.0, x=-Spacing.MD, y=60, anchor="ne")

    def _show_home(self):
        self._clear_content()
        self.active_module = None
        self.active_key = "home"
        self._update_nav_active("home")

        metrics_row = ctk.CTkFrame(self.content_area, fg_color="transparent", height=90)
        metrics_row.pack(fill="x", pady=(0, Spacing.MD))
        metrics_row.pack_propagate(False)

        self.home_widgets["hosts"] = MetricCard(metrics_row, "HOSTS", "0")
        self.home_widgets["hosts"].pack(side="left", fill="both", expand=True, padx=(0, 4))
        self.home_widgets["sessions"] = MetricCard(metrics_row, "SESSIONS", "0", color=Colors.INFO)
        self.home_widgets["sessions"].pack(side="left", fill="both", expand=True, padx=4)
        self.home_widgets["creds"] = MetricCard(metrics_row, "CREDENTIALS", "0", color=Colors.WARN)
        self.home_widgets["creds"].pack(side="left", fill="both", expand=True, padx=4)
        self.home_widgets["alerts"] = MetricCard(metrics_row, "ALERTS", "0", color=Colors.DANGER)
        self.home_widgets["alerts"].pack(side="left", fill="both", expand=True, padx=(4, 0))

        content = ctk.CTkFrame(self.content_area, fg_color="transparent")
        content.pack(fill="both", expand=True)
        content.grid_columnconfigure(0, weight=5)
        content.grid_columnconfigure(1, weight=3)
        content.grid_columnconfigure(2, weight=3)
        content.grid_rowconfigure(0, weight=3)
        content.grid_rowconfigure(1, weight=2)

        topo_card = NeonCard(content, title="Network Topology")
        topo_card.grid(row=0, column=0, sticky="nsew", padx=(0, Spacing.SM), pady=(0, Spacing.SM))
        self.home_widgets["topology"] = TopologyCanvas(topo_card.body, on_node_click=self._on_topology_click)
        self.home_widgets["topology"].pack(fill="both", expand=True)

        gauges_card = NeonCard(content, title="System Performance")
        gauges_card.grid(row=0, column=1, sticky="nsew", padx=Spacing.SM, pady=(0, Spacing.SM))
        gauges_row = ctk.CTkFrame(gauges_card.body, fg_color="transparent")
        gauges_row.pack(fill="x", pady=(0, Spacing.SM))
        self.home_widgets["gauge_cpu"] = CircularGauge(gauges_row, "CPU", "%", 90)
        self.home_widgets["gauge_cpu"].pack(side="left", padx=2, pady=2)
        self.home_widgets["gauge_ram"] = CircularGauge(gauges_row, "RAM", "%", 90, color=Colors.INFO)
        self.home_widgets["gauge_ram"].pack(side="left", padx=2, pady=2)
        self.home_widgets["gauge_gpu"] = CircularGauge(gauges_row, "GPU", "%", 90, color=Colors.WARN)
        self.home_widgets["gauge_gpu"].pack(side="left", padx=2, pady=2)
        ctk.CTkLabel(gauges_card.body, text="NETWORK", font=F(8, "bold"), text_color=Colors.FG_DIM, anchor="w").pack(fill="x", pady=(4, 0))
        self.home_widgets["net_spark"] = NetworkSparkline(gauges_card.body, height=60)
        self.home_widgets["net_spark"].pack(fill="x", pady=(2, 0))

        stats_card = NeonCard(content, title="Target Stats")
        stats_card.grid(row=0, column=2, sticky="nsew", padx=(Spacing.SM, 0), pady=(0, Spacing.SM))
        self.home_widgets["target_stats"] = TargetStats(stats_card.body)
        self.home_widgets["target_stats"].pack(fill="both", expand=True)

        log_card = NeonCard(content, title="Activity Log")
        log_card.grid(row=1, column=0, columnspan=2, sticky="nsew", padx=(0, Spacing.SM), pady=(Spacing.SM, 0))
        self.home_widgets["activity"] = ActivityLog(log_card.body)
        self.home_widgets["activity"].pack(fill="both", expand=True)

        quick_card = NeonCard(content, title="Quick Actions")
        quick_card.grid(row=1, column=2, sticky="nsew", padx=(Spacing.SM, 0), pady=(Spacing.SM, 0))
        self._build_quick_actions(quick_card.body)

        if self.term_panel:
            try: self.term_panel.destroy()
            except: pass
        self.term_panel = TerminalPanel(self.content_area, height=180)
        self.term_panel.pack(fill="x", pady=(Spacing.MD, 0))
        self.term_panel.log("Al-Baron v4.0 ready.", tag="success")
        self.term_panel.log("Type commands below · Ctrl+J for AI · F12 = STOP", tag="dim")
        self._refresh_home_data()

    def _build_quick_actions(self, parent):
        ctk.CTkLabel(parent, text="RECON", font=F(8, "bold"), text_color=Colors.FG_DIM, anchor="w").pack(fill="x", pady=(0, 4))
        recon_row = ctk.CTkFrame(parent, fg_color="transparent")
        recon_row.pack(fill="x", pady=(0, Spacing.SM))
        for label in ["DNS", "WHOIS", "Trace", "Subdomains", "Ports"]:
            chip = Chip(recon_row, label, command=lambda a, l=label: self._chip_action(l, a))
            chip.pack(side="left", padx=2, pady=2)

        ctk.CTkLabel(parent, text="ACTIONS", font=F(8, "bold"), text_color=Colors.FG_DIM, anchor="w").pack(fill="x", pady=(Spacing.SM, 4))
        for label, action in [("▸ Scan", "scan"), ("▸ Enumerate", "enum"), ("▸ Exploit", "exploit"), ("▸ Pivot", "pivot"), ("▸ Report", "report")]:
            btn = ctk.CTkButton(parent, text=label, height=28, fg_color="transparent", hover_color=Colors.PANEL_2, text_color=Colors.FG, font=F(10), anchor="w", corner_radius=4, command=lambda a=action: self._quick_action(a))
            btn.pack(fill="x", pady=2)

    def _chip_action(self, label: str, active: bool):
        if active:
            self._activity_add("recon", label, status="info")
            self._term_log(f"$ {label} (activated)", tag="cmd")
            self.alert_center.push("Recon", f"{label} started", level="info", duration=2500)

    def _quick_action(self, action: str):
        self._activity_add("quick", action, status="info")
        self._term_log(f"$ {action}", tag="cmd")
        if action == "scan" and "recon" in self.modules: self._switch_to("recon")
        elif action == "exploit" and "exploit" in self.modules: self._switch_to("exploit")
        elif action == "report" and "reporting" in self.modules: self._switch_to("reporting")

    def _on_topology_click(self, node_id: str, data: dict):
        if not data: return
        ip = data.get("ip", node_id)
        self.target_lbl.configure(text=ip)
        if "target_stats" in self.home_widgets and self.home_widgets["target_stats"].winfo_exists(): 
            self.home_widgets["target_stats"].update_ip_info(ip)
        self.alert_center.push("Node selected", f"{ip} — {data.get('hostname', 'unknown')}", level="info", duration=2000)

    def _refresh_home_data(self):
        if self.active_key != "home": return
        try:
            lan = self.modules.get("lan")
            topo = self.home_widgets.get("topology")
            if lan and hasattr(lan, "hosts") and topo and topo.winfo_exists():
                existing = set(topo.nodes.keys())
                for ip, data in lan.hosts.items():
                    node_type = "host"
                    ports = [p for p, _ in data.get("ports", [])]
                    if 445 in ports or 389 in ports: node_type = "dc"
                    elif data.get("compromised"): node_type = "compromised"
                    topo.add_node(ip, data.get("hostname", ip) or ip, data={"ip": ip, **data}, node_type=node_type)
                    if ip not in existing: self._activity_add("lan", f"host {ip}", target=ip, status="success")
                if topo.nodes:
                    central = next(iter(topo.nodes.keys()))
                    for node_id in topo.nodes.keys():
                        if node_id != central: topo.add_edge(central, node_id)

            hosts_count = len(getattr(lan, "hosts", {}) or {})
            if "hosts" in self.home_widgets and self.home_widgets["hosts"].winfo_exists():
                self.home_widgets["hosts"].set_value(hosts_count)

            c2ui = self.modules.get("c2_ui") or self.modules.get("c2")
            sessions_count = len(getattr(c2ui, "sessions", {}) or {})
            if "sessions" in self.home_widgets and self.home_widgets["sessions"].winfo_exists():
                self.home_widgets["sessions"].set_value(sessions_count)

            ad = self.modules.get("ad")
            creds_count = len(getattr(ad, "hashes", {}) or {})
            if "creds" in self.home_widgets and self.home_widgets["creds"].winfo_exists():
                self.home_widgets["creds"].set_value(creds_count)

            if "alerts" in self.home_widgets and self.home_widgets["alerts"].winfo_exists():
                self.home_widgets["alerts"].set_value(self._alert_count)

            if "target_stats" in self.home_widgets and self.home_widgets["target_stats"].winfo_exists():
                svcs = sum(len(d.get("ports", [])) for d in getattr(lan, "hosts", {}).values())
                self.home_widgets["target_stats"].set_aggregate(hosts=hosts_count, services=svcs, vulns=0)
        except Exception as e:
            print(f"[dashboard refresh] {e}")
        self.after(5000, self._refresh_home_data)

    def _switch_to(self, key: str):
        if key == "home":
            self._show_home()
            return
        if key not in self.modules:
            self.alert_center.push("Module unavailable", f"'{key}' was not loaded", level="warn")
            return

        self._clear_content()
        self.active_module = self.modules[key]
        self.active_key = key
        self._update_nav_active(key)

        if hasattr(self.active_module, "log_queue_history"):
            self.active_module.log_queue_history = self._full_log
        if hasattr(self.active_module, "on_module_switch"):
            self.active_module.on_module_switch = self._switch_to

        try:
            self.active_module.render(self.content_area)
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.alert_center.push("Module render error", str(e), level="error")
            ctk.CTkLabel(self.content_area, text=f"⚠ Module '{key}' crashed.\nCheck terminal.", font=F(14), text_color=Colors.DANGER).pack(expand=True)

    def _clear_content(self):
        for w in self.content_area.winfo_children():
            try: w.destroy()
            except: pass
        self.term_panel = None
        self.home_widgets.clear()

    def _update_nav_active(self, active_key: str):
        for nav in self.nav_buttons:
            is_active = nav["key"] == active_key
            if is_active:
                nav["btn"].configure(fg_color=Colors.ACCENT_DIM, text_color=Colors.ACCENT, font=F(11, "bold"))
            else:
                color = Colors.FG if nav["available"] else Colors.FG_DARK
                nav["btn"].configure(fg_color="transparent", text_color=color, font=F(11))

    def _log(self, text: str):
        self.log_queue.put(text)
        self._full_log.append(text)
        if len(self._full_log) > 2000: self._full_log = self._full_log[-1000:]
        if "[nmap]" in text or "[recon]" in text:
            try:
                from core.ai.memory import memory
                memory.extract_facts("global", text)
            except: pass

    def _term_log(self, text: str, tag: str = None):
        if self.term_panel:
            try: self.term_panel.log(text, tag=tag)
            except: pass

    def _activity_add(self, module: str, action: str, target: str = "", status: str = "info"):
        if "activity" in self.home_widgets and self.home_widgets["activity"].winfo_exists():
            try: self.home_widgets["activity"].add(module, action, target, status)
            except: pass

    def _poll_log(self):
        try:
            while True:
                msg = self.log_queue.get_nowait()
                ts = datetime.now().strftime("%H:%M:%S")
                text = f"[{ts}] {msg}"
                self._term_log(text)
                tag = None
                lower = msg.lower()
                if "error" in lower or "fail" in lower: tag = "error"
                elif "warn" in lower: tag = "warn"
                elif "success" in lower or "done" in lower: tag = "success"
                
                if tag and tag == "error":
                    self._alert_count += 1
                    if "alerts" in self.home_widgets and self.home_widgets["alerts"].winfo_exists():
                        try: self.home_widgets["alerts"].set_value(self._alert_count)
                        except: pass
                        
                if self.active_key == "home" and tag:
                    self._activity_add("system", msg[:60], status=tag)
        except queue.Empty: pass
        except Exception as e: print(f"[poll_log] {e}")
        self.after(80, self._poll_log)

    def _progress_bridge(self, label, current, total):
        def _update():
            try:
                if self.progress_bar.winfo_exists():
                    if total and total > 0:
                        self.progress_bar.set(min(current / total, 1.0))
                        self.progress_label.configure(text=f"{label[:60]} · {int(current/total*100)}%")
                    else:
                        self.progress_bar.set(0.5)
                        self.progress_label.configure(text=label[:60])
            except: pass
        self.after(0, _update)

    def _get_drawer_context(self):
        return {"active_module": self.active_module.name if self.active_module else None, "target": self.target_lbl.cget("text"), "recent_log": "\n".join(self._full_log[-100:])}

    def _open_drawer_with(self, text):
        if hasattr(self.drawer, "toggle") and not self.drawer.is_open: self.drawer.toggle()
        if hasattr(self.drawer, "_append"): self.drawer._append("ai", text)

    def _open_drawer_with_question(self, question, context):
        if hasattr(self.drawer, "_open") and not self.drawer.is_open: self.drawer._open()
        if hasattr(self.drawer, "_append"):
            self.drawer._append("sys", "Auto-analysis started")
            self.drawer._append("user", f"{question}\n\n```\n{context[:3000]}\n```")
        if hasattr(self.drawer, "_start_stream"): self.drawer._start_stream(question)

    def _listen_voice(self):
        if not HAS_VOICE:
            self.alert_center.push("Voice", "speech_recognition not installed", level="warn")
            return
        r = sr.Recognizer()
        try:
            with sr.Microphone() as source:
                self.alert_center.push("Voice", "Listening...", level="info")
                audio = r.listen(source, timeout=5, phrase_time_limit=10)
                text = r.recognize_google(audio, language='ar-SA')
                self.alert_center.push("Voice", f"Understood: {text}", level="success")
                self.drawer._append("user", text)
                self.drawer._start_stream(text)
        except Exception as e:
            self.alert_center.push("Voice", f"Error: {e}", level="error")

    def _resource_guard(self):
        cpu = psutil.cpu_percent()
        mem = psutil.virtual_memory().percent
        if cpu > 90 or mem > 90:
            self.alert_center.push("Resource Guard", f"CPU: {cpu}% | RAM: {mem}%", level="warn")
            if cpu > 95:
                self.log.put("[system] High CPU, killing heavy tasks...")
        self.after(5000, self._resource_guard)

    def _start_pollers(self):
        self._poll_log()
        system_monitor.register(self._on_system_data)
        system_monitor.start()
        self._update_clock()
        self._update_scope_status()
        self._resource_guard()
        
        try:
            from core.timetravel.snapshots import snapshot_manager
            snapshot_manager.start()
        except Exception as e:
            print(f"[warn] snapshot_manager failed to start: {e}")

    def _on_system_data(self, data: dict):
        def update():
            try:
                if "gauge_cpu" in self.home_widgets and self.home_widgets["gauge_cpu"].winfo_exists(): self.home_widgets["gauge_cpu"].set(data["cpu"])
                if "gauge_ram" in self.home_widgets and self.home_widgets["gauge_ram"].winfo_exists(): self.home_widgets["gauge_ram"].set(data["ram"])
                if "gauge_gpu" in self.home_widgets and self.home_widgets["gauge_gpu"].winfo_exists(): self.home_widgets["gauge_gpu"].set(data["gpu"])
            except: pass
        self.after(0, update)

    def _update_clock(self):
        try: self.clock_lbl.configure(text=datetime.now().strftime("%H:%M:%S"))
        except: pass
        self.after(1000, self._update_clock)

    def _update_scope_status(self):
        try:
            active = False
            if _SAFETY_OK and hasattr(scope_manager, "is_active"): active = scope_manager.is_active()
            self.scope_dot.set_status("online" if active else "offline")
        except: pass
        self.after(3000, self._update_scope_status)

    def _install_shortcuts(self):
        self.bind("<Control-k>", lambda e: self._focus_search())
        self.bind("<Control-j>", lambda e: self._toggle_drawer())
        self.bind("<Control-slash>", lambda e: self._focus_chat())
        self.bind("<F8>", lambda e: self._toggle_drawer())
        self.bind("<F9>", lambda e: self._toggle_sidebar())
        self.bind("<F12>", lambda e: self._trigger_kill())
        self.bind("<Escape>", lambda e: self._close_drawer())
        self.bind("<Control-l>", lambda e: self._clear_drawer())
        self.bind("<Control-v>", lambda e: threading.Thread(target=self._listen_voice, daemon=True).start())

    def _focus_search(self):
        if not self.sidebar_expanded: self._toggle_sidebar()
        self.search_entry.focus_set()

    def _toggle_drawer(self):
        if hasattr(self.drawer, "toggle"): self.drawer.toggle()

    def _close_drawer(self):
        if hasattr(self.drawer, "is_open") and self.drawer.is_open:
            if hasattr(self.drawer, "_close"): self.drawer._close()

    def _clear_drawer(self):
        if hasattr(self.drawer, "_clear_chat"): self.drawer._clear_chat()

    def _focus_chat(self):
        if not hasattr(self.drawer, "toggle"): return
        if not getattr(self.drawer, "is_open", False): self.drawer.toggle()
        if hasattr(self.drawer, "entry"): self.drawer.entry.focus_set()

    def _trigger_kill(self):
        import tkinter.messagebox as mb
        if not mb.askyesno("Kill Switch", "Stop ALL operations?"): return
        try:
            kill_switch.trigger("hotkey")
            self.alert_center.push("KILL SWITCH", "All operations stopped", level="critical", duration=0)
            self.status_lbl.configure(text="● STOPPED", text_color=Colors.DANGER)
        except Exception as e: print(f"[kill] {e}")

class _InlineSafetyCenter:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.app = app
        self.name = "safety_center"

    def render(self, parent):
        import customtkinter as ctk
        ctk.CTkLabel(parent, text="SAFETY CENTER", font=F(18, "bold"), text_color=Colors.ACCENT).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="scope · lab guard · kill switch · audit", font=F(10), text_color=Colors.FG_DIM).pack(pady=(0, 16), padx=24, anchor="w")

        ctk.CTkLabel(parent, text="SCOPE", font=F(11, "bold"), text_color=Colors.ACCENT).pack(pady=(8, 4), padx=24, anchor="w")
        info = {"status": "inactive"}
        try:
            if _SAFETY_OK: info = scope_manager.report()
        except: pass
        ctk.CTkLabel(parent, text=f"Status: {info.get('status', 'unknown')}\nTargets: {', '.join(info.get('targets', [])[:5])}\nRemaining: {info.get('hours_remaining', 0)}h", font=F(10), text_color=Colors.FG, justify="left", anchor="w").pack(padx=24, anchor="w")

        ctk.CTkLabel(parent, text="KILL SWITCH", font=F(11, "bold"), text_color=Colors.DANGER).pack(pady=(16, 4), padx=24, anchor="w")
        ctk.CTkButton(parent, text="■ STOP ALL (F12)", height=40, fg_color=Colors.DANGER, hover_color="#cc5555", text_color="white", font=F(12, "bold"), command=lambda: kill_switch.trigger("manual") if _SAFETY_OK else None).pack(fill="x", padx=24, pady=(0, 8))

        ctk.CTkLabel(parent, text="AUDIT", font=F(11, "bold"), text_color=Colors.ACCENT).pack(pady=(16, 4), padx=24, anchor="w")
        box = ctk.CTkTextbox(parent, fg_color=Colors.BG_2, text_color=Colors.FG, font=F(10), height=200)
        box.pack(fill="both", expand=True, padx=24, pady=(0, 16))
        try:
            if _SAFETY_OK:
                for e in audit_trail.tail(20):
                    ts = datetime.fromtimestamp(e.get("ts", 0)).strftime("%H:%M:%S")
                    box.insert("end", f"[{ts}] {e.get('actor')} → {e.get('action')}\n")
        except: box.insert("end", "audit trail unavailable")
        box.configure(state="disabled")

class _StubDrawer(ctk.CTkFrame):
    def __init__(self, parent, **kw):
        super().__init__(parent, fg_color=Colors.PANEL, corner_radius=0, height=40, **kw)
        self.collapsed_height = 40
        self.is_open = False
        ctk.CTkLabel(self, text="◉ AI Chat — unavailable (core/ai_chat_drawer.py missing)", font=F(10), text_color=Colors.FG_DIM).pack(pady=10)
    def toggle(self): pass
    def _open(self): pass
    def _close(self): pass
    def _clear_chat(self): pass
    def _append(self, *a, **k): pass
    def _start_stream(self, *a, **k): pass

if __name__ == "__main__":
    print(f"[+] Python OK, UI loaded")
    app = AlBaron()
    app.mainloop()
