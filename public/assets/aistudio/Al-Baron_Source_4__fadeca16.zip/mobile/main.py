# language: Python, file: mobile/main.py
# Kivy mobile app for Al-Baron
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.clock import Clock
import requests
import threading


class MobileApp(App):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.base_url = ""
        self.token = ""
        self.stats = {}

    def build(self):
        self.layout = BoxLayout(orientation="vertical", padding=20, spacing=10)

        # login
        self.url_input = TextInput(hint_text="server URL",
                                     text="http://192.168.1.210:8443",
                                     multiline=False, size_hint=(1, None),
                                     height=50)
        self.layout.add_widget(self.url_input)

        self.user_input = TextInput(hint_text="username",
                                      multiline=False, size_hint=(1, None),
                                      height=50)
        self.layout.add_widget(self.user_input)

        self.pass_input = TextInput(hint_text="password",
                                      password=True, multiline=False,
                                      size_hint=(1, None), height=50)
        self.layout.add_widget(self.pass_input)

        self.login_btn = Button(text="Login", size_hint=(1, None),
                                  height=50)
        self.login_btn.bind(on_press=self.login)
        self.layout.add_widget(self.login_btn)

        self.status = Label(text="not connected",
                             size_hint=(1, None), height=50)
        self.layout.add_widget(self.status)

        self.stats_label = Label(text="",
                                   size_hint=(1, None), height=200,
                                   halign="left")
        self.layout.add_widget(self.stats_label)

        # actions
        kill_btn = Button(text="🔴 KILL SWITCH",
                            size_hint=(1, None), height=60,
                            background_color=(0.8, 0.2, 0.2, 1))
        kill_btn.bind(on_press=self.kill_switch)
        self.layout.add_widget(kill_btn)

        return self.layout

    def login(self, *args):
        def do_login():
            try:
                r = requests.post(
                    f"{self.url_input.text}/api/login",
                    json={
                        "username": self.user_input.text,
                        "password": self.pass_input.text,
                    }, timeout=10)
                if r.status_code == 200:
                    self.token = r.json()["token"]
                    self.base_url = self.url_input.text
                    self.status.text = "✓ connected"
                    Clock.schedule_interval(self.refresh_stats, 5)
                else:
                    self.status.text = "✗ login failed"
            except Exception as e:
                self.status.text = f"✗ {e}"
        threading.Thread(target=do_login, daemon=True).start()

    def refresh_stats(self, dt=None):
        def fetch():
            try:
                r = requests.get(
                    f"{self.base_url}/api/stats",
                    params={"token": self.token}, timeout=5)
                if r.status_code == 200:
                    s = r.json()
                    self.stats_label.text = (
                        f"Hosts: {s['hosts']}\n"
                        f"Sessions: {s['sessions']}\n"
                        f"Creds: {s['creds']}\n"
                        f"Vulns: {s['vulns']}"
                    )
            except Exception:
                pass
        threading.Thread(target=fetch, daemon=True).start()

    def kill_switch(self, *args):
        try:
            requests.post(
                f"{self.base_url}/api/action",
                json={"action": "kill_switch"},
                params={"token": self.token}, timeout=5)
            self.status.text = "🔴 KILL SWITCH TRIGGERED"
        except Exception as e:
            self.status.text = f"✗ {e}"


if __name__ == "__main__":
    MobileApp().run()
