[app]
title = ShadowOps Mobile
package.name = shadowops
package.domain = io.shadowops
source.dir = .
source.include_exts = py,png,jpg,kv,atlas
version = 0.1.0
requirements = python3,kivy,requests

[buildozer]
log_level = 2
warn_on_root = 1
