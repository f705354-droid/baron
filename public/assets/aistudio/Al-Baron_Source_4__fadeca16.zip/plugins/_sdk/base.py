# language: Python, file: plugins/_sdk/base.py
"""
Al-Baron Plugin SDK — base classes and helpers.
Plugin authors import from this module.
"""


class Al-BaronPlugin:
    """
    Base class for Al-Baron plugins.
    Override any hook method; register() is called once at load.
    """
    def __init__(self, context):
        self.ctx = context
        self.name = context.get("name", "unnamed")

    def register(self, context):
        """called once when plugin is loaded — set up state here"""
        pass

    # ==================== hooks ====================
    def on_session_new(self, session: dict):
        """called for each new session"""
        pass

    def on_session_lost(self, sid: str):
        """session went offline"""
        pass

    def on_task_sent(self, sid: str, task: str, by: str):
        pass

    def on_task_result(self, sid: str, task_id: str, result: str):
        pass

    def on_credential_hit(self, source: str, user: str, secret: str):
        pass

    def on_phishing_hit(self, hit: dict):
        pass

    def enrich_finding(self, finding: dict) -> dict:
        """return finding with added context — called per report finding"""
        return finding

    def transform_task(self, sid: str, task: str) -> str:
        """return task to dispatch — mutate it if needed"""
        return task

    def unload(self):
        """called on shutdown — clean up resources"""
        pass


# helper — pattern for a simple plugin
def simple_plugin(name, hooks: dict, permissions: list):
    """construct a plugin from a dict of hook handlers"""
    class Simple(Al-BaronPlugin):
        pass
    inst = Simple({"name": name})
    inst.permissions = permissions
    for k, v in hooks.items():
        setattr(inst, k, v)
    return inst
