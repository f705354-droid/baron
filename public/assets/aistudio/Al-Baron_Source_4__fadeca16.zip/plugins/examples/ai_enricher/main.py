# language: Python, file: plugins/examples/ai_enricher/main.py
def register(ctx):
    ctx["log"]("ai_enricher registered")


def enrich_finding(finding):
    # ctx is captured at load time
    try:
        from plugins._sdk.base import Al-BaronPlugin
        # access ctx through a closure — simplified
        # in real impl, ctx is injected via register()
        pass
    except Exception:
        pass
    return finding
