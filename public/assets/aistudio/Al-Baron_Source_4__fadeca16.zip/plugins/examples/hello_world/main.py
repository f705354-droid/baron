# language: Python, file: plugins/examples/hello_world/main.py
def register(ctx):
    ctx["log"]("hello_world registered")


def on_session_new(session):
    print(f"[hello_world] new session: {session}")


def on_task_result(sid, task_id, result):
    print(f"[hello_world] {sid} → {result[:80]}")
