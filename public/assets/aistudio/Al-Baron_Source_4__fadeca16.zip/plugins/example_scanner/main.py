# language: Python, file: plugins/example_scanner/main.py
from core.plugins.sdk import Al-BaronPlugin


class ExampleScanner(Al-BaronPlugin):
    name = "example_scanner"
    version = "1.0.0"

    def register(self, ctx):
        self.log(f"registered with {len(ctx)} context items")

    def on_host_discovered(self, host_ip, props):
        self.log(f"new host: {host_ip} — {props}")
        # add a detection rule
        from core.blue.detection_engine import DetectionRule, engine
        rule = DetectionRule(
            f"example-{host_ip}",
            f"Host {host_ip} detected",
            "info",
            f"Example detection for {host_ip}",
            {"host.name": host_ip},
        )
        engine.add_rule(rule)

    def unload(self):
        self.log("unloaded")
