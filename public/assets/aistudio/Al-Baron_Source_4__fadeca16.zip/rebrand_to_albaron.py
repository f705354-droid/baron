# language: Python, file: rebrand_to_albaron.py
# سكربت شامل لتغيير اسم المنصة من Al-Baron إلى Al-Baron
import os
import re

# المجلدات التي سيتم تجاهلها
IGNORE_DIRS = {'.git', '__pycache__', '.venv', 'node_modules', 'loot', 'reports', 'backups'}
# الامتدادات التي سيتم تعديلها
TEXT_EXTENSIONS = {'.py', '.json', '.md', '.txt', '.yaml', '.yml', '.html', '.css', '.js', '.ts', '.tsx', '.sh', '.sql'}

# خريطة الاستبدال (من القديم إلى الجديد)
REPLACEMENTS = {
    "Al-Baron": "Al-Baron",
    "AL-BARON": "AL-BARON",
    "albaron": "albaron",
    "Al Baron": "Al Baron",
    "AL BARON": "AL BARON",
    "al_baron": "al_baron",
    "♛": "♛", # تغيير الشعار
    "v4.0 // empire": "v4.0 // empire",
    "The Baron Cyber Empire": "The Baron Cyber Empire",
    "The Baron Empire": "The Baron Empire",
}

def rebrand_file(filepath):
    """يقرأ الملف، يغير النصوص، ويحفظه"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        original_content = content
        for old, new in REPLACEMENTS.items():
            content = content.replace(old, new)
            
        if content != original_content:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
    except Exception as e:
        pass # تجاهل الملفات التي لا يمكن قراءتها كـ Text
    return False

def main():
    print("♛ Starting Global Rebranding: Al-Baron -> Al-Baron")
    count = 0
    for root, dirs, files in os.walk('.'):
        # تجاهل المجلدات
        dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]
        
        for file in files:
            ext = os.path.splitext(file)[1].lower()
            if ext in TEXT_EXTENSIONS:
                filepath = os.path.join(root, file)
                if rebrand_file(filepath):
                    print(f"  [+] Rebranded: {filepath}")
                    count += 1
                    
    print(f"\n♛ Rebranding complete! {count} files updated.")
    print("Next steps:")
    print("1. If you have a web folder, update the package.json name.")
    print("2. Rename your root folder from 'albaron' to 'albaron' (optional).")
    print("3. Run: python3 main.py")

if __name__ == '__main__':
    main()
