# language: Python, file: utils/crypto.py
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os
import hashlib


def gen_key():
    return Fernet.generate_key()


def encrypt_file(path, key):
    f = Fernet(key)
    with open(path, "rb") as fh:
        data = fh.read()
    enc = f.encrypt(data)
    with open(path + ".enc", "wb") as fh:
        fh.write(enc)
    return path + ".enc"


def decrypt_file(path, key):
    f = Fernet(key)
    with open(path, "rb") as fh:
        data = fh.read()
    dec = f.decrypt(data)
    out = path.replace(".enc", ".dec")
    with open(out, "wb") as fh:
        fh.write(dec)
    return out


def aes_gcm_encrypt(plaintext: bytes, key: bytes = None):
    key = key or AESGCM.generate_key(bit_length=256)
    aad = b"albaron"
    nonce = os.urandom(12)
    ct = AESGCM(key).encrypt(nonce, plaintext, aad)
    return {"key": key.hex(), "nonce": nonce.hex(), "ct": ct.hex()}


def rc4(key: bytes, data: bytes) -> bytes:
    """RC4 — used in Ekko sleep obfuscation and shellcode loaders"""
    S = list(range(256))
    j = 0
    out = bytearray()
    for i in range(256):
        j = (j + S[i] + key[i % len(key)]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    for b in data:
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out.append(b ^ S[(S[i] + S[j]) % 256])
    return bytes(out)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()
