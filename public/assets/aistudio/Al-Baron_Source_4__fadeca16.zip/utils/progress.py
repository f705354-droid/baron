# language: Python, file: utils/progress.py
# unified progress reporting — pushed to log queue + GUI bars
import queue
import time
import threading
from collections import defaultdict


class ProgressTracker:
    """thread-safe progress registry. GUI polls .snapshot()."""
    def __init__(self, log_queue=None, ui_callback=None):
        self.log = log_queue
        self.ui_callback = ui_callback
        self._tasks = {}
        self._lock = threading.Lock()
        self._start_time = {}

    def start(self, task_id, label, total=None):
        with self._lock:
            self._tasks[task_id] = {
                "label": label,
                "current": 0,
                "total": total,
                "status": "running",
                "detail": "",
            }
            self._start_time[task_id] = time.time()
        if self.log:
            self.log.put(f"[progress] ▸ {label}" + (f" (0/{total})" if total else ""))
        if self.ui_callback:
            self.ui_callback(label, 0, total)

    def update(self, task_id, current=None, detail=None, increment=1):
        with self._lock:
            t = self._tasks.get(task_id)
            if not t:
                return
            if current is not None:
                t["current"] = current
            else:
                t["current"] += increment
            if detail is not None:
                t["detail"] = detail
            label = t.get("label", "")
            curr = t["current"]
            tot = t["total"]
        if self.ui_callback:
            self.ui_callback(label, curr, tot)

    def finish(self, task_id, status="done", detail=None):
        with self._lock:
            t = self._tasks.get(task_id)
            if not t:
                return
            t["status"] = status
            if detail:
                t["detail"] = detail
            elapsed = time.time() - self._start_time.get(task_id, time.time())
        if self.log:
            mark = "✓" if status == "done" else "✗"
            self.log.put(f"[progress] {mark} {t['label']} — {elapsed:.1f}s"
                         + (f" — {detail}" if detail else ""))

    def snapshot(self):
        with self._lock:
            return dict(self._tasks)

    def clear_finished(self):
        with self._lock:
            self._tasks = {k: v for k, v in self._tasks.items()
                           if v["status"] == "running"}


GLOBAL_PROGRESS = ProgressTracker()
