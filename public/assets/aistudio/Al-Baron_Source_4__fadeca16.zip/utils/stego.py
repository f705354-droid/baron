# language: Python, file: utils/stego.py
# LSB image stego + DCT + audio + video container abuse
import os
import struct
import hashlib
import base64


class ImageStego:
    """LSB steganography for PNG/BMP — 1 bit per channel, ~12% capacity"""

    @staticmethod
    def hide_lsb(carrier_path, payload: bytes, out_path):
        from PIL import Image
        img = Image.open(carrier_path).convert("RGB")
        pixels = list(img.getdata())

        # header: 4-byte magic + 4-byte length
        header = b"STG0" + struct.pack(">I", len(payload))
        data = header + payload
        bits = "".join(f"{b:08b}" for b in data)

        if len(bits) > len(pixels) * 3:
            raise ValueError(f"payload too big: {len(bits)} bits, "
                             f"capacity {len(pixels)*3}")

        new_pixels = []
        i = 0
        for px in pixels:
            r, g, b = px
            if i < len(bits):
                r = (r & ~1) | int(bits[i]); i += 1
            if i < len(bits):
                g = (g & ~1) | int(bits[i]); i += 1
            if i < len(bits):
                b = (b & ~1) | int(bits[i]); i += 1
            new_pixels.append((r, g, b))

        out = Image.new("RGB", img.size)
        out.putdata(new_pixels)
        out.save(out_path, "PNG")
        return out_path

    @staticmethod
    def extract_lsb(carrier_path) -> bytes:
        from PIL import Image
        img = Image.open(carrier_path).convert("RGB")
        bits = []
        for px in img.getdata():
            for c in px:
                bits.append(str(c & 1))
            if len(bits) >= 32:
                # check for header
                header_bits = "".join(bits[:32])
                if header_bits[:32] == "".join(
                    f"{b:08b}" for b in b"STG0"
                )[:32]:
                    # read length
                    if len(bits) >= 64:
                        length_bits = "".join(bits[32:64])
                        length = struct.unpack(">I",
                            bytes(int(length_bits[i:i+8], 2)
                                  for i in range(0, 32, 8)))[0]
                        if len(bits) >= 64 + length * 8:
                            payload_bits = "".join(bits[64:64 + length*8])
                            return bytes(int(payload_bits[i:i+8], 2)
                                         for i in range(0, len(payload_bits), 8))
                break

        # fallback: read everything, look for header
        all_bits = []
        for px in Image.open(carrier_path).convert("RGB").getdata():
            for c in px:
                all_bits.append(c & 1)
        header_bits = "".join(str(b) for b in all_bits[:32])
        if header_bits != "".join(f"{b:08b}" for b in b"STG0"):
            raise ValueError("no STG0 magic found")
        length_bits = "".join(str(b) for b in all_bits[32:64])
        length = struct.unpack(">I", bytes(
            int(length_bits[i:i+8], 2) for i in range(0, 32, 8)))[0]
        payload_bits = "".join(str(b) for b in all_bits[64:64 + length*8])
        return bytes(int(payload_bits[i:i+8], 2)
                     for i in range(0, len(payload_bits), 8))

    @staticmethod
    def hide_dct(carrier_path, payload: bytes, out_path, strength=25):
        """DCT-based — survives JPEG compression and mild re-encoding"""
        from PIL import Image
        import numpy as np
        img = np.array(Image.open(carrier_path).convert("L"), dtype=np.float32)
        h, w = img.shape
        h, w = h - h % 8, w - w % 8
        img = img[:h, :w]

        header = b"STG1" + struct.pack(">I", len(payload))
        data = header + payload
        bits = "".join(f"{b:08b}" for b in data)

        idx = 0
        for i in range(0, h, 8):
            for j in range(0, w, 8):
                if idx >= len(bits):
                    break
                block = img[i:i+8, j:j+8]
                # DCT via scipy or manual
                try:
                    from scipy.fftpack import dct, idct
                    d = dct(dct(block.T, norm="ortho").T, norm="ortho")
                except ImportError:
                    d = block  # fallback
                bit = int(bits[idx])
                d[3, 2] = (abs(d[3, 2]) // strength) * strength
                if bit:
                    d[3, 2] += strength / 2
                else:
                    d[3, 2] += strength / 4
                try:
                    block2 = idct(idct(d.T, norm="ortho").T, norm="ortho")
                except Exception:
                    block2 = d
                img[i:i+8, j:j+8] = block2
                idx += 1

        Image.fromarray(img.astype("uint8")).save(out_path, "PNG")
        return out_path


class AudioStego:
    """LSB in WAV samples — 1 bit per 16-bit sample, ~6% capacity"""

    @staticmethod
    def hide(wav_path, payload: bytes, out_path):
        import wave
        with wave.open(wav_path, "rb") as w:
            params = w.getparams()
            frames = w.readframes(w.getnframes())
        samples = list(struct.unpack(f"<{len(frames)//2}h", frames))

        header = b"STA0" + struct.pack(">I", len(payload))
        data = header + payload
        bits = "".join(f"{b:08b}" for b in data)

        if len(bits) > len(samples):
            raise ValueError(f"payload too big: {len(bits)} bits, "
                             f"capacity {len(samples)}")

        for i, bit in enumerate(bits):
            samples[i] = (samples[i] & ~1) | int(bit)

        with wave.open(out_path, "wb") as w:
            w.setparams(params)
            w.writeframes(struct.pack(f"<{len(samples)}h", *samples))
        return out_path

    @staticmethod
    def extract(wav_path) -> bytes:
        import wave
        with wave.open(wav_path, "rb") as w:
            frames = w.readframes(w.getnframes())
        samples = struct.unpack(f"<{len(frames)//2}h", frames)
        bits = [s & 1 for s in samples]

        header_bits = "".join(str(b) for b in bits[:32])
        if header_bits != "".join(f"{b:08b}" for b in b"STA0"):
            raise ValueError("no STA0 magic")
        length_bits = "".join(str(b) for b in bits[32:64])
        length = struct.unpack(">I", bytes(
            int(length_bits[i:i+8], 2) for i in range(0, 32, 8)))[0]
        payload_bits = "".join(str(b) for b in bits[64:64+length*8])
        return bytes(int(payload_bits[i:i+8], 2)
                     for i in range(0, len(payload_bits), 8))


class VideoStego:
    """Append data after last MP4 frame — invisible, survives upload"""

    @staticmethod
    def hide(mp4_path, payload: bytes, out_path):
        with open(mp4_path, "rb") as f:
            data = f.read()
        # MP4 files end with moov atom; extra data after is ignored by players
        # but some strict players may complain. Alternative: use free/skip atom.
        with open(out_path, "wb") as f:
            f.write(data)
            f.write(b"STV0" + struct.pack(">I", len(payload)) + payload)
        return out_path

    @staticmethod
    def extract(mp4_path) -> bytes:
        with open(mp4_path, "rb") as f:
            data = f.read()
        idx = data.rfind(b"STV0")
        if idx < 0:
            raise ValueError("no STV0 magic")
        length = struct.unpack(">I", data[idx+4:idx+8])[0]
        return data[idx+8:idx+8+length]


def encrypt_payload(data: bytes, key: bytes = None) -> bytes:
    """AES-GCM encrypt before embedding"""
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    key = key or AESGCM.generate_key(bit_length=256)
    nonce = os.urandom(12)
    ct = AESGCM(key).encrypt(nonce, data, b"stego")
    return key + nonce + ct
