#!/bin/bash
# language: bash, file: scripts/schedule_backup.sh
# يثبت cron job أو systemd timer للنسخ اليومي

set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
AL-BARON_ROOT="$(dirname "$SCRIPT_DIR")"

install_cron() {
    # cron يومياً 3 AM
    CRON_LINE="0 3 * * * cd $AL-BARON_ROOT && python3 scripts/backup.py --mode auto >> ~/.albaron/backup.log 2>&1"

    (crontab -l 2>/dev/null | grep -v "albaron/scripts/backup.py"; echo "$CRON_LINE") | crontab -
    echo "[+] cron installed: daily 3 AM"
    crontab -l | grep backup
}

install_systemd() {
    mkdir -p ~/.config/systemd/user

    cat > ~/.config/systemd/user/albaron-backup.service <<EOF
[Unit]
Description=Al-Baron daily backup

[Service]
Type=oneshot
WorkingDirectory=$AL-BARON_ROOT
ExecStart=/usr/bin/python3 $AL-BARON_ROOT/scripts/backup.py --mode auto
StandardOutput=append:%h/.albaron/backup.log
StandardError=append:%h/.albaron/backup.log
EOF

    cat > ~/.config/systemd/user/albaron-backup.timer <<EOF
[Unit]
Description=Daily Al-Baron backup at 3 AM

[Timer]
OnCalendar=*-*-* 03:00:00
Persistent=true

[Install]
WantedBy=timers.target
EOF

    systemctl --user daemon-reload
    systemctl --user enable --now albaron-backup.timer
    echo "[+] systemd timer installed"
    systemctl --user status albaron-backup.timer --no-pager
}

case "${1:-cron}" in
    cron) install_cron ;;
    systemd) install_systemd ;;
    *)
        echo "usage: $0 {cron|systemd}"
        exit 1
        ;;
esac
