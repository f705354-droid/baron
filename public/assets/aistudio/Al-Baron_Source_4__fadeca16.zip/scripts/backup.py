# language: Python, file: scripts/backup.py
# Backup — نسخ احتياطي كامل/تزايدي مع تشفير age
import os
import sys
import json
import time
import hashlib
import shutil
import subprocess
import tarfile
import tempfile
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict
import yaml


def load_config(path: str = "scripts/backup_config.yaml") -> dict:
    with open(path) as f:
        cfg = yaml.safe_load(f)
    # expand ~
    def expand(v):
        if isinstance(v, str) and v.startswith("~"):
            return os.path.expanduser(v)
        return v
    cfg["backup_root"] = expand(cfg["backup_root"])
    cfg["temp_dir"] = expand(cfg["temp_dir"])
    return cfg


def ensure_age_key(key_dir: str) -> tuple:
    """
    يتأكد من وجود مفتاح age.
    يرجع (private_path، public).
    """
    os.makedirs(key_dir, exist_ok=True)
    priv = os.path.join(key_dir, "age.key")
    pub = priv + ".pub"

    # ولّد لو غير موجود
    if not os.path.exists(priv):
        if shutil.which("age-keygen") is None:
            raise RuntimeError(
                "age-keygen not found. Install: sudo apt install age")
        print(f"[*] generating age key: {priv}")
        r = subprocess.run(["age-keygen", "-o", priv],
                            capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError(f"age-keygen failed: {r.stderr}")
        # استخرج public key
        for line in r.stderr.splitlines():
            if "public key:" in line:
                pk = line.split("public key:")[1].strip()
                with open(pub, "w") as f:
                    f.write(pk)
                break
    # اقرأ public
    with open(pub) as f:
        public = f.read().strip()
    return priv, public


def detect_full_or_incremental(backup_root: str) -> str:
    """
    full إذا آخر نسخة كاملة أقدم من 7 أيام.
    incremental لو هناك نسخة كاملة حديثة.
    """
    manifests_dir = os.path.join(backup_root, "manifests")
    if not os.path.isdir(manifests_dir):
        return "full"
    for f in sorted(os.listdir(manifests_dir), reverse=True):
        if f.startswith("full_"):
            path = os.path.join(manifests_dir, f)
            with open(path) as fh:
                m = json.load(fh)
            age_days = (time.time() - m.get("ts", 0)) / 86400
            if age_days < 7:
                return "incremental"
            break
    return "full"


def should_copy(src: str, since: float, mode: str) -> bool:
    """في incremental، فقط الملفات الجديدة/المعدلة"""
    if mode == "full":
        return True
    try:
        mtime = os.path.getmtime(src)
        return mtime >= since
    except FileNotFoundError:
        return False


def collect_files(cfg: dict, mode: str, since: float = 0) -> dict:
    """
    يجمع قائمة الملفات للحفظ حسب config.
    يرجع {category: [(src, rel_path)]}.
    """
    from fnmatch import fnmatch
    result = {}
    for cat_name, cat_cfg in cfg["categories"].items():
        if cat_name == "excluded":
            continue
        if cat_cfg.get("optional") and mode == "incremental":
            continue   # models لا تُنسخ في incremental

        files = []
        for entry in cat_cfg.get("paths", []):
            src = os.path.expanduser(entry["source"])
            excludes = entry.get("exclude", [])

            if os.path.isfile(src):
                if should_copy(src, since, mode):
                    files.append((src, entry["source"]))
                continue
            if os.path.isdir(src):
                for root, dirs, fnames in os.walk(src):
                    # فلترة dirs
                    dirs[:] = [d for d in dirs
                                if d not in ("__pycache__",
                                              "node_modules", ".venv")]
                    for fname in fnames:
                        if any(fnmatch(fname, ex) for ex in excludes):
                            continue
                        full = os.path.join(root, fname)
                        if should_copy(full, since, mode):
                            rel = os.path.relpath(full, os.path.dirname(src))
                            files.append((full, os.path.join(
                                os.path.basename(src.rstrip("/")), rel)))
                continue

            # wildcard paths
            import glob
            for match in glob.glob(src):
                if os.path.isfile(match):
                    if should_copy(match, since, mode):
                        files.append((match,
                                       os.path.basename(match)))

        if files:
            result[cat_name] = files
    return result


def create_manifest(files: dict, mode: str, size_bytes: int) -> dict:
    """ينشئ manifest مع checksums"""
    checksums = {}
    for cat, flist in files.items():
        for src, rel in flist:
            try:
                h = hashlib.sha256()
                with open(src, "rb") as f:
                    for chunk in iter(lambda: f.read(65536), b""):
                        h.update(chunk)
                checksums[rel] = h.hexdigest()
            except Exception as e:
                checksums[rel] = f"error: {e}"

    return {
        "ts": time.time(),
        "mode": mode,
        "size_bytes": size_bytes,
        "size_human": human_size(size_bytes),
        "file_count": sum(len(v) for v in files.values()),
        "categories": {k: len(v) for k, v in files.items()},
        "checksums": checksums,
        "hostname": os.uname().nodename,
        "user": os.getenv("USER", "unknown"),
    }


def human_size(n: int) -> str:
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"


def backup(mode: Optional[str] = None,
            categories: Optional[List[str]] = None,
            password: Optional[str] = None,
            no_encrypt: bool = False,
            config_path: str = "scripts/backup_config.yaml") -> dict:
    """
    Main backup function.
    mode: full / incremental / auto
    """
    cfg = load_config(config_path)
    backup_root = cfg["backup_root"]
    os.makedirs(backup_root, exist_ok=True)
    os.makedirs(os.path.join(backup_root, "manifests"), exist_ok=True)

    # تحديد mode
    if mode is None or mode == "auto":
        mode = detect_full_or_incremental(backup_root)

    # since = آخر نسخة
    since = 0
    if mode == "incremental":
        manifests_dir = os.path.join(backup_root, "manifests")
        all_m = sorted(
            [f for f in os.listdir(manifests_dir) if f.endswith(".json")],
            reverse=True)
        if all_m:
            with open(os.path.join(manifests_dir, all_m[0])) as f:
                last = json.load(f)
            since = last.get("ts", 0)

    # collect
    print(f"[*] mode={mode}, collecting files...")
    files = collect_files(cfg, mode, since)
    if categories:
        files = {k: v for k, v in files.items() if k in categories}
    total_files = sum(len(v) for v in files.values())
    if total_files == 0:
        print("[!] no files to backup")
        return {"status": "empty"}

    print(f"[*] {total_files} files across {len(files)} categories")

    # timestamp
    ts = datetime.utcnow().strftime("%Y-%m-%d_%H%M%S")
    base_name = f"{mode}_{ts}"

    # temp working dir
    tmp = tempfile.mkdtemp(prefix="albaron_bk_")
    try:
        # 1. نسخ الملفات إلى tmp
        print(f"[*] staging to {tmp}")
        for cat, flist in files.items():
            cat_dir = os.path.join(tmp, cat)
            os.makedirs(cat_dir, exist_ok=True)
            for src, rel in flist:
                dst = os.path.join(cat_dir, rel)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                try:
                    shutil.copy2(src, dst)
                except Exception as e:
                    print(f"  [!] skip {src}: {e}")

        # 2. أنشئ tarball
        tar_path = os.path.join(tmp, f"{base_name}.tar")
        print(f"[*] creating tarball...")
        with tarfile.open(tar_path, "w") as tar:
            for cat in files.keys():
                cat_dir = os.path.join(tmp, cat)
                if os.path.isdir(cat_dir):
                    tar.add(cat_dir, arcname=cat)

        tar_size = os.path.getsize(tar_path)
        print(f"[*] tarball: {human_size(tar_size)}")

        # 3. ضغط zstd
        zst_path = tar_path + ".zst"
        zstd_level = cfg["compression"].get("level", 9)
        print(f"[*] compressing (zstd -{zstd_level})...")
        r = subprocess.run(
            ["zstd", f"-{zstd_level}", "--rm", tar_path, "-o", zst_path],
            capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError(f"zstd failed: {r.stderr}")

        compressed_size = os.path.getsize(zst_path)
        ratio = tar_size / compressed_size if compressed_size else 0
        print(f"[*] compressed: {human_size(compressed_size)} "
              f"({ratio:.1f}x)")

        # 4. تشفير age
        final_path = zst_path
        if not no_encrypt and cfg["encryption"]["enabled"]:
            print("[*] encrypting...")
            key_dir = os.path.join(backup_root, "keys")
            priv, public = ensure_age_key(key_dir)
            encrypted = zst_path + ".age"
            cmd = ["age", "-r", public, "-o", encrypted, zst_path]
            if password:
                cmd = ["age", "-p", "-o", encrypted, zst_path]
            r = subprocess.run(
                cmd, capture_output=True, text=True,
                input=password + "\n" if password else None)
            if r.returncode != 0:
                raise RuntimeError(f"age failed: {r.stderr}")
            os.remove(zst_path)
            final_path = encrypted

        # 5. انقل إلى backup_root
        final_name = os.path.basename(final_path)
        final_dest = os.path.join(backup_root, final_name)
        shutil.move(final_path, final_dest)
        print(f"[+] backup written: {final_dest}")

        # 6. manifest
        manifest = create_manifest(files, mode,
                                     os.path.getsize(final_dest))
        manifest["backup_file"] = final_name
        manifest["encrypted"] = not no_encrypt
        manifest_path = os.path.join(
            backup_root, "manifests", f"{base_name}.json")
        with open(manifest_path, "w") as f:
            json.dump(manifest, f, indent=2)
        print(f"[+] manifest: {manifest_path}")

        # 7. retention
        apply_retention(cfg)

        return {
            "status": "success",
            "mode": mode,
            "file": final_dest,
            "size": compressed_size,
            "manifest": manifest_path,
        }
    finally:
        # cleanup
        try:
            shutil.rmtree(tmp)
        except Exception:
            pass


def apply_retention(cfg: dict):
    """يطبق سياسة الاحتفاظ"""
    root = cfg["backup_root"]
    keep_full = cfg["retention"]["full_keep"]
    keep_inc = cfg["retention"]["incremental_keep"]

    files = sorted(
        [f for f in os.listdir(root)
         if f.startswith(("full_", "incremental_"))
         and f.endswith((".age", ".zst"))],
        reverse=True
    )
    full = [f for f in files if f.startswith("full_")]
    inc = [f for f in files if f.startswith("incremental_")]

    to_remove = full[keep_full:] + inc[keep_inc:]
    for f in to_remove:
        try:
            os.remove(os.path.join(root, f))
            # manifest
            base = f.replace(".age", "").replace(".zst", "")
            mf = os.path.join(root, "manifests", f"{base}.json")
            if os.path.exists(mf):
                os.remove(mf)
            print(f"[*] pruned old backup: {f}")
        except Exception:
            pass


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Al-Baron backup")
    parser.add_argument("--mode", choices=["full", "incremental", "auto"],
                         default="auto")
    parser.add_argument("--categories", nargs="*",
                         help="subset: essential memory loot models config")
    parser.add_argument("--password", help="encrypt with password instead of age key")
    parser.add_argument("--no-encrypt", action="store_true")
    parser.add_argument("--config", default="scripts/backup_config.yaml")
    args = parser.parse_args()

    result = backup(
        mode=args.mode,
        categories=args.categories,
        password=args.password,
        no_encrypt=args.no_encrypt,
        config_path=args.config,
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
