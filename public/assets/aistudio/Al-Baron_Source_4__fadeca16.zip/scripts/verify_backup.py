# language: Python, file: scripts/verify_backup.py
# Verify backup — يتأكد أن الملف سليم + checksums متطابقة
import os
import sys
import json
import hashlib
import subprocess
import tempfile
import shutil
import yaml
from typing import Optional


def verify_backup(backup_file: str,
                    manifest_file: str,
                    age_key: Optional[str] = None) -> dict:
    """
    يتحقق من:
      1. hash الملف نفسه
      2. checksums كل ملف بعد فك التشفير
    """
    results = {
        "file": backup_file,
        "checks": {},
    }

    # hash الملف
    print("[*] computing file hash...")
    h = hashlib.sha256()
    with open(backup_file, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    results["checks"]["file_hash"] = h.hexdigest()

    # اقرأ manifest
    with open(manifest_file) as f:
        manifest = json.load(f)
    results["checks"]["manifest_mode"] = manifest["mode"]
    results["checks"]["manifest_file_count"] = manifest["file_count"]

    # فك تشفير + استخراج
    work_dir = tempfile.mkdtemp(prefix="albaron_verify_")
    try:
        if backup_file.endswith(".age"):
            print("[*] decrypting...")
            decrypted = os.path.join(work_dir, "v.tar.zst")
            cmd = ["age", "-d", "-i", age_key, "-o", decrypted, backup_file]
            r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode != 0:
                results["checks"]["decrypt"] = "FAIL"
                results["error"] = r.stderr
                return results
            results["checks"]["decrypt"] = "OK"
        else:
            decrypted = backup_file

        # decompress
        if decrypted.endswith(".zst"):
            print("[*] decompressing...")
            tar_path = decrypted.replace(".zst", "")
            r = subprocess.run(
                ["zstd", "-d", "--rm", decrypted, "-o", tar_path],
                capture_output=True, text=True)
            if r.returncode != 0:
                results["checks"]["decompress"] = "FAIL"
                return results
            results["checks"]["decompress"] = "OK"
        else:
            tar_path = decrypted

        # extract
        print("[*] extracting...")
        import tarfile
        extract_dir = os.path.join(work_dir, "ext")
        os.makedirs(extract_dir, exist_ok=True)
        with tarfile.open(tar_path, "r") as tar:
            tar.extractall(extract_dir)

        # verify checksums
        print("[*] verifying checksums...")
        manifest_checksums = manifest.get("checksums", {})
        missing = []
        mismatches = []
        checked = 0

        for cat_name in manifest["categories"].keys():
            cat_dir = os.path.join(extract_dir, cat_name)
            if not os.path.isdir(cat_dir):
                continue
            for root, _, fnames in os.walk(cat_dir):
                for fname in fnames:
                    src = os.path.join(root, fname)
                    rel = os.path.relpath(src, cat_dir)
                    # ابحث في manifest
                    expected = None
                    for k in [f"{cat_name}/{rel}", rel]:
                        if k in manifest_checksums:
                            expected = manifest_checksums[k]
                            break
                    if not expected:
                        continue
                    checked += 1
                    h = hashlib.sha256()
                    with open(src, "rb") as f:
                        for chunk in iter(lambda: f.read(65536), b""):
                            h.update(chunk)
                    actual = h.hexdigest()
                    if actual != expected:
                        mismatches.append({
                            "file": rel, "category": cat_name,
                            "expected": expected, "actual": actual,
                        })

        results["checks"]["checksums_verified"] = checked
        results["checks"]["mismatches"] = mismatches[:10]
        results["checks"]["checksum_status"] = (
            "OK" if not mismatches else f"{len(mismatches)} MISMATCHES")

        return results
    finally:
        try:
            shutil.rmtree(work_dir)
        except Exception:
            pass


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Verify Al-Baron backup")
    parser.add_argument("--backup", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--age-key",
                         default="~/.albaron/backups/keys/age.key")
    args = parser.parse_args()

    age_key = os.path.expanduser(args.age_key) if args.age_key else None
    result = verify_backup(args.backup, args.manifest, age_key)
    print(json.dumps(result, indent=2))
    if result["checks"].get("checksum_status") != "OK":
        sys.exit(1)


if __name__ == "__main__":
    main()
