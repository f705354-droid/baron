# language: Python, file: scripts/restore.py
# Restore — يفك تشفير، decompress، استعادة كاملة/انتقائية
import os
import sys
import json
import time
import shutil
import subprocess
import tarfile
import tempfile
from pathlib import Path
from typing import Optional, List, Dict
import yaml


def load_config(path: str = "scripts/backup_config.yaml") -> dict:
    with open(path) as f:
        cfg = yaml.safe_load(f)
    cfg["backup_root"] = os.path.expanduser(cfg["backup_root"])
    cfg["temp_dir"] = os.path.expanduser(cfg["temp_dir"])
    return cfg


def list_backups(backup_root: str) -> List[dict]:
    """يقرأ manifests ويعرض النسخ المتاحة"""
    manifests_dir = os.path.join(backup_root, "manifests")
    if not os.path.isdir(manifests_dir):
        return []
    backups = []
    for f in sorted(os.listdir(manifests_dir), reverse=True):
        if not f.endswith(".json"):
            continue
        path = os.path.join(manifests_dir, f)
        with open(path) as fh:
            m = json.load(fh)
        backups.append({
            "manifest": path,
            "backup_file": os.path.join(backup_root, m["backup_file"]),
            "mode": m["mode"],
            "ts": m["ts"],
            "size": m["size_human"],
            "categories": m["categories"],
        })
    return backups


def decrypt_and_decompress(backup_file: str,
                            out_dir: str,
                            age_key: Optional[str] = None,
                            password: Optional[str] = None) -> str:
    """يفك كل الطبقات"""
    work_dir = tempfile.mkdtemp(prefix="albaron_restore_")

    # 1. decrypt
    if backup_file.endswith(".age"):
        print("[*] decrypting...")
        decrypted = os.path.join(work_dir, "backup.tar.zst")
        if password:
            cmd = ["age", "-d", "-o", decrypted, backup_file]
            r = subprocess.run(cmd, capture_output=True, text=True,
                                input=password + "\n")
        else:
            if not age_key:
                age_key = os.path.expanduser(
                    "~/.albaron/backups/keys/age.key")
            if not os.path.exists(age_key):
                raise FileNotFoundError(
                    f"age key not found: {age_key}")
            cmd = ["age", "-d", "-i", age_key, "-o", decrypted, backup_file]
            r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError(f"decrypt failed: {r.stderr}")
    else:
        decrypted = backup_file
        work_dir = os.path.dirname(backup_file)

    # 2. decompress
    if decrypted.endswith(".zst"):
        print("[*] decompressing...")
        tar_path = decrypted.replace(".zst", "")
        r = subprocess.run(
            ["zstd", "-d", "--rm", decrypted, "-o", tar_path],
            capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError(f"zstd failed: {r.stderr}")
    else:
        tar_path = decrypted

    # 3. extract
    print("[*] extracting...")
    extract_dir = os.path.join(work_dir, "extracted")
    os.makedirs(extract_dir, exist_ok=True)
    with tarfile.open(tar_path, "r") as tar:
        tar.extractall(extract_dir)

    return extract_dir


def restore_file(src: str, dst: str, backup_existing: bool = True):
    """
    يستعيد ملفاً من tarball إلى مكانه الأصلي.
    backup_existing: يحفظ نسخة من الملف الحالي أولاً.
    """
    dst = os.path.expanduser(dst)
    os.makedirs(os.path.dirname(dst), exist_ok=True)

    if os.path.exists(dst) and backup_existing:
        ts = time.strftime("%Y%m%d_%H%M%S")
        bak = f"{dst}.pre_restore_{ts}"
        try:
            shutil.copy2(dst, bak)
        except Exception:
            pass

    shutil.copy2(src, dst)


def restore(backup_file: str,
             mode: str = "safe",
             categories: Optional[List[str]] = None,
             age_key: Optional[str] = None,
             password: Optional[str] = None,
             config_path: str = "scripts/backup_config.yaml") -> dict:
    """
    mode:
      safe     — نسخ احتياطي للموجود أولاً، ثم استعادة
      overlay  — استبدال مباشر
      dry-run  — عرض ما سيحدث فقط
    """
    cfg = load_config(config_path)

    if not os.path.exists(backup_file):
        raise FileNotFoundError(backup_file)

    print(f"[*] restoring from {backup_file}")
    extract_dir = decrypt_and_decompress(
        backup_file, cfg["temp_dir"], age_key, password)

    # اقرأ manifest
    manifest_dir = os.path.join(cfg["backup_root"], "manifests")
    base = os.path.basename(backup_file)
    for suffix in [".age", ".zst"]:
        if base.endswith(suffix):
            base = base[:-len(suffix)]
    manifest_path = os.path.join(manifest_dir, f"{base}.json")
    if not os.path.exists(manifest_path):
        raise FileNotFoundError(f"manifest: {manifest_path}")

    with open(manifest_path) as f:
        manifest = json.load(f)

    # معالجة كل category
    stats = {"files": 0, "skipped": 0, "errors": 0}
    for cat_name, count in manifest["categories"].items():
        if categories and cat_name not in categories:
            stats["skipped"] += count
            continue

        cat_src = os.path.join(extract_dir, cat_name)
        if not os.path.isdir(cat_src):
            continue

        print(f"[*] restoring category '{cat_name}' ({count} files)")

        for root, dirs, fnames in os.walk(cat_src):
            for fname in fnames:
                src = os.path.join(root, fname)
                rel = os.path.relpath(src, cat_src)
                # استعادة إلى location الصحيح حسب category
                dst = resolve_destination(cat_name, rel, cfg)
                if not dst:
                    continue

                if mode == "dry-run":
                    print(f"  would restore: {dst}")
                else:
                    try:
                        restore_file(src, dst,
                                       backup_existing=(mode == "safe"))
                        stats["files"] += 1
                    except Exception as e:
                        print(f"  [!] {dst}: {e}")
                        stats["errors"] += 1

    # cleanup
    try:
        shutil.rmtree(extract_dir)
    except Exception:
        pass

    return stats


def resolve_destination(category: str, rel: str, cfg: dict) -> Optional[str]:
    """
    يحوّل مسار داخل tarball إلى مسار النظام الفعلي.
    """
    if category == "essential":
        return rel
    if category == "memory":
        return os.path.expanduser(f"~/.albaron/{rel}")
    if category == "loot":
        return rel
    if category == "models":
        return os.path.expanduser(f"~/.albaron/{rel}")
    if category == "config":
        if rel.startswith("k8s/"):
            return rel
        return os.path.expanduser(f"~/.albaron/{rel}")
    return rel


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Al-Baron restore")
    parser.add_argument("--list", action="store_true",
                         help="list available backups")
    parser.add_argument("--file",
                         help="backup file to restore")
    parser.add_argument("--mode", choices=["safe", "overlay", "dry-run"],
                         default="safe")
    parser.add_argument("--categories", nargs="*",
                         help="subset of categories")
    parser.add_argument("--age-key")
    parser.add_argument("--password")
    parser.add_argument("--config", default="scripts/backup_config.yaml")
    args = parser.parse_args()

    cfg = load_config(args.config)

    if args.list:
        backups = list_backups(cfg["backup_root"])
        if not backups:
            print("no backups found")
            return
        print(f"{'Timestamp':<22} {'Mode':<12} {'Size':<10} {'Categories'}")
        print("-" * 70)
        for b in backups:
            from datetime import datetime
            ts = datetime.fromtimestamp(b["ts"]).strftime("%Y-%m-%d %H:%M")
            cats = ",".join(b["categories"].keys())
            print(f"{ts:<22} {b['mode']:<12} {b['size']:<10} {cats}")
        return

    if not args.file:
        print("use --file or --list")
        return

    stats = restore(
        backup_file=args.file,
        mode=args.mode,
        categories=args.categories,
        age_key=args.age_key,
        password=args.password,
        config_path=args.config,
    )
    print(json.dumps(stats, indent=2))


if __name__ == "__main__":
    main()
