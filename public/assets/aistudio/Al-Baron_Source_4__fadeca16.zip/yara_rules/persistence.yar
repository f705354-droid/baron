
rule Persistence_Indicators {
    meta:
        description = "Detects persistence mechanisms"
    strings:
        $p1 = "schtasks /create" nocase
        $p2 = "reg add" nocase
        $p3 = "CurrentVersion\\Run" nocase
        $p4 = "/etc/crontab"
        $p5 = "systemctl enable"
    condition:
        any of them
}
