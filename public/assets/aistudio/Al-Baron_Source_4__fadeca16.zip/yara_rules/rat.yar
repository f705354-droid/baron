
rule RAT_Indicators {
    meta:
        description = "Detects RAT-like behavior"
    strings:
        $r1 = "CreateRemoteThread"
        $r2 = "WriteProcessMemory"
        $r3 = "VirtualAllocEx"
        $r4 = "SetWindowsHookEx"
        $r5 = "GetAsyncKeyState"
        $r6 = "socket"
        $r7 = "connect"
    condition:
        3 of them
}
