
rule Ransomware_Indicators {
    meta:
        description = "Detects ransomware indicators"
    strings:
        $r1 = "vssadmin delete shadows"
        $r2 = "wbadmin delete catalog"
        $r3 = "bcdedit /set {default} recoveryenabled no"
        $r4 = ".locked"
        $r5 = ".encrypted"
        $b1 = "bitcoin" nocase
        $b2 = "ransom" nocase
    condition:
        2 of them
}
