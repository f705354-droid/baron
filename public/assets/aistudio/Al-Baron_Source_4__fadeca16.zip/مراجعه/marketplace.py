# language: Python, file: modules/marketplace.py
# Plugin Marketplace
import customtkinter as ctk
import os
import json
from core.plugins.loader import loader


class MarketplaceModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "marketplace"
        self.app = app
        self.loader = loader

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="PLUGIN MARKETPLACE",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="discover · load · unload community plugins",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ── actions ──
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24)
        for label, fn in [
            ("▸ Discover", self._discover),
            ("▸ Load all", self._load_all),
            ("▸ Unload all", self._unload),
            ("▸ Installed", self._installed),
            ("▸ Open plugins dir", self._open_dir),
        ]:
            ctk.CTkButton(
                row, text=label, width=170, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).pack(side="left", padx=(0, 4))

        # ── plugins list ──
        ctk.CTkLabel(parent, text="Available plugins:",
                      font=ctk.CTkFont(size=12, weight="bold"),
                      text_color="#c8d6e5").pack(
            pady=(16, 4), padx=24, anchor="w")

        self.plugins_frame = ctk.CTkScrollableFrame(
            parent, fg_color="#0d1319", corner_radius=6,
            scrollbar_button_color="#1a2332")
        self.plugins_frame.pack(fill="x", padx=24, pady=(0, 8))

        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=300
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

        self._discover()

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _discover(self):
        for w in self.plugins_frame.winfo_children():
            w.destroy()
        plugins = self.loader.discover()
        if not plugins:
            ctk.CTkLabel(self.plugins_frame,
                          text="no plugins found in plugins/",
                          font=ctk.CTkFont(size=11),
                          text_color="#4a5568").pack(pady=20)
            return

        for p in plugins:
            card = ctk.CTkFrame(self.plugins_frame,
                                  fg_color="#141a22", corner_radius=6)
            card.pack(fill="x", pady=4, padx=4)

            top = ctk.CTkFrame(card, fg_color="transparent")
            top.pack(fill="x", padx=8, pady=(6, 2))

            ctk.CTkLabel(top, text=p.get("name", "?"),
                          font=ctk.CTkFont(size=13, weight="bold"),
                          text_color="#00ff9c").pack(side="left")
            ctk.CTkLabel(top, text=f"v{p.get('version', '?')}",
                          font=ctk.CTkFont(size=10),
                          text_color="#6a7a8a").pack(side="left", padx=(8, 0))

            ctk.CTkLabel(card, text=p.get("description", ""),
                          font=ctk.CTkFont(size=10),
                          text_color="#c8d6e5",
                          anchor="w", justify="left",
                          wraplength=600).pack(fill="x", padx=8, anchor="w")

            perms = p.get("permissions", [])
            perm_frame = ctk.CTkFrame(card, fg_color="transparent")
            perm_frame.pack(fill="x", padx=8, pady=(4, 4))
            ctk.CTkLabel(perm_frame, text="perms:",
                          font=ctk.CTkFont(size=9),
                          text_color="#6a7a8a").pack(side="left")
            for perm in perms[:5]:
                ctk.CTkLabel(perm_frame, text=perm,
                              font=ctk.CTkFont(size=9),
                              text_color="#00bfff").pack(side="left",
                                                          padx=(4, 0))

            btn_frame = ctk.CTkFrame(card, fg_color="transparent")
            btn_frame.pack(fill="x", padx=8, pady=(0, 6))
            name = p["name"]

            ctk.CTkButton(
                btn_frame, text="▸ Load",
                width=100, height=26,
                fg_color="#0d2818", hover_color="#1a4a2e",
                text_color="#00ff9c",
                command=lambda n=name: self._load(n)).pack(side="left", padx=(0, 4))
            ctk.CTkButton(
                btn_frame, text="× Unload",
                width=100, height=26,
                fg_color="#4a1a1a", hover_color="#6b1a1a",
                text_color="#ff6b6b",
                command=lambda n=name: self._unload_one(n)
            ).pack(side="left")

    def _load(self, name):
        result = self.loader.load(name, self.app)
        self._out(f"[load] {name}: {result}")

    def _load_all(self):
        for p in self.loader.discover():
            name = p["name"]
            result = self.loader.load(name, self.app)
            self._out(f"[load] {name}: {result}")

    def _unload(self):
        self.loader.unload_all()
        self._out("[+] all plugins unloaded")

    def _unload_one(self, name):
        if name in self.loader.plugins:
            try:
                instance = self.loader.plugins[name]["instance"]
                if hasattr(instance, "unload"):
                    instance.unload()
            except Exception:
                pass
            del self.loader.plugins[name]
            self._out(f"[+] {name} unloaded")

    def _installed(self):
        loaded = self.loader.list_loaded()
        self._out(f"\n=== {len(loaded)} loaded plugins ===\n")
        for p in loaded:
            self._out(f"  {p['name']} (loaded at {p['loaded_at'][11:19]})")

    def _open_dir(self):
        import subprocess
        subprocess.Popen(["xdg-open", os.path.abspath("plugins")])
