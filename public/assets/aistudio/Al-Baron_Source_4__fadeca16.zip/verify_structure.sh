#!/bin/bash
# language: bash, file: verify_structure.sh
# يفحص البنية كاملة ويخبرك بالملفات الناقصة

cd "$(dirname "$0")"

echo "═══ Al-Baron — Structure Verification ═══"
echo ""

# ── قائمة كاملة بكل الملفات المطلوبة ──
REQUIRED_DIRS=(
    "core/ai/rl/hrl"
    "core/ai/rl/bayesian"
    "core/ai/rl/distributional"
    "core/ai/rl/meta"
    "core/ai/rl/world_model"
    "core/ai/rl/causal"
    "core/ai/rl/synthesis"
    "core/ai/rl/synthesis/generated"
    "core/ai/society"
    "core/ai/federated"
    "core/ai/formal/coq_runtime"
    "modules"
    "utils"
    "teamserver"
    "teamserver/adapters"
    "plugins/_sdk"
)

REQUIRED_INIT=(
    "core/__init__.py"
    "core/ai/__init__.py"
    "core/ai/rl/__init__.py"
    "core/ai/rl/hrl/__init__.py"
    "core/ai/rl/bayesian/__init__.py"
    "core/ai/rl/distributional/__init__.py"
    "core/ai/rl/meta/__init__.py"
    "core/ai/rl/world_model/__init__.py"
    "core/ai/rl/causal/__init__.py"
    "core/ai/rl/synthesis/__init__.py"
    "core/ai/society/__init__.py"
    "core/ai/federated/__init__.py"
    "core/ai/formal/__init__.py"
    "core/ai/formal/coq_runtime/__init__.py"
    "modules/__init__.py"
    "utils/__init__.py"
    "teamserver/__init__.py"
    "teamserver/adapters/__init__.py"
)

REQUIRED_PY=(
    # AI core
    "core/ai/embeddings.py"
    "core/ai/agents.py"
    "core/ai/tools.py"
    "core/ai/memory.py"
    "core/ai/offline.py"
    "core/ai/reflect.py"
    "core/ai/sessions.py"
    "core/ai/voice.py"
    "core/ai/collab.py"
    "core/ai/guardrails.py"
    "core/ai/autonomous.py"
    "core/ai/finetune.py"
    "core/ai/k8s_jobs.py"
    # RL core
    "core/ai/rl/reward.py"
    "core/ai/rl/replay.py"
    "core/ai/rl/policy.py"
    "core/ai/rl/trainer.py"
    # HRL
    "core/ai/rl/hrl/options.py"
    "core/ai/rl/hrl/manager.py"
    "core/ai/rl/hrl/worker.py"
    "core/ai/rl/hrl/intrinsic.py"
    # Bayesian
    "core/ai/rl/bayesian/ensemble.py"
    "core/ai/rl/bayesian/dropout.py"
    "core/ai/rl/bayesian/bbb.py"
    "core/ai/rl/bayesian/thompson.py"
    "core/ai/rl/bayesian/calibration.py"
    # Distributional
    "core/ai/rl/distributional/c51.py"
    "core/ai/rl/distributional/qr_dqn.py"
    "core/ai/rl/distributional/iqn.py"
    "core/ai/rl/distributional/risk.py"
    # Meta
    "core/ai/rl/meta/maml.py"
    "core/ai/rl/meta/reptile.py"
    "core/ai/rl/meta/task_sampler.py"
    # World model
    "core/ai/rl/world_model/rssm.py"
    "core/ai/rl/world_model/dreamer.py"
    "core/ai/rl/world_model/imagination.py"
    "core/ai/rl/world_model/decoder.py"
    # Causal
    "core/ai/rl/causal/scm.py"
    "core/ai/rl/causal/do_calculus.py"
    "core/ai/rl/causal/counterfactual.py"
    "core/ai/rl/causal/discovery.py"
    # Synthesis
    "core/ai/rl/synthesis/ir.py"
    "core/ai/rl/synthesis/extractor.py"
    "core/ai/rl/synthesis/python_gen.py"
    "core/ai/rl/synthesis/verifier.py"
    # Society
    "core/ai/society/debate.py"
    "core/ai/society/roles.py"
    "core/ai/society/consensus.py"
    "core/ai/society/transcript.py"
    # Federated
    "core/ai/federated/client.py"
    "core/ai/federated/server.py"
    "core/ai/federated/secure_agg.py"
    "core/ai/federated/coordinator.py"
    # Formal
    "core/ai/formal/model_checker.py"
    "core/ai/formal/coq_export.py"
    "core/ai/formal/invariants_runtime.py"
    "core/ai/formal/coq_runtime/wrapper.py"
    # Chat
    "core/ai_chat_drawer.py"
    "core/ai_assistant.py"
    # Modules (GUI)
    "modules/autonomous.py"
    "modules/research_console.py"
    "modules/rl_console.py"
    "modules/society.py"
    "modules/federated.py"
    "modules/formal.py"
)

# ── فحص ──
echo "── Directories ──"
MISSING_DIRS=0
for d in "${REQUIRED_DIRS[@]}"; do
    if [ -d "$d" ]; then
        echo "  ✓ $d"
    else
        echo "  ✗ $d  ← MISSING"
        MISSING_DIRS=$((MISSING_DIRS + 1))
    fi
done

echo ""
echo "── __init__.py files ──"
MISSING_INIT=0
for f in "${REQUIRED_INIT[@]}"; do
    if [ -f "$f" ]; then
        echo "  ✓ $f"
    else
        echo "  ✗ $f  ← MISSING"
        MISSING_INIT=$((MISSING_INIT + 1))
    fi
done

echo ""
echo "── Python files ──"
MISSING_PY=0
for f in "${REQUIRED_PY[@]}"; do
    if [ -f "$f" ]; then
        echo "  ✓ $f"
    else
        echo "  ✗ $f  ← MISSING"
        MISSING_PY=$((MISSING_PY + 1))
    fi
done

echo ""
echo "═══════════════════════════════════════"
echo "SUMMARY:"
echo "  missing dirs:  $MISSING_DIRS"
echo "  missing init:  $MISSING_INIT"
echo "  missing .py:   $MISSING_PY"
echo "═══════════════════════════════════════"
