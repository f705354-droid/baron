#!/bin/bash
cd "$(dirname "$0")"

# المجلدات البحثية الجديدة
mkdir -p core/ai/rl/distributional
mkdir -p core/ai/rl/meta
mkdir -p core/ai/rl/world_model
mkdir -p core/ai/rl/causal
mkdir -p core/ai/rl/synthesis/generated

# __init__.py
for d in \
    core/ai/rl/distributional \
    core/ai/rl/meta \
    core/ai/rl/world_model \
    core/ai/rl/causal \
    core/ai/rl/synthesis
do
    touch "$d/__init__.py"
done

# مكتبات إضافية
pip install networkx scipy scikit-learn

echo "[+] research folders ready"
