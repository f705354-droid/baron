# language: Python, file: modules/recon.py
# Al-Baron Recon Module — full UI + real nmap execution
import customtkinter as ctk
import threading
import subprocess
import re
import socket
import tkinter.simpledialog as sd
from core.executor import ToolExecutor

class ReconModule:
    def __init__(self, log_queue, progress_cb=None):
        self.log = log_queue
        self.progress_cb = progress_cb
        self.name = "recon"
        self.executor = ToolExecutor(log_queue, self._parse_output)
        self._parent = None
        self.out = None
        self.target_entry = None

    def render(self, parent):
        self._parent = parent

        ctk.CTkLabel(parent, text="RECONNAISSANCE", font=ctk.CTkFont(size=18, weight="bold"), text_color="#ffd700").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="target discovery · port scanning · service fingerprinting", font=ctk.CTkFont(size=11), text_color="#8a8a8a").pack(pady=(0, 16), padx=24, anchor="w")

        # Target form
        form = ctk.CTkFrame(parent, fg_color="transparent")
        form.pack(fill="x", padx=24)

        self.target_entry = ctk.CTkEntry(form, placeholder_text="target (ip / host / cidr)", width=320, height=38, fg_color="#05080c", border_color="#1a2332")
        self.target_entry.pack(side="left", padx=(0, 8))

        self.scan_type = ctk.CTkOptionMenu(form, values=["quick", "full", "stealth", "udp", "vuln"], width=120, fg_color="#1a2332", button_color="#1a2332")
        self.scan_type.pack(side="left", padx=(0, 8))

        ctk.CTkButton(form, text="▸ SCAN", width=100, height=38, fg_color="#2b2000", hover_color="#554400", text_color="#ffd700", command=self._run_nmap).pack(side="left")

        # Quick tools
        tools = ctk.CTkFrame(parent, fg_color="transparent")
        tools.pack(fill="x", padx=24, pady=(12, 0))
        for label, fn in [
            ("DNS enum", self._dns_enum),
            ("WHOIS", self._whois),
            ("Traceroute", self._traceroute),
            ("Subdomain sweep", self._subdomain),
        ]:
            ctk.CTkButton(tools, text=label, width=110, height=32, fg_color="#141a22", hover_color="#1a2332", font=ctk.CTkFont(size=11), command=fn).pack(side="left", padx=(0, 6))

        # Output Console
        ctk.CTkLabel(parent, text="Live Output:", font=ctk.CTkFont(size=12, weight="bold"), text_color="#c8d6e5").pack(pady=(16, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(parent, fg_color="#05080c", text_color="#ffd700", font=ctk.CTkFont(family="Consolas", size=10), height=400)
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 24))

    def _run_nmap(self):
        t = self.target_entry.get().strip()
        if not t: return
        mode = self.scan_type.get()
        flags = {
            "quick": "-sS -sV -T4 --top-ports 1000",
            "full": "-sS -sV -O -p- -T4",
            "stealth": "-sS -T2 --randomize-hosts --data-length 24 -f",
            "udp": "-sU --top-ports 100",
            "vuln": "-sS -sV --script vuln",
        }[mode]
        cmd = f"nmap {flags} {t}"
        
        if self.out: self.out.delete("1.0", "end")
        self._safe_out(f"[*] Running: {cmd}")
        
        if self.progress_cb: self.progress_cb("Nmap Scan", 1, 10)
        self.executor.run("nmap", cmd, self._on_scan_done)

    def _parse_output(self, line):
        if "About" in line and "%" in line:
            match = re.search(r"About ([\d.]+)%", line)
            if match and self.progress_cb:
                pct = float(match.group(1)) / 10
                self.progress_cb("Nmap Scan", int(pct), 10)

    def _on_scan_done(self, full_output):
        if self.progress_cb: self.progress_cb("Nmap Scan", 10, 10)
        self._safe_out("\n[+] SCAN COMPLETED.")

    def _dns_enum(self):
        t = self.target_entry.get().strip()
        if t:
            self._safe_out(f"[*] DNS enum on {t}...")
            self.executor.run("dns", f"nslookup {t}")

    def _whois(self):
        t = self.target_entry.get().strip()
        if t:
            self._safe_out(f"[*] WHOIS on {t}...")
            self.executor.run("whois", f"whois {t}")

    def _traceroute(self):
        t = self.target_entry.get().strip()
        if t:
            self._safe_out(f"[*] Traceroute to {t}...")
            self.executor.run("trace", f"traceroute {t}")

    def _subdomain(self):
        t = self.target_entry.get().strip()
        if not t: return
        self._safe_out(f"[*] Subdomain sweep on {t}...")
        def sweep():
            common = ["www", "mail", "ftp", "admin", "api", "dev", "staging", "test", "vpn"]
            for sub in common:
                host = f"{sub}.{t}"
                try:
                    ip = socket.gethostbyname(host)
                    self._safe_out(f"[+] {host} → {ip}")
                except socket.gaierror:
                    pass
        threading.Thread(target=sweep, daemon=True).start()

    def _safe_out(self, text):
        if not self._parent: return
        def _u():
            if self.out and self.out.winfo_exists():
                self.out.insert("end", text + "\n")
                self.out.see("end")
        self._parent.after(0, _u)
