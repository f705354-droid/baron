# language: Python, file: modules/siem.py
# SIEM feed — live events, alert correlation, auto-adjustment
import customtkinter as ctk
import threading
import asyncio
import os
import json
from teamserver.siem import siem_forwarder


class SIEMModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "siem"
        self.events = []

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="SIEM FEED",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="Splunk · Sentinel · Elastic — outbound + feedback loop",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r1 = ctk.CTkFrame(cfg, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=8)
        self.splunk = ctk.CTkEntry(r1, placeholder_text="Splunk HEC URL",
                                    width=260, height=32,
                                    fg_color="#05080c", border_color="#1a2332")
        self.splunk.insert(0, os.getenv("SPLUNK_HEC_URL", ""))
        self.splunk.pack(side="left", padx=(0, 6))
        self.splunk_tok = ctk.CTkEntry(r1, placeholder_text="HEC token",
                                        width=220, height=32, show="*",
                                        fg_color="#05080c", border_color="#1a2332")
        self.splunk_tok.pack(side="left", padx=(0, 6))
        self.sentinel_ws = ctk.CTkEntry(r1, placeholder_text="Sentinel workspace",
                                         width=220, height=32,
                                         fg_color="#05080c", border_color="#1a2332")
        self.sentinel_ws.pack(side="left", padx=(0, 6))
        ctk.CTkButton(r1, text="▸ Save", width=90, height=32,
                      fg_color="#0d2818", hover_color="#1a4a2e",
                      text_color="#00ff9c",
                      command=self._save).pack(side="left")

        # ---- actions ----
        ctk.CTkLabel(parent, text="Operations:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        grid = ctk.CTkFrame(parent, fg_color="transparent")
        grid.pack(fill="x", padx=24)
        actions = [
            ("▸ Test Splunk", self._test_splunk),
            ("▸ Test Sentinel", self._test_sentinel),
            ("▸ Send test event", self._test_event),
            ("▸ Pull alerts (15m)", self._pull),
            ("▸ Pull alerts (1h)", self._pull_hour),
            ("▸ Auto-respond", self._auto),
            ("▸ Firewall rules", self._firewall),
            ("▸ Whitelist patterns", self._whitelist),
        ]
        for i, (label, fn) in enumerate(actions):
            ctk.CTkButton(
                grid, text=label, width=200, height=32,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).grid(row=i // 4, column=i % 4, padx=4, pady=4)

        ctk.CTkLabel(parent, text="Events / Alerts:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10)
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _save(self):
        os.environ["SPLUNK_HEC_URL"] = self.splunk.get().strip()
        os.environ["SPLUNK_HEC_TOKEN"] = self.splunk_tok.get().strip()
        os.environ["SENTINEL_WORKSPACE_ID"] = self.sentinel_ws.get().strip()
        import importlib
        from teamserver import siem
        importlib.reload(siem)
        self._out("[+] saved SIEM config")

    def _run_async(self, coro_fn, label):
        def run():
            try:
                result = asyncio.run(coro_fn())
                if isinstance(result, (dict, list)):
                    self._out(f"\n=== {label} ===\n" +
                              json.dumps(result, indent=2, default=str)[:8000])
                else:
                    self._out(f"\n=== {label} ===\n{result}")
            except Exception as e:
                self._out(f"[!] {e}")
        threading.Thread(target=run, daemon=True).start()

    def _test_splunk(self):
        async def fn():
            await siem_forwarder._splunk_send({
                "test": True, "src": "albaron-test"})
            return "sent (check Splunk index)"
        self._run_async(fn, "test splunk")

    def _test_sentinel(self):
        async def fn():
            await siem_forwarder._sentinel_send({
                "test": True, "source": "albaron", "timestamp": "now"})
            return "sent (check Log Analytics)"
        self._run_async(fn, "test sentinel")

    def _test_event(self):
        async def fn():
            await siem_forwarder.emit({
                "event_type": "test", "tenant_id": "test",
                "source": "albaron", "message": "hello SIEM"})
            return "event queued"
        self._run_async(fn, "test event")

    def _pull(self):
        async def fn():
            return await siem_forwarder.pull_alerts(since_minutes=15)
        self._run_async(fn, "alerts 15m")

    def _pull_hour(self):
        async def fn():
            return await siem_forwarder.pull_alerts(since_minutes=60)
        self._run_async(fn, "alerts 1h")

    def _auto(self):
        async def fn():
            alerts = await siem_forwarder.pull_alerts(since_minutes=60)
            actions = []
            async for a in siem_forwarder.react_to_alerts(alerts):
                actions.append(a)
            return actions
        self._run_async(fn, "auto-response")

    def _firewall(self):
        self._out("""
=== Firewall-aware C2 ===
Splunk query to detect our beacons:
  index=fw action=allowed dest_port=443
  | stats count by src_ip, dest_ip, bytes_out
  | where bytes_out < 5000 AND count > 20
  → these are beacon patterns

Counter-evasion tactics:
  - Beacon with realistic HTTPS (Mozilla UA, ~30KB payloads)
  - Random jitter ±40%
  - Domain fronting
  - Server name whitelist from top 1000 domains
  - Rotate C2 IPs every 4h (use CDN like Fastly/Cloudflare)
""")

    def _whitelist(self):
        self._out("""
=== Whitelist patterns — avoid tripping common SIEM rules ===
Common rules that catch naive C2:
  1. "Periodic DNS to unusual domain"
  2. "TLS with self-signed cert"
  3. "Long-lived HTTP without user activity"
  4. "Beacon interval within 10% jitter"

Patterns to blend:
  - Match average enterprise traffic profile (Microsoft, Google, AWS)
  - Random beacon 30s-300s
  - Download real content (weather API, news RSS) as cover traffic
  - Route through legit CDN
  - Use DoH/DoT for DNS
""")
