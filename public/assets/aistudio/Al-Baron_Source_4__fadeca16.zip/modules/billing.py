# language: Python, file: modules/billing.py
# Billing dashboard — plans, usage, invoices, Stripe portal
import customtkinter as ctk
import threading
import asyncio
import os
import webbrowser
import json
import asyncpg
from teamserver.billing import BillingManager, PLANS


class BillingModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "billing"
        self.manager = None

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="BILLING",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="plans · usage metering · invoices · Stripe portal",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ---- tenant picker ----
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r1 = ctk.CTkFrame(cfg, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=8)
        self.tid = ctk.CTkEntry(r1, placeholder_text="tenant id",
                                 width=340, height=32,
                                 fg_color="#05080c", border_color="#1a2332")
        self.tid.pack(side="left", padx=(0, 6))
        ctk.CTkButton(r1, text="▸ Load", width=100, height=32,
                      fg_color="#0d2818", hover_color="#1a4a2e",
                      text_color="#00ff9c",
                      command=self._load).pack(side="left", padx=(0, 6))
        ctk.CTkButton(r1, text="▸ Open Stripe portal", width=180, height=32,
                      fg_color="#141a22", hover_color="#1a2332",
                      command=self._portal).pack(side="left")

        # ---- plans grid ----
        ctk.CTkLabel(parent, text="Plans:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        plans_frame = ctk.CTkFrame(parent, fg_color="transparent")
        plans_frame.pack(fill="x", padx=24)
        for i, (name, cfg) in enumerate(PLANS.items()):
            card = ctk.CTkFrame(plans_frame, fg_color="#0d1319",
                                 corner_radius=6, width=260)
            card.grid(row=0, column=i, padx=8, pady=4, sticky="nsew")
            card.grid_propagate(False)
            ctk.CTkLabel(card, text=name.upper(),
                          font=ctk.CTkFont(size=14, weight="bold"),
                          text_color="#00ff9c").pack(pady=(12, 4))
            ctk.CTkLabel(card, text=f"${cfg['monthly_usd']}/mo",
                          font=ctk.CTkFont(size=20, weight="bold"),
                          text_color="#7dffb0").pack()
            for line in [f"{cfg['max_sessions']} sessions",
                          f"{cfg['max_operators']} operators",
                          f"{cfg['max_workers']} workers"]:
                ctk.CTkLabel(card, text=line,
                              font=ctk.CTkFont(size=10),
                              text_color="#c8d6e5").pack(anchor="w", padx=12)
            ctk.CTkButton(card, text="▸ Subscribe", width=200, height=32,
                          fg_color="#0d2818", hover_color="#1a4a2e",
                          text_color="#00ff9c",
                          command=lambda n=name: self._subscribe(n)
                          ).pack(pady=8)

        # ---- usage ----
        ctk.CTkLabel(parent, text="Usage (last 30d):",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.usage_box = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=180
        )
        self.usage_box.pack(fill="x", padx=24)

        ctk.CTkLabel(parent, text="Events:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(8, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=140
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    async def _get_manager(self):
        if not self.manager:
            dsn = os.getenv("AL-BARON_DSN",
                            "postgresql://shadow:shadow@postgres:5432/albaron")
            pool = await asyncpg.create_pool(dsn, min_size=1, max_size=4)
            self.manager = BillingManager(pool)
        return self.manager

    def _run_async(self, coro_fn, label):
        def run():
            try:
                result = asyncio.run(coro_fn())
                if isinstance(result, (dict, list)):
                    self._out(f"\n=== {label} ===\n" +
                              json.dumps(result, indent=2, default=str)[:8000])
                else:
                    self._out(f"\n=== {label} ===\n{result}")
            except Exception as e:
                self._out(f"[!] {e}")
        threading.Thread(target=run, daemon=True).start()

    def _load(self):
        tid = self.tid.get().strip()
        if not tid:
            return
        async def fn():
            m = await self._get_manager()
            usage = await m.get_usage_summary(tid)
            return usage
        def on_done():
            pass
        def run():
            try:
                result = asyncio.run(fn())
                self.usage_box.delete("1.0", "end")
                self.usage_box.insert("end", json.dumps(result, indent=2))
                self._out(f"[+] loaded tenant {tid}")
            except Exception as e:
                self._out(f"[!] {e}")
        threading.Thread(target=run, daemon=True).start()

    def _subscribe(self, plan):
        tid = self.tid.get().strip()
        if not tid:
            self._out("[!] enter tenant id first")
            return
        async def fn():
            m = await self._get_manager()
            url = await m.create_checkout(
                tid, plan,
                success_url="https://ops.your-c2.com/billing/success",
                cancel_url="https://ops.your-c2.com/billing/cancel",
            )
            return url
        def run():
            try:
                url = asyncio.run(fn())
                self._out(f"[+] checkout url: {url}")
                webbrowser.open(url)
            except Exception as e:
                self._out(f"[!] {e}")
        threading.Thread(target=run, daemon=True).start()

    def _portal(self):
        tid = self.tid.get().strip()
        if not tid:
            return
        async def fn():
            m = await self._get_manager()
            url = await m.create_portal(
                tid, return_url="https://ops.your-c2.com/billing")
            return url
        def run():
            try:
                url = asyncio.run(fn())
                webbrowser.open(url)
            except Exception as e:
                self._out(f"[!] {e}")
        threading.Thread(target=run, daemon=True).start()
