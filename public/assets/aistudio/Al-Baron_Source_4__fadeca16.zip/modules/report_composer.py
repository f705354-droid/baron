# language: Python, file: modules/report_composer.py
# Report Composer UI
import customtkinter as ctk
from core.composer.report_builder import ReportComposer


class ReportComposerModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "report_composer"
        self.app = app
        self.composer = ReportComposer()

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="REPORT COMPOSER",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="visual composer · build PDF from graph",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ── metadata ──
        meta_frame = ctk.CTkFrame(parent, fg_color="#0d1319",
                                    corner_radius=6)
        meta_frame.pack(fill="x", padx=24)
        r = ctk.CTkFrame(meta_frame, fg_color="transparent")
        r.pack(fill="x", padx=12, pady=8)

        self.client_entry = ctk.CTkEntry(
            r, placeholder_text="client name", width=180, height=30,
            fg_color="#05080c", border_color="#1a2332")
        self.client_entry.pack(side="left", padx=(0, 6))

        self.tester_entry = ctk.CTkEntry(
            r, placeholder_text="tester", width=150, height=30,
            fg_color="#05080c", border_color="#1a2332")
        self.tester_entry.pack(side="left", padx=(0, 6))

        self.classification = ctk.CTkOptionMenu(
            r, values=["CONFIDENTIAL", "INTERNAL", "PUBLIC"],
            width=140, height=30, fg_color="#1a2332",
            button_color="#1a2332")
        self.classification.pack(side="left")

        # ── actions ──
        ctk.CTkLabel(parent, text="Sections:",
                      font=ctk.CTkFont(size=12, weight="bold"),
                      text_color="#c8d6e5").pack(
            pady=(16, 4), padx=24, anchor="w")

        grid = ctk.CTkFrame(parent, fg_color="transparent")
        grid.pack(fill="x", padx=24)
        for label, fn in [
            ("+ Executive Summary", lambda: self._add("Executive Summary", "text", "Summary of engagement findings.")),
            ("+ Methodology", lambda: self._add("Methodology", "text", "Approach and tools used.")),
            ("+ Graph Summary", lambda: self._add("Graph Summary", "graph")),
            ("+ Findings", self._add_findings),
            ("+ Recommendations", lambda: self._add("Recommendations", "text", "Prioritized remediation steps.")),
            ("+ Custom text", self._add_custom),
            ("+ Hosts table", self._add_hosts_table),
        ]:
            ctk.CTkButton(
                grid, text=label, width=200, height=32,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).pack(side="left", padx=(0, 4), pady=4)

        # ── render buttons ──
        r_row = ctk.CTkFrame(parent, fg_color="transparent")
        r_row.pack(fill="x", padx=24, pady=(12, 12))
        for label, fn in [
            ("▤ Auto-populate (full)", lambda: self._autopop("full")),
            ("▤ Auto (executive)", lambda: self._autopop("executive")),
            ("▤ Auto (technical)", lambda: self._autopop("technical")),
            ("⚡ Render PDF", self._render),
            ("▸ Preview sections", self._preview),
        ]:
            ctk.CTkButton(
                r_row, text=label, width=180, height=34,
                fg_color="#0d2818", hover_color="#1a4a2e",
                text_color="#00ff9c",
                font=ctk.CTkFont(size=11), command=fn
            ).pack(side="left", padx=(0, 4))

        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=350
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _add(self, title, kind, data=None):
        self.composer.add_section(title, kind, data)
        self._out(f"[+] {title} ({kind})")

    def _add_findings(self):
        from core.graph.graph_db import graph
        findings = []
        for h in graph.list_nodes("host"):
            for v in graph.neighbors("host", h["key"],
                                       edge_type="vulnerable_to",
                                       direction="out"):
                findings.append({
                    "severity": "high",
                    "title": f"{v['key']} on {h['key']}",
                })
        self.composer.add_section("Findings", "findings", findings)
        self._out(f"[+] Findings ({len(findings)})")

    def _add_custom(self):
        import tkinter.simpledialog as sd
        title = sd.askstring("Title", "Section title:")
        if not title:
            return
        content = sd.askstring("Content", "Section content:")
        self._add(title, "text", content or "")

    def _add_hosts_table(self):
        from core.graph.graph_db import graph
        hosts = graph.list_nodes("host")
        rows = [[h["key"], h["properties"].get("hostname", ""),
                  h["properties"].get("os", "")]
                 for h in hosts]
        self.composer.add_section("Hosts", "table", {
            "headers": ["IP", "Hostname", "OS"],
            "rows": rows,
        })
        self._out(f"[+] Hosts table ({len(rows)} rows)")

    def _autopop(self, template):
        self.composer.set_metadata(
            client=self.client_entry.get(),
            tester=self.tester_entry.get(),
            classification=self.classification.get(),
        )
        self.composer.auto_populate(template)
        self._out(f"[+] auto-populated ({template}) with "
                   f"{len(self.composer.sections)} sections")

    def _render(self):
        import tkinter.filedialog as fd
        path = fd.asksaveasfilename(
            defaultextension=".pdf",
            initialfile=f"report_{self.client_entry.get() or 'albaron'}.pdf")
        if not path:
            return
        self.composer.set_metadata(
            client=self.client_entry.get(),
            tester=self.tester_entry.get(),
            classification=self.classification.get(),
        )
        result = self.composer.render_pdf(path)
        self._out(f"[+] {result}")

    def _preview(self):
        self.out.delete("1.0", "end")
        self._out(f"=== {len(self.composer.sections)} sections ===")
        for i, s in enumerate(self.composer.sections):
            self._out(f"  {i+1}. {s.title} ({s.kind})")
