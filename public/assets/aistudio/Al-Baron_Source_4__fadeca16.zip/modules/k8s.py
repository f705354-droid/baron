# language: Python, file: modules/k8s.py
# Kubernetes deployment + scale management from the GUI
import customtkinter as ctk
import threading
import subprocess
import os
import yaml
import time


class K8sModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "k8s"

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="KUBERNETES OPS",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="cluster deploy · scale · logs · exec · port-forward",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r1 = ctk.CTkFrame(cfg, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=8)
        self.ns_e = ctk.CTkEntry(r1, placeholder_text="namespace",
                                 width=160, height=32,
                                 fg_color="#05080c", border_color="#1a2332")
        self.ns_e.insert(0, "albaron")
        self.ns_e.pack(side="left", padx=(0, 6))
        self.kubeconfig = ctk.CTkEntry(r1, placeholder_text="kubeconfig path (blank = default)",
                                       width=300, height=32,
                                       fg_color="#05080c", border_color="#1a2332")
        self.kubeconfig.pack(side="left", padx=(0, 6))
        self.context = ctk.CTkEntry(r1, placeholder_text="context",
                                    width=180, height=32,
                                    fg_color="#05080c", border_color="#1a2332")
        self.context.pack(side="left")

        actions = ctk.CTkFrame(parent, fg_color="transparent")
        actions.pack(fill="x", padx=24, pady=12)
        for label, fn in [
            ("▸ Deploy all", self._deploy_all),
            ("▸ Status", self._status),
            ("▸ Pods", self._pods),
            ("▸ Services", self._svcs),
            ("▸ Scale up", self._scale_up),
            ("▸ Scale down", self._scale_down),
            ("▸ Logs teamserver", self._logs_ts),
            ("▸ Logs worker", self._logs_worker),
            ("▸ Exec shell", self._exec_shell),
            ("▸ Port-forward", self._port_forward),
            ("▸ Delete stack", self._delete),
        ]:
            ctk.CTkButton(actions, text=label, width=150, height=32,
                          fg_color="#141a22", hover_color="#1a2332",
                          font=ctk.CTkFont(size=10), command=fn
                          ).pack(side="left", padx=(0, 4))

        ctk.CTkLabel(parent, text="Output:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(8, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10)
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _kubectl(self, args, raw=False):
        cmd = ["kubectl"]
        kc = self.kubeconfig.get().strip()
        if kc:
            cmd += ["--kubeconfig", kc]
        ctx = self.context.get().strip()
        if ctx:
            cmd += ["--context", ctx]
        cmd += args
        self._out(f"$ {' '.join(cmd)}")
        try:
            p = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            out = p.stdout + p.stderr
            self._out(out)
            self.log.put(f"[k8s] {' '.join(args[:3])}")
            return out
        except Exception as e:
            self._out(f"[!] {e}")
            return str(e)

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _deploy_all(self):
        ns = self.ns_e.get().strip()
        k8s_dir = "k8s"
        if not os.path.isdir(k8s_dir):
            self._out("[!] k8s/ directory not found")
            return
        def run():
            self._kubectl(["create", "namespace", ns])
            for f in sorted(os.listdir(k8s_dir)):
                if f.endswith(".yaml"):
                    path = os.path.join(k8s_dir, f)
                    self._kubectl(["apply", "-f", path])
            self._kubectl(["-n", ns, "get", "all"])
        threading.Thread(target=run, daemon=True).start()

    def _status(self):
        ns = self.ns_e.get().strip()
        self._kubectl(["-n", ns, "get", "pods,svc,deploy,sts,hpa,ing"])

    def _pods(self):
        ns = self.ns_e.get().strip()
        self._kubectl(["-n", ns, "get", "pods", "-o", "wide"])

    def _svcs(self):
        ns = self.ns_e.get().strip()
        self._kubectl(["-n", ns, "get", "svc"])

    def _scale_up(self):
        ns = self.ns_e.get().strip()
        for dep, n in [("worker", 20), ("teamserver", 5)]:
            self._kubectl(["-n", ns, "scale", "deploy", dep, f"--replicas={n}"])

    def _scale_down(self):
        ns = self.ns_e.get().strip()
        for dep in ["worker", "teamserver"]:
            self._kubectl(["-n", ns, "scale", "deploy", dep, "--replicas=1"])

    def _logs_ts(self):
        ns = self.ns_e.get().strip()
        self._kubectl(["-n", ns, "logs", "-l", "app=teamserver",
                       "--tail=200", "--prefix=true"])

    def _logs_worker(self):
        ns = self.ns_e.get().strip()
        self._kubectl(["-n", ns, "logs", "-l", "app=worker",
                       "--tail=200", "--prefix=true"])

    def _exec_shell(self):
        ns = self.ns_e.get().strip()
        # exec into first teamserver pod
        def run():
            out = self._kubectl(["-n", ns, "get", "pods", "-l", "app=teamserver",
                                 "-o", "jsonpath={.items[0].metadata.name}"])
            pod = out.strip().split("\n")[-1]
            if pod:
                subprocess.Popen([
                    "x-terminal-emulator", "-e",
                    f"kubectl -n {ns} exec -it {pod} -- /bin/bash"
                ])
        threading.Thread(target=run, daemon=True).start()

    def _port_forward(self):
        ns = self.ns_e.get().strip()
        subprocess.Popen([
            "x-terminal-emulator", "-e",
            f"kubectl -n {ns} port-forward svc/teamserver 8000:8000"
        ])
        self._out("[+] port-forward 8000 → localhost:8000")

    def _delete(self):
        ns = self.ns_e.get().strip()
        if not ctk.messagebox.askyesno("Delete", f"Delete namespace {ns}?"):
            return
        self._kubectl(["delete", "namespace", ns])
