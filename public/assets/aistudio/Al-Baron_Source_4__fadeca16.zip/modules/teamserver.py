# language: Python, file: modules/teamserver.py
# Team Server — multi-operator collaboration backend
import customtkinter as ctk
import threading
import asyncio
import json
import os
import hashlib
import uuid
from datetime import datetime, timedelta
from typing import Dict, Set, List


# ═══════════════════════════════════════════════════════════════════
# TeamServer — WebSocket + JWT + RBAC
# ═══════════════════════════════════════════════════════════════════
class TeamServer:
    def __init__(self, log_queue=None, host="0.0.0.0", port=8000):
        self.log = log_queue
        self.host = host
        self.port = port
        self.users = {}
        self.tokens = {}
        self.ws_connections = {}  # username → set of WebSocket
        self.messages = []
        self.findings = []
        self.running = False
        self._app = None
        self._thread = None

    def _out(self, text):
        if self.log:
            self.log.put(f"[team] {text}")

    # ==================== users ====================
    def add_user(self, username, password, role="operator"):
        self.users[username] = {
            "username": username,
            "password_hash": hashlib.sha256(password.encode()).hexdigest(),
            "role": role,
            "created": datetime.now().isoformat(),
        }
        self._out(f"user added: {username} ({role})")

    def authenticate(self, username, password):
        u = self.users.get(username)
        if not u:
            return None
        if u["password_hash"] != hashlib.sha256(password.encode()).hexdigest():
            return None
        token = str(uuid.uuid4())
        self.tokens[token] = {
            "user": username,
            "role": u["role"],
            "exp": (datetime.now() + timedelta(hours=24)).timestamp(),
        }
        return token

    def check_token(self, token):
        t = self.tokens.get(token)
        if not t:
            return None
        if t["exp"] < datetime.now().timestamp():
            self.tokens.pop(token, None)
            return None
        return t

    # ==================== server ====================
    def start(self):
        """starts FastAPI in background thread"""
        try:
            from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Request
            from fastapi.middleware.cors import CORSMiddleware
            from fastapi.security import OAuth2PasswordRequestForm
            from fastapi import Depends
            import uvicorn
        except ImportError:
            self._out("install: pip install fastapi uvicorn")
            return

        server = self
        app = FastAPI(title="Al-Baron TeamServer")

        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_methods=["*"],
            allow_headers=["*"],
        )

        @app.post("/api/login")
        async def login(form: OAuth2PasswordRequestForm = Depends()):
            token = server.authenticate(form.username, form.password)
            if not token:
                raise HTTPException(401, "invalid creds")
            return {"access_token": token, "token_type": "bearer"}

        @app.get("/api/users")
        async def list_users(request: Request):
            token = request.headers.get("Authorization", "").replace(
                "Bearer ", "")
            if not server.check_token(token):
                raise HTTPException(401)
            return [{"username": u["username"], "role": u["role"]}
                    for u in server.users.values()]

        @app.get("/api/messages")
        async def get_messages(request: Request):
            token = request.headers.get("Authorization", "").replace(
                "Bearer ", "")
            if not server.check_token(token):
                raise HTTPException(401)
            return server.messages[-100:]

        @app.get("/api/findings")
        async def get_findings(request: Request):
            token = request.headers.get("Authorization", "").replace(
                "Bearer ", "")
            if not server.check_token(token):
                raise HTTPException(401)
            return server.findings[-100:]

        @app.websocket("/ws/operator")
        async def ws_operator(ws: WebSocket, token: str):
            info = server.check_token(token)
            if not info:
                await ws.close(code=4001)
                return

            username = info["user"]
            await ws.accept()
            server.ws_connections.setdefault(username, set()).add(ws)

            # broadcast join
            await server._broadcast({
                "type": "operator_joined",
                "user": username,
                "time": datetime.now().isoformat(),
            })

            try:
                while True:
                    data = await ws.receive_json()
                    msg_type = data.get("type")

                    if msg_type == "chat":
                        msg = {
                            "type": "chat",
                            "from": username,
                            "text": data.get("text", "")[:2000],
                            "time": datetime.now().isoformat(),
                        }
                        server.messages.append(msg)
                        await server._broadcast(msg)

                    elif msg_type == "finding":
                        finding = {
                            "type": "finding",
                            "from": username,
                            "finding": data.get("finding", {}),
                            "time": datetime.now().isoformat(),
                        }
                        server.findings.append(finding)
                        await server._broadcast(finding)

                    elif msg_type == "cursor":
                        await server._broadcast({
                            "type": "cursor",
                            "user": username,
                            "x": data.get("x", 0),
                            "y": data.get("y", 0),
                            "time": datetime.now().isoformat(),
                        })

                    elif msg_type == "ping":
                        await ws.send_json({"type": "pong"})

            except WebSocketDisconnect:
                pass
            finally:
                server.ws_connections[username].discard(ws)
                if not server.ws_connections[username]:
                    del server.ws_connections[username]
                await server._broadcast({
                    "type": "operator_left",
                    "user": username,
                    "time": datetime.now().isoformat(),
                })

        @app.get("/api/health")
        async def health():
            return {
                "status": "ok",
                "operators": len(server.ws_connections),
                "users": len(server.users),
            }

        self._app = app
        self.running = True

        def run():
            uvicorn.run(app, host=self.host, port=self.port,
                        log_level="warning")

        self._thread = threading.Thread(target=run, daemon=True)
        self._thread.start()
        self._out(f"TeamServer listening on {self.host}:{self.port}")

    def stop(self):
        self.running = False
        self._out("TeamServer stopped")

    async def _broadcast(self, message):
        dead = []
        for user, conns in list(self.ws_connections.items()):
            for ws in list(conns):
                try:
                    await ws.send_json(message)
                except Exception:
                    dead.append((user, ws))
        for u, w in dead:
            self.ws_connections[u].discard(w)

    def broadcast_sync(self, message):
        """broadcast من threads غير async"""
        if not self._app:
            return
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop.run_until_complete(self._broadcast(message))
            loop.close()
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════════════
# Module UI
# ═══════════════════════════════════════════════════════════════════
class TeamServerModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "teamserver"
        self.app = app
        self.server = TeamServer(log_queue)
        self.refresh_timer = None

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="TEAM SERVER",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="WebSocket · multi-operator · JWT · RBAC",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # Server config
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r = ctk.CTkFrame(cfg, fg_color="transparent")
        r.pack(fill="x", padx=12, pady=8)

        ctk.CTkLabel(r, text="Bind:",
                     font=ctk.CTkFont(size=11),
                     text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.host_entry = ctk.CTkEntry(r, width=160, height=30,
                                        fg_color="#05080c",
                                        border_color="#1a2332")
        self.host_entry.insert(0, "0.0.0.0")
        self.host_entry.pack(side="left", padx=(0, 8))

        ctk.CTkLabel(r, text="Port:",
                     font=ctk.CTkFont(size=11),
                     text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.port_entry = ctk.CTkEntry(r, width=80, height=30,
                                        fg_color="#05080c",
                                        border_color="#1a2332")
        self.port_entry.insert(0, "8000")
        self.port_entry.pack(side="left", padx=(0, 8))

        ctk.CTkButton(r, text="▶ Start Server", width=140, height=30,
                      fg_color="#0d2818", hover_color="#1a4a2e",
                      text_color="#00ff9c",
                      command=self._start).pack(side="left", padx=(0, 4))

        ctk.CTkButton(r, text="■ Stop", width=90, height=30,
                      fg_color="#4a1a1a", hover_color="#6b1a1a",
                      text_color="#ff6b6b",
                      command=self._stop).pack(side="left")

        # User management
        user_cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        user_cfg.pack(fill="x", padx=24, pady=(8, 0))
        ur = ctk.CTkFrame(user_cfg, fg_color="transparent")
        ur.pack(fill="x", padx=12, pady=8)

        ctk.CTkLabel(ur, text="Add user — Username:",
                     font=ctk.CTkFont(size=11),
                     text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.new_user_entry = ctk.CTkEntry(ur, width=140, height=30,
                                            fg_color="#05080c",
                                            border_color="#1a2332")
        self.new_user_entry.pack(side="left", padx=(0, 4))

        ctk.CTkLabel(ur, text="Password:",
                     font=ctk.CTkFont(size=11),
                     text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.new_pass_entry = ctk.CTkEntry(ur, width=140, height=30,
                                            show="*",
                                            fg_color="#05080c",
                                            border_color="#1a2332")
        self.new_pass_entry.pack(side="left", padx=(0, 4))

        ctk.CTkLabel(ur, text="Role:",
                     font=ctk.CTkFont(size=11),
                     text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.role_selector = ctk.CTkOptionMenu(
            ur, values=["admin", "operator", "analyst", "viewer"],
            width=120, height=30, fg_color="#1a2332",
            button_color="#1a2332")
        self.role_selector.pack(side="left", padx=(0, 8))

        ctk.CTkButton(ur, text="+ Add User", width=120, height=30,
                      fg_color="#141a22", hover_color="#1a2332",
                      command=self._add_user).pack(side="left")

        # Quick actions
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24, pady=(8, 12))
        for label, fn in [
            ("▸ List users", self._list_users),
            ("▸ Active operators", self._list_operators),
            ("▸ Recent messages", self._recent_messages),
            ("▸ Broadcast message", self._broadcast_msg),
            ("▸ Add sample users", self._add_samples),
        ]:
            ctk.CTkButton(row, text=label, width=180, height=34,
                          fg_color="#141a22", hover_color="#1a2332",
                          font=ctk.CTkFont(size=11),
                          command=fn).pack(side="left", padx=(0, 4))

        # Status + output
        self.summary_label = ctk.CTkLabel(
            parent, text="Status: not started   |   Users: 0   |   Operators: 0",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#00ff9c")
        self.summary_label.pack(pady=(8, 4), padx=24, anchor="w")

        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=400
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _start(self):
        try:
            host = self.host_entry.get().strip()
            port = int(self.port_entry.get())
        except ValueError:
            self._out("[!] invalid port")
            return

        self.server.host = host
        self.server.port = port
        self.server.start()
        self._out(f"[+] TeamServer starting on {host}:{port}")
        self._refresh_status()

    def _stop(self):
        self.server.stop()
        self._out("[■] TeamServer stopped")
        self._refresh_status()

    def _add_user(self):
        username = self.new_user_entry.get().strip()
        password = self.new_pass_entry.get().strip()
        role = self.role_selector.get()

        if not username or not password:
            self._out("[!] username + password required")
            return

        self.server.add_user(username, password, role)
        self._out(f"[+] user added: {username} ({role})")
        self.new_user_entry.delete(0, "end")
        self.new_pass_entry.delete(0, "end")
        self._refresh_status()

    def _add_samples(self):
        samples = [
            ("admin", "admin", "admin"),
            ("operator1", "operator", "operator"),
            ("analyst1", "analyst", "analyst"),
            ("viewer1", "viewer", "viewer"),
        ]
        for user, pwd, role in samples:
            if user not in self.server.users:
                self.server.add_user(user, pwd, role)
        self._out(f"[+] added sample users")
        self._refresh_status()

    def _list_users(self):
        if not self.server.users:
            self._out("no users — add some first")
            return
        self._out(f"\n=== {len(self.server.users)} users ===")
        for u in self.server.users.values():
            self._out(f"  {u['username']:<20} {u['role']:<10} "
                      f"({u['created'][:19]})")

    def _list_operators(self):
        ops = list(self.server.ws_connections.keys())
        self._out(f"\n=== {len(ops)} active operators ===")
        for op in ops:
            conns = len(self.server.ws_connections[op])
            self._out(f"  {op} ({conns} connections)")

    def _recent_messages(self):
        if not self.server.messages:
            self._out("no messages yet")
            return
        self._out(f"\n=== last {min(20, len(self.server.messages))} messages ===")
        for msg in self.server.messages[-20:]:
            self._out(f"[{msg['time'][11:19]}] {msg['from']}: {msg['text'][:100]}")

    def _broadcast_msg(self):
        import tkinter.simpledialog as sd
        msg = sd.askstring("Broadcast", "Message:")
        if not msg:
            return

        event = {
            "type": "system_broadcast",
            "text": msg,
            "time": datetime.now().isoformat(),
        }
        self.server.messages.append({
            "from": "SYSTEM",
            "text": msg,
            "time": event["time"],
        })
        self.server.broadcast_sync(event)
        self._out(f"[+] broadcast sent: {msg}")

    def _refresh_status(self):
        state = "running" if self.server.running else "stopped"
        self.summary_label.configure(
            text=f"Status: {state}   |   "
                 f"Users: {len(self.server.users)}   |   "
                 f"Operators: {len(self.server.ws_connections)}")

        if self.refresh_timer:
            self.after_cancel(self.refresh_timer)
        self.refresh_timer = self.after(3000, self._refresh_status)


# Module exposes helper to attach to Tkinter callbacks
def _attach_after(module):
    """helper for after() in non-widget context"""
    if hasattr(module, "after"):
        return
    # in modules, self.after is available from widget inheritance
    pass
