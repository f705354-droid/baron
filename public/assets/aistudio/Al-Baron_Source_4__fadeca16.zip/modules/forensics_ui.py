# language: Python, file: modules/forensics_ui.py
# Al-Baron Forensics Module — analyze loot
import customtkinter as ctk
import threading
import os
import json
import hashlib
import re

class ForensicsModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "forensics"
        self.app = app
        self._parent = None
        self.out = None

    def render(self, parent):
        self._parent = parent
        ctk.CTkLabel(parent, text="FORENSICS", font=ctk.CTkFont(size=18, weight="bold"), text_color="#a855f7").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="analyze loot · extract credentials · hash verification", font=ctk.CTkFont(size=11), text_color="#8a8a8a").pack(pady=(0, 12), padx=24, anchor="w")

        # Actions
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24, pady=12)
        for label, fn in [
            ("📂 Analyze Loot Folder", self._analyze_loot),
            ("🔑 Extract Credentials", self._extract_creds),
            ("# Hash Verification", self._hash_files),
        ]:
            ctk.CTkButton(row, text=label, width=200, height=34, fg_color="#2a1a3a", hover_color="#3a2a5a", text_color="#a855f7", command=fn).pack(side="left", padx=(0, 4))

        # Output
        ctk.CTkLabel(parent, text="Analysis Results:", font=ctk.CTkFont(size=12, weight="bold"), text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(parent, fg_color="#05080c", text_color="#a855f7", font=ctk.CTkFont(family="Consolas", size=10), height=450)
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 24))

    def _analyze_loot(self):
        loot_dir = "loot"
        if not os.path.exists(loot_dir):
            self._safe_out("[!] 'loot' folder not found. Exfiltrate some files first.")
            return
        
        self._safe_out(f"[*] Scanning loot folder...")
        def run():
            for root, dirs, files in os.walk(loot_dir):
                for file in files:
                    path = os.path.join(root, file)
                    size = os.path.getsize(path)
                    self._safe_out(f"[+] {path} ({size} bytes)")
        threading.Thread(target=run, daemon=True).start()

    def _extract_creds(self):
        self._safe_out("[*] Searching for credentials in loot...")
        def run():
            patterns = [
                r"(?i)password\s*[:=]\s*['\"]?([^\s'\"]+)",
                r"(?i)passwd\s*[:=]\s*['\"]?([^\s'\"]+)",
                r"(?i)secret\s*[:=]\s*['\"]?([^\s'\"]+)",
                r"(?i)api[_-]key\s*[:=]\s*['\"]?([^\s'\"]+)",
            ]
            for root, _, files in os.walk("loot"):
                for file in files:
                    path = os.path.join(root, file)
                    try:
                        with open(path, 'r', errors='ignore') as f:
                            content = f.read()
                            for pat in patterns:
                                matches = re.findall(pat, content)
                                for m in matches:
                                    self._safe_out(f"[🔑] {path}: {m[:50]}")
                    except Exception:
                        pass
        threading.Thread(target=run, daemon=True).start()

    def _hash_files(self):
        self._safe_out("[*] Calculating SHA256 for loot files...")
        def run():
            for root, _, files in os.walk("loot"):
                for file in files:
                    path = os.path.join(root, file)
                    try:
                        h = hashlib.sha256()
                        with open(path, 'rb') as f:
                            for chunk in iter(lambda: f.read(65536), b""):
                                h.update(chunk)
                        self._safe_out(f"[#] {path}: {h.hexdigest()}")
                    except Exception:
                        pass
        threading.Thread(target=run, daemon=True).start()

    def _safe_out(self, text):
        if not self._parent: return
        def _u():
            if self.out and self.out.winfo_exists():
                self.out.insert("end", text + "\n")
                self.out.see("end")
        self._parent.after(0, _u)
