# language: Python, file: modules/apt_emulator.py
# APT Emulator UI
import customtkinter as ctk
import threading
import json
from core.adversary.emulator import get_emulator


class APTEmulatorModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "apt_emulator"
        self.app = app
        self.emulator = get_emulator(app, log_queue)

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="APT EMULATOR",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="emulate APT28 · APT29 · Lazarus in your lab",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ── config ──
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r = ctk.CTkFrame(cfg, fg_color="transparent")
        r.pack(fill="x", padx=12, pady=8)

        ctk.CTkLabel(r, text="Profile:",
                      font=ctk.CTkFont(size=11),
                      text_color="#c8d6e5").pack(side="left", padx=(0, 4))

        self.profile_selector = ctk.CTkOptionMenu(
            r, values=list(self._get_profiles().keys()),
            width=180, fg_color="#1a2332", button_color="#1a2332")
        self.profile_selector.pack(side="left", padx=(0, 8))

        ctk.CTkLabel(r, text="Target:",
                      font=ctk.CTkFont(size=11),
                      text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.target_entry = ctk.CTkEntry(
            r, placeholder_text="10.0.0.0/24",
            width=180, height=30,
            fg_color="#05080c", border_color="#1a2332")
        self.target_entry.pack(side="left", padx=(0, 8))

        ctk.CTkLabel(r, text="Speed:",
                      font=ctk.CTkFont(size=11),
                      text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.speed = ctk.CTkOptionMenu(
            r, values=["fast", "normal", "slow"],
            width=100, fg_color="#1a2332", button_color="#1a2332")
        self.speed.set("normal")
        self.speed.pack(side="left")

        # ── controls ──
        ctl = ctk.CTkFrame(parent, fg_color="transparent")
        ctl.pack(fill="x", padx=24, pady=12)
        ctk.CTkButton(
            ctl, text="▶ Start emulation",
            width=180, height=40,
            fg_color="#0d2818", hover_color="#1a4a2e",
            text_color="#00ff9c", font=ctk.CTkFont(size=12, weight="bold"),
            command=self._start).pack(side="left", padx=(0, 8))
        ctk.CTkButton(
            ctl, text="■ Stop",
            width=120, height=40,
            fg_color="#4a1a1a", hover_color="#6b1a1a",
            text_color="#ff6b6b", font=ctk.CTkFont(size=12, weight="bold"),
            command=lambda: self.emulator.stop()).pack(side="left", padx=(0, 8))
        ctk.CTkButton(
            ctl, text="▸ View timeline",
            width=170, height=40,
            fg_color="#141a22", hover_color="#1a2332",
            command=self._timeline).pack(side="left")

        # ── output ──
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=450
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

        self.emulator.on_event = self._on_event

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _get_profiles(self):
        return {p["name"]: p for p in self.emulator.list_profiles()}

    def _start(self):
        profile = self.profile_selector.get()
        target = self.target_entry.get().strip()
        if not target:
            self._out("[!] target required")
            return
        result = self.emulator.start(profile, target, self.speed.get())
        self._out(f"[+] {result}")

    def _timeline(self):
        events = self.emulator.get_timeline()
        self.out.delete("1.0", "end")
        self._out(f"=== TIMELINE ({len(events)} events) ===\n")
        for ev in events:
            marker = "✓" if ev["status"] == "completed" else \
                      "●" if ev["status"] == "running" else "✗"
            detected = " [DETECTED]" if ev["detected"] else ""
            self._out(f"{marker} {ev['phase']}: {ev['action']}{detected}")
            if ev.get("detection_source"):
                self._out(f"    detection: {ev['detection_source']}")

    def _on_event(self, ev: dict):
        def update():
            t = ev.get("type")
            if t == "start":
                self._out(f"\n[*] starting {ev['profile']} "
                           f"({ev['alias']}) → {ev['target']}")
            elif t == "step_start":
                self._out(f"\n[step {ev['step']}] {ev['phase']}: "
                           f"{ev['action']}")
            elif t == "step_complete":
                self._out(f"  ✓ {ev['status']}")
            elif t == "detected":
                self._out(f"  ⚠ DETECTED: {ev.get('hint', '')}")
            elif t == "step_error":
                self._out(f"  ✗ error: {ev['error']}")
            elif t == "complete":
                self._out(f"\n[*] done: {ev['total_steps']} steps, "
                           f"{ev['detected']} detected, "
                           f"{ev['undetected']} undetected")
        self.after(0, update)
