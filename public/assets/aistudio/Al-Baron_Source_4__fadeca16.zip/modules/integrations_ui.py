# language: Python, file: modules/integrations_ui.py
import customtkinter as ctk
import json
from core.integrations.splunk import SplunkIntegration
from core.integrations.elastic import ElasticIntegration
from core.integrations.wazuh import WazuhIntegration
from core.integrations.thehive import TheHiveIntegration
from core.integrations.thehive import hub


class IntegrationsModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "integrations"
        self.app = app
        self.hub = hub

    def render(self, parent):
        ctk.CTkLabel(parent, text="INTEGRATION HUB",
                      font=ctk.CTkFont(size=18, weight="bold"),
                      text_color="#00ff9c").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="Splunk · Elastic · Wazuh · TheHive",
                      font=ctk.CTkFont(size=11),
                      text_color="#4a5568").pack(pady=(0, 12), padx=24, anchor="w")

        # config for each
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r = ctk.CTkFrame(cfg, fg_color="transparent")
        r.pack(fill="x", padx=12, pady=8)

        ctk.CTkLabel(r, text="Integration:",
                      font=ctk.CTkFont(size=11),
                      text_color="#c8d6e5").pack(side="left", padx=(0, 4))

        self.integration_selector = ctk.CTkOptionMenu(
            r, values=["splunk", "elastic", "wazuh", "thehive"],
            width=140, fg_color="#1a2332", button_color="#1a2332")
        self.integration_selector.pack(side="left", padx=(0, 8))

        self.url_entry = ctk.CTkEntry(
            r, placeholder_text="URL",
            width=300, height=30,
            fg_color="#05080c", border_color="#1a2332")
        self.url_entry.pack(side="left", padx=(0, 8))

        self.token_entry = ctk.CTkEntry(
            r, placeholder_text="token/key/user:pass",
            width=200, height=30,
            fg_color="#05080c", border_color="#1a2332")
        self.token_entry.pack(side="left", padx=(0, 8))

        ctk.CTkButton(r, text="⚡ Connect", width=120, height=30,
                       fg_color="#0d2818", hover_color="#1a4a2e",
                       text_color="#00ff9c",
                       command=self._connect).pack(side="left")

        # actions
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24, pady=12)
        for label, fn in [
            ("▸ List integrations", self._list),
            ("▸ Test all", self._test_all),
            ("⚡ Broadcast test", self._broadcast),
        ]:
            ctk.CTkButton(row, text=label, width=170, height=34,
                          fg_color="#141a22", hover_color="#1a2332",
                          command=fn).pack(side="left", padx=(0, 4))

        self.out = ctk.CTkTextbox(parent, fg_color="#05080c",
                                    text_color="#7dffb0",
                                    font=ctk.CTkFont(family="Consolas", size=10),
                                    height=450)
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _connect(self):
        name = self.integration_selector.get()
        url = self.url_entry.get().strip()
        token = self.token_entry.get().strip()

        if name == "splunk":
            intg = SplunkIntegration(hec_url=url, hec_token=token)
        elif name == "elastic":
            user, _, pwd = token.partition(":")
            intg = ElasticIntegration(url=url, username=user, password=pwd)
        elif name == "wazuh":
            user, _, pwd = token.partition(":")
            intg = WazuhIntegration(url=url, username=user, password=pwd)
        elif name == "thehive":
            intg = TheHiveIntegration(url=url, api_key=token)
        else:
            return

        result = intg.test_connection()
        self._out(f"[{name}] {json.dumps(result, indent=2)}")

        if result.get("connected"):
            self.hub.register(intg)
            self._out(f"[+] {name} registered")

    def _list(self):
        intgs = list(self.hub.integrations.keys())
        self._out(f"\n=== {len(intgs)} integrations ===")
        for name in intgs:
            i = self.hub.integrations[name]
            self._out(f"  • {name} (enabled: {i.enabled})")

    def _test_all(self):
        for name, intg in self.hub.integrations.items():
            r = intg.test_connection()
            self._out(f"[{name}] {r}")

    def _broadcast(self):
        event = {
            "type": "test",
            "message": "Al-Baron integration test",
        }
        results = self.hub.broadcast(event)
        self._out(json.dumps(results, indent=2))
