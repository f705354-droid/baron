# language: Python, file: modules/autonomous.py
# Autonomous mode GUI — goal input, live log, approvals, budget
import customtkinter as ctk
import threading
import json
from datetime import datetime
from core.ai.autonomous import get_autonomous_agent


class AutonomousModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "autonomous"
        self.app = app
        self.agent = None
        self.event_log = []

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="AUTONOMOUS MODE",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="goal-driven · no human loop · budget + guardrails",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ── goal config ──
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)

        ctk.CTkLabel(cfg, text="الهدف:",
                     font=ctk.CTkFont(size=11, weight="bold"),
                     text_color="#c8d6e5").pack(padx=12, pady=(8, 2), anchor="w")
        self.goal_e = ctk.CTkTextbox(cfg, height=60,
                                       fg_color="#05080c",
                                       text_color="#7dffb0",
                                       font=ctk.CTkFont(family="Consolas", size=11))
        self.goal_e.pack(fill="x", padx=12, pady=(0, 6))
        self.goal_e.insert("end", "اكتشف كل hosts في 192.168.1.0/24 مع منافذ مفتوحة، "
                                   "حلل الخدمات، اقترح 3 أهداف للاستغلال.")

        ctk.CTkLabel(cfg, text="معايير النجاح (اختياري):",
                     font=ctk.CTkFont(size=11, weight="bold"),
                     text_color="#c8d6e5").pack(padx=12, pady=(4, 2), anchor="w")
        self.criteria_e = ctk.CTkEntry(cfg, height=32,
                                        fg_color="#05080c",
                                        border_color="#1a2332",
                                        font=ctk.CTkFont(size=11))
        self.criteria_e.pack(fill="x", padx=12, pady=(0, 6))
        self.criteria_e.insert(0, "خطة مكتوبة مع 3 hosts مكتشفة")

        ctk.CTkLabel(cfg, text="قيود (اختياري):",
                     font=ctk.CTkFont(size=11, weight="bold"),
                     text_color="#c8d6e5").pack(padx=12, pady=(4, 2), anchor="w")
        self.constraints_e = ctk.CTkEntry(cfg, height=32,
                                            fg_color="#05080c",
                                            border_color="#1a2332",
                                            font=ctk.CTkFont(size=11))
        self.constraints_e.pack(fill="x", padx=12, pady=(0, 6))
        self.constraints_e.insert(0, "لا تفعل write_file أو dispatch_task بدون موافقتي")

        # ── budget + limits ──
        budget_row = ctk.CTkFrame(cfg, fg_color="transparent")
        budget_row.pack(fill="x", padx=12, pady=(4, 8))
        for label, default, key in [
            ("max iter", "50", "iter"),
            ("max min", "60", "min"),
            ("max $", "5.0", "usd"),
            ("throttle", "3", "sec"),
        ]:
            ctk.CTkLabel(budget_row, text=label,
                          font=ctk.CTkFont(size=10),
                          text_color="#4a5568").pack(side="left", padx=(0, 4))
            e = ctk.CTkEntry(budget_row, width=70, height=28,
                              fg_color="#05080c",
                              border_color="#1a2332",
                              font=ctk.CTkFont(size=10))
            e.insert(0, default)
            e.pack(side="left", padx=(0, 8))
            setattr(self, f"{key}_e", e)

        # ── control buttons ──
        ctl = ctk.CTkFrame(parent, fg_color="transparent")
        ctl.pack(fill="x", padx=24, pady=12)
        for label, fn, color in [
            ("▶ START", self._start, "#0d2818"),
            ("⏸ PAUSE", self._pause, "#2a2a0d"),
            ("▶ RESUME", self._resume, "#0d2818"),
            ("■ STOP", self._stop, "#4a1a1a"),
            ("⚡ AUTO-APPROVE", self._toggle_auto, "#141a22"),
            ("📄 EXPORT", self._export, "#141a22"),
        ]:
            ctk.CTkButton(ctl, text=label, width=140, height=34,
                           fg_color=color, hover_color="#1a2332",
                           font=ctk.CTkFont(size=11, weight="bold"),
                           command=fn).pack(side="left", padx=(0, 6))

        # ── progress ──
        self.bar = ctk.CTkProgressBar(parent, height=10,
                                        progress_color="#00ff9c",
                                        fg_color="#1a2332")
        self.bar.set(0)
        self.bar.pack(fill="x", padx=24, pady=(0, 4))
        self.progress_lbl = ctk.CTkLabel(parent, text="idle",
                                          font=ctk.CTkFont(size=10),
                                          text_color="#4a5568")
        self.progress_lbl.pack(padx=24, anchor="w")

        # ── pending approval ──
        self.approval_frame = ctk.CTkFrame(parent, fg_color="#2a1a00",
                                            corner_radius=6,
                                            border_width=1,
                                            border_color="#ffaa00")
        self.approval_lbl = ctk.CTkLabel(
            self.approval_frame, text="", text_color="#ffaa00",
            font=ctk.CTkFont(family="Consolas", size=11))
        self.approval_lbl.pack(padx=12, pady=8, side="left")
        ctk.CTkButton(self.approval_frame, text="✓ Approve",
                       width=100, height=28, fg_color="#0d2818",
                       hover_color="#1a4a2e", text_color="#00ff9c",
                       command=self._approve).pack(side="right", padx=4)
        ctk.CTkButton(self.approval_frame, text="✗ Deny",
                       width=100, height=28, fg_color="#4a1a1a",
                       hover_color="#6b1a1a", text_color="#ff6b6b",
                       command=self._deny).pack(side="right", padx=4)
        # لا نعرضه حتى يأتي طلب

        # ── log ──
        ctk.CTkLabel(parent, text="Live:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10),
            wrap="word")
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

        self._pending_approval = None

    # ==================== callbacks ====================
    def _on_event(self, ev: dict):
        def _u():
            t = ev.get("type")
            ts = ev.get("ts", "")[11:19]
            if t == "iteration":
                self.out.insert("end", f"\n── iteration {ev['n']} ──\n")
            elif t == "decision":
                self.out.insert("end",
                    f"[{ts}] 💭 {ev['thought'][:150]}\n")
                self.out.insert("end",
                    f"    → {ev['tool']} {json.dumps(ev['args'])[:120]}\n")
                self.bar.set(ev.get("progress", 0) / 100)
                self.progress_lbl.configure(
                    text=f"iteration · progress {ev.get('progress',0)}%")
            elif t == "executing":
                self.out.insert("end", f"    ⚙ executing {ev['tool']}...\n")
            elif t == "result":
                r = json.dumps(ev["result"])[:300]
                mark = "✓" if ev["success"] else "✗"
                self.out.insert("end", f"    {mark} {r}\n")
            elif t == "awaiting_confirmation":
                self._pending_approval = ev
                self.approval_lbl.configure(
                    text=f"⚠ {ev['tool']} {json.dumps(ev['args'])[:100]}")
                self.approval_frame.pack(fill="x", padx=24, pady=8,
                                          before=self.out)
            elif t == "goal_reached":
                self.out.insert("end",
                    f"\n🎯 GOAL REACHED · iterations={ev['iterations']}\n"
                    f"   {ev['summary']}\n")
                self.bar.set(1.0)
            elif t == "stopped":
                self.out.insert("end", f"\n■ STOPPED: {ev['reason']}\n")
                self.bar.set(0)
            elif t == "error":
                self.out.insert("end",
                    f"    ✗ error[{ev.get('phase')}]: {ev.get('error')}\n")
            self.out.see("end")
        self.after(0, _u)

    # ==================== controls ====================
    def _start(self):
        if not self.app:
            return
        self.agent = get_autonomous_agent(self.app)
        goal = self.goal_e.get("1.0", "end").strip()
        criteria = self.criteria_e.get().strip()
        constraints = self.constraints_e.get().strip()
        try:
            mi = int(self.iter_e.get())
            mm = int(self.min_e.get())
            mu = float(self.usd_e.get())
            ts = float(self.sec_e.get())
        except ValueError:
            mi, mm, mu, ts = 50, 60, 5.0, 3.0

        self.agent.guardrails.throttle_sec = ts
        self.out.delete("1.0", "end")
        self.out.insert("end", f"🎯 Goal: {goal}\n")
        self.out.insert("end", f"📏 Criteria: {criteria}\n")
        self.out.insert("end", f"🔒 Constraints: {constraints}\n")
        self.out.insert("end",
            f"💰 Budget: iter={mi} min={mm} usd=${mu} throttle={ts}s\n\n")

        rid = self.agent.start(
            goal=goal,
            success_criteria=criteria,
            constraints=constraints,
            max_iterations=mi, max_minutes=mm, max_usd=mu,
            on_event=self._on_event)
        self.log.put(f"[autonomous] started run {rid}")

    def _pause(self):
        if self.agent:
            self.agent.pause()

    def _resume(self):
        if self.agent:
            self.agent.resume()

    def _stop(self):
        if self.agent:
            self.agent.stop("user_abort")

    def _toggle_auto(self):
        if not self.agent:
            return
        self.agent.guardrails.auto_approve = not self.agent.guardrails.auto_approve
        state = "ON" if self.agent.guardrails.auto_approve else "OFF"
        self.log.put(f"[autonomous] auto-approve {state}")

    def _approve(self):
        if self._pending_approval and self.agent:
            ev = self._pending_approval
            self.agent.guardrails.approve(
                self.agent.run_id, ev["tool"], ev["args"])
            self.out.insert("end", "    ✓ approved\n")
            self.approval_frame.pack_forget()
            self._pending_approval = None

    def _deny(self):
        if self._pending_approval and self.agent:
            self.agent.stop("approval_denied")
            self.out.insert("end", "    ✗ denied — stopping\n")
            self.approval_frame.pack_forget()
            self._pending_approval = None

    def _export(self):
        if not self.agent:
            return
        import tkinter.filedialog as fd
        path = fd.asksaveasfilename(defaultextension=".json",
                                     initialfile="autonomous_report.json")
        if not path:
            return
        with open(path, "w") as f:
            json.dump(self.agent.report(), f, indent=2, default=str)
        self.log.put(f"[autonomous] report → {path}")
