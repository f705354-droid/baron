# language: Python, file: modules/safety_center.py
# Safety Center — Scope, Lab Guard, Kill Switch, Audit, Backup
import customtkinter as ctk
import threading
import json
import os
from datetime import datetime
from core.safety.scope import scope_manager
from core.safety.lab_guard import lab_guard
from core.safety.kill_switch import kill_switch
from core.safety.audit_trail import audit_trail
from core.perf.cache import semantic_cache
from core.perf.memory import memory_guard
from core.perf.profiler import profiler


class SafetyCenterModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "safety_center"
        self.app = app

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="SAFETY CENTER",
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="scope · lab guard · kill switch · audit · cache · memory",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ── scope card ──
        scope_card = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        scope_card.pack(fill="x", padx=24, pady=(0, 8))
        ctk.CTkLabel(scope_card, text="◆ SCOPE",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#00ff9c").pack(anchor="w", padx=12, pady=(8, 4))

        self.scope_status = ctk.CTkLabel(
            scope_card, text="no active scope",
            font=ctk.CTkFont(family="Consolas", size=11),
            text_color="#ff6b6b")
        self.scope_status.pack(anchor="w", padx=12)

        scope_row = ctk.CTkFrame(scope_card, fg_color="transparent")
        scope_row.pack(fill="x", padx=12, pady=8)

        self.scope_input = ctk.CTkEntry(
            scope_row, placeholder_text="targets (10.0.0.0/24, *.lab.local)",
            height=32, fg_color="#05080c", border_color="#1a2332")
        self.scope_input.pack(side="left", fill="x", expand=True, padx=(0, 6))

        self.hours_input = ctk.CTkEntry(
            scope_row, placeholder_text="hours", width=80,
            height=32, fg_color="#05080c", border_color="#1a2332")
        self.hours_input.insert(0, "8")
        self.hours_input.pack(side="left", padx=(0, 6))

        ctk.CTkButton(scope_row, text="▸ Declare",
                       width=110, height=32,
                       fg_color="#0d2818", hover_color="#1a4a2e",
                       text_color="#00ff9c",
                       command=self._declare_scope).pack(side="left", padx=(0, 4))

        ctk.CTkButton(scope_row, text="■ End",
                       width=80, height=32,
                       fg_color="#4a1a1a", hover_color="#6b1a1a",
                       text_color="#ff6b6b",
                       command=self._end_scope).pack(side="left")

        # ── kill switch ──
        kill_card = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        kill_card.pack(fill="x", padx=24, pady=(0, 8))
        ctk.CTkLabel(kill_card, text="◆ KILL SWITCH",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#ff6b6b").pack(anchor="w", padx=12, pady=(8, 4))
        ctk.CTkButton(kill_card, text="■ STOP ALL OPERATIONS (F12)",
                       height=40, fg_color="#4a1a1a",
                       hover_color="#6b1a1a", text_color="#ff6b6b",
                       font=ctk.CTkFont(size=13, weight="bold"),
                       command=self._trigger_kill).pack(fill="x", padx=12, pady=(0, 4))
        self.kill_status = ctk.CTkLabel(
            kill_card, text="● armed",
            font=ctk.CTkFont(size=10), text_color="#00ff9c")
        self.kill_status.pack(anchor="w", padx=12, pady=(0, 8))

        # ── backup card ──
        backup_card = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        backup_card.pack(fill="x", padx=24, pady=(0, 8))
        ctk.CTkLabel(backup_card, text="◆ BACKUP",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#00ff9c").pack(anchor="w", padx=12, pady=(8, 4))
        row = ctk.CTkFrame(backup_card, fg_color="transparent")
        row.pack(fill="x", padx=12, pady=(0, 8))
        ctk.CTkButton(row, text="▸ Full backup",
                       width=140, height=32,
                       fg_color="#0d2818", hover_color="#1a4a2e",
                       text_color="#00ff9c",
                       command=self._backup_full).pack(side="left", padx=(0, 4))
        ctk.CTkButton(row, text="▸ Incremental",
                       width=140, height=32,
                       fg_color="#141a22", hover_color="#1a2332",
                       command=self._backup_inc).pack(side="left", padx=(0, 4))
        ctk.CTkButton(row, text="▸ List",
                       width=80, height=32,
                       fg_color="#141a22", hover_color="#1a2332",
                       command=self._backup_list).pack(side="left", padx=(0, 4))
        ctk.CTkButton(row, text="▸ Verify latest",
                       width=140, height=32,
                       fg_color="#141a22", hover_color="#1a2332",
                       command=self._backup_verify).pack(side="left")
        self.backup_out = ctk.CTkTextbox(
            backup_card, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=9), height=100)
        self.backup_out.pack(fill="x", padx=12, pady=(0, 8))

        # ── quick launcher ──
        launcher_card = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        launcher_card.pack(fill="x", padx=24, pady=(0, 8))
        ctk.CTkLabel(launcher_card, text="◆ QUICK LAUNCHER",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#00ff9c").pack(anchor="w", padx=12, pady=(8, 4))
        
        l_row = ctk.CTkFrame(launcher_card, fg_color="transparent")
        l_row.pack(fill="x", padx=12, pady=(0, 8))
        
        for label, action in [
            ("▸ Recon", "recon"),
            ("▸ Exploit", "exploit"),
            ("▸ AD Attack", "ad"),
            ("▸ C2 Console", "c2_ui")
        ]:
            ctk.CTkButton(
                l_row, text=label, width=120, height=32,
                fg_color="#141a22", hover_color="#1a2332",
                command=lambda a=action: self._switch_module(a)
            ).pack(side="left", padx=(0, 4))

        # ── audit + perf ──
        info_row = ctk.CTkFrame(parent, fg_color="transparent")
        info_row.pack(fill="both", expand=True, padx=24, pady=(0, 12))

        audit_card = ctk.CTkFrame(info_row, fg_color="#0d1319", corner_radius=6)
        audit_card.pack(side="left", fill="both", expand=True, padx=(0, 4))
        ctk.CTkLabel(audit_card, text="◆ AUDIT",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#00ff9c").pack(anchor="w", padx=12, pady=(8, 4))
        ctk.CTkButton(audit_card, text="▸ Verify chain",
                       height=30, fg_color="#141a22",
                       hover_color="#1a2332",
                       command=self._verify_audit).pack(fill="x", padx=12, pady=2)
        ctk.CTkButton(audit_card, text="▸ Show last 20",
                       height=30, fg_color="#141a22",
                       hover_color="#1a2332",
                       command=self._show_audit).pack(fill="x", padx=12, pady=2)
        self.audit_out = ctk.CTkTextbox(
            audit_card, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=9), height=150)
        self.audit_out.pack(fill="both", expand=True, padx=12, pady=(4, 8))

        perf_card = ctk.CTkFrame(info_row, fg_color="#0d1319", corner_radius=6)
        perf_card.pack(side="left", fill="both", expand=True, padx=(4, 0))
        ctk.CTkLabel(perf_card, text="◆ PERFORMANCE",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#00ff9c").pack(anchor="w", padx=12, pady=(8, 4))
        ctk.CTkButton(perf_card, text="▸ Cache stats",
                       height=30, fg_color="#141a22",
                       hover_color="#1a2332",
                       command=self._cache_stats).pack(fill="x", padx=12, pady=2)
        ctk.CTkButton(perf_card, text="▸ Memory report",
                       height=30, fg_color="#141a22",
                       hover_color="#1a2332",
                       command=self._mem_stats).pack(fill="x", padx=12, pady=2)
        ctk.CTkButton(perf_card, text="▸ Top hotspots",
                       height=30, fg_color="#141a22",
                       hover_color="#1a2332",
                       command=self._hotspots).pack(fill="x", padx=12, pady=2)
        ctk.CTkButton(perf_card, text="▸ Clear cache",
                       height=30, fg_color="#141a22",
                       hover_color="#1a2332",
                       command=self._clear_cache).pack(fill="x", padx=12, pady=2)
        self.perf_out = ctk.CTkTextbox(
            perf_card, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=9), height=150)
        self.perf_out.pack(fill="both", expand=True, padx=12, pady=(4, 8))

        self._refresh_scope()

    # ── Actions ──

    def _switch_module(self, key):
        if self.app and hasattr(self.app, "_switch_to"):
            self.app._switch_to(key)

    def _refresh_scope(self):
        rep = scope_manager.report()
        if rep["status"] == "active":
            self.scope_status.configure(
                text=f"● ACTIVE | {rep['hours_remaining']}h remaining | "
                     f"{len(rep['targets'])} targets",
                text_color="#00ff9c")
        else:
            self.scope_status.configure(
                text="● no active scope",
                text_color="#ff6b6b")

    def _declare_scope(self):
        targets_text = self.scope_input.get().strip()
        if not targets_text:
            return
        targets = [t.strip() for t in targets_text.split(",") if t.strip()]
        try:
            hours = int(self.hours_input.get() or "8")
        except ValueError:
            hours = 8

        import tkinter.messagebox as mb
        ack = mb.askyesno(
            "Authorization",
            "Declare that you have authorization for these targets?\n\n"
            f"Targets: {targets}\n"
            f"Duration: {hours} hours")
        if not ack:
            return

        try:
            scope_manager.declare(
                targets=targets,
                hours=hours,
                acknowledgment="I have authorization for these targets.")
            audit_trail.log("operator", "scope_declared",
                             details={"targets": targets, "hours": hours})
            self._refresh_scope()
        except Exception as e:
            mb.showerror("Scope error", str(e))

    def _end_scope(self):
        scope_manager.end()
        audit_trail.log("operator", "scope_ended")
        self._refresh_scope()

    def _trigger_kill(self):
        import tkinter.messagebox as mb
        if not mb.askyesno("Kill Switch",
                            "Stop ALL operations? This kills every process."):
            return
        kill_switch.trigger("manual")
        audit_trail.log("operator", "kill_switch_triggered")
        self.kill_status.configure(
            text="● TRIGGERED", text_color="#ff6b6b")

    # ── Backup ──

    def _backup_full(self):
        threading.Thread(
            target=self._run_backup, args=("full",), daemon=True).start()

    def _backup_inc(self):
        threading.Thread(
            target=self._run_backup, args=("incremental",), daemon=True).start()

    def _run_backup(self, mode):
        self.backup_out.insert("end", f"[*] running {mode} backup...\n")
        try:
            import sys
            sys.path.insert(0, "scripts")
            from scripts.backup import backup
            result = backup(mode=mode)
            self.backup_out.insert(
                "end",
                f"[+] {result.get('file')}\n"
                f"    size: {result.get('size', 0):,} bytes\n")
            audit_trail.log("operator", f"backup_{mode}",
                             details=result)
        except Exception as e:
            self.backup_out.insert("end", f"[!] {e}\n")
        self.backup_out.see("end")

    def _backup_list(self):
        try:
            from scripts.restore import list_backups, load_config
            cfg = load_config("scripts/backup_config.yaml")
            backups = list_backups(cfg["backup_root"])
            self.backup_out.delete("1.0", "end")
            if not backups:
                self.backup_out.insert("end", "no backups found\n")
                return
            self.backup_out.insert("end", "Available backups:\n\n")
            for b in backups:
                ts = datetime.fromtimestamp(b["ts"]).strftime("%Y-%m-%d %H:%M")
                self.backup_out.insert(
                    "end",
                    f"  {ts}  {b['mode']:<12}  {b['size']:<10}  "
                    f"{os.path.basename(b['backup_file'])}\n")
        except Exception as e:
            self.backup_out.insert("end", f"[!] {e}\n")

    def _backup_verify(self):
        """Verify latest backup integrity"""
        from scripts.verify_backup import verify_backup
        from scripts.restore import list_backups, load_config
        
        def run():
            self.backup_out.insert("end", "[*] verifying latest backup...\n")
            try:
                cfg = load_config("scripts/backup_config.yaml")
                backups = list_backups(cfg["backup_root"])
                if not backups:
                    self.backup_out.insert("end", "[!] no backups found\n")
                    return
                
                latest = backups[0]
                age_key = os.path.expanduser("~/.albaron/backups/keys/age.key")
                
                res = verify_backup(
                    latest["backup_file"],
                    latest["manifest"],
                    age_key
                )
                
                if res.get("error"):
                    self.backup_out.insert("end", f"[!] error: {res['error']}\n")
                elif res["checks"].get("checksum_status") == "OK":
                    self.backup_out.insert(
                        "end", 
                        f"[+] VERIFIED: {res['checks'].get('checksums_verified', 0)} files OK\n"
                    )
                else:
                    self.backup_out.insert(
                        "end", 
                        f"[!] verification failed: {res['checks'].get('checksum_status')}\n"
                    )
            except Exception as e:
                self.backup_out.insert("end", f"[!] verify exception: {e}\n")
            self.backup_out.see("end")
        
        threading.Thread(target=run, daemon=True).start()

    # ── Audit ──

    def _verify_audit(self):
        res = audit_trail.verify_integrity()
        self.audit_out.delete("1.0", "end")
        if res.get("ok"):
            self.audit_out.insert(
                "end",
                f"✓ CHAIN INTACT\n"
                f"  entries: {res['entries']}\n"
                f"  no tampering detected")
        else:
            self.audit_out.insert(
                "end",
                f"✗ TAMPERING DETECTED\n"
                f"  {len(res.get('tampered', []))} bad entries\n\n"
                f"{json.dumps(res.get('tampered', [])[:5], indent=2)}")

    def _show_audit(self):
        entries = audit_trail.tail(20)
        self.audit_out.delete("1.0", "end")
        for e in entries:
            ts = datetime.fromtimestamp(e.get("ts", 0)).strftime("%H:%M:%S")
            self.audit_out.insert(
                "end",
                f"[{ts}] {e.get('actor')} → {e.get('action')} "
                f"({e.get('target', '')})\n")

    # ── Performance ──

    def _cache_stats(self):
        stats = semantic_cache.get_stats()
        self.perf_out.delete("1.0", "end")
        self.perf_out.insert("end", json.dumps(stats, indent=2))

    def _mem_stats(self):
        rep = memory_guard.report()
        self.perf_out.delete("1.0", "end")
        self.perf_out.insert("end", json.dumps(rep, indent=2))

    def _hotspots(self):
        rep = profiler.report(top_n=15)
        self.perf_out.delete("1.0", "end")
        if not rep:
            self.perf_out.insert("end", "no profiler data yet")
            return
        for r in rep:
            self.perf_out.insert(
                "end",
                f"{r['function'][:45]:<45} "
                f"{r['calls']:>4} calls  "
                f"avg {r['avg_ms']:>7.1f}ms  "
                f"total {r['total_sec']:>6.2f}s\n")

    def _clear_cache(self):
        semantic_cache.clear()
        self.perf_out.delete("1.0", "end")
        self.perf_out.insert("end", "cache cleared")
