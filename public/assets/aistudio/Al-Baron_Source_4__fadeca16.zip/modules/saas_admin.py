# language: Python, file: modules/saas_admin.py
# SaaS Admin Panel
import customtkinter as ctk
from core.saas.tenant_manager import tenant_manager


class SaaSAdminModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "saas_admin"
        self.app = app
        self.manager = tenant_manager

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="SAAS ADMIN",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="multi-tenant · billing · plans · usage",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ── create tenant ──
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r = ctk.CTkFrame(cfg, fg_color="transparent")
        r.pack(fill="x", padx=12, pady=8)

        self.name_entry = ctk.CTkEntry(
            r, placeholder_text="tenant name",
            width=180, height=30,
            fg_color="#05080c", border_color="#1a2332")
        self.name_entry.pack(side="left", padx=(0, 6))

        self.email_entry = ctk.CTkEntry(
            r, placeholder_text="admin email",
            width=200, height=30,
            fg_color="#05080c", border_color="#1a2332")
        self.email_entry.pack(side="left", padx=(0, 6))

        self.plan_selector = ctk.CTkOptionMenu(
            r, values=["starter", "pro", "enterprise"],
            width=120, fg_color="#1a2332", button_color="#1a2332")
        self.plan_selector.pack(side="left", padx=(0, 6))

        ctk.CTkButton(
            r, text="▸ Create Tenant",
            width=160, height=30,
            fg_color="#0d2818", hover_color="#1a4a2e",
            text_color="#00ff9c",
            command=self._create).pack(side="left")

        # ── actions ──
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24, pady=(12, 12))
        for label, fn in [
            ("▸ List tenants", self._list),
            ("▸ Check limits", self._check),
            ("▸ Add usage", self._add_usage),
            ("▸ Delete", self._delete),
        ]:
            ctk.CTkButton(
                row, text=label, width=170, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).pack(side="left", padx=(0, 4))

        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=450
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _create(self):
        name = self.name_entry.get().strip()
        email = self.email_entry.get().strip()
        plan = self.plan_selector.get()
        if not name or not email:
            self._out("[!] name and email required")
            return
        result = self.manager.create_tenant(name, email, plan)
        self._out(f"\n[+] tenant created:")
        self._out(f"    ID: {result['tenant_id']}")
        self._out(f"    API key: {result['api_key']}")
        self._out(f"    plan: {result['plan']}")
        self._out(f"    trial ends: {result['trial_ends_at']}")

    def _list(self):
        tenants = self.manager.list_tenants()
        self.out.delete("1.0", "end")
        self._out(f"=== {len(tenants)} tenants ===\n")
        for t in tenants:
            self._out(f"  {t['name']} ({t['plan']})")
            self._out(f"    id: {t['id'][:8]}...")
            self._out(f"    email: {t['email']}")
            self._out(f"    status: {t['subscription_status']}")

    def _check(self):
        import tkinter.simpledialog as sd
        tid = sd.askstring("Check", "tenant ID:")
        if not tid:
            return
        result = self.manager.check_limits(tid)
        import json
        self._out(json.dumps(result, indent=2))

    def _add_usage(self):
        import tkinter.simpledialog as sd
        tid = sd.askstring("Usage", "tenant ID:")
        metric = sd.askstring("Usage", "metric (hosts/sessions/users):")
        if not tid or not metric:
            return
        qty = sd.askfloat("Usage", "quantity:", initialvalue=1.0)
        self.manager.record_usage(tid, metric, qty)
        self._out(f"[+] recorded {qty} {metric} for {tid[:8]}")

    def _delete(self):
        import tkinter.simpledialog as sd
        tid = sd.askstring("Delete", "tenant ID:")
        if not tid:
            return
        self.manager.delete_tenant(tid)
        self._out(f"[+] deleted tenant {tid[:8]}")
