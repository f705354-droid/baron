# language: Python, file: modules/cctv.py
# Al-Baron CCTV Module — discover and test IP cameras
import customtkinter as ctk
import threading
import subprocess
import re
import socket
import os
from core.executor import ToolExecutor

class CCTVModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "cctv"
        self.executor = ToolExecutor(log_queue)
        self._parent = None
        self.out = None
        self.cameras = [] # IPs

    def render(self, parent):
        self._parent = parent
        ctk.CTkLabel(parent, text="CCTV ATTACKS", font=ctk.CTkFont(size=18, weight="bold"), text_color="#ffd700").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="discover · default creds · snapshot", font=ctk.CTkFont(size=11), text_color="#8a8a8a").pack(pady=(0, 12), padx=24, anchor="w")

        # Config
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r = ctk.CTkFrame(cfg, fg_color="transparent")
        r.pack(fill="x", padx=12, pady=8)

        self.iface = ctk.CTkOptionMenu(r, values=self._get_ifaces(), width=100, fg_color="#1a2332", button_color="#1a2332")
        self.iface.pack(side="left", padx=(0, 6))

        self.subnet = ctk.CTkEntry(r, placeholder_text="192.168.1.0/24", width=200, height=32, fg_color="#05080c", border_color="#1a2332")
        self.subnet.pack(side="left", padx=(0, 6))

        ctk.CTkButton(r, text="📹 SCAN CAMERAS", width=160, height=32, fg_color="#2b2000", hover_color="#554400", text_color="#ffd700", command=self._scan_cameras).pack(side="left", padx=(0, 6))
        ctk.CTkButton(r, text="📸 SNAPSHOT", width=140, height=32, fg_color="#141a22", hover_color="#1a2332", command=self._snapshot).pack(side="left")

        # Output
        ctk.CTkLabel(parent, text="Console:", font=ctk.CTkFont(size=12, weight="bold"), text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(parent, fg_color="#05080c", text_color="#ffd700", font=ctk.CTkFont(family="Consolas", size=10), height=450)
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 24))

    def _get_ifaces(self):
        try:
            out = subprocess.run(["ip", "-o", "link", "show"], capture_output=True, text=True).stdout
            ifaces = re.findall(r"\d+:\s+(\S+):", out)
            return [i for i in ifaces if i != "lo"] or ["eth0"]
        except Exception:
            return ["eth0"]

    def _scan_cameras(self):
        subnet = self.subnet.get().strip()
        if not subnet:
            self._safe_out("[!] Subnet required")
            return

        self._safe_out(f"[*] Scanning for cameras on {subnet}...")
        
        # نقوم بفحص المنافذ التي تستخدمها الكاميرات عادة (80, 554, 8080)
        cmd = f"nmap -p 80,554,8080 --open {subnet} -oG -"
        self.executor.run("cctv-scan", cmd, self._on_scan_done)

    def _on_scan_done(self, output):
        # استخراج IPs التي لديها منافذ مفتوحة
        ips = re.findall(r"Host:\s+(\d+\.\d+\.\d+\.\d+)\s+\(\)\s+Ports:\s+([^#]+)", output)
        self.cameras = []
        for ip, ports in ips:
            if "80/open" in ports or "554/open" in ports or "8080/open" in ports:
                self.cameras.append(ip)
                self._safe_out(f"[+] Potential Camera found: {ip} (Ports: {ports.strip()})")
        
        if not self.cameras:
            self._safe_out("[-] No cameras found.")
        else:
            self._safe_out(f"\n[+] Found {len(self.cameras)} potential cameras.")
            self._safe_out("[*] Use 'SNAPSHOT' to try to grab a picture from the first camera.")

    def _snapshot(self):
        if not self.cameras:
            self._safe_out("[!] No cameras found. Scan first.")
            return
        
        ip = self.cameras[0]
        self._safe_out(f"[*] Attempting to grab snapshot from {ip} (RTSP)...")
        
        # نستخدم ffmpeg لسحب صورة من RTSP (يفترض المسار الافتراضي)
        os.makedirs("loot/cctv_snapshots", exist_ok=True)
        outfile = f"loot/cctv_snapshots/{ip.replace('.', '_')}.jpg"
        
        cmd = ["ffmpeg", "-rtsp_transport", "tcp", "-i", f"rtsp://{ip}:554/", "-frames:v", "1", "-y", outfile]
        
        try:
            subprocess.run(cmd, capture_output=True, timeout=15)
            if os.path.exists(outfile):
                self._safe_out(f"[+] SUCCESS! Snapshot saved to {outfile}")
            else:
                self._safe_out("[-] Failed to grab snapshot (might require auth).")
        except Exception as e:
            self._safe_out(f"[!] Error: {e}")

    def _safe_out(self, text):
        if not self._parent: return
        def _u():
            if self.out and self.out.winfo_exists():
                self.out.insert("end", text + "\n")
                self.out.see("end")
        self._parent.after(0, _u)
