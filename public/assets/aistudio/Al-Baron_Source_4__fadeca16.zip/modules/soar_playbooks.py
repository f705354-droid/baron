# language: Python, file: modules/soar_playbooks.py
import customtkinter as ctk
import threading
import json
from core.soar.engine import soar_engine


class SOARPlaybooksModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "soar_playbooks"
        self.app = app
        self.engine = soar_engine

    def render(self, parent):
        ctk.CTkLabel(parent, text="SOAR PLAYBOOKS",
                      font=ctk.CTkFont(size=18, weight="bold"),
                      text_color="#00ff9c").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="orchestration · automation · response",
                      font=ctk.CTkFont(size=11),
                      text_color="#4a5568").pack(pady=(0, 12), padx=24, anchor="w")

        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24)
        for label, fn in [
            ("▸ Load playbooks", self._load),
            ("▸ List playbooks", self._list),
            ("⚡ Trigger event", self._trigger),
            ("▸ View executions", self._executions),
            ("▤ Export executions", self._export),
        ]:
            ctk.CTkButton(row, text=label, width=170, height=34,
                          fg_color="#141a22", hover_color="#1a2332",
                          command=fn).pack(side="left", padx=(0, 4))

        self.out = ctk.CTkTextbox(parent, fg_color="#05080c",
                                    text_color="#7dffb0",
                                    font=ctk.CTkFont(family="Consolas", size=10),
                                    height=500)
        self.out.pack(fill="both", expand=True, padx=24, pady=(12, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _load(self):
        self.engine.load_playbooks()
        self._out(f"[+] {len(self.engine.playbooks)} playbooks loaded")

    def _list(self):
        if not self.engine.playbooks:
            self._load()
        self._out(f"\n=== {len(self.engine.playbooks)} playbooks ===")
        for pb in self.engine.playbooks:
            self._out(f"  • {pb.name} (trigger: {pb.trigger}, "
                      f"{len(pb.actions)} actions)")

    def _trigger(self):
        import tkinter.simpledialog as sd
        event = sd.askstring("Trigger", "event name:")
        if not event:
            return
        data_str = sd.askstring("Trigger", "data (JSON):") or "{}"
        try:
            data = json.loads(data_str)
        except Exception:
            data = {}
        self.engine.emit_event(event, data)
        self._out(f"[+] event '{event}' fired")

    def _executions(self):
        execs = self.engine.get_executions()
        self._out(f"\n=== {len(execs)} executions ===")
        for e in execs[-10:]:
            self._out(f"\n• {e['playbook']} ({e['status']})")
            for a in e.get("actions_executed", []):
                self._out(f"    {a['action']}: {a['status']}")

    def _export(self):
        import tkinter.filedialog as fd
        path = fd.asksaveasfilename(
            defaultextension=".json",
            initialfile="soar_executions.json")
        if path:
            with open(path, "w") as f:
                json.dump(self.engine.get_executions(), f,
                          indent=2, default=str)
            self._out(f"[+] exported → {path}")
