# language: Python, file: modules/threat_modeler.py
# Threat Modeler UI
import customtkinter as ctk
import threading
import json
from core.threat.threat_model import ThreatModelGenerator


class ThreatModelerModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "threat_modeler"
        self.app = app
        self.generator = ThreatModelGenerator()

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="THREAT MODELER",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="STRIDE · per-host analysis · auto-mitigations",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24)
        for label, fn in [
            ("⚡ Generate all", self._generate_all),
            ("▸ Per host", self._generate_one),
            ("▤ Export JSON", self._export),
            ("▸ Show STRIDE", self._show_stride),
        ]:
            ctk.CTkButton(
                row, text=label, width=170, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).pack(side="left", padx=(0, 4))

        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=500
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(12, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _generate_all(self):
        def run():
            models = self.generator.generate_all()
            self._out(f"[+] Generated {len(models)} threat models\n")
            for m in models:
                d = m.to_dict()
                self._out(f"\n=== {d['host']} ===")
                self._out(f"  Threats: {len(d['threats'])}")
                for t in d["threats"][:5]:
                    self._out(f"    • {t.get('stride', '?')}: "
                               f"{t.get('detail') or t.get('cve')}")
                self._out(f"  Controls: {len(d['controls'])}")
                for c in d["controls"][:3]:
                    self._out(f"    ✓ {c.get('control')}")
        threading.Thread(target=run, daemon=True).start()

    def _generate_one(self):
        import tkinter.simpledialog as sd
        host = sd.askstring("Host", "IP:")
        if not host:
            return
        tm = self.generator.generate(host)
        d = tm.to_dict()
        self._out(json.dumps(d, indent=2, default=str))

    def _export(self):
        import tkinter.filedialog as fd
        path = fd.asksaveasfilename(
            defaultextension=".json",
            initialfile="threat_models.json")
        if not path:
            return
        models = self.generator.generate_all()
        with open(path, "w") as f:
            json.dump([m.to_dict() for m in models], f,
                       indent=2, default=str)
        self._out(f"[+] Exported → {path}")

    def _show_stride(self):
        from core.threat.threat_model import ThreatModel
        self._out("STRIDE Categories:")
        for cat in ThreatModel.STRIDE_CATEGORIES:
            self._out(f"  • {cat}")
