# language: Python, file: modules/graph_view.py
# Graph visualizer — force-directed view of the unified graph
import customtkinter as ctk
import tkinter as tk
import threading
import math
import random
from core.graph.graph_db import graph


class GraphViewModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "graph_view"
        self.app = app

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="UNIFIED GRAPH",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="hosts · sessions · creds · vulns — all connected",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ── actions ──
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24)
        for label, fn in [
            ("▸ Refresh", self._refresh),
            ("▸ Add host", self._add_host),
            ("▸ Add cred", self._add_cred),
            ("⌖ Find attack paths", self._find_paths),
            ("▤ Export GraphML", self._export_graphml),
            ("▤ Attack surface", self._surface),
        ]:
            ctk.CTkButton(
                row, text=label, width=170, height=32,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).pack(side="left", padx=(0, 4))

        # ── canvas ──
        self.canvas = tk.Canvas(parent, bg="#05080c",
                                  highlightthickness=0)
        self.canvas.pack(fill="both", expand=True,
                          padx=24, pady=(12, 12))

        # ── output ──
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=120
        )
        self.out.pack(fill="x", padx=24, pady=(0, 12))

        self._refresh()

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _refresh(self):
        self.out.delete("1.0", "end")
        surface = graph.get_attack_surface()
        self._out(f"Graph stats: {surface}")

        nodes = graph.list_nodes()
        if not nodes:
            self._out("no nodes yet")
            return

        # assign positions in circle
        canvas = self.canvas
        canvas.delete("all")
        w = canvas.winfo_width() or 800
        h = canvas.winfo_height() or 400
        if w < 100:
            self.after(100) if hasattr(self, "after") else None
            canvas.update()
            w = canvas.winfo_width() or 800
            h = canvas.winfo_height() or 400

        cx, cy, r = w / 2, h / 2, min(w, h) * 0.35
        positions = {}
        type_colors = {
            "host": "#00ff9c",
            "session": "#ffaa00",
            "credential": "#ff6b6b",
            "vulnerability": "#00bfff",
            "technique": "#a855f7",
            "task": "#6a7a8a",
            "artifact": "#f59e0b",
        }

        for i, n in enumerate(nodes):
            angle = (2 * math.pi * i) / len(nodes) - math.pi / 2
            x = cx + r * math.cos(angle)
            y = cy + r * math.sin(angle)
            positions[n["id"]] = (x, y)

        # edges
        for row in graph.db.execute(
            "SELECT e.src_id, e.dst_id, e.edge_type FROM edges e"
        ).fetchall():
            src, dst, etype = row
            if src in positions and dst in positions:
                x1, y1 = positions[src]
                x2, y2 = positions[dst]
                canvas.create_line(x1, y1, x2, y2,
                                    fill="#1a4a2e", width=1)

        # nodes
        for n in nodes:
            x, y = positions[n["id"]]
            color = type_colors.get(n["type"], "#4a5568")
            radius = 20
            canvas.create_oval(x - radius, y - radius,
                                x + radius, y + radius,
                                fill="#0d1319", outline=color, width=2)
            label = n["key"][:6]
            canvas.create_text(x, y, text=label,
                                fill=color,
                                font=("Consolas", 8, "bold"))
            canvas.create_text(x, y + radius + 8,
                                text=n["key"][:20],
                                fill="#6a7a8a",
                                font=("Consolas", 7))

    def _add_host(self):
        import tkinter.simpledialog as sd
        ip = sd.askstring("Add Host", "IP address:")
        if ip:
            graph.register_host(ip)
            self._refresh()
            self._out(f"[+] added host {ip}")

    def _add_cred(self):
        import tkinter.simpledialog as sd
        user = sd.askstring("Add Cred", "username:")
        if not user:
            return
        secret = sd.askstring("Add Cred", "password/hash:", show="*")
        source = sd.askstring("Add Cred", "source host:") or "manual"
        if secret:
            graph.register_credential(user, secret, source)
            self._refresh()
            self._out(f"[+] added cred {user}@{source}")

    def _find_paths(self):
        import tkinter.simpledialog as sd
        src = sd.askstring("Path", "from host IP:")
        dst = sd.askstring("Path", "to host IP:")
        if not src or not dst:
            return
        paths = graph.attack_paths(src, dst)
        self._out(f"\n[*] {len(paths)} paths from {src} → {dst}")
        for i, p in enumerate(paths[:5], 1):
            path_str = " → ".join(f"{n['key']}" for n in p)
            self._out(f"  [{i}] {path_str}")

    def _export_graphml(self):
        import tkinter.filedialog as fd
        path = fd.asksaveasfilename(
            defaultextension=".graphml",
            initialfile="albaron_graph.graphml")
        if path:
            graph.export_graphml(path)
            self._out(f"[+] exported → {path}")
            self._out("  open in Gephi, yEd, or neo4j-admin")

    def _surface(self):
        s = graph.get_attack_surface()
        self._out(f"\n=== Attack Surface ===")
        for k, v in s.items():
            self._out(f"  {k}: {v}")
