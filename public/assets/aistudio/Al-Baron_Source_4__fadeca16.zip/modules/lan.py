# language: Python, file: modules/lan.py
# Al-Baron LAN Module — discovery, port scan, vuln scan, SMB spray
import customtkinter as ctk
import threading
import subprocess
import re
import os
from core.executor import ToolExecutor

class LANModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "lan"
        self.executor = ToolExecutor(log_queue, self._parse_output)
        self._parent = None
        self.out = None
        self.hosts = {} # تخزين الأجهزة المكتشفة (IP -> MAC/Info)

    def render(self, parent):
        self._parent = parent
        ctk.CTkLabel(parent, text="LAN DOMINATION", font=ctk.CTkFont(size=18, weight="bold"), text_color="#ffd700").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="ARP discovery · port scan · vuln scan · SMB attacks", font=ctk.CTkFont(size=11), text_color="#8a8a8a").pack(pady=(0, 12), padx=24, anchor="w")

        # Discovery Config
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r = ctk.CTkFrame(cfg, fg_color="transparent")
        r.pack(fill="x", padx=12, pady=8)

        self.iface = ctk.CTkOptionMenu(r, values=self._get_ifaces(), width=120, fg_color="#1a2332", button_color="#1a2332")
        self.iface.pack(side="left", padx=(0, 6))

        self.subnet = ctk.CTkEntry(r, placeholder_text="subnet (e.g. 192.168.1.0/24)", width=220, height=32, fg_color="#05080c", border_color="#1a2332")
        self.subnet.pack(side="left", padx=(0, 6))

        ctk.CTkButton(r, text="⚡ DISCOVER", width=120, height=32, fg_color="#2b2000", hover_color="#554400", text_color="#ffd700", command=self._discover).pack(side="left", padx=(0, 6))
        ctk.CTkButton(r, text="⌖ PORT SCAN ALL", width=140, height=32, fg_color="#141a22", hover_color="#1a2332", command=self._port_scan_all).pack(side="left", padx=(0, 6))
        ctk.CTkButton(r, text="☢ VULN SCAN ALL", width=140, height=32, fg_color="#4a1a1a", hover_color="#6b1a1a", text_color="#ff6b6b", command=self._vuln_scan_all).pack(side="left")

        # Output Boxes
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="both", expand=True, padx=24, pady=12)
        row.grid_columnconfigure(0, weight=1)
        row.grid_columnconfigure(1, weight=2)
        row.grid_rowconfigure(0, weight=1)

        # Discovered Hosts (Left)
        host_frame = ctk.CTkFrame(row, fg_color="#0d1319", corner_radius=6)
        host_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        ctk.CTkLabel(host_frame, text="Discovered Hosts:", font=ctk.CTkFont(size=12, weight="bold"), text_color="#ffd700").pack(pady=8, padx=12, anchor="w")
        self.host_box = ctk.CTkTextbox(host_frame, fg_color="#05080c", text_color="#ffd700", font=ctk.CTkFont(family="Consolas", size=10))
        self.host_box.pack(fill="both", expand=True, padx=12, pady=(0, 12))

        # Console Output (Right)
        out_frame = ctk.CTkFrame(row, fg_color="#0d1319", corner_radius=6)
        out_frame.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        ctk.CTkLabel(out_frame, text="Console Output:", font=ctk.CTkFont(size=12, weight="bold"), text_color="#c8d6e5").pack(pady=8, padx=12, anchor="w")
        self.out = ctk.CTkTextbox(out_frame, fg_color="#05080c", text_color="#ffd700", font=ctk.CTkFont(family="Consolas", size=10))
        self.out.pack(fill="both", expand=True, padx=12, pady=(0, 12))

    def _get_ifaces(self):
        try:
            out = subprocess.run(["ip", "-o", "link", "show"], capture_output=True, text=True).stdout
            ifaces = re.findall(r"\d+:\s+(\S+):", out)
            return [i for i in ifaces if i != "lo"] or ["eth0"]
        except Exception:
            return ["eth0"]

    def _discover(self):
        iface = self.iface.get()
        subnet = self.subnet.get().strip()
        if not subnet:
            self._safe_out("[!] Subnet required")
            return

        self.out.delete("1.0", "end")
        self.host_box.delete("1.0", "end")
        self.hosts = {} # تصفير القائمة
        
        self._safe_out(f"[*] Scanning {subnet} on {iface}...")
        
        # استخدام nmap بدلاً من arp-scan ليعمل بدون root
        cmd = f"nmap -sn {subnet} -oG -"
        self.executor.run("nmap-discovery", cmd, self._on_discovery_done)

    def _parse_output(self, line):
        # استخراج IP من مخرجات nmap -oG
        match = re.search(r"Host:\s+(\d+\.\d+\.\d+\.\d+)", line)
        if match:
            ip = match.group(1)
            if ip not in self.hosts:
                self.hosts[ip] = "UP"
                self._safe_out_host(f"{ip:<16} UP")
                self._safe_out(f"[+] Found host: {ip}")

    def _on_discovery_done(self, output):
        self._safe_out(f"\n[+] Discovery complete. Found {len(self.hosts)} hosts.")

    def _port_scan_all(self):
        if not self.hosts:
            self._safe_out("[!] Discover hosts first.")
            return
        
        self._safe_out(f"\n[*] Starting port scan on {len(self.hosts)} hosts...")
        for ip in list(self.hosts.keys()):
            self._safe_out(f"\n[*] Scanning ports on {ip}...")
            # فحص سريع لأشهر المنافذ
            cmd = f"nmap -sS -sV --top-ports 1000 -T4 {ip}"
            self.executor.run(f"nmap-{ip}", cmd)

    def _vuln_scan_all(self):
        if not self.hosts:
            self._safe_out("[!] Discover hosts first.")
            return
        
        self._safe_out(f"\n[!] Starting VULNERABILITY scan on {len(self.hosts)} hosts...")
        self._safe_out("[*] This may take a while. Sit back.")
        
        for ip in list(self.hosts.keys()):
            self._safe_out(f"\n[☢] Scanning for CVEs on {ip}...")
            # فحص الثغرات باستخدام سكربتات nmap
            cmd = f"nmap -sV --script vuln -T4 {ip}"
            self.executor.run(f"vuln-{ip}", cmd, lambda out, ip=ip: self._on_vuln_done(ip, out))

    def _on_vuln_done(self, ip, output):
        # البحث عن كلمة "VULNERABLE" في المخرجات
        if "VULNERABLE" in output or "CVE-" in output:
            self._safe_out(f"\n[!!!] {ip} HAS VULNERABILITIES! Check output above.")
            self._safe_out_host(f"{ip:<16} ⚠ VULNERABLE")
        else:
            self._safe_out(f"[+] {ip} seems clean (no known vulns in script).")

    def _safe_out(self, text):
        if not self._parent: return
        def _u():
            if self.out and self.out.winfo_exists():
                self.out.insert("end", text + "\n")
                self.out.see("end")
        self._parent.after(0, _u)

    def _safe_out_host(self, text):
        if not self._parent: return
        def _u():
            if self.host_box and self.host_box.winfo_exists():
                self.host_box.insert("end", text + "\n")
                self.host_box.see("end")
        self._parent.after(0, _u)
