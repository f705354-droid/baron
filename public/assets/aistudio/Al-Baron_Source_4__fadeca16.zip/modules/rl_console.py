# language: Python, file: modules/rl_console.py
# RL console — policy stats, replay buffer, DPO training, HRL, Bayesian, Coq
import customtkinter as ctk
import threading
import json
from core.ai.rl.replay import replay
from core.ai.rl.policy import policy, HAS_TORCH
from core.ai.rl.trainer import trainer


class RLConsoleModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "rl_console"
        self.app = app

    def render(self, parent):
        ctk.CTkLabel(parent, text="RL CONSOLE",
                      font=ctk.CTkFont(size=18, weight="bold"),
                      text_color="#00ff9c").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="policy · replay · DPO training · HRL · Bayesian · Coq",
                      font=ctk.CTkFont(size=11),
                      text_color="#4a5568").pack(pady=(0, 12), padx=24, anchor="w")

        actions = ctk.CTkFrame(parent, fg_color="transparent")
        actions.pack(fill="x", padx=24)
        
        # الأزرار الأساسية وأزرار الإضافات الجديدة لـ HRL و Bayesian و Coq
        for label, fn in [
            ("▸ Replay stats", self._stats),
            ("▸ Policy tool stats", self._tool_stats),
            ("▸ Train DPO", self._train_dpo),
            ("▸ Train reward model", self._train_rm),
            ("▸ Sample batch", self._sample),
            ("▸ Export trajectory", self._export_traj),
            ("▸ Reset policy", self._reset),
            ("▸ Save policy", lambda: policy.save()),
            ("▸ HRL option stats", self._hrl_stats),
            ("▸ Intrinsic bonuses", self._intrinsic),
            ("▸ Ensemble uncertainty", self._ensemble),
            ("▸ Calibration ECE", self._calibration),
            ("▸ Coq runtime test", self._coq_test),
            ("▸ Save all models", self._save_all),
        ]:
            ctk.CTkButton(actions, text=label, width=160, height=32,
                           fg_color="#141a22", hover_color="#1a2332",
                           font=ctk.CTkFont(size=11),
                           command=fn).pack(side="left", padx=(0, 4), pady=(0, 4))

        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10))
        self.out.pack(fill="both", expand=True, padx=24, pady=(12, 12))

    def _out(self, t):
        self.out.insert("end", t + "\n")
        self.out.see("end")

    def _stats(self):
        self._out(json.dumps(replay.stats(), indent=2))

    def _tool_stats(self):
        data = {
            t: {"alpha": round(policy.tool_alpha[t], 2),
                "beta": round(policy.tool_beta[t], 2),
                "mean": round(policy.tool_alpha[t] /
                              (policy.tool_alpha[t] + policy.tool_beta[t]), 3)}
            for t in policy.tool_list
        }
        data = dict(sorted(data.items(), key=lambda x: -x[1]["mean"]))
        self._out(json.dumps(data, indent=2))

    def _train_dpo(self):
        def run():
            self._out("[*] training DPO...")
            res = trainer.train_dpo(epochs=3)
            self._out(json.dumps(res, indent=2))
        threading.Thread(target=run, daemon=True).start()

    def _train_rm(self):
        def run():
            self._out("[*] training reward model...")
            res = trainer.train_reward_model()
            self._out(json.dumps(res, indent=2))
        threading.Thread(target=run, daemon=True).start()

    def _sample(self):
        b = replay.sample(batch_size=5)
        self._out(json.dumps([{
            "reward": x["reward"],
            "action": x["action"][:80],
            "priority": round(x["priority"], 3),
        } for x in b], indent=2))

    def _export_traj(self):
        import tkinter.simpledialog as sd
        rid = sd.askstring("Export", "Run ID:")
        if rid:
            traj = replay.trajectories(rid)
            import tkinter.filedialog as fd
            path = fd.asksaveasfilename(defaultextension=".json",
                                          initialfile=f"traj-{rid}.json")
            if path:
                with open(path, "w") as f:
                    json.dump(traj, f, indent=2, default=str)
                self._out(f"exported {len(traj)} steps → {path}")

    def _reset(self):
        import tkinter.messagebox as mb
        if mb.askyesno("Reset", "مسح الـpolicy والـreplay؟"):
            import os
            for p in ["~/.albaron/policy.pt", "~/.albaron/policy.pt.bandit"]:
                try:
                    os.remove(os.path.expanduser(p))
                except Exception:
                    pass
            self._out("reset requested — أعد تشغيل الواجهة")

    # ── وحدات الإضافات الجديدة (HRL + Bayesian + Coq) ──
    def _hrl_stats(self):
        from core.ai.rl.hrl.manager import manager
        self._out(json.dumps({
            "K": manager.K,
            "options": manager.option_stats,
        }, indent=2))

    def _intrinsic(self):
        from core.ai.rl.hrl.intrinsic import intrinsic
        self._out(json.dumps(intrinsic.describe(), indent=2))

    def _ensemble(self):
        from core.ai.rl.bayesian.ensemble import ensemble
        import numpy as np
        s = np.random.randn(128).astype(np.float32)
        mean, ep, al = ensemble.predict(s)
        self._out(json.dumps({
            "n_members": ensemble.n_members,
            "sample_epistemic": ep,
            "sample_aleatoric": al,
            "max_prob": float(mean.max()),
        }, indent=2))

    def _calibration(self):
        from core.ai.rl.bayesian.calibration import calibrator
        self._out(json.dumps({
            "temperature": calibrator.temperature,
            "ece_history": calibrator.ece_history[-10:],
        }, indent=2))

    def _coq_test(self):
        from core.ai.formal.coq_runtime.wrapper import coq_runtime
        test_state = {
            "iteration": 5, "tokens_used": 100,
            "minutes_elapsed": 10, "auto_approve": False,
            "goal_reached": False, "approvals": set(),
            "max_iterations": 50, "max_tokens": 500_000,
            "max_minutes": 60,
        }
        test_action = {"tool": "run_shell", "args": {"cmd": "id"}}
        res = coq_runtime.check(test_state, test_action)
        self._out(json.dumps(res, indent=2))

    def _save_all(self):
        from core.ai.rl.hrl.manager import manager
        from core.ai.rl.hrl.worker import worker
        from core.ai.rl.bayesian.ensemble import ensemble
        from core.ai.rl.bayesian.dropout import mc_dropout
        from core.ai.rl.bayesian.bbb import bbb
        from core.ai.rl.policy import policy
        manager.save()
        worker.save()
        ensemble.save()
        mc_dropout.save()
        bbb.save()
        policy.save()
        self._out("all models saved")
