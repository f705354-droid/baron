# language: Python, file: modules/ai_advanced.py
# advanced AI — multi-agent, RAG over past ops, planner, autopilot
import customtkinter as ctk
import threading
import os
import json
import time
from datetime import datetime
from utils.progress import ProgressTracker


SYSTEM_PLANNER = """You are the Al-Baron mission planner AI.
Given: target description, scope, constraints, prior findings.
Output: an ordered attack plan with tool calls, per step, and abort conditions.
Be terse. Format: numbered steps, each with [tool], [input], [expected], [risk]."""

SYSTEM_ANALYST = """You are the Al-Baron analyst AI.
Given: raw output of a security tool, produce: (1) parsed facts, (2) notable findings,
(3) next-step suggestions. Terse. Markdown-free. Bullet-prefixed."""

SYSTEM_REPORTER = """You are the Al-Baron report writer AI.
Given: structured engagement data, produce: exec summary, key findings, recommendations.
Match tone: professional, direct, no filler."""


class AIAdvancedModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "ai_advanced"
        self.app = app
        self.progress = ProgressTracker(log_queue)
        self.history = []       # (prompt, response, ts)
        self.rag_index = {}     # session_id → list of past interactions
        self.autopilot_thread = None
        self.autopilot_stop = threading.Event()

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="AI OPERATIONS",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="planner · analyst · autopilot · RAG over past ops · agents",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ---- config ----
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r1 = ctk.CTkFrame(cfg, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=8)
        self.provider = ctk.CTkOptionMenu(
            r1, values=["anthropic", "openai", "local", "hybrid"],
            width=140, fg_color="#1a2332", button_color="#1a2332")
        self.provider.pack(side="left", padx=(0, 6))
        self.model = ctk.CTkEntry(
            r1, placeholder_text="model (claude-sonnet-4, gpt-4o, ...)",
            width=280, height=32, fg_color="#05080c", border_color="#1a2332")
        self.model.pack(side="left", padx=(0, 6))
        self.mode = ctk.CTkOptionMenu(
            r1, values=["chat", "plan", "analyze", "report", "autopilot"],
            width=130, fg_color="#1a2332", button_color="#1a2332")
        self.mode.pack(side="left", padx=(0, 6))
        self.rag_toggle = ctk.CTkCheckBox(
            r1, text="RAG", fg_color="#0d2818", hover_color="#1a4a2e",
            text_color="#c8d6e5")
        self.rag_toggle.select()
        self.rag_toggle.pack(side="left")

        # ---- actions ----
        ctk.CTkLabel(parent, text="Operations:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")

        grid = ctk.CTkFrame(parent, fg_color="transparent")
        grid.pack(fill="x", padx=24)

        actions = [
            ("▸ Ask (chat)", self._ask),
            ("▸ Plan mission", self._plan),
            ("▸ Analyze output", self._analyze),
            ("▸ Write report", self._write_report),
            ("▸ Start autopilot", self._autopilot_start),
            ("▸ Stop autopilot", self._autopilot_stop_fn),
            ("▸ Index past ops (RAG)", self._index_rag),
            ("▸ Search past (RAG)", self._search_rag),
            ("▸ Model A/B", self._ab_test),
            ("▸ Suggest next step", self._suggest_next),
            ("▸ Explain output", self._explain),
            ("▸ Auto-triage findings", self._triage),
            ("▸ Multi-agent session", self._multi_agent),
            ("▸ Fingerprint target", self._fingerprint),
            ("▸ Simulate attack", self._simulate),
            ("▸ Generate payload (AI)", self._gen_payload),
        ]
        for i, (label, fn) in enumerate(actions):
            ctk.CTkButton(
                grid, text=label, width=220, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).grid(row=i // 4, column=i % 4, padx=4, pady=4)

        # ---- input ----
        ctk.CTkLabel(parent, text="Query / context:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.input = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#c8d6e5",
            font=ctk.CTkFont(family="Consolas", size=11), height=100
        )
        self.input.pack(fill="x", padx=24)
        ctk.CTkButton(
            parent, text="▸ SEND", height=36,
            fg_color="#0d2818", hover_color="#1a4a2e",
            text_color="#00ff9c", command=self._ask
        ).pack(pady=8, padx=24, anchor="w")

        # ---- output ----
        ctk.CTkLabel(parent, text="Output:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(8, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=11), height=280
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    # ==================== backends ====================
    def _call(self, system: str, prompt: str, max_tokens=2048) -> str:
        provider = self.provider.get()
        model = self.model.get().strip() or None
        if provider in ("anthropic", "hybrid"):
            try:
                from anthropic import Anthropic
                c = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
                r = c.messages.create(
                    model=model or "claude-sonnet-4-20250514",
                    max_tokens=max_tokens, system=system,
                    messages=[{"role": "user", "content": prompt}])
                return r.content[0].text
            except Exception as e:
                if provider == "hybrid":
                    pass
                else:
                    return f"[ai error: {e}]"
        if provider in ("openai", "hybrid"):
            try:
                from openai import OpenAI
                c = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
                r = c.chat.completions.create(
                    model=model or "gpt-4o",
                    messages=[{"role": "system", "content": system},
                              {"role": "user", "content": prompt}],
                    max_tokens=max_tokens)
                return r.choices[0].message.content
            except Exception as e:
                return f"[ai error: {e}]"
        # local fallback
        return self._local_reasoning(system, prompt)

    def _local_reasoning(self, system: str, prompt: str) -> str:
        """rule-based fallback with heuristic output"""
        p = prompt.lower()
        if "plan" in system.lower():
            return ("Local planner: 1) Recon with nmap -sS -sV -O\n"
                    "2) Enumerate services with relevant scripts\n"
                    "3) Search exploits via searchsploit/CVE DB\n"
                    "4) Test auth/defaults\n"
                    "5) Post-ex for privilege and lateral\n"
                    "6) Exfil + cleanup")
        if "analyst" in system.lower():
            return ("Local analyst: extracted ports, services, versions above.\n"
                    "- Note any <2-year-old CVEs on the identified versions\n"
                    "- Note any admin panels or default creds paths\n"
                    "- Next: targeted exploit search per service")
        if "reporter" in system.lower():
            return ("Executive summary: engagement tested X hosts, found Y findings.\n"
                    "Key findings: list categories by severity.\n"
                    "Recommendations: patch cadence, IAM hardening, monitoring.")
        return ("Local AI — set ANTHROPIC_API_KEY or OPENAI_API_KEY for full "
                "reasoning. Question received.")

    # ==================== operations ====================
    def _ask(self):
        q = self.input.get("1.0", "end").strip()
        if not q:
            return
        self._out(f"\n[user]\n{q}\n")
        ctx = self._rag_context(q) if self.rag_toggle.get() else ""
        prompt = f"{ctx}\n\n{q}" if ctx else q
        threading.Thread(target=self._run_query,
                         args=(SYSTEM_PLANNER, prompt), daemon=True).start()

    def _run_query(self, system, prompt):
        self.progress.start(f"ai-{int(time.time())}", "AI query")
        try:
            reply = self._call(system, prompt)
            self._out(f"\n[ai]\n{reply}\n")
            self.history.append((prompt, reply, datetime.utcnow().isoformat()))
        finally:
            self.progress.finish(f"ai-{int(time.time())}", detail="done")

    def _plan(self):
        ctx = self._engagement_context()
        self._out("\n=== Mission plan ===\n")
        threading.Thread(target=self._run_query,
                         args=(SYSTEM_PLANNER, ctx), daemon=True).start()

    def _analyze(self):
        data = self.input.get("1.0", "end").strip()
        if not data:
            self._out("[!] paste tool output into input box")
            return
        threading.Thread(target=self._run_query,
                         args=(SYSTEM_ANALYST, data), daemon=True).start()

    def _write_report(self):
        data = self._engagement_context()
        threading.Thread(target=self._run_query,
                         args=(SYSTEM_REPORTER, data), daemon=True).start()

    def _suggest_next(self):
        ctx = self._engagement_context()
        prompt = f"{ctx}\n\nSuggest next 3 highest-value actions."
        threading.Thread(target=self._run_query,
                         args=(SYSTEM_PLANNER, prompt), daemon=True).start()

    def _explain(self):
        data = self.input.get("1.0", "end").strip()
        if data:
            threading.Thread(target=self._run_query,
                args=("Explain this output for a junior operator. Terse.",
                      data), daemon=True).start()

    def _triage(self):
        data = self.input.get("1.0", "end").strip() or self._engagement_context()
        system = ("Triage findings. Output table: SEV | FINDING | REASON | ACTION.")
        threading.Thread(target=self._run_query, args=(system, data),
                         daemon=True).start()

    def _fingerprint(self):
        target = self.input.get("1.0", "end").strip()
        system = "Fingerprint target from given description. Output: OS, services, likely stack, attack surface."
        threading.Thread(target=self._run_query, args=(system, target),
                         daemon=True).start()

    def _simulate(self):
        target = self.input.get("1.0", "end").strip()
        system = ("Simulate attack chain. For each step: action, tool, expected output, "
                  "detection risk (L/M/H), abort condition.")
        threading.Thread(target=self._run_query, args=(system, target),
                         daemon=True).start()

    def _gen_payload(self):
        spec = self.input.get("1.0", "end").strip()
        system = ("Write a payload matching the spec. Output runnable code only. "
                  "Language per request. No markdown fences.")
        threading.Thread(target=self._run_query, args=(system, spec),
                         daemon=True).start()

    def _ab_test(self):
        """run same query against two providers, compare"""
        q = self.input.get("1.0", "end").strip()
        if not q:
            return
        def run():
            self._out(f"\n=== A/B test ===\nQuery: {q}\n")
            providers = ["anthropic", "openai"]
            old = self.provider.get()
            for p in providers:
                self.provider.set(p)
                r = self._call(SYSTEM_PLANNER, q)
                self._out(f"\n--- {p} ---\n{r}\n")
            self.provider.set(old)
        threading.Thread(target=run, daemon=True).start()

    # ==================== RAG ====================
    def _index_rag(self):
        """index past sessions and findings for later retrieval"""
        tid = f"rag-{int(time.time())}"
        self.progress.start(tid, "Indexing past ops")
        docs = []
        # pull from app modules
        if self.app:
            for key, mod in self.app.modules.items():
                try:
                    if hasattr(mod, "sessions"):
                        for sid, s in mod.sessions.items():
                            docs.append({
                                "source": f"{key}:session:{sid}",
                                "text": json.dumps(s, default=str),
                            })
                    if hasattr(mod, "hosts"):
                        for ip, h in mod.hosts.items():
                            docs.append({
                                "source": f"{key}:host:{ip}",
                                "text": json.dumps(h, default=str),
                            })
                except Exception:
                    pass
            # loot files
            for root, _, files in os.walk("loot"):
                for f in files:
                    p = os.path.join(root, f)
                    try:
                        size = os.path.getsize(p)
                        if size < 100_000:
                            with open(p, "r", errors="ignore") as fh:
                                docs.append({"source": f"loot:{p}",
                                             "text": fh.read()[:5000]})
                    except Exception:
                        pass
        self.rag_index = {f"doc-{i}": d for i, d in enumerate(docs)}
        self._out(f"[+] indexed {len(self.rag_index)} documents")
        self.progress.finish(tid, detail=f"{len(self.rag_index)} docs")

    def _search_rag(self):
        q = self.input.get("1.0", "end").strip()
        if not q:
            return
        if not self.rag_index:
            self._index_rag()
        # simple keyword + trigram scoring (fallback)
        q_terms = set(q.lower().split())
        results = []
        for did, d in self.rag_index.items():
            score = sum(1 for t in q_terms if t in d["text"].lower())
            if score > 0:
                results.append((score, d))
        results.sort(key=lambda x: -x[0])
        self._out(f"\n=== RAG top {min(len(results), 10)} ===")
        for score, d in results[:10]:
            self._out(f"\n[{d['source']}] (score={score})")
            self._out(d["text"][:400])

    def _rag_context(self, query: str) -> str:
        if not self.rag_index:
            return ""
        q_terms = set(query.lower().split())
        scored = []
        for d in self.rag_index.values():
            s = sum(1 for t in q_terms if t in d["text"].lower())
            if s > 0:
                scored.append((s, d["text"][:1500]))
        scored.sort(key=lambda x: -x[0])
        return "\n\n--- prior context ---\n" + "\n---\n".join(
            t for _, t in scored[:5])

    # ==================== autopilot ====================
    def _autopilot_start(self):
        if self.autopilot_thread and self.autopilot_thread.is_alive():
            self._out("[!] autopilot already running")
            return
        self.autopilot_stop.clear()
        self.autopilot_thread = threading.Thread(
            target=self._autopilot_loop, daemon=True)
        self.autopilot_thread.start()
        self._out("[+] autopilot started")

    def _autopilot_stop_fn(self):
        self.autopilot_stop.set()
        self._out("[+] autopilot stop requested")

    def _autopilot_loop(self):
        """
        Autopilot reads recent findings, plans next step, and pushes tasks
        into the active C2 session. Loops with human-in-the-loop timer.
        """
        cycles = 0
        while not self.autopilot_stop.is_set():
            cycles += 1
            try:
                ctx = self._engagement_context()
                # ask AI for a single next action
                action = self._call(SYSTEM_PLANNER,
                    f"{ctx}\n\nSuggest ONE next action in format: "
                    f"SESSION_ID | shell:COMMAND or SUGGESTION. "
                    f"Nothing else.", max_tokens=200)
                self._out(f"\n[autopilot cycle {cycles}]\n{action}\n")

                # parse and dispatch
                for line in action.splitlines():
                    if "|" in line:
                        sid, task = [x.strip() for x in line.split("|", 1)]
                        if self.app:
                            c2ui = self.app.modules.get("c2_ui")
                            if c2ui and hasattr(c2ui, "on_dispatch"):
                                c2ui.on_dispatch(sid, task)
                                self._out(f"[+] dispatched to {sid}: {task}")
                                break
            except Exception as e:
                self._out(f"[autopilot err] {e}")

            # wait 60s between cycles (or stop signal)
            for _ in range(60):
                if self.autopilot_stop.is_set():
                    break
                time.sleep(1)

        self._out("[+] autopilot stopped")

    # ==================== multi-agent ====================
    def _multi_agent(self):
        """
        Launch a multi-agent workflow: Planner → Executor → Analyst → Reporter.
        Executor dispatches real tasks via the C2 UI. Agents communicate through
        a shared blackboard (dict).
        """
        goal = self.input.get("1.0", "end").strip()
        if not goal:
            self._out("[!] enter a goal in the input box")
            return

        def run():
            blackboard = {"goal": goal, "history": [], "findings": []}
            self._out(f"\n=== multi-agent session ===\nGoal: {goal}\n")

            # Agent 1: Planner
            plan = self._call(SYSTEM_PLANNER, goal)
            blackboard["plan"] = plan
            self._out(f"\n[planner]\n{plan}\n")

            # Agent 2: Executor — picks first action, dispatches
            c2ui = self.app.modules.get("c2_ui") if self.app else None
            if c2ui and c2ui.sessions:
                sid = next(iter(c2ui.sessions))
                first_cmd = None
                for line in plan.splitlines():
                    if line.strip().startswith("1.") or "shell:" in line:
                        first_cmd = line.split("shell:")[-1].strip()
                        break
                if first_cmd:
                    self._out(f"\n[executor] dispatching to {sid}: {first_cmd}")
                    if hasattr(c2ui, "on_dispatch"):
                        c2ui.on_dispatch(sid, f"shell:{first_cmd}")
                    blackboard["history"].append({"sid": sid, "cmd": first_cmd})

            # Agent 3: Analyst
            result = "\n".join(blackboard["history"] and [""] or [])
            analysis = self._call(SYSTEM_ANALYST, json.dumps(blackboard))
            blackboard["analysis"] = analysis
            self._out(f"\n[analyst]\n{analysis}\n")

            # Agent 4: Reporter
            report = self._call(SYSTEM_REPORTER, json.dumps(blackboard))
            self._out(f"\n[reporter]\n{report}\n")

        threading.Thread(target=run, daemon=True).start()

    # ==================== context ====================
    def _engagement_context(self) -> str:
        if not self.app:
            return "(no app context)"
        parts = []
        for key, mod in self.app.modules.items():
            try:
                if hasattr(mod, "hosts"):
                    parts.append(f"[{key}] {len(mod.hosts)} hosts")
                if hasattr(mod, "sessions"):
                    parts.append(f"[{key}] {len(mod.sessions)} sessions")
                if hasattr(mod, "domain") and mod.domain:
                    parts.append(f"[{key}] domain {mod.domain}")
            except Exception:
                pass
        return "\n".join(parts)
