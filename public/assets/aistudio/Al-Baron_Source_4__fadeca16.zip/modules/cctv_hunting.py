# language: Python, file: modules/cctv_hunting.py
# CCTV Threat Hunting — Blue Team passive & active detection
import customtkinter as ctk
import threading
import json
import socket
import struct
import time
import os
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor


# ═══════════════════════════════════════════════════════════════════
# CCTV Hunter
# ═══════════════════════════════════════════════════════════════════
class CCTVHunter:
    CAMERA_OUIS = {
        "C0:56:E3": "Hikvision", "44:19:B6": "Hikvision",
        "4C:BD:8F": "Hikvision", "BC:76:70": "Hikvision",
        "28:57:BE": "Hikvision", "B4:A3:82": "Dahua",
        "3C:EF:8C": "Dahua", "90:02:A9": "Dahua",
        "E0:50:8B": "Dahua", "00:40:8C": "Axis",
        "AC:CC:8E": "Axis", "B8:A4:4F": "Axis",
        "00:0D:C5": "Vivotek", "00:02:D1": "Vivotek",
        "3C:A3:08": "TP-Link Tapo", "A4:DA:22": "TP-Link Tapo",
        "78:11:DC": "Xiaomi", "F0:B4:29": "Xiaomi",
        "C4:2F:90": "Xiaomi",
    }

    CAMERA_SIGNATURES = [
        ("Server", "Hikvision"), ("Server", "Dahua"),
        ("Server", "Boa"), ("Server", "goahead"),
        ("Server", "App-webs"), ("WWW-Authenticate", "Hikvision"),
        ("WWW-Authenticate", "Dahua"), ("WWW-Authenticate", "AXIS"),
    ]

    TITLE_KEYWORDS = [
        "camera", "ipc", "nvr", "dvr", "cctv", "surveillance",
        "webcam", "hikvision", "dahua", "axis", "vivotek",
        "reolink", "amcrest", "uniview", "foscam", "tapo",
    ]

    def __init__(self, log_queue=None):
        self.log = log_queue
        self.findings = []
        self.on_finding = None

    def _out(self, text):
        if self.log:
            self.log.put(f"[hunt] {text}")

    def _emit(self, finding):
        self.findings.append(finding)
        self._out(f"{finding['severity'].upper()}: {finding['title']}")
        if self.on_finding:
            try:
                self.on_finding(finding)
            except Exception:
                pass

    def sniff_multicast(self, duration=30):
        self._out(f"passive sniffing for {duration}s...")
        found = []

        def ssdp():
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(("", 1900))
                mreq = struct.pack("4s4s", socket.inet_aton("239.255.255.250"), socket.inet_aton("0.0.0.0"))
                sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
                sock.settimeout(1)
                start = time.time()
                seen = set()
                while time.time() - start < duration:
                    try:
                        data, addr = sock.recvfrom(65535)
                        ip = addr[0]
                        if ip in seen: continue
                        text = data.decode(errors="ignore")
                        lower = text.lower()
                        if any(kw in lower for kw in self.TITLE_KEYWORDS):
                            seen.add(ip)
                            finding = {
                                "severity": "medium",
                                "title": f"Camera detected (SSDP): {ip}",
                                "ip": ip, "source": "ssdp",
                                "evidence": text[:300],
                                "detected_at": datetime.now().isoformat(),
                            }
                            found.append(finding)
                            self._emit(finding)
                    except socket.timeout:
                        continue
                sock.close()
            except Exception as e:
                self._out(f"ssdp: {e}")

        t = threading.Thread(target=ssdp)
        t.start()
        t.join()
        return found

    def probe_host(self, ip, timeout=2.0):
        import httpx
        ports = [80, 554, 8080, 8000, 88, 443]
        open_ports = []
        for port in ports:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(timeout)
                if sock.connect_ex((ip, port)) == 0:
                    open_ports.append(port)
                sock.close()
            except Exception:
                pass
        if not open_ports:
            return {}

        if 554 in open_ports:
            try:
                sock = socket.create_connection((ip, 554), timeout=timeout)
                sock.settimeout(timeout)
                sock.send(f"OPTIONS rtsp://{ip}:554/ RTSP/1.0\r\nCSeq: 1\r\n\r\n".encode())
                resp = sock.recv(4096).decode(errors="ignore")
                sock.close()
                if "RTSP/1.0" in resp:
                    finding = {
                        "severity": "medium",
                        "title": f"Unauthorized RTSP camera: {ip}",
                        "ip": ip, "source": "rtsp",
                        "open_ports": open_ports,
                        "detected_at": datetime.now().isoformat(),
                    }
                    self._emit(finding)
                    return finding
            except Exception:
                pass

        for port in [80, 8080, 8000]:
            if port in open_ports:
                try:
                    r = httpx.get(f"http://{ip}:{port}/", timeout=timeout, verify=False, follow_redirects=True)
                    for header, expected in self.CAMERA_SIGNATURES:
                        val = r.headers.get(header, "")
                        if expected.lower() in val.lower():
                            finding = {
                                "severity": "medium",
                                "title": f"Camera signature ({expected}): {ip}",
                                "ip": ip, "source": "http",
                                "open_ports": open_ports,
                                "detected_at": datetime.now().isoformat(),
                            }
                            self._emit(finding)
                            return finding
                    import re
                    m = re.search(r"<title>(.*?)</title>", r.text, re.I | re.DOTALL)
                    if m:
                        title = m.group(1).lower()
                        if any(kw in title for kw in self.TITLE_KEYWORDS):
                            finding = {
                                "severity": "medium",
                                "title": f"Camera page: {ip} ({m.group(1)[:40]})",
                                "ip": ip, "source": "http_title",
                                "open_ports": open_ports,
                                "detected_at": datetime.now().isoformat(),
                            }
                            self._emit(finding)
                            return finding
                except Exception:
                    pass
        return {}

    def hunt_network(self, cidr, active=True, passive_duration=30):
        self._out(f"starting hunt on {cidr}")
        findings = []
        findings.extend(self.sniff_multicast(duration=passive_duration))

        if active:
            import ipaddress
            try:
                net = ipaddress.ip_network(cidr, strict=False)
            except ValueError:
                return {"error": "invalid CIDR"}

            hosts = [str(ip) for ip in net.hosts()]
            self._out(f"active probing {len(hosts)} hosts...")

            with ThreadPoolExecutor(max_workers=50) as ex:
                results = list(ex.map(self.probe_host, hosts))

            for r in results:
                if r:
                    findings.append(r)

        return {
            "cidr": cidr,
            "total_findings": len(findings),
            "findings": findings,
            "completed_at": datetime.now().isoformat(),
        }


# ═══════════════════════════════════════════════════════════════════
# Module UI
# ═══════════════════════════════════════════════════════════════════
class CCTVHuntingModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "cctv_hunting"
        self.app = app
        self.hunter = CCTVHunter(log_queue)
        self.findings = []
        self._parent = None
        self.out = None

    def render(self, parent):
        self._parent = parent
        
        ctk.CTkLabel(
            parent, text="CCTV THREAT HUNTING",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00bfff"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="blue team · passive sniffing · active probing · OUI detection",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r = ctk.CTkFrame(cfg, fg_color="transparent")
        r.pack(fill="x", padx=12, pady=8)

        ctk.CTkLabel(r, text="CIDR:", font=ctk.CTkFont(size=11), text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.cidr_entry = ctk.CTkEntry(r, placeholder_text="192.168.1.0/24", width=220, height=30, fg_color="#05080c", border_color="#1a2332")
        self.cidr_entry.pack(side="left", padx=(0, 8))

        ctk.CTkLabel(r, text="Passive duration (s):", font=ctk.CTkFont(size=11), text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.duration_entry = ctk.CTkEntry(r, width=60, height=30, fg_color="#05080c", border_color="#1a2332")
        self.duration_entry.insert(0, "30")
        self.duration_entry.pack(side="left")

        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24, pady=12)
        for label, fn in [
            ("🎯 Full Hunt (active+passive)", self._hunt_full),
            ("📡 Passive Only", self._hunt_passive),
            ("📡 Active Only", self._hunt_active),
            ("▸ Export Findings", self._export),
            ("▸ Clear", self._clear),
        ]:
            ctk.CTkButton(row, text=label, width=220, height=34, fg_color="#141a22", hover_color="#1a2332", font=ctk.CTkFont(size=11), command=fn).pack(side="left", padx=(0, 4))

        ctk.CTkLabel(parent, text="Findings:", font=ctk.CTkFont(size=12, weight="bold"), text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")

        self.out = ctk.CTkTextbox(parent, fg_color="#05080c", text_color="#7dffb0", font=ctk.CTkFont(family="Consolas", size=10), height=450)
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _safe_out(self, text):
        """دالة آمنة للكتابة في الـ Textbox من داخل Threads"""
        if not self._parent:
            return
        def _update():
            if self.out and self.out.winfo_exists():
                self.out.insert("end", text + "\n")
                self.out.see("end")
        self._parent.after(0, _update)

    def _hunt_full(self):
        cidr = self.cidr_entry.get().strip()
        if not cidr:
            self._safe_out("[!] CIDR required")
            return
        try:
            duration = int(self.duration_entry.get() or "30")
        except ValueError:
            duration = 30

        def run():
            if self.out and self.out.winfo_exists():
                self._parent.after(0, lambda: self.out.delete("1.0", "end"))
            self._safe_out(f"[*] hunting on {cidr} (passive {duration}s + active)...")
            
            self.hunter.on_finding = lambda f: self._safe_out(f"\n⚠ [{f['severity'].upper()}] {f['title']}")
            
            result = self.hunter.hunt_network(cidr, active=True, passive_duration=duration)
            
            self._safe_out(f"\n[+] Hunt complete: {result.get('total_findings', 0)} findings")
            self._safe_out(json.dumps(result, indent=2, default=str)[:5000])
        
        threading.Thread(target=run, daemon=True).start()

    def _hunt_passive(self):
        try:
            duration = int(self.duration_entry.get() or "30")
        except ValueError:
            duration = 30

        def run():
            if self.out and self.out.winfo_exists():
                self._parent.after(0, lambda: self.out.delete("1.0", "end"))
            self._safe_out(f"[*] passive sniffing for {duration}s...")
            
            self.hunter.on_finding = lambda f: self._safe_out(f"⚠ {f['title']}")
            
            findings = self.hunter.sniff_multicast(duration=duration)
            self._safe_out(f"\n[+] {len(findings)} findings")
        
        threading.Thread(target=run, daemon=True).start()

    def _hunt_active(self):
        cidr = self.cidr_entry.get().strip()
        if not cidr:
            return

        def run():
            if self.out and self.out.winfo_exists():
                self._parent.after(0, lambda: self.out.delete("1.0", "end"))
            self._safe_out(f"[*] active probing {cidr}...")
            
            result = self.hunter.hunt_network(cidr, active=True, passive_duration=0)
            
            self._safe_out(json.dumps(result, indent=2, default=str)[:5000])
        
        threading.Thread(target=run, daemon=True).start()

    def _export(self):
        import tkinter.filedialog as fd
        path = fd.asksaveasfilename(defaultextension=".json", initialfile="cctv_findings.json")
        if not path:
            return
        with open(path, "w") as f:
            json.dump({"generated": datetime.now().isoformat(), "findings": self.hunter.findings}, f, indent=2, default=str)
        self._safe_out(f"[+] exported → {path}")

    def _clear(self):
        self.hunter.findings = []
        if self.out and self.out.winfo_exists():
            self.out.delete("1.0", "end")
