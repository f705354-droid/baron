# language: Python, file: modules/society.py
# Multi-agent debate GUI
import customtkinter as ctk
import threading
import json
from core.ai.society.debate import DebateSociety, make_ai_call
from core.ai.society.consensus import DebateConsensus


class SocietyModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "society"
        self.app = app
        self.society = None
        self.last_transcript = None

    def render(self, parent):
        ctk.CTkLabel(parent, text="AGENT SOCIETY",
                      font=ctk.CTkFont(size=18, weight="bold"),
                      text_color="#00ff9c").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="debate · advocate · skeptic · judge · BFT consensus",
                      font=ctk.CTkFont(size=11),
                      text_color="#4a5568").pack(pady=(0, 12), padx=24, anchor="w")

        ctk.CTkLabel(parent, text="القرار/السؤال:",
                      font=ctk.CTkFont(size=11, weight="bold"),
                      text_color="#c8d6e5").pack(padx=24, anchor="w")
        self.q = ctk.CTkTextbox(parent, height=80,
                                  fg_color="#05080c", text_color="#7dffb0",
                                  font=ctk.CTkFont(size=11))
        self.q.pack(fill="x", padx=24, pady=(0, 8))
        self.q.insert("end", "هل نستخدم Kerberoasting ضد الحسابات "
                              "المكتشفة الآن في corp.local؟")

        ctl = ctk.CTkFrame(parent, fg_color="transparent")
        ctl.pack(fill="x", padx=24)
        ctk.CTkButton(ctl, text="▸ Run debate", width=160, height=34,
                       fg_color="#0d2818", hover_color="#1a4a2e",
                       text_color="#00ff9c",
                       command=self._run).pack(side="left", padx=(0, 6))
        ctk.CTkButton(ctl, text="▸ Run BFT debate", width=160, height=34,
                       fg_color="#0d2818", hover_color="#1a4a2e",
                       text_color="#00ff9c",
                       command=self._run_bft).pack(side="left", padx=(0, 6))
        ctk.CTkButton(ctl, text="▸ Export", width=120, height=34,
                       fg_color="#141a22", hover_color="#1a2332",
                       command=self._export).pack(side="left")

        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10))
        self.out.pack(fill="both", expand=True, padx=24, pady=(12, 12))

    def _out(self, t):
        self.out.insert("end", t + "\n")
        self.out.see("end")

    def _init_society(self):
        if not self.society:
            ai_call = make_ai_call(None)
            self.society = DebateSociety(ai_call, max_rounds=2)

    def _run(self):
        self._init_society()
        q = self.q.get("1.0", "end").strip()
        if not q:
            return
        self.out.delete("1.0", "end")
        def run():
            self._out(f"🎬 Debate: {q[:100]}\n")
            transcript = self.society.debate(q, context="engagement active")
            self.last_transcript = transcript
            self._render(transcript)
        threading.Thread(target=run, daemon=True).start()

    def _run_bft(self):
        self._init_society()
        q = self.q.get("1.0", "end").strip()
        if not q:
            return
        self.out.delete("1.0", "end")
        def run():
            consensus = DebateConsensus(self.society)
            res = consensus.decide(q, "engagement active", use_bft=True, f=1)
            self.last_transcript = res
            self._render(res["transcript"])
            self._out("\n=== BFT consensus ===")
            self._out(json.dumps(res["consensus"], indent=2))
        threading.Thread(target=run, daemon=True).start()

    def _render(self, t):
        for rnd in t.get("rounds", []):
            self._out(f"\n── round {rnd['n']} ──")
            for role, pos in rnd["positions"].items():
                self._out(f"\n[{role}]\n{pos[:600]}")
            if rnd.get("red_team"):
                self._out(f"\n[red_team]\n{rnd['red_team'][:500]}")
        self._out("\n=== VERDICT ===")
        self._out(json.dumps(t.get("verdict", {}), indent=2, ensure_ascii=False))

    def _export(self):
        if not self.last_transcript:
            return
        import tkinter.filedialog as fd
        path = fd.asksaveasfilename(defaultextension=".json",
                                      initialfile="debate.json")
        if path:
            with open(path, "w") as f:
                json.dump(self.last_transcript, f, indent=2, default=str)
