# language: Python, file: modules/tenants.py
# tenant admin — create, list, quota, isolation
import customtkinter as ctk
import threading
import asyncio
import os
import json
import asyncpg
from teamserver.tenants import TenantManager


class TenantsModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "tenants"
        self.manager = None

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="TENANT ADMIN",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="multi-tenant · quotas · RLS isolation · per-client data",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ---- create ----
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r1 = ctk.CTkFrame(cfg, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=8)
        self.name_e = ctk.CTkEntry(r1, placeholder_text="tenant name",
                                    width=220, height=32,
                                    fg_color="#05080c", border_color="#1a2332")
        self.name_e.pack(side="left", padx=(0, 6))
        self.plan_e = ctk.CTkOptionMenu(
            r1, values=["starter", "pro", "enterprise"],
            width=140, fg_color="#1a2332", button_color="#1a2332")
        self.plan_e.pack(side="left", padx=(0, 6))
        self.iso_e = ctk.CTkOptionMenu(
            r1, values=["row", "schema", "cluster"],
            width=140, fg_color="#1a2332", button_color="#1a2332")
        self.iso_e.pack(side="left", padx=(0, 6))
        self.maxsess = ctk.CTkEntry(r1, placeholder_text="max sessions",
                                     width=120, height=32,
                                     fg_color="#05080c", border_color="#1a2332")
        self.maxsess.insert(0, "500")
        self.maxsess.pack(side="left", padx=(0, 6))
        self.maxops = ctk.CTkEntry(r1, placeholder_text="max operators",
                                    width=120, height=32,
                                    fg_color="#05080c", border_color="#1a2332")
        self.maxops.insert(0, "20")
        self.maxops.pack(side="left", padx=(0, 6))
        ctk.CTkButton(r1, text="▸ Create", width=90, height=32,
                      fg_color="#0d2818", hover_color="#1a4a2e",
                      text_color="#00ff9c",
                      command=self._create).pack(side="left")

        # ---- actions ----
        ctk.CTkLabel(parent, text="Operations:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        grid = ctk.CTkFrame(parent, fg_color="transparent")
        grid.pack(fill="x", padx=24)
        actions = [
            ("▸ List tenants", self._list),
            ("▸ Show tenant", self._show),
            ("▸ Delete tenant", self._delete),
            ("▸ Assign operator", self._assign),
            ("▸ List operators", self._list_ops),
            ("▸ Enable RLS", self._enable_rls),
            ("▸ Quota check", self._quota),
            ("▸ Export tenant data", self._export),
        ]
        for i, (label, fn) in enumerate(actions):
            ctk.CTkButton(
                grid, text=label, width=220, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).grid(row=i // 4, column=i % 4, padx=4, pady=4)

        ctk.CTkLabel(parent, text="Output:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=280
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    async def _get_manager(self):
        if not self.manager:
            dsn = os.getenv("AL-BARON_DSN",
                            "postgresql://shadow:shadow@postgres:5432/albaron")
            pool = await asyncpg.create_pool(dsn, min_size=1, max_size=4)
            self.manager = TenantManager(pool)
        return self.manager

    def _run_async(self, coro_fn, label):
        def run():
            try:
                result = asyncio.run(coro_fn())
                if isinstance(result, (dict, list)):
                    self._out(f"\n=== {label} ===\n" +
                              json.dumps(result, indent=2, default=str)[:10000])
                else:
                    self._out(f"\n=== {label} ===\n{result}")
            except Exception as e:
                self._out(f"[!] {e}")
        threading.Thread(target=run, daemon=True).start()

    def _create(self):
        name = self.name_e.get().strip()
        plan = self.plan_e.get()
        iso = self.iso_e.get()
        try:
            ms = int(self.maxsess.get() or "500")
            mo = int(self.maxops.get() or "20")
        except ValueError:
            ms, mo = 500, 20
        async def fn():
            m = await self._get_manager()
            tid = await m.create_tenant(name, plan, ms, mo, 50, iso)
            return {"tenant_id": tid, "name": name, "iso": iso}
        self._run_async(fn, "create tenant")

    def _list(self):
        async def fn():
            m = await self._get_manager()
            return await m.list_tenants()
        self._run_async(fn, "tenants")

    def _show(self):
        import tkinter.simpledialog as sd
        tid = sd.askstring("Tenant", "Tenant ID:")
        if not tid:
            return
        async def fn():
            m = await self._get_manager()
            return await m.get_tenant(tid)
        self._run_async(fn, "tenant")

    def _delete(self):
        import tkinter.simpledialog as sd
        tid = sd.askstring("Delete", "Tenant ID to delete:")
        if not tid:
            return
        async def fn():
            m = await self._get_manager()
            await m.delete_tenant(tid)
            return "deleted"
        self._run_async(fn, "delete")

    def _assign(self):
        import tkinter.simpledialog as sd
        tid = sd.askstring("Assign", "Tenant ID:")
        user = sd.askstring("Assign", "Username:")
        if tid and user:
            async def fn():
                m = await self._get_manager()
                await m.assign_operator(tid, user, "operator")
                return "assigned"
            self._run_async(fn, "assign")

    def _list_ops(self):
        import tkinter.simpledialog as sd
        tid = sd.askstring("List", "Tenant ID:")
        if tid:
            async def fn():
                m = await self._get_manager()
                return await m.list_operators(tid)
            self._run_async(fn, "operators")

    def _enable_rls(self):
        async def fn():
            m = await self._get_manager()
            await m.enable_rls()
            return "RLS enabled"
        self._run_async(fn, "enable rls")

    def _quota(self):
        import tkinter.simpledialog as sd
        tid = sd.askstring("Quota", "Tenant ID:")
        if tid:
            async def fn():
                m = await self._get_manager()
                return {
                    "sessions_ok": await m.check_quota(tid, "sessions"),
                    "operators_ok": await m.check_quota(tid, "operators"),
                }
            self._run_async(fn, "quota")

    def _export(self):
        import tkinter.simpledialog as sd
        tid = sd.askstring("Export", "Tenant ID:")
        if tid:
            async def fn():
                m = await self._get_manager()
                # export all tenant rows
                async with m.pool.acquire() as c:
                    await c.execute("SELECT set_current_tenant($1)", tid)
                    sessions = await c.fetch("SELECT * FROM sessions WHERE tenant_id=$1", tid)
                    tasks = await c.fetch("SELECT * FROM tasks WHERE tenant_id=$1", tid)
                    audit = await c.fetch("SELECT * FROM audit WHERE tenant_id=$1", tid)
                out = {
                    "tenant_id": tid,
                    "sessions": [dict(s) for s in sessions],
                    "tasks": [dict(t) for t in tasks],
                    "audit": [dict(a) for a in audit],
                }
                path = f"exports/tenant_{tid[:8]}.json"
                os.makedirs("exports", exist_ok=True)
                with open(path, "w") as f:
                    json.dump(out, f, indent=2, default=str)
                return f"exported → {path}"
            self._run_async(fn, "export")
