# language: Python, file: modules/intel_center.py
import customtkinter as ctk
import json
from core.intel.aggregator import IntelAggregator


class IntelCenterModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "intel_center"
        self.app = app
        self.aggregator = IntelAggregator()

    def render(self, parent):
        ctk.CTkLabel(parent, text="THREAT INTEL",
                      font=ctk.CTkFont(size=18, weight="bold"),
                      text_color="#00ff9c").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="MISP · VirusTotal · Shodan combined",
                      font=ctk.CTkFont(size=11),
                      text_color="#4a5568").pack(pady=(0, 12), padx=24, anchor="w")

        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24)
        for label, fn in [
            ("▸ Test all", self._test_all),
            ("▸ Lookup IP", self._lookup),
            ("▸ Recent MISP", self._recent_misp),
            ("▸ Export", self._export),
        ]:
            ctk.CTkButton(row, text=label, width=150, height=34,
                          fg_color="#141a22", hover_color="#1a2332",
                          command=fn).pack(side="left", padx=(0, 4))

        self.out = ctk.CTkTextbox(parent, fg_color="#05080c",
                                    text_color="#7dffb0",
                                    font=ctk.CTkFont(family="Consolas", size=10),
                                    height=500)
        self.out.pack(fill="both", expand=True, padx=24, pady=(12, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _test_all(self):
        result = self.aggregator.test_all()
        self._out(json.dumps(result, indent=2))

    def _lookup(self):
        import tkinter.simpledialog as sd
        ip = sd.askstring("Lookup", "IP:")
        if not ip:
            return
        result = self.aggregator.lookup_ip(ip)
        self._out(json.dumps(result, indent=2))

    def _recent_misp(self):
        events = self.aggregator.misp.recent_events(limit=10)
        for e in events[:10]:
            info = e.get("Event", {}).get("info", "")
            date = e.get("Event", {}).get("date", "")
            self._out(f"  [{date}] {info}")

    def _export(self):
        import tkinter.filedialog as fd
        path = fd.asksaveasfilename(defaultextension=".json",
                                     initialfile="intel_cache.json")
        if path:
            with open(path, "w") as f:
                json.dump(self.aggregator.cache, f, indent=2, default=str)
            self._out(f"[+] exported → {path}")
