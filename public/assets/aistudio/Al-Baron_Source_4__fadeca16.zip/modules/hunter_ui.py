# language: Python, file: modules/hunter_ui.py
# Autonomous Hunter UI
import customtkinter as ctk
import threading
from core.autonomy.hunter import AutonomousHunter, Budget


class HunterModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "hunter"
        self.app = app
        self.hunter = AutonomousHunter(app, log_queue)

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="AUTONOMOUS HUNTER",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="goal-driven · budget-aware · auto-document",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ── config ──
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r = ctk.CTkFrame(cfg, fg_color="transparent")
        r.pack(fill="x", padx=12, pady=8)

        ctk.CTkLabel(r, text="Target:",
                      font=ctk.CTkFont(size=11),
                      text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.target_entry = ctk.CTkEntry(
            r, placeholder_text="10.0.0.0/24",
            width=200, height=32,
            fg_color="#05080c", border_color="#1a2332")
        self.target_entry.pack(side="left", padx=(0, 8))

        ctk.CTkLabel(r, text="Budget $:",
                      font=ctk.CTkFont(size=11),
                      text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.usd_entry = ctk.CTkEntry(
            r, width=80, height=32,
            fg_color="#05080c", border_color="#1a2332")
        self.usd_entry.insert(0, "10")
        self.usd_entry.pack(side="left", padx=(0, 8))

        ctk.CTkLabel(r, text="Actions:",
                      font=ctk.CTkFont(size=11),
                      text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.actions_entry = ctk.CTkEntry(
            r, width=80, height=32,
            fg_color="#05080c", border_color="#1a2332")
        self.actions_entry.insert(0, "100")
        self.actions_entry.pack(side="left")

        # ── controls ──
        ctl = ctk.CTkFrame(parent, fg_color="transparent")
        ctl.pack(fill="x", padx=24, pady=12)
        ctk.CTkButton(
            ctl, text="▶ Start Hunter",
            width=180, height=40,
            fg_color="#0d2818", hover_color="#1a4a2e",
            text_color="#00ff9c", font=ctk.CTkFont(size=12, weight="bold"),
            command=self._start).pack(side="left", padx=(0, 8))
        ctk.CTkButton(
            ctl, text="■ Stop",
            width=120, height=40,
            fg_color="#4a1a1a", hover_color="#6b1a1a",
            text_color="#ff6b6b", font=ctk.CTkFont(size=12, weight="bold"),
            command=self._stop).pack(side="left", padx=(0, 8))
        ctk.CTkButton(
            ctl, text="▸ Show budget",
            width=160, height=40,
            fg_color="#141a22", hover_color="#1a2332",
            command=self._show_budget).pack(side="left")

        # ── live log ──
        ctk.CTkLabel(parent, text="Live events:",
                      font=ctk.CTkFont(size=12, weight="bold"),
                      text_color="#c8d6e5").pack(
            pady=(8, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=450
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

        self.hunter.on_event = self._on_event

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _start(self):
        target = self.target_entry.get().strip()
        if not target:
            self._out("[!] no target")
            return
        try:
            usd = float(self.usd_entry.get())
            actions = int(self.actions_entry.get())
        except ValueError:
            usd, actions = 10.0, 100

        budget = Budget(max_usd=usd, max_actions=actions)
        self.hunter.start(target, budget, approval_mode="manual")
        self._out(f"[+] hunter started for {target}")
        self._out(f"    budget: ${usd}, {actions} actions")

    def _stop(self):
        self.hunter.stop()
        self._out("[*] hunter stopped")

    def _show_budget(self):
        if self.hunter.budget:
            b = self.hunter.budget.report()
            self._out(f"\n=== Budget ===")
            for k, v in b.items():
                self._out(f"  {k}: {v}")
        else:
            self._out("no active hunt")

    def _on_event(self, ev: dict):
        def update():
            self._out(f"[{ev.get('ts', '')[:19]}] {ev.get('type')}: "
                       f"{ {k: v for k, v in ev.items() if k not in ('type', 'ts')} }")
        self.after(0, update)
