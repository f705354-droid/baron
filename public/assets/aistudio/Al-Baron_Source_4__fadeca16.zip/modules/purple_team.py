# language: Python, file: modules/purple_team.py
import customtkinter as ctk
import threading
import json
from core.purple.orchestrator import get_orchestrator


class PurpleTeamModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "purple_team"
        self.app = app
        self.orchestrator = get_orchestrator(app, log_queue)

    def render(self, parent):
        ctk.CTkLabel(parent, text="PURPLE TEAM",
                      font=ctk.CTkFont(size=18, weight="bold"),
                      text_color="#a855f7").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="auto-attack · auto-detect · measure rate",
                      font=ctk.CTkFont(size=11),
                      text_color="#4a5568").pack(pady=(0, 12), padx=24, anchor="w")

        # config
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r = ctk.CTkFrame(cfg, fg_color="transparent")
        r.pack(fill="x", padx=12, pady=8)

        self.profile = ctk.CTkOptionMenu(
            r, values=["APT28", "APT29", "Lazarus"],
            width=140, fg_color="#1a2332", button_color="#1a2332")
        self.profile.pack(side="left", padx=(0, 8))

        self.target = ctk.CTkEntry(r, placeholder_text="target",
                                     width=180, height=30,
                                     fg_color="#05080c", border_color="#1a2332")
        self.target.pack(side="left", padx=(0, 8))

        ctk.CTkButton(r, text="⚡ Run exercise",
                       width=170, height=30,
                       fg_color="#0d2818", hover_color="#1a4a2e",
                       text_color="#00ff9c",
                       command=self._run).pack(side="left", padx=(0, 8))

        ctk.CTkButton(r, text="▸ Trend",
                       width=120, height=30,
                       fg_color="#141a22", hover_color="#1a2332",
                       command=self._trend).pack(side="left")

        self.out = ctk.CTkTextbox(parent, fg_color="#05080c",
                                    text_color="#7dffb0",
                                    font=ctk.CTkFont(family="Consolas", size=10),
                                    height=500)
        self.out.pack(fill="both", expand=True, padx=24, pady=(12, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _run(self):
        profile = self.profile.get()
        target = self.target.get().strip()
        if not target:
            self._out("[!] target required")
            return

        def run():
            self._out(f"[*] starting {profile} → {target}")
            result = self.orchestrator.run_exercise(profile, target)
            self._out(json.dumps(result, indent=2))
        threading.Thread(target=run, daemon=True).start()

    def _trend(self):
        trend = self.orchestrator.trend()
        self._out(f"\n=== {len(trend)} exercises ===")
        for t in trend:
            self._out(f"  {t['date']} {t['profile']:<10} "
                      f"{t['detection_rate']:>5.1f}% [{t['score']}]")
