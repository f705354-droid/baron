# language: Python, file: modules/mitre_report.py
# MITRE ATT&CK Report — automatic technique coverage
import customtkinter as ctk
import threading
import os
import json
from datetime import datetime
from collections import defaultdict


ATTACK_MAP = {
    "recon": {
        "scan": ("T1046", "Network Service Discovery", "Discovery"),
        "subdomain": ("T1590.001", "Domain Trust Discovery", "Reconnaissance"),
        "dns_enum": ("T1590.002", "DNS Lookups", "Reconnaissance"),
    },
    "lan": {
        "discover": ("T1018", "Remote System Discovery", "Discovery"),
        "arp_poison": ("T1557.001", "LLMNR/NBT-NS Poisoning", "Credential Access"),
    },
    "mitm": {
        "ssl_strip": ("T1557", "Adversary-in-the-Middle", "Collection"),
        "dns_spoof": ("T1557.004", "Evil Twin", "Collection"),
    },
    "ad": {
        "kerberoast": ("T1558.003", "Kerberoasting", "Credential Access"),
        "asrep": ("T1558.004", "AS-REP Roasting", "Credential Access"),
        "dcsync": ("T1003.006", "DCSync", "Credential Access"),
        "golden_ticket": ("T1558.001", "Golden Ticket", "Credential Access"),
    },
    "adcs": {
        "esc8": ("T1649", "Steal or Forge Authentication Certificates",
                  "Credential Access"),
        "esc1": ("T1649", "Steal or Forge Authentication Certificates",
                  "Credential Access"),
    },
    "cloud": {
        "aws_enum": ("T1526", "Cloud Service Discovery", "Discovery"),
        "s3_exfil": ("T1530", "Data from Cloud Storage", "Collection"),
        "imds_ssrf": ("T1552.005", "Cloud Instance Metadata API",
                       "Credential Access"),
    },
    "exfil": {
        "dns": ("T1048.003", "Exfil Over Unencrypted Non-C2", "Exfiltration"),
        "icmp": ("T1048.003", "Exfil Over Unencrypted Non-C2", "Exfiltration"),
        "https": ("T1041", "Exfil Over C2 Channel", "Exfiltration"),
    },
    "c2_ui": {
        "session": ("T1071.001", "Web Protocols", "Command and Control"),
        "screenshot": ("T1113", "Screen Capture", "Collection"),
        "keylog": ("T1056.001", "Keylogging", "Collection"),
    },
    "post_pipeline": {
        "enum_system": ("T1082", "System Information Discovery", "Discovery"),
        "enum_network": ("T1016", "System Network Configuration Discovery",
                          "Discovery"),
        "enum_users": ("T1087", "Account Discovery", "Discovery"),
        "loot_files": ("T1005", "Data from Local System", "Collection"),
        "loot_ssh": ("T1552.004", "Private Keys", "Credential Access"),
        "pivot_scan": ("T1018", "Remote System Discovery", "Discovery"),
    },
    "phishing": {
        "campaign": ("T1566.002", "Spearphishing Link", "Initial Access"),
    },
}


class MITREReportModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "mitre_report"
        self.app = app
        self.coverage = defaultdict(set)  # tactic → techniques

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="MITRE ATT&CK REPORT",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="coverage analysis · tactic mapping · gap analysis",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ── actions ──
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24)
        for label, fn in [
            ("⚡ Scan all modules", self._scan_all),
            ("▸ Add technique", self._add_manual),
            ("▤ Generate PDF", self._generate_pdf),
            ("▤ Export JSON", self._export_json),
            ("▸ Clear", self._clear),
            ("▸ Show coverage", self._show_coverage),
        ]:
            ctk.CTkButton(
                row, text=label, width=170, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).pack(side="left", padx=(0, 4))

        # ── coverage display ──
        ctk.CTkLabel(parent, text="Coverage:",
                      font=ctk.CTkFont(size=12, weight="bold"),
                      text_color="#c8d6e5").pack(
            pady=(16, 4), padx=24, anchor="w")

        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=500
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _scan_all(self):
        """يمشي على كل module ويستخرج ما فعله"""
        def run():
            self.coverage.clear()
            self.out.delete("1.0", "end")
            self._out("[*] Scanning all modules for ATT&CK coverage...\n")

            # جرب كل method معروف
            if not self.app:
                self._out("[!] app not attached")
                return

            for module_name, techniques in ATTACK_MAP.items():
                module = self.app.modules.get(module_name)
                if not module:
                    continue
                self._out(f"\n=== {module_name} ===")
                for method_name, (tid, name, tactic) in techniques.items():
                    self.coverage[tactic].add((tid, name, module_name))
                    self._out(f"  ✓ {tid}  {name}")

            # ملخص
            total_tech = sum(len(v) for v in self.coverage.values())
            self._out(f"\n{'='*60}")
            self._out(f"TOTAL: {total_tech} techniques across "
                       f"{len(self.coverage)} tactics")
            self._out(f"{'='*60}")

            for tactic, techs in sorted(self.coverage.items()):
                self._out(f"\n{tactic.upper()} ({len(techs)} techniques):")
                for tid, name, module in sorted(techs):
                    self._out(f"  {tid:<15} {name:<45} [{module}]")
        threading.Thread(target=run, daemon=True).start()

    def _add_manual(self):
        import tkinter.simpledialog as sd
        tid = sd.askstring("Technique ID", "T-ID (e.g. T1046):")
        if not tid:
            return
        name = sd.askstring("Name", "Technique name:") or "unknown"
        tactic = sd.askstring("Tactic", "Tactic:") or "Unknown"
        self.coverage[tactic].add((tid, name, "manual"))
        self._out(f"[+] added {tid} ({name}) to {tactic}")

    def _show_coverage(self):
        if not self.coverage:
            self._scan_all()
            return
        self.out.delete("1.0", "end")
        for tactic, techs in sorted(self.coverage.items()):
            self._out(f"\n{tactic}:")
            for tid, name, module in sorted(techs):
                self._out(f"  {tid} — {name}")

    def _clear(self):
        self.coverage.clear()
        self.out.delete("1.0", "end")
        self._out("[+] coverage cleared")

    def _generate_pdf(self):
        def run():
            try:
                from fpdf import FPDF
            except ImportError:
                self._out("[!] fpdf2 not installed")
                return
            os.makedirs("reports", exist_ok=True)
            pdf = FPDF()
            pdf.add_page()
            pdf.set_font("Courier", "B", 16)
            pdf.cell(0, 10, "MITRE ATT&CK Coverage Report", ln=True)
            pdf.set_font("Courier", "", 9)
            pdf.cell(0, 6, f"Generated: {datetime.now().isoformat()}", ln=True)
            pdf.cell(0, 6, f"Total techniques: {sum(len(v) for v in self.coverage.values())}", ln=True)
            pdf.ln(6)

            for tactic in sorted(self.coverage):
                pdf.set_font("Courier", "B", 11)
                pdf.cell(0, 7, tactic, ln=True)
                pdf.set_font("Courier", "", 9)
                for tid, name, module in sorted(self.coverage[tactic]):
                    pdf.cell(0, 5, f"  {tid}  {name}  [{module}]", ln=True)
                pdf.ln(2)

            out = f"reports/mitre_{int(datetime.now().timestamp())}.pdf"
            pdf.output(out)
            self._out(f"\n[+] PDF → {out}")
        threading.Thread(target=run, daemon=True).start()

    def _export_json(self):
        import tkinter.filedialog as fd
        path = fd.asksaveasfilename(
            defaultextension=".json",
            initialfile="mitre_coverage.json")
        if not path:
            return
        data = {
            "generated": datetime.now().isoformat(),
            "total_techniques": sum(len(v) for v in self.coverage.values()),
            "by_tactic": {
                tactic: [
                    {"id": tid, "name": name, "module": module}
                    for tid, name, module in techs
                ]
                for tactic, techs in self.coverage.items()
            },
        }
        with open(path, "w") as f:
            json.dump(data, f, indent=2)
        self._out(f"[+] JSON → {path}")
