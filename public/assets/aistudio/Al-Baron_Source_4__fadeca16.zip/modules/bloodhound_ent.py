# language: Python, file: modules/bloodhound_ent.py
# BloodHound Enterprise GUI — AD attack paths, posture, cypher
import customtkinter as ctk
import threading
import asyncio
import os
import json
from teamserver.adapters.bloodhound import BloodHoundEnterpriseAdapter


class BloodHoundEntModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "bloodhound_ent"
        self.adapter = BloodHoundEnterpriseAdapter()

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="BLOODHOUND ENTERPRISE",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="AD attack paths · Tier Zero · posture · Cypher queries",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r1 = ctk.CTkFrame(cfg, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=8)
        self.url = ctk.CTkEntry(r1, placeholder_text="BHE url (tenant.bloodhoundenterprise.io)",
                                 width=300, height=32,
                                 fg_color="#05080c", border_color="#1a2332")
        self.url.pack(side="left", padx=(0, 6))
        self.tid = ctk.CTkEntry(r1, placeholder_text="token id",
                                 width=180, height=32,
                                 fg_color="#05080c", border_color="#1a2332")
        self.tid.pack(side="left", padx=(0, 6))
        self.tkey = ctk.CTkEntry(r1, placeholder_text="token key",
                                  width=200, height=32, show="*",
                                  fg_color="#05080c", border_color="#1a2332")
        self.tkey.pack(side="left", padx=(0, 6))
        ctk.CTkButton(r1, text="▸ Save", width=90, height=32,
                      fg_color="#0d2818", hover_color="#1a4a2e",
                      text_color="#00ff9c", command=self._save).pack(side="left")

        # ---- actions ----
        ctk.CTkLabel(parent, text="Operations:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")

        grid = ctk.CTkFrame(parent, fg_color="transparent")
        grid.pack(fill="x", padx=24)
        actions = [
            ("▸ Posture score", self._posture),
            ("▸ Critical paths", self._critical_paths),
            ("▸ High paths", self._high_paths),
            ("▸ Tier Zero assets", self._tier_zero),
            ("▸ Kerberoastable", self._kerberoastable),
            ("▸ AS-REP roastable", self._asrep),
            ("▸ Unconstrained delegation", self._unconstr),
            ("▸ Domain admins", self._domain_admins),
            ("▸ Owned principals", self._owned),
            ("▸ Cypher query", self._cypher),
            ("▸ Mark owned", self._mark_owned),
            ("▸ Sync → Report PDF", self._sync_report),
        ]
        for i, (label, fn) in enumerate(actions):
            ctk.CTkButton(
                grid, text=label, width=220, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).grid(row=i // 4, column=i % 4, padx=4, pady=4)

        ctk.CTkLabel(parent, text="Output:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=280
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _save(self):
        os.environ["BHE_URL"] = self.url.get().strip()
        os.environ["BHE_TOKEN_ID"] = self.tid.get().strip()
        os.environ["BHE_TOKEN_KEY"] = self.tkey.get().strip()
        self.adapter = BloodHoundEnterpriseAdapter()
        self._out("[+] saved BHE config")

    def _run_async(self, coro_fn, label):
        def run():
            try:
                result = asyncio.run(coro_fn())
                if isinstance(result, (dict, list)):
                    self._out(f"\n=== {label} ===\n" +
                              json.dumps(result, indent=2)[:10000])
                else:
                    self._out(f"\n=== {label} ===\n{result}")
            except Exception as e:
                self._out(f"[!] {e}")
        threading.Thread(target=run, daemon=True).start()

    def _posture(self):
        self._run_async(self.adapter.get_posture, "posture")

    def _critical_paths(self):
        self._run_async(
            lambda: self.adapter.attack_paths("critical", 100),
            "critical paths")

    def _high_paths(self):
        self._run_async(
            lambda: self.adapter.attack_paths("high", 200),
            "high paths")

    def _tier_zero(self):
        self._run_async(self.adapter.tier_zero_assets, "tier zero")

    def _kerberoastable(self):
        self._run_async(
            lambda: self.adapter.risky_assets("kerberoastable"),
            "kerberoastable")

    def _asrep(self):
        self._run_async(
            lambda: self.adapter.risky_assets("asreproastable"),
            "asrep roastable")

    def _unconstr(self):
        self._run_async(
            lambda: self.adapter.risky_assets("unconstrained_delegation"),
            "unconstrained delegation")

    def _domain_admins(self):
        self._run_async(self.adapter.search_domain_admins, "domain admins")

    def _owned(self):
        self._run_async(self.adapter.owned_principals, "owned")

    def _cypher(self):
        import tkinter.simpledialog as sd
        q = sd.askstring("Cypher",
            "Query (MATCH ... RETURN ...):",
            initialvalue="MATCH (u:User) WHERE u.hasspn=true RETURN u.name LIMIT 20")
        if q:
            self._run_async(lambda: self.adapter.cypher(q), "cypher")

    def _mark_owned(self):
        import tkinter.simpledialog as sd
        oid = sd.askstring("Mark owned", "Object ID:")
        if oid:
            self._run_async(
                lambda: self.adapter.mark_owned(oid),
                "mark owned")

    def _sync_report(self):
        self._out("[+] BHE findings merged into Reporting via "
                  "get_findings() hook")
