# language: Python, file: modules/marketplace.py
# plugin marketplace — install, enable, sandbox permissions
import customtkinter as ctk
import threading
import os
import json
import tkinter.filedialog as fd
from teamserver.marketplace import registry


class MarketplaceModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "marketplace"
        self.app = app

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="PLUGIN MARKETPLACE",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="install · sandboxed hooks · permissions · community",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        actions = ctk.CTkFrame(parent, fg_color="transparent")
        actions.pack(fill="x", padx=24)
        for label, fn in [
            ("▸ List installed", self._list),
            ("▸ Install from zip", self._install_zip),
            ("▸ Install from dir", self._install_dir),
            ("▸ Load plugin", self._load),
            ("▸ Unload all", self._unload_all),
            ("▸ Uninstall", self._uninstall),
            ("▸ Refresh remote", self._refresh_remote),
            ("▸ Open plugin dir", self._open_dir),
        ]:
            ctk.CTkButton(actions, text=label, width=180, height=32,
                          fg_color="#141a22", hover_color="#1a2332",
                          font=ctk.CTkFont(size=11), command=fn
                          ).pack(side="left", padx=(0, 4))

        ctk.CTkLabel(parent, text="Installed plugins:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10)
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

        self._list()

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _list(self):
        plugins = registry.list_installed()
        self.out.delete("1.0", "end")
        for p in plugins:
            self.out.insert("end",
                f"[{p.get('version','?')}] {p.get('name','?'):20} "
                f"{p.get('description','')[:60]}\n"
                f"     hooks: {', '.join(p.get('hooks',[]))}\n"
                f"     perms: {', '.join(p.get('permissions',[]))}\n\n")

    def _install_zip(self):
        path = fd.askopenfilename(filetypes=[("ZIP", "*.zip")])
        if not path:
            return
        try:
            m = registry.install_from_zip(path)
            self._out(f"[+] installed: {m['name']} v{m['version']}")
            self._list()
        except Exception as e:
            self._out(f"[!] {e}")

    def _install_dir(self):
        path = fd.askdirectory()
        if not path:
            return
        try:
            m = registry.install_from_dir(path)
            self._out(f"[+] installed: {m['name']}")
            self._list()
        except Exception as e:
            self._out(f"[!] {e}")

    def _load(self):
        import tkinter.simpledialog as sd
        name = sd.askstring("Load", "Plugin name:")
        if not name:
            return
        try:
            ctx = self._build_context()
            m = registry.load(name, ctx)
            self._out(f"[+] loaded: {m['name']}")
        except Exception as e:
            self._out(f"[!] {e}")

    def _build_context(self):
        """bridge full app capabilities into plugin context"""
        ctx = {
            "get_sessions": lambda: self._all_sessions(),
            "dispatch_task": lambda sid, task: self._dispatch(sid, task),
            "emit_event": lambda ev: self.log.put(f"[plugin] {ev}"),
            "ai_query": self._ai_query,
        }
        return ctx

    def _all_sessions(self):
        if not self.app:
            return {}
        out = {}
        for key in ("c2_ui", "c2", "lan", "ad"):
            mod = self.app.modules.get(key)
            if mod and hasattr(mod, "sessions"):
                out.update(mod.sessions)
        return out

    def _dispatch(self, sid, task):
        if self.app:
            ui = self.app.modules.get("c2_ui")
            if ui and hasattr(ui, "on_dispatch"):
                ui.on_dispatch(sid, task)

    def _ai_query(self, prompt):
        ai = self.app.modules.get("ai_advanced") if self.app else None
        if ai:
            return ai._call("You are a helpful plugin assistant.", prompt)
        return ""

    def _unload_all(self):
        registry.unload_all()
        self._out("[+] all plugins unloaded")

    def _uninstall(self):
        import tkinter.simpledialog as sd
        name = sd.askstring("Uninstall", "Plugin name:")
        if not name:
            return
        if registry.uninstall(name):
            self._out(f"[+] uninstalled: {name}")
            self._list()
        else:
            self._out(f"[!] not found: {name}")

    def _refresh_remote(self):
        remote = registry.list_remote()
        self._out(f"[+] {len(remote)} remote plugins cached")

    def _open_dir(self):
        import subprocess
        subprocess.Popen(["xdg-open", "/var/lib/albaron/plugins"])
