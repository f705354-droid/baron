# language: Python, file: modules/offline.py
# Offline knowledge base — CVE, exploitdb, wordlists
import customtkinter as ctk
import threading
import os
import sqlite3
import json
import subprocess
import urllib.request


class OfflineModule:
    """قاعدة معرفة محلية تعمل بدون إنترنت"""
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "offline"
        self.app = app
        self.kb_dir = "core/offline"
        self.db_path = os.path.join(self.kb_dir, "cve.db")

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="OFFLINE KNOWLEDGE BASE",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="CVE · exploits · wordlists · Ollama · no internet needed",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ── status ──
        status = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        status.pack(fill="x", padx=24)
        self.status_lbl = ctk.CTkLabel(
            status, text="checking...",
            font=ctk.CTkFont(family="Consolas", size=11),
            text_color="#c8d6e5", justify="left"
        )
        self.status_lbl.pack(anchor="w", padx=12, pady=8)
        self._check_status()

        # ── search ──
        ctk.CTkLabel(parent, text="Search CVE:",
                      font=ctk.CTkFont(size=12, weight="bold"),
                      text_color="#c8d6e5").pack(
            pady=(16, 4), padx=24, anchor="w")
        search_row = ctk.CTkFrame(parent, fg_color="transparent")
        search_row.pack(fill="x", padx=24)
        self.search_entry = ctk.CTkEntry(
            search_row, placeholder_text="CVE-2021-44228 OR apache OR 'remote code'",
            height=36, fg_color="#05080c", border_color="#1a2332"
        )
        self.search_entry.pack(side="left", fill="x", expand=True, padx=(0, 6))
        self.search_entry.bind("<Return>", lambda e: self._search_cve())
        ctk.CTkButton(
            search_row, text="▸ Search", width=110, height=36,
            fg_color="#0d2818", hover_color="#1a4a2e",
            text_color="#00ff9c",
            command=self._search_cve
        ).pack(side="left")

        # ── actions ──
        ctk.CTkLabel(parent, text="Maintenance:",
                      font=ctk.CTkFont(size=12, weight="bold"),
                      text_color="#c8d6e5").pack(
            pady=(16, 4), padx=24, anchor="w")

        grid = ctk.CTkFrame(parent, fg_color="transparent")
        grid.pack(fill="x", padx=24)
        actions = [
            ("⚡ Download CVE DB", self._download_cve),
            ("⚡ Download SecLists", self._download_wordlists),
            ("⚡ Download ExploitDB", self._download_exploitdb),
            ("⚡ Install Ollama model", self._install_ollama),
            ("⌖ Check Ollama", self._check_ollama),
            ("⌖ Check ExploitDB", self._check_exploitdb),
            ("⌖ Check Wordlists", self._check_wordlists),
            ("⌖ Reindex", self._reindex),
            ("⌖ Test offline AI", self._test_ai),
            ("▤ Export results", self._export),
        ]
        for i, (label, fn) in enumerate(actions):
            ctk.CTkButton(
                grid, text=label, width=200, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).grid(row=i // 3, column=i % 3, padx=4, pady=4)

        # ── output ──
        ctk.CTkLabel(parent, text="Output:",
                      font=ctk.CTkFont(size=12, weight="bold"),
                      text_color="#c8d6e5").pack(
            pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=380
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _check_status(self):
        """يعرض حالة قاعدة المعرفة"""
        def check():
            results = []
            # CVE db
            if os.path.exists(self.db_path):
                size = os.path.getsize(self.db_path) / 1e6
                results.append(f"CVE DB: {size:.1f} MB")
            else:
                results.append("CVE DB: not installed")

            # wordlists
            wl_dir = os.path.join(self.kb_dir, "wordlists")
            if os.path.isdir(wl_dir):
                count = sum(len(files) for _, _, files in os.walk(wl_dir))
                results.append(f"Wordlists: {count} files")
            else:
                results.append("Wordlists: not installed")

            # exploitdb
            if os.path.exists("/usr/share/exploitdb"):
                results.append("ExploitDB: installed (system)")
            else:
                results.append("ExploitDB: missing")

            # ollama
            try:
                r = subprocess.run(["ollama", "list"],
                                     capture_output=True, text=True, timeout=3)
                if r.returncode == 0 and r.stdout.strip():
                    models = r.stdout.strip().split("\n")[1:]
                    results.append(f"Ollama: {len(models)} models")
                else:
                    results.append("Ollama: not running")
            except Exception:
                results.append("Ollama: not installed")

            self.after(0, lambda: self.status_lbl.configure(
                text="\n".join(results)))
        threading.Thread(target=check, daemon=True).start()

    def _download_cve(self):
        """يُحمّل CVE database من NVD"""
        def run():
            os.makedirs(self.kb_dir, exist_ok=True)
            self._out("[*] Downloading CVE database from NVD...")
            self._out("[*] This is ~200MB, takes 5-10 min...")

            # create schema
            conn = sqlite3.connect(self.db_path)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS cves (
                    id TEXT PRIMARY KEY,
                    description TEXT,
                    cvss REAL,
                    severity TEXT,
                    published TEXT,
                    refs TEXT
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_cvss ON cves(cvss)")
            conn.execute(
                "CREATE VIRTUAL TABLE IF NOT EXISTS cve_fts "
                "USING fts5(id, description, content='cves', content_rowid='rowid')")
            conn.commit()

            # download from NVD (last 2 years)
            import gzip
            base = "https://nvd.nist.gov/feeds/json/cve/1.1"
            now = datetime.now()
            total = 0
            for year in [now.year, now.year - 1]:
                for i in range(1, 13):
                    url = f"{base}/nvdcve-1.1-{year}.json.gz"
                    break  # simplified: use annual
                url = f"{base}/nvdcve-1.1-{year}.json.gz"
                self._out(f"[*] fetching {url}")
                try:
                    req = urllib.request.Request(url,
                        headers={"User-Agent": "Mozilla/5.0"})
                    with urllib.request.urlopen(req, timeout=60) as r:
                        data = gzip.decompress(r.read())
                    j = json.loads(data)
                    for item in j.get("CVE_Items", []):
                        try:
                            cve = item["cve"]
                            cid = cve["CVE_data_meta"]["ID"]
                            desc = cve["description"]["description_data"][0]["value"]
                            cvss = 0.0
                            sev = "UNKNOWN"
                            try:
                                metrics = item.get("impact", {}).get("baseMetricV3", {})
                                cvss = metrics.get("cvssV3", {}).get("baseScore", 0.0)
                                sev = metrics.get("cvssV3", {}).get("baseSeverity", "UNKNOWN")
                            except Exception:
                                pass
                            conn.execute(
                                "INSERT OR REPLACE INTO cves VALUES (?,?,?,?,?,?)",
                                (cid, desc, cvss, sev, "", "[]"))
                            total += 1
                        except Exception:
                            continue
                    conn.commit()
                except Exception as e:
                    self._out(f"[!] {year}: {e}")
                    continue
            conn.close()
            self._out(f"\n[+] {total} CVEs loaded → {self.db_path}")
            self._check_status()
        threading.Thread(target=run, daemon=True).start()

    def _search_cve(self):
        query = self.search_entry.get().strip()
        if not query:
            return
        if not os.path.exists(self.db_path):
            self._out("[!] CVE DB not installed — click 'Download CVE DB'")
            return
        conn = sqlite3.connect(self.db_path)
        try:
            # FTS search
            results = conn.execute("""
                SELECT id, description, cvss, severity FROM cves
                WHERE id LIKE ? OR description LIKE ?
                ORDER BY cvss DESC LIMIT 20
            """, (f"%{query}%", f"%{query}%")).fetchall()
        except Exception as e:
            self._out(f"[!] {e}")
            return
        conn.close()

        self.out.delete("1.0", "end")
        self._out(f"=== {len(results)} results for '{query}' ===\n")
        for cid, desc, cvss, sev in results:
            self._out(f"{cid} [{cvss}] {sev}")
            self._out(f"  {desc[:200]}\n")

    def _download_wordlists(self):
        def run():
            wl_dir = os.path.join(self.kb_dir, "wordlists")
            os.makedirs(wl_dir, exist_ok=True)
            wordlists = {
                "rockyou_mini.txt":
                    "https://raw.githubusercontent.com/danielmiessler/SecLists/master/Passwords/Common-Credentials/10-million-password-list-top-10000.txt",
                "common_users.txt":
                    "https://raw.githubusercontent.com/danielmiessler/SecLists/master/Usernames/top-usernames-shortlist.txt",
                "directories.txt":
                    "https://raw.githubusercontent.com/danielmiessler/SecLists/master/Discovery/Web-Content/common.txt",
                "subdomains.txt":
                    "https://raw.githubusercontent.com/danielmiessler/SecLists/master/Discovery/DNS/subdomains-top1million-5000.txt",
            }
            for name, url in wordlists.items():
                path = os.path.join(wl_dir, name)
                if os.path.exists(path):
                    self._out(f"[skip] {name} exists")
                    continue
                self._out(f"[*] downloading {name}...")
                try:
                    urllib.request.urlretrieve(url, path)
                    size = os.path.getsize(path) / 1024
                    self._out(f"[+] {name} ({size:.0f} KB)")
                except Exception as e:
                    self._out(f"[!] {name}: {e}")
            self._check_status()
        threading.Thread(target=run, daemon=True).start()

    def _download_exploitdb(self):
        def run():
            self._out("[*] Installing exploitdb...")
            r = subprocess.run(
                ["sudo", "apt", "install", "-y", "exploitdb"],
                capture_output=True, text=True)
            if r.returncode == 0:
                self._out("[+] exploitdb installed")
                # try to update
                subprocess.run(["searchsploit", "-u"], timeout=120)
            else:
                self._out(f"[!] apt failed — try manually: sudo apt install exploitdb")
            self._check_status()
        threading.Thread(target=run, daemon=True).start()

    def _check_exploitdb(self):
        if os.path.exists("/usr/share/exploitdb"):
            self._out("[+] exploitdb installed at /usr/share/exploitdb")
        else:
            self._out("[!] exploitdb not installed")

    def _check_wordlists(self):
        wl_dir = os.path.join(self.kb_dir, "wordlists")
        if not os.path.isdir(wl_dir):
            self._out("[!] no wordlists — click 'Download SecLists'")
            return
        for f in os.listdir(wl_dir):
            path = os.path.join(wl_dir, f)
            size = os.path.getsize(path) / 1024
            self._out(f"  {f} ({size:.0f} KB)")

    def _install_ollama(self):
        def run():
            self._out("[*] Installing Ollama...")
            r = subprocess.run(
                "curl -fsSL https://ollama.ai/install.sh | sh",
                shell=True, capture_output=True, text=True)
            if r.returncode == 0:
                self._out("[+] Ollama installed")
                self._out("[*] Pulling llama3.1:8b (4GB)...")
                subprocess.run(["ollama", "pull", "llama3.1:8b"],
                                 timeout=600)
                self._out("[+] model ready")
            else:
                self._out(f"[!] {r.stderr}")
            self._check_status()
        threading.Thread(target=run, daemon=True).start()

    def _check_ollama(self):
        try:
            r = subprocess.run(["ollama", "list"],
                                 capture_output=True, text=True, timeout=5)
            self._out(r.stdout or "no models")
        except FileNotFoundError:
            self._out("[!] ollama not installed")
        except Exception as e:
            self._out(f"[!] {e}")

    def _reindex(self):
        self._out("[*] reindexing CVE FTS...")
        if not os.path.exists(self.db_path):
            return
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("""
                INSERT INTO cve_fts(cve_fts) VALUES('rebuild')
            """)
            conn.commit()
            self._out("[+] reindexed")
        except Exception as e:
            self._out(f"[!] {e}")
        conn.close()

    def _test_ai(self):
        def run():
            self._out("[*] Testing offline AI...")
            try:
                import httpx
                r = httpx.post(
                    "http://localhost:11434/api/chat",
                    json={
                        "model": "llama3.1:8b",
                        "messages": [
                            {"role": "user",
                             "content": "قل مرحبا في كلمة واحدة"}
                        ],
                        "stream": False
                    }, timeout=60)
                if r.status_code == 200:
                    content = r.json().get("message", {}).get("content", "")
                    self._out(f"[+] AI response: {content}")
                else:
                    self._out(f"[!] {r.status_code}")
            except Exception as e:
                self._out(f"[!] Ollama not running: {e}")
        threading.Thread(target=run, daemon=True).start()

    def _export(self):
        import tkinter.filedialog as fd
        path = fd.asksaveasfilename(
            defaultextension=".json",
            initialfile="offline_kb.json")
        if not path:
            return
        data = {
            "cve_db": self.db_path if os.path.exists(self.db_path) else None,
            "wordlists": [],
            "timestamp": datetime.now().isoformat(),
        }
        wl_dir = os.path.join(self.kb_dir, "wordlists")
        if os.path.isdir(wl_dir):
            data["wordlists"] = os.listdir(wl_dir)
        with open(path, "w") as f:
            json.dump(data, f, indent=2)
        self._out(f"[+] exported → {path}")

    def _test_ai(self):
        def run():
            self._out("[*] Testing offline AI...")
            try:
                import httpx
                r = httpx.post(
                    "http://localhost:11434/api/chat",
                    json={
                        "model": "llama3.1:8b",
                        "messages": [
                            {"role": "user",
                             "content": "قل مرحبا في كلمة واحدة"}
                        ],
                        "stream": False
                    }, timeout=60)
                if r.status_code == 200:
                    content = r.json().get("message", {}).get("content", "")
                    self._out(f"[+] AI response: {content}")
                else:
                    self._out(f"[!] {r.status_code}")
            except Exception as e:
                self._out(f"[!] Ollama not running: {e}")
        threading.Thread(target=run, daemon=True).start()
