# language: Python, file: modules/team_ui.py
# Team Room UI
import customtkinter as ctk
from datetime import datetime
from core.collab.team_room import TeamRoom


class TeamModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "team"
        self.app = app
        self.room = TeamRoom(log_queue)
        self.room.on_event = self._on_room_event

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="TEAM ROOM",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="multi-operator · shared chat · live findings",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ── config ──
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r = ctk.CTkFrame(cfg, fg_color="transparent")
        r.pack(fill="x", padx=12, pady=8)

        ctk.CTkLabel(r, text="Server:",
                      font=ctk.CTkFont(size=11),
                      text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.url_entry = ctk.CTkEntry(
            r, placeholder_text="ws://teamserver:8000/ws/operator",
            width=280, height=32,
            fg_color="#05080c", border_color="#1a2332")
        self.url_entry.insert(0, "ws://localhost:8000/ws/operator")
        self.url_entry.pack(side="left", padx=(0, 8))

        ctk.CTkLabel(r, text="User:",
                      font=ctk.CTkFont(size=11),
                      text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.user_entry = ctk.CTkEntry(
            r, placeholder_text="operator1",
            width=140, height=32,
            fg_color="#05080c", border_color="#1a2332")
        self.user_entry.pack(side="left", padx=(0, 8))

        ctk.CTkButton(
            r, text="▸ Connect",
            width=120, height=32,
            fg_color="#0d2818", hover_color="#1a4a2e",
            text_color="#00ff9c",
            command=self._connect).pack(side="left")

        # ── operators ──
        self.operators_lbl = ctk.CTkLabel(
            parent, text="operators: none",
            font=ctk.CTkFont(size=10),
            text_color="#6a7a8a")
        self.operators_lbl.pack(pady=(8, 0), padx=24, anchor="w")

        # ── chat ──
        ctk.CTkLabel(parent, text="Chat:",
                      font=ctk.CTkFont(size=12, weight="bold"),
                      text_color="#c8d6e5").pack(
            pady=(12, 4), padx=24, anchor="w")
        self.chat = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=350
        )
        self.chat.pack(fill="both", expand=True, padx=24)

        # ── input ──
        inp = ctk.CTkFrame(parent, fg_color="transparent")
        inp.pack(fill="x", padx=24, pady=(8, 12))
        self.msg_entry = ctk.CTkEntry(
            inp, placeholder_text="type message...",
            height=34, fg_color="#05080c", border_color="#1a2332")
        self.msg_entry.pack(side="left", fill="x", expand=True, padx=(0, 6))
        self.msg_entry.bind("<Return>", lambda e: self._send())
        ctk.CTkButton(
            inp, text="▸ Send",
            width=100, height=34,
            fg_color="#0d2818", hover_color="#1a4a2e",
            text_color="#00ff9c",
            command=self._send).pack(side="left")

    def _out(self, text):
        self.chat.insert("end", text + "\n")
        self.chat.see("end")

    def _connect(self):
        url = self.url_entry.get().strip()
        user = self.user_entry.get().strip() or "operator1"
        self.room.connect(url, user)
        self._out(f"[*] connecting to {url} as {user}...")

    def _send(self):
        msg = self.msg_entry.get().strip()
        if not msg:
            return
        self.msg_entry.delete(0, "end")
        self.room.send_message(msg)
        self._out(f"[you] {msg}")

    def _on_room_event(self, ev: dict):
        def update():
            t = ev.get("type")
            if t == "chat":
                self._out(f"[{ev.get('from')}] {ev.get('text')}")
            elif t == "operator_join":
                self._out(f"* {ev['username']} joined")
                self._update_operators()
            elif t == "operator_leave":
                self._out(f"* {ev['username']} left")
                self._update_operators()
            elif t == "findings":
                self._out(f"[finding from {ev.get('from')}] {ev}")
        self.after(0, update)

    def _update_operators(self):
        ops = list(self.room.operators.keys())
        self.operators_lbl.configure(
            text=f"operators: {', '.join(ops) if ops else 'none'}")
