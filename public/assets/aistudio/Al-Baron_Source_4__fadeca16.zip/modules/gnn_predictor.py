# language: Python, file: modules/gnn_predictor.py
# GNN Predictor UI
import customtkinter as ctk
import threading
from core.gnn.attack_predictor import predictor


class GNNPredictorModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "gnn_predictor"
        self.app = app

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="GNN ATTACK PREDICTOR",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="graph neural network · predicts unseen attack paths",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24)
        for label, fn in [
            ("⚡ Train GNN", self._train),
            ("▸ Predict paths", self._predict),
            ("▸ Model info", self._info),
            ("▸ Test random", self._test),
        ]:
            ctk.CTkButton(
                row, text=label, width=170, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).pack(side="left", padx=(0, 4))

        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=500
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(12, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _train(self):
        def run():
            self._out("[*] Training GNN on current graph...")
            result = predictor.train(epochs=100)
            self._out(f"[+] Training complete: {result}")
        threading.Thread(target=run, daemon=True).start()

    def _predict(self):
        def run():
            self._out("[*] Predicting attack paths...")
            paths = predictor.predict_attack_paths(top_k=20)
            self._out(f"\n[+] {len(paths)} predicted attack paths:\n")
            for i, p in enumerate(paths, 1):
                marker = "✓" if p["predicted"] else " "
                self._out(f"  [{marker}] {p['score']:.3f}  "
                           f"{p['host']} → {p['vuln']}")
        threading.Thread(target=run, daemon=True).start()

    def _info(self):
        import os
        path = predictor.model_path
        if os.path.exists(path):
            size = os.path.getsize(path) / 1024
            self._out(f"Model: {path} ({size:.1f} KB)")
        else:
            self._out("Model: not trained yet")

    def _test(self):
        self._out("[*] testing predict on random graph...")
        self._out("(train first for real results)")
