# language: Python, file: modules/training.py
# AI-generated hands-on labs for operator training
import customtkinter as ctk
import threading
import os
import json
import subprocess
import time
from datetime import datetime
from utils.progress import ProgressTracker


SYSTEM_LAB_GEN = """You are a red-team training lab generator.
Given: topic, difficulty, target platform.
Output a complete lab in JSON:
{
  "title": "...",
  "difficulty": "beginner|intermediate|advanced|expert",
  "duration_min": N,
  "prerequisites": [...],
  "learning_objectives": [...],
  "environment": {
    "docker_compose": "... full compose yaml ...",
    "or_vms": [{"name": "...", "image": "...", "services": [...]}],
    "network_topology": "..."
  },
  "scenario": "...",
  "tasks": [
    {"id": 1, "title": "...", "goal": "...", "hints": ["...", "..."],
     "solution_command": "...", "detection_evasion": "..."}
  ],
  "verification": "... how to check success ...",
  "mitre_techniques": ["T1078", ...]
}
Output ONLY valid JSON, no fences."""


class TrainingModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "training"
        self.app = app
        self.progress = ProgressTracker(log_queue)
        self.labs = {}

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="TRAINING LABS",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="AI-generated hands-on labs · dockerized · MITRE-mapped",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ---- generator ----
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r1 = ctk.CTkFrame(cfg, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=8)
        self.topic = ctk.CTkEntry(r1, placeholder_text="topic (e.g. ADCS ESC8)",
                                   width=300, height=32,
                                   fg_color="#05080c", border_color="#1a2332")
        self.topic.pack(side="left", padx=(0, 6))
        self.difficulty = ctk.CTkOptionMenu(
            r1, values=["beginner", "intermediate", "advanced", "expert"],
            width=140, fg_color="#1a2332", button_color="#1a2332")
        self.difficulty.pack(side="left", padx=(0, 6))
        self.platform = ctk.CTkOptionMenu(
            r1, values=["docker", "vmware", "proxmox", "vagrant", "aws"],
            width=140, fg_color="#1a2332", button_color="#1a2332")
        self.platform.pack(side="left", padx=(0, 6))
        ctk.CTkButton(r1, text="▸ Generate", width=110, height=32,
                      fg_color="#0d2818", hover_color="#1a4a2e",
                      text_color="#00ff9c",
                      command=self._generate).pack(side="left")

        # ---- actions ----
        ctk.CTkLabel(parent, text="Operations:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        grid = ctk.CTkFrame(parent, fg_color="transparent")
        grid.pack(fill="x", padx=24)
        actions = [
            ("▸ Generate lab", self._generate),
            ("▸ Browse library", self._browse),
            ("▸ Deploy lab (docker)", self._deploy),
            ("▸ Stop lab", self._stop),
            ("▸ Verify completion", self._verify),
            ("▸ Hint for current", self._hint),
            ("▸ Solution", self._solution),
            ("▸ Reset lab", self._reset),
            ("▸ Progress report", self._progress_report),
            ("▸ Curated packs", self._packs),
            ("▸ Export lab bundle", self._export),
            ("▸ Deploy all beginner pack", self._deploy_pack),
        ]
        for i, (label, fn) in enumerate(actions):
            ctk.CTkButton(
                grid, text=label, width=220, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).grid(row=i // 4, column=i % 4, padx=4, pady=4)

        # ---- tree of labs ----
        ctk.CTkLabel(parent, text="Lab library:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.labs_box = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=180
        )
        self.labs_box.pack(fill="x", padx=24)

        ctk.CTkLabel(parent, text="Output:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(8, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=200
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

        self._refresh_labs()

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _refresh_labs(self):
        os.makedirs("training/labs", exist_ok=True)
        self.labs_box.delete("1.0", "end")
        for f in sorted(os.listdir("training/labs")):
            if f.endswith(".json"):
                path = os.path.join("training/labs", f)
                try:
                    with open(path) as fh:
                        lab = json.load(fh)
                    self.labs_box.insert("end",
                        f"[{lab.get('difficulty','?')[:4]}] {lab.get('title','?')} "
                        f"({lab.get('duration_min','?')}m)\n")
                    self.labs[lab.get("title", f)] = path
                except Exception:
                    pass

    # ==================== browsing ====================
    def _browse(self):
        """تصفح مكتبة المعامل المتاحة وعرضها في لوحة التحكم"""
        self._out("\n=== Browsing Training Library ===")
        self._refresh_labs()
        self._out(f"[+] Found {len(self.labs)} lab(s) in training/labs/")

    # ==================== generation ====================
    def _generate(self):
        topic = self.topic.get().strip()
        if not topic:
            return
        difficulty = self.difficulty.get()
        platform = self.platform.get()
        tid = f"lab-{int(time.time())}"
        self.progress.start(tid, f"Generating lab: {topic}")

        def run():
            try:
                # call AI module
                ai = self.app.modules.get("ai_advanced") if self.app else None
                if not ai:
                    self._out("[!] AI module not available")
                    return
                prompt = (f"Topic: {topic}\nDifficulty: {difficulty}\n"
                          f"Platform: {platform}")
                response = ai._call(SYSTEM_LAB_GEN, prompt, max_tokens=4000)
                # extract JSON
                text = response.strip()
                if text.startswith("```"):
                    text = text.split("```")[1]
                    if text.startswith("json"):
                        text = text[4:]
                lab = json.loads(text)
                # save
                safe = topic.replace(" ", "_").replace("/", "_")[:40]
                path = f"training/labs/{safe}_{int(time.time())}.json"
                with open(path, "w") as f:
                    json.dump(lab, f, indent=2)
                # save docker-compose if present
                if lab.get("environment", {}).get("docker_compose"):
                    dc = f"training/labs/{safe}_docker-compose.yml"
                    with open(dc, "w") as f:
                        f.write(lab["environment"]["docker_compose"])
                    lab["_docker_path"] = dc
                self._out(f"[+] lab generated: {path}")
                self._out(json.dumps(lab, indent=2)[:5000])
                self._refresh_labs()
                self.progress.finish(tid, detail=path)
            except Exception as e:
                self._out(f"[!] {e}")
                self.progress.finish(tid, "failed", str(e))

        threading.Thread(target=run, daemon=True).start()

    # ==================== deploy ====================
    def _deploy(self):
        import tkinter.simpledialog as sd
        title = sd.askstring("Deploy", "Lab title:")
        if not title or title not in self.labs:
            self._out("[!] lab not found")
            return
        path = self.labs[title]
        with open(path) as f:
            lab = json.load(f)
        dc = lab.get("_docker_path")
        if not dc or not os.path.exists(dc):
            self._out("[!] no docker-compose for this lab")
            return
        project = f"shadowlab-{int(time.time())}"
        cmd = ["docker", "compose", "-f", dc, "-p", project, "up", "-d"]
        self._out(f"$ {' '.join(cmd)}")
        subprocess.Popen(cmd)

    def _stop(self):
        import tkinter.simpledialog as sd
        title = sd.askstring("Stop", "Lab title:")
        if not title or title not in self.labs:
            return
        with open(self.labs[title]) as f:
            lab = json.load(f)
        dc = lab.get("_docker_path")
        if dc:
            subprocess.Popen(["docker", "compose", "-f", dc, "down"])

    def _verify(self):
        self._out("""
=== Verify lab completion ===
Check:
  1. All target flags captured?
  2. Required files exfiltrated?
  3. Persistence established?
  4. MITRE techniques executed?

Verification commands vary per lab — see lab JSON "verification" field.
""")

    def _hint(self):
        import tkinter.simpledialog as sd
        title = sd.askstring("Hint", "Lab title:")
        idx = sd.askinteger("Hint", "Task number:", initialvalue=1)
        if not title or title not in self.labs or not idx:
            return
        with open(self.labs[title]) as f:
            lab = json.load(f)
        tasks = lab.get("tasks", [])
        for t in tasks:
            if t.get("id") == idx:
                for i, h in enumerate(t.get("hints", []), 1):
                    self._out(f"  hint {i}: {h}")
                return

    def _solution(self):
        import tkinter.simpledialog as sd
        title = sd.askstring("Solution", "Lab title:")
        idx = sd.askinteger("Solution", "Task number:", initialvalue=1)
        if not title or title not in self.labs or not idx:
            return
        with open(self.labs[title]) as f:
            lab = json.load(f)
        for t in lab.get("tasks", []):
            if t.get("id") == idx:
                self._out(f"solution:\n{t.get('solution_command','')}")
                self._out(f"evasion: {t.get('detection_evasion','')}")
                return

    def _reset(self):
        self._stop()
        time.sleep(3)
        self._deploy()

    def _progress_report(self):
        completed = 0
        total = len(self.labs)
        self._out(f"\n=== Training progress ===\n{completed}/{total} labs")

    def _packs(self):
        self._out("""
=== Curated packs ===
- beginner_web: XSS, SQLi, IDOR, auth bypass (Docker: bWAPP, DVWA, Juice Shop)
- intermediate_ad: Kerberoast, ACL abuse, delegation (labs: GOAD)
- advanced_adcs: ESC1-ESC8 (labs: VULNERABLE-ADCS, Certipy labs)
- advanced_lan: ARP poison, MITM, SMB relay (labs: NetworkChuck VMs)
- advanced_cloud: AWS IAM privesc (labs: CloudGoat, flaws.cloud)
- advanced_firmware: UEFI/DMA (labs: Damn Vulnerable UEFI)
- expert_enterprise: multi-vector (labs: DetectionLab + GOAD + Splunk)
""")

    def _export(self):
        import tkinter.simpledialog as sd
        title = sd.askstring("Export", "Lab title:")
        if title in self.labs:
            path = self.labs[title]
            self._out(f"exported: {path}")

    def _deploy_pack(self):
        self._out("[!] beginner pack includes 6 labs, ~5GB pull")
