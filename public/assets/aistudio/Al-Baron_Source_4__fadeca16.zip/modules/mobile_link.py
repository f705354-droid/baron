# language: Python, file: modules/mobile_link.py
import customtkinter as ctk
import threading
import json
import os
from core.mobile.api_server import MobileAPI


class MobileLinkModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "mobile_link"
        self.app = app
        self.api = MobileAPI(app)

    def render(self, parent):
        ctk.CTkLabel(parent, text="MOBILE OPERATIONS",
                      font=ctk.CTkFont(size=18, weight="bold"),
                      text_color="#00ff9c").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="Android app · REST API · JWT auth",
                      font=ctk.CTkFont(size=11),
                      text_color="#4a5568").pack(pady=(0, 12), padx=24, anchor="w")

        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24)
        for label, fn in [
            ("⚡ Start API server", self._start_api),
            ("▸ Add user", self._add_user),
            ("▸ Show QR", self._show_qr),
            ("▸ Test connection", self._test),
        ]:
            ctk.CTkButton(row, text=label, width=170, height=34,
                          fg_color="#141a22", hover_color="#1a2332",
                          command=fn).pack(side="left", padx=(0, 4))

        self.out = ctk.CTkTextbox(parent, fg_color="#05080c",
                                    text_color="#7dffb0",
                                    font=ctk.CTkFont(family="Consolas", size=10),
                                    height=500)
        self.out.pack(fill="both", expand=True, padx=24, pady=(12, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _start_api(self):
        try:
            self.api.start()
            self._out("[+] API server started on :8443")
            self._out("[*] Add a user first: 'Add user'")
            self._out("[*] Then open mobile app and login")
        except Exception as e:
            self._out(f"[!] {e}")

    def _add_user(self):
        import tkinter.simpledialog as sd
        user = sd.askstring("User", "username:")
        if not user:
            return
        pwd = sd.askstring("User", "password:", show="*")
        if not pwd:
            return
        self.api.add_user(user, pwd, "operator")
        self._out(f"[+] user {user} added")

    def _show_qr(self):
        """يعرض QR code للربط"""
        try:
            import qrcode
            import socket
            # grab local IP
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            url = f"albaron://{ip}:8443"
            qr = qrcode.QRCode()
            qr.add_data(url)
            qr.make()
            self._out(f"[+] Connect URL: {url}")
            qr.print_ascii()
        except ImportError:
            self._out("[!] pip install qrcode[pil]")
        except Exception as e:
            self._out(f"[!] {e}")

    def _test(self):
        try:
            # quick test
            stats = self.api.get_stats()
            self._out(f"[+] API responding: {json.dumps(stats, indent=2)}")
        except Exception as e:
            self._out(f"[!] {e}")
