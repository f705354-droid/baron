# language: Python, file: modules/compliance_ui.py
import customtkinter as ctk
import json
from core.compliance.frameworks import ALL_FRAMEWORKS
from core.compliance.mapper import mapper
from core.compliance.exporter import exporter


class ComplianceModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "compliance"
        self.app = app

    def render(self, parent):
        ctk.CTkLabel(parent, text="COMPLIANCE",
                      font=ctk.CTkFont(size=18, weight="bold"),
                      text_color="#00ff9c").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="ISO 27001 · NIST CSF · PCI DSS mapping",
                      font=ctk.CTkFont(size=11),
                      text_color="#4a5568").pack(pady=(0, 12), padx=24, anchor="w")

        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24)
        for label, fn in [
            ("▸ List frameworks", self._list),
            ("▸ Map findings", self._map),
            ("▤ Export PDF (ISO)", lambda: self._export("ISO 27001")),
            ("▤ Export PDF (NIST)", lambda: self._export("NIST CSF")),
            ("▤ Export PDF (PCI)", lambda: self._export("PCI DSS")),
        ]:
            ctk.CTkButton(row, text=label, width=170, height=34,
                          fg_color="#141a22", hover_color="#1a2332",
                          command=fn).pack(side="left", padx=(0, 4))

        self.out = ctk.CTkTextbox(parent, fg_color="#05080c",
                                    text_color="#7dffb0",
                                    font=ctk.CTkFont(family="Consolas", size=10),
                                    height=500)
        self.out.pack(fill="both", expand=True, padx=24, pady=(12, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _list(self):
        self._out(f"\n=== {len(ALL_FRAMEWORKS)} frameworks ===")
        for name, fw in ALL_FRAMEWORKS.items():
            self._out(f"  • {fw.name} v{fw.version}: "
                      f"{len(fw.controls)} controls")

    def _map(self):
        # collect findings from graph
        from core.graph.graph_db import graph
        findings = []
        for h in graph.list_nodes("host"):
            vulns = graph.neighbors("host", h["key"],
                                       edge_type="vulnerable_to",
                                       direction="out")
            for v in vulns:
                findings.append({
                    "title": f"{v['key']} on {h['key']}",
                    "cve": v["key"],
                    "host": h["key"],
                })

        if not findings:
            self._out("[!] no findings — run recon first")
            return

        result = mapper.map_all(findings)
        self._out(f"\n=== {len(findings)} findings mapped ===\n")
        for fw, controls in result["summary"].items():
            self._out(f"\n{fw}: {len(controls)} controls affected")
            for c in controls[:10]:
                self._out(f"  • {c}")

    def _export(self, framework):
        # collect findings
        from core.graph.graph_db import graph
        findings = []
        for h in graph.list_nodes("host"):
            vulns = graph.neighbors("host", h["key"],
                                       edge_type="vulnerable_to",
                                       direction="out")
            for v in vulns:
                findings.append({
                    "title": f"{v['key']} on {h['key']}",
                    "cve": v["key"],
                    "host": h["key"],
                })

        output = exporter.export_pdf(framework, findings)
        if output:
            self._out(f"[+] exported → {output}")
        else:
            self._out("[!] export failed")
