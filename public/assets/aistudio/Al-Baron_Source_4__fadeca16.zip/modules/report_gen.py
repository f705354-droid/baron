# language: Python, file: modules/report_gen.py
import customtkinter as ctk
from datetime import datetime
from core.reports.composer import report_composer


class ReportGenModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "report_gen"
        self.app = app

    def render(self, parent):
        ctk.CTkLabel(parent, text="REPORT GENERATOR",
                      font=ctk.CTkFont(size=18, weight="bold"),
                      text_color="#00ff9c").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="client-ready PDF · exec + technical",
                      font=ctk.CTkFont(size=11),
                      text_color="#4a5568").pack(pady=(0, 12), padx=24, anchor="w")

        # metadata inputs
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        for row_data in [
            [("client", "client name"), ("engagement", "engagement name")],
            [("tester", "tester name"), ("scope", "scope (CIDR)")],
        ]:
            r = ctk.CTkFrame(cfg, fg_color="transparent")
            r.pack(fill="x", padx=12, pady=4)
            for key, placeholder in row_data:
                ctk.CTkLabel(r, text=f"{key}:",
                              font=ctk.CTkFont(size=10),
                              text_color="#6a7a8a").pack(side="left", padx=(0, 4))
                entry = ctk.CTkEntry(r, placeholder_text=placeholder,
                                       width=200, height=30,
                                       fg_color="#05080c",
                                       border_color="#1a2332")
                entry.pack(side="left", padx=(0, 12))
                setattr(self, f"{key}_entry", entry)

        # actions
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24, pady=12)
        for label, fn in [
            ("⚡ Generate report", self._generate),
            ("▸ Preview findings", self._preview),
        ]:
            ctk.CTkButton(row, text=label, width=170, height=34,
                          fg_color="#0d2818", hover_color="#1a4a2e",
                          text_color="#00ff9c",
                          command=fn).pack(side="left", padx=(0, 4))

        self.out = ctk.CTkTextbox(parent, fg_color="#05080c",
                                    text_color="#7dffb0",
                                    font=ctk.CTkFont(family="Consolas", size=10),
                                    height=500)
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _collect_findings(self) -> list:
        """يجمع findings من graph"""
        from core.graph.graph_db import graph
        findings = []
        for h in graph.list_nodes("host"):
            vulns = graph.neighbors("host", h["key"],
                                       edge_type="vulnerable_to",
                                       direction="out")
            for v in vulns:
                cve = v["key"]
                sev = "critical" if any(
                    kw in cve for kw in ["2021-44228", "2020-1472",
                                            "2019-0708"]) else "high"
                findings.append({
                    "severity": sev,
                    "title": f"{cve} on {h['key']}",
                    "host": h["key"],
                    "cve": cve,
                    "description": f"Detected {cve} via enumeration",
                    "evidence": v["properties"].get("evidence", ""),
                })
        return findings

    def _preview(self):
        findings = self._collect_findings()
        self._out(f"\n=== {len(findings)} findings ===")
        for f in findings[:20]:
            self._out(f"  [{f['severity']}] {f['title']}")

    def _generate(self):
        import tkinter.filedialog as fd
        path = fd.asksaveasfilename(
            defaultextension=".pdf",
            initialfile=f"pentest_report_{int(datetime.now().timestamp())}.pdf")
        if not path:
            return

        engagement = {
            "name": getattr(self, "engagement_entry", None) and
                      self.engagement_entry.get() or "Test Engagement",
            "client": getattr(self, "client_entry", None) and
                        self.client_entry.get() or "Client",
            "tester": getattr(self, "tester_entry", None) and
                        self.tester_entry.get() or "Tester",
            "start": datetime.now().strftime("%Y-%m-%d"),
            "end": datetime.now().strftime("%Y-%m-%d"),
            "scope": getattr(self, "scope_entry", None) and
                       self.scope_entry.get() or "",
        }

        findings = self._collect_findings()

        self._out(f"[*] generating report with {len(findings)} findings...")
        result = report_composer.generate_engagement_report(
            engagement, findings, path)
        self._out(f"[+] {result}")
