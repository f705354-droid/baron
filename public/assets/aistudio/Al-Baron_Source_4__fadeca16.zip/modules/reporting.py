# language: Python, file: modules/reporting.py
# Al-Baron Reporting Module (full — executive + technical + MITRE)
import customtkinter as ctk
import threading
import os
import json
import time
from datetime import datetime
from utils.progress import ProgressTracker


class ReportingModule:
    def __init__(self, log_queue, albaron_app=None):
        self.log = log_queue
        self.name = "reporting"
        self.progress = ProgressTracker(log_queue)
        self.app = albaron_app

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="REPORTING",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="auto PDF · exec summary · technical detail · MITRE ATT&CK map",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)

        r1 = ctk.CTkFrame(cfg, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=8)
        self.engagement_e = ctk.CTkEntry(
            r1, placeholder_text="engagement name", width=260, height=32,
            fg_color="#05080c", border_color="#1a2332")
        self.engagement_e.pack(side="left", padx=(0, 6))
        self.client_e = ctk.CTkEntry(
            r1, placeholder_text="client", width=200, height=32,
            fg_color="#05080c", border_color="#1a2332")
        self.client_e.pack(side="left", padx=(0, 6))
        self.tester_e = ctk.CTkEntry(
            r1, placeholder_text="tester(s)", width=220, height=32,
            fg_color="#05080c", border_color="#1a2332")
        self.tester_e.pack(side="left", padx=(0, 6))
        self.classification = ctk.CTkOptionMenu(
            r1, values=["CONFIDENTIAL", "INTERNAL", "CLIENT-PRIVATE", "PUBLIC"],
            width=160, fg_color="#1a2332", button_color="#1a2332")
        self.classification.pack(side="left")

        r2 = ctk.CTkFrame(cfg, fg_color="transparent")
        r2.pack(fill="x", padx=12, pady=(0, 10))
        self.start_date = ctk.CTkEntry(
            r2, placeholder_text="start (YYYY-MM-DD)", width=180, height=32,
            fg_color="#05080c", border_color="#1a2332")
        self.start_date.pack(side="left", padx=(0, 6))
        self.end_date = ctk.CTkEntry(
            r2, placeholder_text="end (YYYY-MM-DD)", width=180, height=32,
            fg_color="#05080c", border_color="#1a2332")
        self.end_date.pack(side="left", padx=(0, 6))
        self.scope_e = ctk.CTkEntry(
            r2, placeholder_text="scope (cidr list)", width=300, height=32,
            fg_color="#05080c", border_color="#1a2332")
        self.scope_e.pack(side="left")

        actions = ctk.CTkFrame(parent, fg_color="transparent")
        actions.pack(fill="x", padx=24, pady=12)
        for label, fn in [
            ("▸ Collect findings", self._collect),
            ("▸ Executive PDF", self._exec_pdf),
            ("▸ Technical PDF", self._tech_pdf),
            ("▸ Full report PDF", self._full_pdf),
            ("▸ MITRE ATT&CK map", self._mitre_map),
            ("▸ JSON export", self._json_export),
            ("▸ Preview HTML", self._preview),
        ]:
            ctk.CTkButton(actions, text=label, width=160, height=34,
                          fg_color="#141a22", hover_color="#1a2332",
                          font=ctk.CTkFont(size=11), command=fn
                          ).pack(side="left", padx=(0, 4))

        self.bars = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        self.bars.pack(fill="x", padx=24, pady=(0, 8))

        ctk.CTkLabel(parent, text="Preview:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(8, 4), padx=24, anchor="w")
        self.preview = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=300
        )
        self.preview.pack(fill="both", expand=True, padx=24, pady=(0, 12))

        self._poll_bars()

    def _poll_bars(self):
        for w in self.bars.winfo_children():
            w.destroy()
        for tid, t in list(self.progress.snapshot().items())[:5]:
            row = ctk.CTkFrame(self.bars, fg_color="transparent")
            row.pack(fill="x", padx=8, pady=2)
            ctk.CTkLabel(row, text=t["label"][:50], width=300, anchor="w",
                         font=ctk.CTkFont(size=10),
                         text_color="#c8d6e5").pack(side="left")
            b = ctk.CTkProgressBar(row, width=200, height=10,
                                   progress_color="#00ff9c")
            b.set(min(t["current"]/max(t["total"] or 1, 1), 1.0) if t["total"]
                  else (0.5 if t["status"] == "running" else 1.0))
            b.pack(side="left", padx=(0, 8))
            ctk.CTkLabel(row, text=t.get("detail", "")[:60],
                         font=ctk.CTkFont(size=9),
                         text_color="#4a5568").pack(side="left")
        self.bars.after(500, self._poll_bars)

    # ==================== collect ====================
    def _collect(self):
        """gather findings from all modules in the running app"""
        if not self.app:
            self.log.put("[report] app not attached")
            return
        os.makedirs("reports/data", exist_ok=True)
        data = {
            "engagement": self.engagement_e.get(),
            "client": self.client_e.get(),
            "tester": self.tester_e.get(),
            "classification": self.classification.get(),
            "start": self.start_date.get(),
            "end": self.end_date.get(),
            "scope": self.scope_e.get(),
            "generated": datetime.utcnow().isoformat(),
            "sections": {},
        }
        # LAN
        try:
            lan = self.app.modules.get("lan")
            if lan and hasattr(lan, "hosts"):
                data["sections"]["lan_hosts"] = lan.hosts
        except Exception:
            pass
        # AD
        try:
            ad = self.app.modules.get("ad")
            if ad:
                data["sections"]["ad"] = {
                    "domain": ad.domain,
                    "dc_ip": ad.dc_ip,
                    "kerb_tickets": getattr(ad, "kerb_tickets", {}),
                    "hashes": getattr(ad, "hashes", {}),
                }
        except Exception:
            pass
        # C2 UI sessions
        try:
            ui = self.app.modules.get("c2_ui")
            if ui and hasattr(ui, "sessions"):
                data["sections"]["sessions"] = ui.sessions
        except Exception:
            pass
        # C2 server sessions
        try:
            c2 = self.app.modules.get("c2")
            if c2:
                from modules.c2 import SESSIONS
                data["sections"]["beacons"] = {k: v for k, v in SESSIONS.items()}
        except Exception:
            pass
        # Phishing hits
        try:
            phish = self.app.modules.get("phishing")
            if phish and hasattr(phish, "hits"):
                data["sections"]["phishing"] = phish.hits
        except Exception:
            pass
        # Exfil loot
        try:
            loot_files = []
            for root, _, files in os.walk("loot"):
                for f in files:
                    loot_files.append(os.path.join(root, f))
            data["sections"]["loot"] = loot_files
        except Exception:
            pass

        out = "reports/data/engagement.json"
        with open(out, "w") as f:
            json.dump(data, f, indent=2, default=str)
        self.preview.delete("1.0", "end")
        self.preview.insert("end", json.dumps(data, indent=2, default=str)[:5000])
        self.log.put(f"[report] collected → {out}")

    # ==================== PDF generation ====================
    def _load_data(self):
        try:
            with open("reports/data/engagement.json") as f:
                return json.load(f)
        except Exception:
            self._collect()
            with open("reports/data/engagement.json") as f:
                return json.load(f)

    def _exec_pdf(self):
        self._gen_pdf("executive")

    def _tech_pdf(self):
        self._gen_pdf("technical")

    def _full_pdf(self):
        self._gen_pdf("full")

    def _gen_pdf(self, kind):
        tid = f"pdf-{int(time.time())}"
        self.progress.start(tid, f"Building {kind} PDF", total=10)

        def run():
            try:
                from fpdf import FPDF
            except ImportError:
                self.log.put("[report] pip install fpdf2")
                return

            data = self._load_data()
            sections = data.get("sections", {})

            class PDF(FPDF):
                def header(self):
                    self.set_font("Helvetica", "B", 8)
                    self.set_text_color(120)
                    self.cell(0, 5, data.get("classification", "CONFIDENTIAL"),
                              align="R")
                    self.ln(6)

                def footer(self):
                    self.set_y(-15)
                    self.set_font("Helvetica", "I", 8)
                    self.set_text_color(120)
                    self.cell(0, 10, f"Page {self.page_no()} — "
                              f"Al-Baron / {data.get('client','')}",
                              align="C")

            pdf = PDF()
            pdf.set_auto_page_break(auto=True, margin=15)
            pdf.add_page()

            # ---- cover ----
            pdf.set_font("Helvetica", "B", 28)
            pdf.ln(40)
            pdf.cell(0, 14, "PENETRATION TEST REPORT",
                     align="C", new_x="LMARGIN", new_y="NEXT")
            pdf.ln(20)
            pdf.set_font("Helvetica", "", 14)
            for line in [
                f"Engagement: {data.get('engagement','')}",
                f"Client: {data.get('client','')}",
                f"Tester(s): {data.get('tester','')}",
                f"Window: {data.get('start','')} → {data.get('end','')}",
                f"Scope: {data.get('scope','')}",
                f"Generated: {data.get('generated','')[:19]}",
            ]:
                pdf.cell(0, 8, line, align="C", new_x="LMARGIN", new_y="NEXT")
            pdf.ln(30)
            pdf.set_font("Helvetica", "I", 10)
            pdf.set_text_color(150)
            pdf.cell(0, 6,
                     f"{data.get('classification','CONFIDENTIAL')} — "
                     "distribution restricted",
                     align="C", new_x="LMARGIN", new_y="NEXT")

            self.progress.update(tid, increment=3, detail="cover")

            # ---- exec summary ----
            if kind in ("executive", "full"):
                pdf.add_page()
                pdf.set_text_color(0)
                pdf.set_font("Helvetica", "B", 20)
                pdf.cell(0, 12, "Executive Summary", new_x="LMARGIN", new_y="NEXT")
                pdf.ln(4)
                pdf.set_font("Helvetica", "", 11)

                hosts = sections.get("lan_hosts", {})
                sessions = sections.get("sessions", {})
                beacons = sections.get("beacons", {})
                phishing = sections.get("phishing", [])
                loot = sections.get("loot", [])

                sev_counts = self._severity_summary(sections)

                summary_lines = [
                    f"Network hosts discovered: {len(hosts)}",
                    f"Active C2 sessions: {len(sessions) or len(beacons)}",
                    f"Phishing hits: {len(phishing)}",
                    f"Files exfiltrated: {len(loot)}",
                    "",
                    "Findings by severity:",
                ]
                for k in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
                    summary_lines.append(f"  {k}: {sev_counts.get(k, 0)}")

                for line in summary_lines:
                    pdf.cell(0, 6, line, new_x="LMARGIN", new_y="NEXT")
                self.progress.update(tid, increment=2, detail="exec summary")

            # ---- technical findings ----
            if kind in ("technical", "full"):
                pdf.add_page()
                pdf.set_font("Helvetica", "B", 20)
                pdf.cell(0, 12, "Technical Findings", new_x="LMARGIN", new_y="NEXT")
                pdf.ln(4)

                # LAN hosts
                if "lan_hosts" in sections:
                    pdf.set_font("Helvetica", "B", 14)
                    pdf.cell(0, 8, "Discovered Hosts", new_x="LMARGIN", new_y="NEXT")
                    pdf.set_font("Helvetica", "", 9)
                    for ip, info in list(sections["lan_hosts"].items())[:100]:
                        ports = ",".join(str(p) for p, _ in info.get("ports", [])[:10])
                        pdf.multi_cell(0, 4,
                            f"  {ip}  |  {info.get('hostname','?')}  |  "
                            f"{info.get('mac','?')}  |  ports: {ports}")
                    pdf.ln(4)
                    self.progress.update(tid, increment=1, detail="hosts")

                # AD
                ad = sections.get("ad", {})
                if ad.get("domain"):
                    pdf.set_font("Helvetica", "B", 14)
                    pdf.cell(0, 8, "Active Directory", new_x="LMARGIN", new_y="NEXT")
                    pdf.set_font("Helvetica", "", 10)
                    pdf.multi_cell(0, 5,
                        f"Domain: {ad.get('domain')}\n"
                        f"DC: {ad.get('dc_ip')}\n"
                        f"Kerberos tickets captured: {len(ad.get('kerb_tickets', {}))}\n"
                        f"Hashes captured: {len(ad.get('hashes', {}))}")
                    pdf.ln(4)
                    self.progress.update(tid, increment=1, detail="AD")

                # Sessions
                s = sections.get("sessions") or sections.get("beacons", {})
                if s:
                    pdf.set_font("Helvetica", "B", 14)
                    pdf.cell(0, 8, "Command & Control Sessions",
                             new_x="LMARGIN", new_y="NEXT")
                    pdf.set_font("Helvetica", "", 9)
                    for sid, info in list(s.items())[:50]:
                        pdf.multi_cell(0, 4,
                            f"  {sid[:12]}  |  {info.get('host','?')}  |  "
                            f"{info.get('user','?')}  |  {info.get('os','?')}")
                    pdf.ln(4)
                    self.progress.update(tid, increment=1, detail="C2")

                # Phishing
                if phishing:
                    pdf.set_font("Helvetica", "B", 14)
                    pdf.cell(0, 8, "Phishing Results", new_x="LMARGIN", new_y="NEXT")
                    pdf.set_font("Helvetica", "", 9)
                    for hit in phishing[:50]:
                        pdf.multi_cell(0, 4,
                            f"  {hit.get('_time','')}  |  {hit.get('_ip','')}  |  "
                            f"{hit.get('username','?')}")
                    pdf.ln(4)

                # Loot
                if loot:
                    pdf.set_font("Helvetica", "B", 14)
                    pdf.cell(0, 8, "Exfiltrated Data",
                             new_x="LMARGIN", new_y="NEXT")
                    pdf.set_font("Helvetica", "", 8)
                    for path in loot[:200]:
                        pdf.multi_cell(0, 4, f"  {path}")
                self.progress.update(tid, increment=1, detail="detail")

            # ---- recommendations ----
            if kind == "full":
                pdf.add_page()
                pdf.set_font("Helvetica", "B", 20)
                pdf.cell(0, 12, "Recommendations", new_x="LMARGIN", new_y="NEXT")
                pdf.ln(4)
                pdf.set_font("Helvetica", "", 10)
                recs = self._recommendations(sections)
                for i, r in enumerate(recs, 1):
                    pdf.multi_cell(0, 5, f"{i}. {r}")
                    pdf.ln(1)

            out = f"reports/{kind}_{int(time.time())}.pdf"
            os.makedirs("reports", exist_ok=True)
            pdf.output(out)
            self.log.put(f"[report] {kind} PDF → {out}")
            self.progress.finish(tid, detail=out)

        threading.Thread(target=run, daemon=True).start()

    # ==================== analysis ====================
    def _severity_summary(self, sections):
        counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}
        ad = sections.get("ad", {})
        if ad.get("hashes"):
            counts["CRITICAL"] += len(ad["hashes"])
        if ad.get("kerb_tickets"):
            counts["HIGH"] += len(ad["kerb_tickets"])
        counts["HIGH"] += len(sections.get("sessions", {})) + \
                          len(sections.get("beacons", {}))
        counts["MEDIUM"] += len(sections.get("phishing", []))
        counts["INFO"] += len(sections.get("lan_hosts", {}))
        return counts

    def _recommendations(self, sections):
        recs = []
        if sections.get("lan_hosts"):
            recs.append("Segment networks — deploy 802.1X and NAC to prevent "
                        "unauthorized lateral movement.")
        if sections.get("ad"):
            recs.append("Tier-0 hardening: enforce LAPS, disable unconstrained "
                        "delegation, remove SPNs from service accounts where "
                        "possible, rotate krbtgt twice.")
            recs.append("Enable Windows Defender Credential Guard and LSA "
                        "protection on all Tier-0 assets.")
        if sections.get("sessions") or sections.get("beacons"):
            recs.append("Deploy EDR with behavioral detection on all endpoints — "
                        "current implants avoid signature-only AV.")
        if sections.get("phishing"):
            recs.append("Implement DMARC/DKIM/SPF, external-sender banners, and "
                        "advanced phishing simulation. Enable MFA everywhere.")
        recs.append("Patch management: ensure critical CVEs (see appendix) are "
                    "remediated within 30 days, high within 90.")
        recs.append("Log aggregation: forward Windows Event IDs 4624/4625/4768/"
                    "4769/4776/5140/5145 to SIEM with alerting.")
        return recs

    # ==================== MITRE ATT&CK ====================
    def _mitre_map(self):
        data = self._load_data()
        sections = data.get("sections", {})
        techniques = []
        if sections.get("lan_hosts"):
            techniques.append(("T1046", "Network Service Discovery"))
            techniques.append(("T1018", "Remote System Discovery"))
        if sections.get("ad"):
            techniques.append(("T1558.003", "Kerberoasting"))
            techniques.append(("T1003.006", "DCSync"))
            techniques.append(("T1087.002", "Domain Account Discovery"))
        if sections.get("sessions"):
            techniques.append(("T1071.001", "Web Protocols C2"))
            techniques.append(("T1071.004", "DNS C2"))
            techniques.append(("T1055", "Process Injection"))
            techniques.append(("T1543", "Create or Modify System Process"))
        if sections.get("phishing"):
            techniques.append(("T1566.002", "Spearphishing Link"))
            techniques.append(("T1078", "Valid Accounts"))
        if sections.get("loot"):
            techniques.append(("T1005", "Data from Local System"))
            techniques.append(("T1041", "Exfil Over C2 Channel"))
            techniques.append(("T1048", "Exfil Over Alternative Protocol"))

        self.preview.delete("1.0", "end")
        self.preview.insert("end", "MITRE ATT&CK Coverage:\n\n")
        for tid, name in techniques:
            self.preview.insert("end", f"  {tid:12} {name}\n")
        self.log.put(f"[report] {len(techniques)} techniques mapped")

    def _json_export(self):
        import tkinter.filedialog as fd
        path = fd.asksaveasfilename(defaultextension=".json",
                                     initialfile="albaron_engagement.json")
        if not path:
            return
        data = self._load_data()
        with open(path, "w") as f:
            json.dump(data, f, indent=2, default=str)
        self.log.put(f"[report] JSON → {path}")

    def _preview(self):
        self._collect()
