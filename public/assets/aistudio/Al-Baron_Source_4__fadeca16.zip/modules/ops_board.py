# language: Python, file: modules/ops_board.py
# Al-Baron Ops Board — Kanban for engagement management
import customtkinter as ctk
import json
import os

class OpsBoardModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "ops_board"
        self.app = app
        self._parent = None
        self.tasks_file = "reports/ops_board.json"
        self.tasks = self._load_tasks()

    def render(self, parent):
        self._parent = parent
        ctk.CTkLabel(parent, text="OPS BOARD", font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="kanban · engagement management", font=ctk.CTkFont(size=11), text_color="#8a8a8a").pack(pady=(0, 12), padx=24, anchor="w")

        # Add Task
        add_row = ctk.CTkFrame(parent, fg_color="transparent")
        add_row.pack(fill="x", padx=24, pady=12)
        self.task_entry = ctk.CTkEntry(add_row, placeholder_text="New task description...", height=34, fg_color="#05080c", border_color="#1a2332")
        self.task_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        ctk.CTkButton(add_row, text="+ Add Task", width=120, height=34, fg_color="#0d2818", hover_color="#1a4a2e", text_color="#00ff9c", command=self._add_task).pack(side="left")

        # Board Columns (3 columns)
        board = ctk.CTkFrame(parent, fg_color="transparent")
        board.pack(fill="both", expand=True, padx=24, pady=12)
        for i in range(3):
            board.grid_columnconfigure(i, weight=1)
        board.grid_rowconfigure(0, weight=1)

        self.columns = {}
        for idx, (col_name, color) in enumerate([("BACKLOG", "#6a7a8a"), ("IN PROGRESS", "#ffaa00"), ("DONE", "#00ff9c")]):
            col = ctk.CTkFrame(board, fg_color="#0d1319", corner_radius=6)
            col.grid(row=0, column=idx, sticky="nsew", padx=4)
            
            header = ctk.CTkFrame(col, fg_color=color, corner_radius=0, height=32)
            header.pack(fill="x")
            header.pack_propagate(False)
            ctk.CTkLabel(header, text=col_name, font=ctk.CTkFont(size=12, weight="bold"), text_color="#000").pack(pady=6)

            scroll = ctk.CTkScrollableFrame(col, fg_color="transparent")
            scroll.pack(fill="both", expand=True, padx=4, pady=4)
            self.columns[col_name] = scroll

        self._refresh_board()

    def _add_task(self):
        text = self.task_entry.get().strip()
        if not text: return
        self.tasks.append({"text": text, "status": "BACKLOG"})
        self.task_entry.delete(0, "end")
        self._save_tasks()
        self._refresh_board()

    def _refresh_board(self):
        for col in self.columns.values():
            for w in col.winfo_children():
                w.destroy()

        for i, task in enumerate(self.tasks):
            status = task.get("status", "BACKLOG")
            if status not in self.columns: continue

            card = ctk.CTkFrame(self.columns[status], fg_color="#1a2332", corner_radius=4)
            card.pack(fill="x", pady=2, padx=2)
            
            ctk.CTkLabel(card, text=task["text"], font=ctk.CTkFont(size=11), anchor="w", wraplength=200).pack(fill="x", padx=6, pady=4)

            btn_row = ctk.CTkFrame(card, fg_color="transparent")
            btn_row.pack(fill="x", padx=4, pady=(0, 4))
            
            if status == "BACKLOG":
                ctk.CTkButton(btn_row, text="▶ Start", width=60, height=22, fg_color="#2b2000", text_color="#ffd700", command=lambda idx=i: self._move_task(idx, "IN PROGRESS")).pack(side="left", padx=2)
            elif status == "IN PROGRESS":
                ctk.CTkButton(btn_row, text="✓ Done", width=60, height=22, fg_color="#0d2818", text_color="#00ff9c", command=lambda idx=i: self._move_task(idx, "DONE")).pack(side="left", padx=2)
            
            ctk.CTkButton(btn_row, text="✗", width=30, height=22, fg_color="#4a1a1a", text_color="#ff6b6b", command=lambda idx=i: self._delete_task(idx)).pack(side="right", padx=2)

    def _move_task(self, idx, new_status):
        if 0 <= idx < len(self.tasks):
            self.tasks[idx]["status"] = new_status
            self._save_tasks()
            self._refresh_board()

    def _delete_task(self, idx):
        if 0 <= idx < len(self.tasks):
            del self.tasks[idx]
            self._save_tasks()
            self._refresh_board()

    def _load_tasks(self):
        if os.path.exists(self.tasks_file):
            try:
                with open(self.tasks_file, "r") as f:
                    return json.load(f)
            except: pass
        return []

    def _save_tasks(self):
        os.makedirs("reports", exist_ok=True)
        with open(self.tasks_file, "w") as f:
            json.dump(self.tasks, f, indent=2)
