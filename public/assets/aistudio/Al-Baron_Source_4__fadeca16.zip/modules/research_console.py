# language: Python, file: modules/research_console.py
# Research Console — all five research systems in one GUI
import customtkinter as ctk
import threading
import json
import numpy as np


class ResearchConsoleModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "research_console"
        self.app = app

    def render(self, parent):
        ctk.CTkLabel(parent, text="RESEARCH CONSOLE",
                      font=ctk.CTkFont(size=18, weight="bold"),
                      text_color="#00ff9c").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="distributional · meta · dreamer · causal · synthesis",
                      font=ctk.CTkFont(size=11),
                      text_color="#4a5568").pack(pady=(0, 12), padx=24, anchor="w")

        tabs = ctk.CTkTabview(parent, fg_color="#0d1319",
                                segmented_button_fg_color="#141a22",
                                segmented_button_selected_color="#0d2818")
        tabs.pack(fill="both", expand=True, padx=24, pady=(0, 12))
        for name in ["Distributional", "Meta-RL", "Dreamer", "Causal", "Synthesis"]:
            tabs.add(name)

        # ── Distributional ──
        d_tab = tabs.tab("Distributional")
        for label, fn in [
            ("▸ C51 distribution", self._c51),
            ("▸ QR-DQN quantiles", self._qrdqn),
            ("▸ IQN quantiles", self._iqn),
            ("▸ Risk measures", self._risk),
        ]:
            ctk.CTkButton(d_tab, text=label, width=240, height=32,
                           fg_color="#141a22", hover_color="#1a2332",
                           command=fn).pack(pady=4, padx=12, anchor="w")
        self.d_out = ctk.CTkTextbox(d_tab, fg_color="#05080c",
                                      text_color="#7dffb0",
                                      font=ctk.CTkFont(family="Consolas", size=10))
        self.d_out.pack(fill="both", expand=True, padx=12, pady=8)

        # ── Meta-RL ──
        m_tab = tabs.tab("Meta-RL")
        for label, fn in [
            ("▸ MAML info", self._maml),
            ("▸ Reptile info", self._reptile),
            ("▸ Task sampler", self._tasks),
        ]:
            ctk.CTkButton(m_tab, text=label, width=240, height=32,
                           fg_color="#141a22", hover_color="#1a2332",
                           command=fn).pack(pady=4, padx=12, anchor="w")
        self.m_out = ctk.CTkTextbox(m_tab, fg_color="#05080c",
                                      text_color="#7dffb0",
                                      font=ctk.CTkFont(family="Consolas", size=10))
        self.m_out.pack(fill="both", expand=True, padx=12, pady=8)

        # ── Dreamer ──
        w_tab = tabs.tab("Dreamer")
        for label, fn in [
            ("▸ Imagination rollout", self._dreamer_roll),
            ("▸ Plan trajectories", self._dreamer_plan),
            ("▸ Describe latent", self._dreamer_describe),
        ]:
            ctk.CTkButton(w_tab, text=label, width=240, height=32,
                           fg_color="#141a22", hover_color="#1a2332",
                           command=fn).pack(pady=4, padx=12, anchor="w")
        self.w_out = ctk.CTkTextbox(w_tab, fg_color="#05080c",
                                      text_color="#7dffb0",
                                      font=ctk.CTkFont(family="Consolas", size=10))
        self.w_out.pack(fill="both", expand=True, padx=12, pady=8)

        # ── Causal ──
        c_tab = tabs.tab("Causal")
        for label, fn in [
            ("▸ SCM edges", self._scm),
            ("▸ ACE: stealth → detection", self._ace),
            ("▸ Counterfactual regret", self._cf),
            ("▸ PC discovery", self._pc),
        ]:
            ctk.CTkButton(c_tab, text=label, width=240, height=32,
                           fg_color="#141a22", hover_color="#1a2332",
                           command=fn).pack(pady=4, padx=12, anchor="w")
        self.c_out = ctk.CTkTextbox(c_tab, fg_color="#05080c",
                                      text_color="#7dffb0",
                                      font=ctk.CTkFont(family="Consolas", size=10))
        self.c_out.pack(fill="both", expand=True, padx=12, pady=8)

        # ── Synthesis ──
        s_tab = tabs.tab("Synthesis")
        for label, fn in [
            ("▸ Build from Coq", self._synth_build),
            ("▸ Verify proof", self._synth_verify),
        ]:
            ctk.CTkButton(s_tab, text=label, width=240, height=32,
                           fg_color="#141a22", hover_color="#1a2332",
                           command=fn).pack(pady=4, padx=12, anchor="w")
        self.s_out = ctk.CTkTextbox(s_tab, fg_color="#05080c",
                                      text_color="#7dffb0",
                                      font=ctk.CTkFont(family="Consolas", size=10))
        self.s_out.pack(fill="both", expand=True, padx=12, pady=8)

    def _set(self, widget, text):
        widget.delete("1.0", "end")
        widget.insert("end", text)

    def _c51(self):
        try:
            from core.ai.rl.distributional.c51 import c51
            s = np.random.randn(128).astype(np.float32)
            support, probs = c51.get_distribution(s, 0)
            t = f"C51 support: [{support.min():.1f}, {support.max():.1f}]\n"
            t += f"Mean: {(support*probs).sum():.3f}\n\nDistribution:\n"
            for i in range(0, len(probs), 5):
                t += f"  z={support[i]:7.2f}  p={probs[i]:.4f}\n"
            self._set(self.d_out, t)
        except Exception as e:
            self._set(self.d_out, f"[!] {e}")

    def _qrdqn(self):
        try:
            from core.ai.rl.distributional.qr_dqn import qrdqn
            s = np.random.randn(128).astype(np.float32)
            taus, q = qrdqn.get_quantiles(s, 0)
            t = f"QR-DQN quantiles (first 20 of {len(q)}):\n"
            for i in range(min(20, len(q))):
                t += f"  τ={taus[i]:.3f}  q={q[i]:7.2f}\n"
            t += f"\nMean: {q.mean():.3f}\nCVaR 5%: {q[q<=np.quantile(q,0.05)].mean():.3f}"
            self._set(self.d_out, t)
        except Exception as e:
            self._set(self.d_out, f"[!] {e}")

    def _iqn(self):
        try:
            from core.ai.rl.distributional.iqn import iqn
            s = np.random.randn(128).astype(np.float32)
            taus, q = iqn.get_quantiles(s, 0, n=30)
            t = "IQN quantiles:\n"
            for i in range(len(taus)):
                t += f"  τ={taus[i]:.3f}  q={q[i]:7.2f}\n"
            self._set(self.d_out, t)
        except Exception as e:
            self._set(self.d_out, f"[!] {e}")

    def _risk(self):
        try:
            from core.ai.rl.distributional.risk import RiskMeasures
            rm = RiskMeasures()
            samples = np.random.randn(1000) * 30 + 20
            t = "Risk measures:\n"
            t += f"  Mean:     {rm.mean(samples):.3f}\n"
            t += f"  Std:      {rm.std(samples):.3f}\n"
            t += f"  VaR 5%:   {rm.var(samples, 0.05):.3f}\n"
            t += f"  CVaR 5%:  {rm.cvar(samples, 0.05):.3f}\n"
            t += f"  Wang:     {rm.distorted_expectation(samples, 'wang'):.3f}\n"
            t += f"  Downside: {rm.downside_deviation(samples, 0):.3f}\n"
            t += f"  Omega:    {rm.omega_ratio(samples, 0):.3f}\n"
            self._set(self.d_out, t)
        except Exception as e:
            self._set(self.d_out, f"[!] {e}")

    def _maml(self):
        try:
            from core.ai.rl.meta.maml import maml
            info = {"inner_lr": maml.inner_lr, "outer_lr": maml.outer_lr,
                     "inner_steps": maml.inner_steps,
                     "has_torch": maml.meta_model is not None}
            self._set(self.m_out, json.dumps(info, indent=2))
        except Exception as e:
            self._set(self.m_out, f"[!] {e}")

    def _reptile(self):
        try:
            from core.ai.rl.meta.reptile import reptile
            info = {"inner_steps": reptile.inner_steps,
                     "inner_lr": reptile.inner_lr,
                     "meta_lr": reptile.meta_lr,
                     "has_torch": reptile.model is not None}
            self._set(self.m_out, json.dumps(info, indent=2))
        except Exception as e:
            self._set(self.m_out, f"[!] {e}")

    def _tasks(self):
        try:
            from core.ai.rl.meta.task_sampler import task_sampler
            self._set(self.m_out, f"tasks registered: {len(task_sampler.tasks)}")
        except Exception as e:
            self._set(self.m_out, f"[!] {e}")

    def _dreamer_roll(self):
        try:
            from core.ai.rl.world_model.dreamer import dreamer_agent
            import torch
            if not dreamer_agent.wm:
                self._set(self.w_out, "[!] torch not available")
                return
            h, z = dreamer_agent.wm.initial_state(batch_size=1)
            rollout = dreamer_agent.rollout.run(h, z)
            returns = dreamer_agent.rollout.compute_lambda_returns(rollout)
            t = "Imagination rollout:\n"
            for i, r in enumerate(rollout["rewards"][:10]):
                t += f"  t={i}  r={r.item():.3f}\n"
            t += f"\nTotal return: {returns[0].item():.3f}"
            self._set(self.w_out, t)
        except Exception as e:
            self._set(self.w_out, f"[!] {e}")

    def _dreamer_plan(self):
        try:
            from core.ai.rl.world_model.dreamer import dreamer_agent
            h, z = dreamer_agent.wm.initial_state(batch_size=1)
            best, trajs = dreamer_agent.plan(h, z, n_candidates=8, horizon=10)
            t = f"Best action: {best}\n\nTop trajectories:\n"
            for i, tr in enumerate(trajs[:5]):
                t += f"  #{i}: return={tr['return']:.3f}  "
                t += f"actions={tr['actions'][:5]}\n"
            self._set(self.w_out, t)
        except Exception as e:
            self._set(self.w_out, f"[!] {e}")

    def _dreamer_describe(self):
        try:
            from core.ai.rl.world_model.dreamer import dreamer_agent
            from core.ai.rl.world_model.decoder import feature_decoder
            h, z = dreamer_agent.wm.initial_state(batch_size=1)
            feature_decoder.wm = dreamer_agent.wm
            desc = feature_decoder.describe_latent(h, z)
            self._set(self.w_out, desc)
        except Exception as e:
            self._set(self.w_out, f"[!] {e}")

    def _scm(self):
        try:
            from core.ai.rl.causal.scm import albaron_scm
            t = "SCM edges:\n"
            for v in albaron_scm.graph.nodes:
                t += f"  {v} ← {albaron_scm.parents(v)}\n"
            self._set(self.c_out, t)
        except Exception as e:
            self._set(self.c_out, f"[!] {e}")

    def _ace(self):
        try:
            from core.ai.rl.causal.do_calculus import do_calculus
            res = do_calculus.causal_effect("stealth_mode", "detection", 2000)
            self._set(self.c_out, json.dumps(res, indent=2))
        except Exception as e:
            self._set(self.c_out, f"[!] {e}")

    def _cf(self):
        try:
            from core.ai.rl.causal.counterfactual import counterfactual_engine
            observed = {"stealth_mode": 1.0, "recon_quality": 1.2,
                         "sessions": 2.0, "creds": 1.5, "domain_admin": 1.0,
                         "exploitation_noise": 0.5, "detection": 0.3, "exfil": 1.8}
            res = counterfactual_engine.regret(observed,
                {"stealth_mode": 1.0}, {"stealth_mode": 0.0}, "exfil")
            self._set(self.c_out, json.dumps(res, indent=2))
        except Exception as e:
            self._set(self.c_out, f"[!] {e}")

    def _pc(self):
        try:
            from core.ai.rl.causal.discovery import pc_algorithm
            from core.ai.rl.causal.scm import albaron_scm
            import numpy as np
            names = ["stealth_mode", "recon_quality", "sessions",
                     "creds", "domain_admin", "detection"]
            samples = albaron_scm.sample(n_samples=500)
            data = np.array([[s.get(n, 0.0) for n in names] for s in samples])
            g = pc_algorithm.fit(data, names)
            t = f"PC discovered {len(list(g.edges))} edges:\n"
            for e in g.edges:
                t += f"  {e[0]} → {e[1]}\n"
            self._set(self.c_out, t)
        except Exception as e:
            self._set(self.c_out, f"[!] {e}")

    def _synth_build(self):
        try:
            from core.ai.rl.synthesis.verifier import synthesizer
            res = synthesizer.build("Guardrails.v")
            self._set(self.s_out, json.dumps(res, indent=2))
        except Exception as e:
            self._set(self.s_out, f"[!] {e}")

    def _synth_verify(self):
        try:
            from core.ai.rl.synthesis.verifier import synthesizer
            import tkinter.simpledialog as sd
            meta = sd.askstring("Verify", "meta path:",
                initialvalue="core/ai/rl/synthesis/generated/Guardrails_proof.json")
            code = sd.askstring("Verify", "code path:",
                initialvalue="core/ai/rl/synthesis/generated/Guardrails_synth.py")
            if meta and code:
                res = synthesizer.verify_runtime(meta, code)
                self._set(self.s_out, json.dumps(res, indent=2))
        except Exception as e:
            self._set(self.s_out, f"[!] {e}")
