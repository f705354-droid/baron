# language: Python, file: modules/training_ui.py
import customtkinter as ctk
import json
from core.training.scenarios import SCENARIOS
from core.training.scoring import tracker


class TrainingModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "training"
        self.app = app

    def render(self, parent):
        ctk.CTkLabel(parent, text="TRAINING",
                      font=ctk.CTkFont(size=18, weight="bold"),
                      text_color="#00ff9c").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="scenarios · objectives · scoring · leaderboard",
                      font=ctk.CTkFont(size=11),
                      text_color="#4a5568").pack(pady=(0, 12), padx=24, anchor="w")

        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24)
        for label, fn in [
            ("▸ List scenarios", self._list),
            ("⚡ Start attempt", self._start),
            ("▸ Complete objective", self._complete),
            ("▸ Leaderboard", self._leaderboard),
        ]:
            ctk.CTkButton(row, text=label, width=170, height=34,
                          fg_color="#141a22", hover_color="#1a2332",
                          command=fn).pack(side="left", padx=(0, 4))

        self.out = ctk.CTkTextbox(parent, fg_color="#05080c",
                                    text_color="#7dffb0",
                                    font=ctk.CTkFont(family="Consolas", size=10),
                                    height=500)
        self.out.pack(fill="both", expand=True, padx=24, pady=(12, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _list(self):
        self._out(f"\n=== {len(SCENARIOS)} scenarios ===")
        for name, sc in SCENARIOS.items():
            self._out(f"\n• {sc.name}")
            self._out(f"  difficulty: {sc.difficulty}")
            self._out(f"  category: {sc.category}")
            self._out(f"  objectives: {len(sc.objectives)}")
            self._out(f"  total points: "
                      f"{sum(o['points'] for o in sc.objectives)}")

    def _start(self):
        import tkinter.simpledialog as sd
        name = sd.askstring("Start", "scenario name (or 'web_easy_sqli'):")
        if not name or name not in SCENARIOS:
            self._out("[!] invalid scenario")
            return
        operator = sd.askstring("Start", "operator name:") or "tester"
        sc = SCENARIOS[name]
        total = sum(o["points"] for o in sc.objectives)
        attempt_id = tracker.start_attempt(name, operator, total)
        self._out(f"[+] attempt {attempt_id} started")
        self._out(f"    scenario: {sc.name}")
        self._out(f"    total points: {total}")

    def _complete(self):
        import tkinter.simpledialog as sd
        attempt_id = sd.askinteger("Complete", "attempt ID:")
        if not attempt_id:
            return
        status = tracker.get_attempt_status(attempt_id)
        if "error" in status:
            self._out("[!] attempt not found")
            return

        scenario = SCENARIOS.get(status["scenario"])
        if not scenario:
            return

        # show objectives
        self._out(f"\n=== Objectives for {scenario.name} ===")
        for obj in scenario.objectives:
            done = "✓" if obj["id"] in status["completed_objectives"] else " "
            self._out(f"  [{done}] {obj['id']}. {obj['task']} "
                      f"({obj['points']} pts)")

        obj_id = sd.askinteger("Complete", "objective ID to complete:")
        if not obj_id:
            return
        target_obj = next(
            (o for o in scenario.objectives if o["id"] == obj_id), None)
        if not target_obj:
            return

        result = tracker.complete_objective(
            attempt_id, obj_id, target_obj["points"])
        self._out(f"[+] {result}")

        # finish?
        if len(status["completed_objectives"]) + 1 == len(scenario.objectives):
            final = tracker.finish_attempt(attempt_id)
            self._out(f"[+] Scenario complete: {final}")

    def _leaderboard(self):
        board = tracker.get_leaderboard()
        self._out(f"\n=== Leaderboard ({len(board)}) ===")
        for i, entry in enumerate(board, 1):
            self._out(f"{i}. {entry['operator']:<15} "
                      f"{entry['scenario']:<20} "
                      f"{entry['score']}/{entry['total']} "
                      f"({entry['percentage']}%)")
