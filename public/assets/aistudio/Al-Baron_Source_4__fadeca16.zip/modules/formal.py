# language: Python, file: modules/formal.py
# Formal verification GUI — TLA+ + Coq + Runtime Verification
import customtkinter as ctk
import threading
import json
import subprocess
from core.ai.formal.model_checker import TLAModelChecker
from core.ai.formal.coq_export import CoqExporter


class FormalModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "formal"
        self.app = app
        self.tla = TLAModelChecker()
        self.coq = CoqExporter()

    def render(self, parent):
        ctk.CTkLabel(parent, text="FORMAL VERIFICATION",
                      font=ctk.CTkFont(size=18, weight="bold"),
                      text_color="#00ff9c").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="TLA+ model checking · Coq proofs · runtime invariants · OCaml extraction",
                      font=ctk.CTkFont(size=11),
                      text_color="#4a5568").pack(pady=(0, 12), padx=24, anchor="w")

        actions = ctk.CTkFrame(parent, fg_color="transparent")
        actions.pack(fill="x", padx=24)
        
        # الأزرار الأساسية مع إضافة أزرار بناء وتجربة Coq -> OCaml
        for label, fn in [
            ("▸ Check TLA+ spec", self._check_tla),
            ("▸ Generate Coq spec", self._gen_coq),
            ("▸ Compile Coq", self._compile_coq),
            ("▸ Extract to OCaml", self._extract),
            ("▸ Runtime invariants", self._runtime),
            ("▸ Violation log", self._violations),
            ("▸ Build Coq→OCaml", self._build_runtime),
            ("▸ Test runtime", self._test_runtime),
        ]:
            ctk.CTkButton(actions, text=label, width=170, height=34,
                           fg_color="#141a22", hover_color="#1a2332",
                           font=ctk.CTkFont(size=11),
                           command=fn).pack(side="left", padx=(0, 4), pady=(0, 4))

        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10))
        self.out.pack(fill="both", expand=True, padx=24, pady=(12, 12))

    def _out(self, t):
        self.out.insert("end", t + "\n")
        self.out.see("end")

    def _check_tla(self):
        def run():
            self._out("[*] running TLC...")
            res = self.tla.check()
            self._out(json.dumps(res, indent=2)[:8000])
        threading.Thread(target=run, daemon=True).start()

    def _gen_coq(self):
        path = self.coq.write_spec()
        self._out(f"[+] Coq spec → {path}")

    def _compile_coq(self):
        def run():
            self._out("[*] compiling Coq...")
            res = self.coq.compile()
            self._out(json.dumps(res, indent=2))
        threading.Thread(target=run, daemon=True).start()

    def _extract(self):
        res = self.coq.extract("ocaml")
        self._out(json.dumps(res, indent=2))

    def _runtime(self):
        from core.ai.formal.model_checker import runtime_checker
        sample_state = {
            "iteration": 3, "tokens_used": 500,
            "minutes_elapsed": 5, "state_str": "running",
            "auto_approve": False, "approvals": set(),
            "goal_reached": False,
            "max_tokens": 1000, "max_iterations": 10, "max_minutes": 30,
        }
        sample_action = {"tool": "run_shell", "args": {"cmd": "id"}}
        res = runtime_checker.check_invariants(sample_state, sample_action)
        self._out(json.dumps(res, indent=2))

    def _violations(self):
        from core.ai.formal.model_checker import runtime_checker
        self._out(json.dumps(runtime_checker.violations, indent=2,
                              default=str))

    def _build_runtime(self):
        def run():
            self._out("[*] building Coq runtime...")
            try:
                r = subprocess.run(["bash", "core/ai/formal/coq_runtime/build.sh"],
                                    capture_output=True, text=True, timeout=300)
                self._out(r.stdout[-2000:])
                if r.returncode != 0:
                    self._out(f"[!] stderr: {r.stderr[-1000:]}")
            except Exception as e:
                self._out(f"[!] {e}")
        threading.Thread(target=run, daemon=True).start()

    def _test_runtime(self):
        from core.ai.formal.coq_runtime.wrapper import coq_runtime
        if not coq_runtime.available:
            self._out("[!] runtime not built — run 'Build Coq→OCaml' first")
            return
        test_state = {
            "iteration": 5, "tokens_used": 100, "minutes_elapsed": 10,
            "auto_approve": False, "goal_reached": False, "approvals": set(),
            "max_iterations": 50, "max_tokens": 500_000, "max_minutes": 60,
        }
        for tool in ["run_shell", "get_sessions", "write_file"]:
            res = coq_runtime.check(test_state, {"tool": tool, "args": {}})
            self._out(f"{tool}: {json.dumps(res)}")
