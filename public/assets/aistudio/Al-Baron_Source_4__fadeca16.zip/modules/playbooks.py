# language: Python, file: modules/playbooks.py
# Playbooks — YAML-driven scenarios
import customtkinter as ctk
import threading
import os
import yaml
import time
from datetime import datetime


class PlaybookModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "playbooks"
        self.app = app
        self.playbooks_dir = "playbooks"
        self.current = None

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="PLAYBOOKS",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="YAML-driven attack scenarios · reusable · conditional",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        os.makedirs(self.playbooks_dir, exist_ok=True)
        self._write_templates()

        # ── playbook picker ──
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r = ctk.CTkFrame(cfg, fg_color="transparent")
        r.pack(fill="x", padx=12, pady=8)
        ctk.CTkLabel(r, text="Playbook:",
                      font=ctk.CTkFont(size=11),
                      text_color="#c8d6e5").pack(side="left", padx=(0, 8))

        self.pb_selector = ctk.CTkOptionMenu(
            r, values=self._list_playbooks(), width=250,
            fg_color="#1a2332", button_color="#1a2332",
            command=self._select_playbook
        )
        self.pb_selector.pack(side="left", padx=(0, 8))

        ctk.CTkButton(
            r, text="▸ Reload",
            width=100, height=30,
            fg_color="#141a22", hover_color="#1a2332",
            command=lambda: self.pb_selector.configure(
                values=self._list_playbooks())
        ).pack(side="left", padx=(0, 8))

        # ── target inputs ──
        ctk.CTkLabel(parent, text="Variables:",
                      font=ctk.CTkFont(size=11, weight="bold"),
                      text_color="#c8d6e5").pack(
            pady=(16, 4), padx=24, anchor="w")

        var_frame = ctk.CTkFrame(parent, fg_color="transparent")
        var_frame.pack(fill="x", padx=24)
        self.var_entries = {}
        for var in ["target", "domain", "dc_ip", "lhost"]:
            f = ctk.CTkFrame(var_frame, fg_color="transparent")
            f.pack(side="left", padx=(0, 8))
            ctk.CTkLabel(f, text=f"{var}:",
                          font=ctk.CTkFont(size=10),
                          text_color="#4a5568").pack(side="left")
            entry = ctk.CTkEntry(f, width=140, height=28,
                                   fg_color="#05080c",
                                   border_color="#1a2332",
                                   font=ctk.CTkFont(size=10))
            entry.pack(side="left", padx=(4, 0))
            self.var_entries[var] = entry

        # ── actions ──
        ctk.CTkLabel(parent, text="Controls:",
                      font=ctk.CTkFont(size=12, weight="bold"),
                      text_color="#c8d6e5").pack(
            pady=(16, 4), padx=24, anchor="w")

        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24)
        for label, fn in [
            ("▶ Run playbook", self._run),
            ("▸ Preview", self._preview),
            ("▸ Edit", self._edit),
            ("▸ New", self._new),
            ("▸ Reload", lambda: self.pb_selector.configure(
                values=self._list_playbooks())),
            ("× Delete", self._delete),
        ]:
            ctk.CTkButton(
                row, text=label, width=140, height=32,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).pack(side="left", padx=(0, 4))

        # ── output ──
        ctk.CTkLabel(parent, text="Execution log:",
                      font=ctk.CTkFont(size=12, weight="bold"),
                      text_color="#c8d6e5").pack(
            pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=420
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _list_playbooks(self):
        if not os.path.isdir(self.playbooks_dir):
            return ["(none)"]
        pbs = [f[:-5] for f in os.listdir(self.playbooks_dir)
                if f.endswith(".yaml")]
        return pbs or ["(none)"]

    def _write_templates(self):
        """يكتب 3 playbooks جاهزة للتجربة"""
        templates = {
            "quick_recon": """name: Quick Recon
description: Fast network discovery + service enum
steps:
  - tool: recon
    action: scan
    params:
      target: "{{target}}"
      mode: quick

  - tool: recon
    action: analyze
    when: findings.has_ports
  
  - tool: mitre_report
    action: generate
""",
            "web_pentest": """name: Web Pentest
description: Web app assessment on target URL
steps:
  - tool: recon
    action: subdomain
    params:
      target: "{{domain}}"
  
  - tool: recon
    action: scan
    params:
      target: "{{target}}"
      mode: vuln
  
  - tool: mitre_report
    action: generate
""",
            "full_ad_takeover": """name: Full AD Takeover
description: Complete AD compromise chain
steps:
  - tool: ad
    action: enum_domain
    params:
      domain: "{{domain}}"
      dc_ip: "{{dc_ip}}"
  
  - tool: ad
    action: kerberoast
    when: findings.has_spn
  
  - tool: adcs
    action: esc8
    when: findings.has_adcs
  
  - tool: post_pipeline
    action: full
    params:
      session: "{{session}}"
  
  - tool: mitre_report
    action: generate
""",
        }
        for name, content in templates.items():
            path = os.path.join(self.playbooks_dir, f"{name}.yaml")
            if not os.path.exists(path):
                with open(path, "w") as f:
                    f.write(content)

    def _select_playbook(self, name):
        self.current = name
        self._preview()

    def _preview(self):
        name = self.pb_selector.get()
        path = os.path.join(self.playbooks_dir, f"{name}.yaml")
        if not os.path.exists(path):
            self._out(f"[!] {path} not found")
            return
        self.out.delete("1.0", "end")
        with open(path) as f:
            self._out(f"=== {name} ===")
            self._out(f.read())

    def _edit(self):
        name = self.pb_selector.get()
        path = os.path.join(self.playbooks_dir, f"{name}.yaml")
        if os.path.exists(path):
            os.system(f"x-terminal-emulator -e 'nano {path}' &")

    def _new(self):
        import tkinter.simpledialog as sd
        name = sd.askstring("New Playbook", "name:")
        if not name:
            return
        path = os.path.join(self.playbooks_dir, f"{name}.yaml")
        with open(path, "w") as f:
            f.write("""name: """ + name + """
description: 
steps:
  - tool: recon
    action: scan
    params:
      target: "{{target}}"
""")
        self.pb_selector.configure(values=self._list_playbooks())
        self._out(f"[+] created {path}")

    def _delete(self):
        name = self.pb_selector.get()
        path = os.path.join(self.playbooks_dir, f"{name}.yaml")
        if os.path.exists(path):
            import tkinter.messagebox as mb
            if mb.askyesno("Delete", f"Delete {name}?"):
                os.remove(path)
                self.pb_selector.configure(values=self._list_playbooks())

    def _run(self):
        name = self.pb_selector.get()
        path = os.path.join(self.playbooks_dir, f"{name}.yaml")
        if not os.path.exists(path):
            self._out(f"[!] {path} not found")
            return
        with open(path) as f:
            pb = yaml.safe_load(f)

        # substitute variables
        vars = {k: e.get() for k, e in self.var_entries.items()}
        for step in pb.get("steps", []):
            params = step.get("params", {})
            for k, v in params.items():
                if isinstance(v, str) and "{{" in v:
                    for var, val in vars.items():
                        v = v.replace("{{" + var + "}}", val or f"<{var}>")
                    params[k] = v

        self.out.delete("1.0", "end")
        self._out(f"=== RUNNING: {pb.get('name', name)} ===")
        self._out(f"variables: {vars}\n")

        def run():
            for i, step in enumerate(pb.get("steps", []), 1):
                tool = step.get("tool")
                action = step.get("action")
                params = step.get("params", {})
                condition = step.get("when", "")

                self._out(f"[{i}/{len(pb['steps'])}] {tool}.{action}")

                if condition:
                    self._out(f"  when: {condition}")
                    # simple evaluation
                    should_run = True
                    if "findings." in condition:
                        should_run = True  # placeholder
                    if not should_run:
                        self._out("  skipped (condition false)")
                        continue

                self._out(f"  params: {params}")

                try:
                    self._execute_step(tool, action, params)
                except Exception as e:
                    self._out(f"  [!] {e}")

            self._out("\n[+] Playbook complete")
        threading.Thread(target=run, daemon=True).start()

    def _execute_step(self, tool, action, params):
        """ينفذ خطوة عبر module موجود"""
        if not self.app:
            return
        module = self.app.modules.get(tool)
        if not module:
            self._out(f"  [!] module '{tool}' not loaded")
            return

        # dispatch to module's internal methods
        method = getattr(module, f"_{action}", None)
        if method:
            try:
                method(**params)
                self._out(f"  ✓ {tool}.{action}()")
            except Exception as e:
                self._out(f"  [!] {tool}.{action}: {e}")
        else:
            self._out(f"  [!] {tool}.{action}() not found")
