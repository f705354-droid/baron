# language: Python, file: modules/threat_hunt.py
import customtkinter as ctk
import json
from core.hunting.hunter import hunter


class ThreatHuntModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "threat_hunt"
        self.app = app
        self.hunter = hunter

    def render(self, parent):
        ctk.CTkLabel(parent, text="THREAT HUNT",
                      font=ctk.CTkFont(size=18, weight="bold"),
                      text_color="#00ff9c").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="proactive hunting · hypotheses · TTP detection",
                      font=ctk.CTkFont(size=11),
                      text_color="#4a5568").pack(pady=(0, 12), padx=24, anchor="w")

        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24)
        for label, fn in [
            ("⚡ Run hunt (once)", self._run_once),
            ("⚡ Start continuous", lambda: self.hunter.start()),
            ("■ Stop", lambda: self.hunter.stop()),
            ("▸ Show hypotheses", self._show_hypotheses),
            ("▸ Findings", self._show_findings),
            ("▤ Export", self._export),
        ]:
            ctk.CTkButton(row, text=label, width=170, height=34,
                          fg_color="#141a22", hover_color="#1a2332",
                          command=fn).pack(side="left", padx=(0, 4))

        self.out = ctk.CTkTextbox(parent, fg_color="#05080c",
                                    text_color="#7dffb0",
                                    font=ctk.CTkFont(family="Consolas", size=10),
                                    height=500)
        self.out.pack(fill="both", expand=True, padx=24, pady=(12, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _run_once(self):
        self._out("[*] running hypotheses...")
        results = self.hunter.run_all()
        if not results:
            self._out("[+] no findings")
            return
        for r in results:
            self._out(f"\n[{r['technique']}] {r['hypothesis']}")
            self._out(f"  {r['description']}")
            for m in r["matches"][:5]:
                self._out(f"    • {m}")

    def _show_hypotheses(self):
        self._out(f"\n=== {len(self.hunter.hypotheses)} hypotheses ===")
        for h in self.hunter.hypotheses:
            self._out(f"  • [{h.technique}] {h.name}")
            self._out(f"    {h.description}")

    def _show_findings(self):
        findings = self.hunter.get_findings()
        self._out(f"\n=== {len(findings)} findings ===")
        for f in findings[-20:]:
            self._out(f"  [{f['technique']}] {f['hypothesis']} "
                      f"({len(f['matches'])} matches)")

    def _export(self):
        import tkinter.filedialog as fd
        path = fd.asksaveasfilename(
            defaultextension=".json",
            initialfile="hunt_findings.json")
        if path:
            with open(path, "w") as f:
                json.dump(self.hunter.get_findings(), f,
                          indent=2, default=str)
            self._out(f"[+] exported → {path}")
