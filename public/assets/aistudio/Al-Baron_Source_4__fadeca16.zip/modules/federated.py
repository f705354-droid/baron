# language: Python, file: modules/federated.py
# Federated learning GUI
import customtkinter as ctk
import threading
import json
from core.ai.federated.client import FederatedClient


class FederatedModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "federated"
        self.app = app
        self.client = None

    def render(self, parent):
        ctk.CTkLabel(parent, text="FEDERATED LEARNING",
                      font=ctk.CTkFont(size=18, weight="bold"),
                      text_color="#00ff9c").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="cross-tenant LoRA · secure aggregation · DP",
                      font=ctk.CTkFont(size=11),
                      text_color="#4a5568").pack(pady=(0, 12), padx=24, anchor="w")

        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r = ctk.CTkFrame(cfg, fg_color="transparent")
        r.pack(fill="x", padx=12, pady=8)
        self.tid = ctk.CTkEntry(r, placeholder_text="tenant id", width=200,
                                  height=32, fg_color="#05080c",
                                  border_color="#1a2332")
        self.tid.pack(side="left", padx=(0, 6))
        self.url = ctk.CTkEntry(r, placeholder_text="server url", width=240,
                                  height=32, fg_color="#05080c",
                                  border_color="#1a2332")
        self.url.insert(0, "http://teamserver:8000")
        self.url.pack(side="left", padx=(0, 6))
        self.key = ctk.CTkEntry(r, placeholder_text="api key", width=200,
                                  height=32, show="*", fg_color="#05080c",
                                  border_color="#1a2332")
        self.key.pack(side="left")

        actions = ctk.CTkFrame(parent, fg_color="transparent")
        actions.pack(fill="x", padx=24, pady=12)
        for label, fn in [
            ("▸ Train local LoRA", self._train),
            ("▸ Start round (server)", self._start),
            ("▸ Join + participate", self._join),
            ("▸ Fetch global", self._fetch),
            ("▸ List rounds", self._list),
        ]:
            ctk.CTkButton(actions, text=label, width=180, height=32,
                           fg_color="#141a22", hover_color="#1a2332",
                           font=ctk.CTkFont(size=11),
                           command=fn).pack(side="left", padx=(0, 4))

        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10))
        self.out.pack(fill="both", expand=True, padx=24, pady=(12, 12))

    def _out(self, t):
        self.out.insert("end", t + "\n")
        self.out.see("end")

    def _client(self):
        if not self.client:
            self.client = FederatedClient(
                self.tid.get(), self.url.get(), self.key.get())
        return self.client

    def _train(self):
        def run():
            self._out("[*] training local LoRA...")
            res = self._client().train_local(epochs=1, lora_r=8)
            self._out(json.dumps(res, indent=2))
        threading.Thread(target=run, daemon=True).start()

    def _start(self):
        import httpx
        def run():
            try:
                r = httpx.post(
                    f"{self.url.get()}/federated/start",
                    json={"tenant_id": self.tid.get(),
                          "base_model": "unsloth/llama-3.1-8b-instruct"},
                    headers={"Authorization": f"Bearer {self.key.get()}"},
                    timeout=30)
                self._out(json.dumps(r.json(), indent=2))
            except Exception as e:
                self._out(f"[!] {e}")
        threading.Thread(target=run, daemon=True).start()

    def _join(self):
        def run():
            c = self._client()
            # join (يحتاج round_id من server)
            self._out("join + submit flow: use CLI orchestration")
        threading.Thread(target=run, daemon=True).start()

    def _fetch(self):
        self._out("[*] fetch global — provide round_id")

    def _list(self):
        self._out("[*] list rounds — requires server-side call")
