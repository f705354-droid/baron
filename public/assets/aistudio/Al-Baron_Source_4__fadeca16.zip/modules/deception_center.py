# language: Python, file: modules/deception_center.py
import customtkinter as ctk
from core.deception.honeypot import (
    honeypot_manager, SSHHoneypot, FTPHoneypot, HTTPHoneypot)
from core.deception.canary import canary_tokens, FileCanary


class DeceptionCenterModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "deception_center"
        self.app = app

    def render(self, parent):
        ctk.CTkLabel(parent, text="DECEPTION",
                      font=ctk.CTkFont(size=18, weight="bold"),
                      text_color="#00ff9c").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="honeypots · canary tokens · decoys",
                      font=ctk.CTkFont(size=11),
                      text_color="#4a5568").pack(pady=(0, 12), padx=24, anchor="w")

        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24)
        for label, fn in [
            ("⚡ Start honeypots", self._start_pots),
            ("■ Stop honeypots", self._stop_pots),
            ("▸ Create canary", self._create_canary),
            ("⚡ Start canary server", self._start_canary),
            ("▸ List canaries", self._list_canaries),
            ("▸ View events", self._view_events),
        ]:
            ctk.CTkButton(row, text=label, width=170, height=34,
                          fg_color="#141a22", hover_color="#1a2332",
                          command=fn).pack(side="left", padx=(0, 4))

        self.out = ctk.CTkTextbox(parent, fg_color="#05080c",
                                    text_color="#7dffb0",
                                    font=ctk.CTkFont(family="Consolas", size=10),
                                    height=500)
        self.out.pack(fill="both", expand=True, padx=24, pady=(12, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _start_pots(self):
        # add standard honeypots
        honeypot_manager.add_pot(SSHHoneypot(self.log, 2222))
        honeypot_manager.add_pot(FTPHoneypot(self.log, 2121))
        honeypot_manager.add_pot(HTTPHoneypot(self.log, 8080))
        started = honeypot_manager.start_all()
        self._out(f"[+] honeypots started: {started}")
        self._out("    (needs sudo for ports < 1024)")

    def _stop_pots(self):
        honeypot_manager.stop_all()
        self._out("[+] honeypots stopped")

    def _create_canary(self):
        import tkinter.simpledialog as sd
        name = sd.askstring("Canary", "name:")
        if not name:
            return
        token = canary_tokens.create_token(name)
        url = canary_tokens.generate_tracking_url(token)
        self._out(f"[+] Canary '{name}' created:")
        self._out(f"    token: {token}")
        self._out(f"    URL: {url}")

    def _start_canary(self):
        try:
            canary_tokens.start()
            self._out(f"[+] canary server running on :{canary_tokens.port}")
        except Exception as e:
            self._out(f"[!] {e}")

    def _list_canaries(self):
        tokens = canary_tokens.list_tokens()
        self._out(f"\n=== {len(tokens)} canaries ===")
        for t in tokens:
            self._out(f"  {t['name']} (token: {t['token']}) "
                      f"hits: {t['hits']}")

    def _view_events(self):
        self._out(f"\n=== Honeypot events: {len(honeypot_manager.events)} ===")
        for e in honeypot_manager.events[-20:]:
            self._out(f"  [{e.get('time', '')[:19]}] "
                      f"{e.get('service')}:{e.get('port')} ← "
                      f"{e.get('source_ip')}")
        self._out(f"\n=== Canary hits: {len(canary_tokens.hits)} ===")
        for h in canary_tokens.hits[-20:]:
            self._out(f"  [{h.get('time', '')[:19]}] "
                      f"{h['name']} ← {h['source_ip']}")
