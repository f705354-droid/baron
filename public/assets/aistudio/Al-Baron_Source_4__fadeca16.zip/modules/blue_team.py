# language: Python, file: modules/blue_team.py
# Al-Baron Blue Team Module — detection & defense
import customtkinter as ctk
import threading
import os
import re
from core.executor import ToolExecutor

class BlueTeamModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "blue_team"
        self.executor = ToolExecutor(log_queue)
        self._parent = None
        self.out = None

    def render(self, parent):
        self._parent = parent
        ctk.CTkLabel(parent, text="BLUE TEAM DASHBOARD", font=ctk.CTkFont(size=18, weight="bold"), text_color="#00bfff").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="detection · analysis · incident response", font=ctk.CTkFont(size=11), text_color="#8a8a8a").pack(pady=(0, 12), padx=24, anchor="w")

        # Actions
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24, pady=12)
        for label, fn in [
            ("🔍 Analyze Network Logs", self._analyze_logs),
            ("🛡 Check System Integrity", self._check_integrity),
            ("⚠ Detect Suspicious Processes", self._detect_procs),
            ("🔒 Check Firewall Rules", self._check_firewall),
        ]:
            ctk.CTkButton(row, text=label, width=200, height=34, fg_color="#1a3a4a", hover_color="#2a5a6a", text_color="#00bfff", command=fn).pack(side="left", padx=(0, 4))

        # Output
        ctk.CTkLabel(parent, text="Detection Results:", font=ctk.CTkFont(size=12, weight="bold"), text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(parent, fg_color="#05080c", text_color="#00bfff", font=ctk.CTkFont(family="Consolas", size=10), height=450)
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 24))

    def _analyze_logs(self):
        self._safe_out("[*] Analyzing system logs for attacks...")
        log_paths = ["/var/log/auth.log", "/var/log/syslog", "/var/log/messages"]
        
        def run():
            for path in log_paths:
                if os.path.exists(path):
                    self._safe_out(f"[*] Reading {path}...")
                    try:
                        with open(path, 'r', errors='ignore') as f:
                            lines = f.readlines()[-100:] # آخر 100 سطر
                            for line in lines:
                                if any(kw in line.lower() for kw in ["failed password", "invalid user", "authentication failure", "unauthorized"]):
                                    self._safe_out(f"[!] SUSPICIOUS: {line.strip()}")
                    except Exception as e:
                        self._safe_out(f"[!] Error reading {path}: {e}")
        threading.Thread(target=run, daemon=True).start()

    def _check_integrity(self):
        self._safe_out("[*] Checking critical system file integrity...")
        def run():
            # فحص ملفات حساسة
            critical_files = ["/etc/passwd", "/etc/shadow", "/etc/sudoers", "/etc/ssh/sshd_config"]
            for f in critical_files:
                if os.path.exists(f):
                    stat = os.stat(f)
                    self._safe_out(f"[+] {f}: Mode={oct(stat.st_mode)[-3:]}, Size={stat.st_size}")
                    if f == "/etc/passwd" and stat.st_mode & 0o002:
                        self._safe_out(f"[!!!] WARNING: {f} is WORLD WRITABLE!")
        threading.Thread(target=run, daemon=True).start()

    def _detect_procs(self):
        self._safe_out("[*] Looking for suspicious processes...")
        def run():
            try:
                out = subprocess.run(["ps", "aux"], capture_output=True, text=True).stdout
                keywords = ["nc", "netcat", "ncat", "socat", "python -m http", "bash -i", "sh -i", "meterpreter"]
                for line in out.splitlines():
                    if any(kw in line.lower() for kw in keywords):
                        self._safe_out(f"[!] SUSPICIOUS: {line.strip()[:100]}")
            except Exception as e:
                self._safe_out(f"[!] Error: {e}")
        threading.Thread(target=run, daemon=True).start()

    def _check_firewall(self):
        self._safe_out("[*] Checking firewall status (iptables)...")
        def run():
            try:
                out = subprocess.run(["sudo", "iptables", "-L", "-n"], capture_output=True, text=True).stdout
                self._safe_out(out[:2000])
            except Exception:
                self._safe_out("[!] iptables requires sudo. (Run 'sudo python3 main.py').")
        threading.Thread(target=run, daemon=True).start()

    def _safe_out(self, text):
        if not self._parent: return
        def _u():
            if self.out and self.out.winfo_exists():
                self.out.insert("end", text + "\n")
                self.out.see("end")
        self._parent.after(0, _u)
