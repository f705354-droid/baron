# language: Python, file: modules/caldera.py
# CALDERA GUI — adversary emulation control
import customtkinter as ctk
import threading
import asyncio
import os
import json
from teamserver.adapters.caldera import CalderaAdapter


class CalderaModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "caldera"
        self.adapter = CalderaAdapter()

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="MITRE CALDERA",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="adversary emulation · automated attack chains · MITRE ATT&CK",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r1 = ctk.CTkFrame(cfg, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=8)
        self.url = ctk.CTkEntry(r1, placeholder_text="CALDERA url",
                                 width=260, height=32,
                                 fg_color="#05080c", border_color="#1a2332")
        self.url.insert(0, os.getenv("CALDERA_URL", "http://caldera:8888"))
        self.url.pack(side="left", padx=(0, 6))
        self.key = ctk.CTkEntry(r1, placeholder_text="API key (red)",
                                 width=260, height=32, show="*",
                                 fg_color="#05080c", border_color="#1a2332")
        self.key.pack(side="left", padx=(0, 6))
        ctk.CTkButton(r1, text="▸ Save", width=90, height=32,
                      fg_color="#0d2818", hover_color="#1a4a2e",
                      text_color="#00ff9c", command=self._save).pack(side="left")

        # ---- actions ----
        ctk.CTkLabel(parent, text="Operations:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")

        grid = ctk.CTkFrame(parent, fg_color="transparent")
        grid.pack(fill="x", padx=24)
        actions = [
            ("▸ List agents", self._list_agents),
            ("▸ List abilities", self._list_abilities),
            ("▸ List adversaries", self._list_adversaries),
            ("▸ List operations", self._list_ops),
            ("☣ Start operation", self._start_op),
            ("☣ Run 'Discovery'", self._run_discovery),
            ("☣ Run 'Exfil'", self._run_exfil),
            ("☣ Run 'Persistence'", self._run_persistence),
            ("▸ Operation report", self._op_report),
            ("☣ Import custom adversary", self._import_adv),
            ("▸ Sync agents → C2 UI", self._sync_c2ui),
            ("▸ Sync findings → Report", self._sync_report),
        ]
        for i, (label, fn) in enumerate(actions):
            ctk.CTkButton(
                grid, text=label, width=220, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).grid(row=i // 4, column=i % 4, padx=4, pady=4)

        ctk.CTkLabel(parent, text="Output:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=280
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _save(self):
        os.environ["CALDERA_URL"] = self.url.get().strip()
        os.environ["CALDERA_API_KEY"] = self.key.get().strip()
        self.adapter = CalderaAdapter()
        self._out("[+] saved CALDERA config")

    def _run_async(self, coro_fn, label):
        def run():
            try:
                result = asyncio.run(coro_fn())
                if isinstance(result, (dict, list)):
                    self._out(f"\n=== {label} ===\n" +
                              json.dumps(result, indent=2)[:8000])
                else:
                    self._out(f"\n=== {label} ===\n{result}")
            except Exception as e:
                self._out(f"[!] {e}")
        threading.Thread(target=run, daemon=True).start()

    def _list_agents(self):
        self._run_async(self.adapter.list_agents, "agents")

    def _list_abilities(self):
        self._run_async(self.adapter.list_abilities, "abilities")

    def _list_adversaries(self):
        self._run_async(self.adapter.list_adversaries, "adversaries")

    def _list_ops(self):
        self._run_async(self.adapter.list_operations, "operations")

    def _start_op(self):
        import tkinter.simpledialog as sd
        name = sd.askstring("Operation", "Operation name:")
        adv_id = sd.askstring("Operation", "Adversary ID:")
        if name and adv_id:
            self._run_async(
                lambda: self.adapter.start_operation(name, adv_id),
                "start operation")

    def _run_discovery(self):
        self._find_and_run("discovery")

    def _run_exfil(self):
        self._find_and_run("exfil")

    def _run_persistence(self):
        self._find_and_run("persistence")

    def _find_and_run(self, keyword):
        async def fn():
            advs = await self.adapter.list_adversaries()
            for a in advs:
                if keyword in a.get("name", "").lower():
                    return await self.adapter.start_operation(
                        f"Auto {keyword}", a["adversary_id"])
            return f"no adversary matching '{keyword}'"
        self._run_async(fn, f"start {keyword}")

    def _op_report(self):
        import tkinter.simpledialog as sd
        op_id = sd.askstring("Report", "Operation ID:")
        if op_id:
            self._run_async(
                lambda: self.adapter.operation_report(op_id),
                "report")

    def _import_adv(self):
        import tkinter.filedialog as fd
        path = fd.askopenfilename(filetypes=[("YAML", "*.yml *.yaml")])
        if path:
            self._out(f"[+] to import, use CALDERA UI: "
                      f"Adversaries → Import → {path}")

    def _sync_c2ui(self):
        """pull CALDERA agents and inject them into C2 UI sessions list"""
        async def fn():
            agents = await self.adapter.list_sessions()
            return {"synced": len(agents), "agents": agents}
        self._run_async(fn, "sync")

    def _sync_report(self):
        self._out("[+] CALDERA findings will be merged in Reporting module "
                  "via get_findings() hook")
