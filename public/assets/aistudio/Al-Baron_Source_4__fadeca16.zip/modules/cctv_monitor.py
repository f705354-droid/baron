# language: Python, file: modules/cctv_monitor.py
# Al-Baron CCTV Monitoring — real-time dashboard
import customtkinter as ctk
import threading
import time
import json
import socket
from datetime import datetime
from collections import deque

# ═══════════════════════════════════════════════════════════════════
# Monitor Engine (داخل الملف لضمان عمله بدون استيراد خارجي)
# ═══════════════════════════════════════════════════════════════════
class CCTVMonitor:
    def __init__(self, log_queue=None, check_interval=10):
        self.log = log_queue
        self.cameras = {}
        self.check_interval = check_interval
        self.running = False
        self.thread = None
        self.on_event = None

    def _out(self, text):
        if self.log: self.log.put(f"[monitor] {text}")

    def add_camera(self, ip, name="", vendor=""):
        self.cameras[ip] = {"ip": ip, "name": name or ip, "vendor": vendor, "status": "unknown", "last_check": None, "checks": 0, "failures": 0, "uptime_pct": 100.0}
        self._out(f"added {ip}")

    def start(self):
        if self.running: return
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()
        self._out(f"monitoring {len(self.cameras)} cameras")

    def stop(self):
        self.running = False

    def _loop(self):
        while self.running:
            for ip, cam in list(self.cameras.items()):
                self._check(ip, cam)
            for _ in range(self.check_interval):
                if not self.running: return
                time.sleep(1)

    def _check(self, ip, cam):
        cam["checks"] += 1
        cam["last_check"] = datetime.now().strftime("%H:%M:%S")
        ports = [80, 554, 8080, 443, 8000]
        any_open = False
        for port in ports:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                if sock.connect_ex((ip, port)) == 0:
                    any_open = True
                sock.close()
            except: pass

        prev = cam["status"]
        if any_open:
            cam["status"] = "online"
            if prev != "online": self._emit({"type": "online", "ip": ip, "name": cam["name"]})
        else:
            cam["status"] = "offline"
            cam["failures"] += 1
            if prev != "offline": self._emit({"type": "offline", "ip": ip, "name": cam["name"]})
        cam["uptime_pct"] = round((1 - cam["failures"] / max(cam["checks"], 1)) * 100, 1)

    def _emit(self, event):
        if self.on_event:
            try: self.on_event(event)
            except: pass

    def get_status(self):
        total = len(self.cameras)
        online = sum(1 for c in self.cameras.values() if c["status"] == "online")
        offline = sum(1 for c in self.cameras.values() if c["status"] == "offline")
        return {"total": total, "online": online, "offline": offline, "unknown": total - online - offline, "cameras": self.cameras}

# ═══════════════════════════════════════════════════════════════════
# Module UI (متصل بالمحرك أعلاه)
# ═══════════════════════════════════════════════════════════════════
class CCTVMonitorModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "cctv_monitor"
        self.app = app
        self.monitor = CCTVMonitor(log_queue)
        self.monitor.on_event = self._on_event
        self.refresh_timer = None
        self._parent = None
        self.out = None
        self.table = None
        self.summary_label = None

    def render(self, parent):
        self._parent = parent

        ctk.CTkLabel(parent, text="CCTV MONITORING", font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="real-time dashboard · status · uptime · alerts", font=ctk.CTkFont(size=11), text_color="#4a5568").pack(pady=(0, 12), padx=24, anchor="w")

        # Add camera
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r = ctk.CTkFrame(cfg, fg_color="transparent")
        r.pack(fill="x", padx=12, pady=8)

        ctk.CTkLabel(r, text="Camera IP:", font=ctk.CTkFont(size=11), text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.ip_entry = ctk.CTkEntry(r, placeholder_text="192.168.1.100", width=180, height=30, fg_color="#05080c", border_color="#1a2332")
        self.ip_entry.pack(side="left", padx=(0, 6))

        ctk.CTkLabel(r, text="Name:", font=ctk.CTkFont(size=11), text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.name_entry = ctk.CTkEntry(r, placeholder_text="Front door", width=160, height=30, fg_color="#05080c", border_color="#1a2332")
        self.name_entry.pack(side="left", padx=(0, 6))

        ctk.CTkLabel(r, text="Vendor:", font=ctk.CTkFont(size=11), text_color="#c8d6e5").pack(side="left", padx=(0, 4))
        self.vendor_entry = ctk.CTkEntry(r, placeholder_text="Hikvision", width=120, height=30, fg_color="#05080c", border_color="#1a2332")
        self.vendor_entry.pack(side="left", padx=(0, 6))

        ctk.CTkButton(r, text="+ Add", width=90, height=30, fg_color="#0d2818", hover_color="#1a4a2e", text_color="#00ff9c", command=self._add).pack(side="left")

        # Controls
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24, pady=12)
        for label, fn in [
            ("▶ Start Monitoring", self._start),
            ("■ Stop", self._stop),
            ("▸ Refresh", self._refresh),
            ("+ Add sample cameras", self._add_samples),
            ("▸ Export status", self._export),
        ]:
            ctk.CTkButton(row, text=label, width=180, height=34, fg_color="#141a22", hover_color="#1a2332", font=ctk.CTkFont(size=11), command=fn).pack(side="left", padx=(0, 4))

        # Status summary
        self.summary_frame = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6, height=80)
        self.summary_frame.pack(fill="x", padx=24, pady=(0, 8))
        self.summary_frame.pack_propagate(False)

        self.summary_label = ctk.CTkLabel(self.summary_frame, text="Total: 0   |   Online: 0   |   Offline: 0", font=ctk.CTkFont(size=14, weight="bold"), text_color="#00ff9c")
        self.summary_label.pack(pady=20)

        # Table
        ctk.CTkLabel(parent, text="Cameras:", font=ctk.CTkFont(size=12, weight="bold"), text_color="#c8d6e5").pack(pady=(8, 4), padx=24, anchor="w")
        from tkinter import ttk
        self.table = ttk.Treeview(parent, columns=("ip", "name", "vendor", "status", "uptime", "last"), show="headings", height=8)
        for col, txt, w in [("ip", "IP", 130), ("name", "Name", 150), ("vendor", "Vendor", 120), ("status", "Status", 100), ("uptime", "Uptime %", 90), ("last", "Last Check", 180)]:
            self.table.heading(col, text=txt)
            self.table.column(col, width=w)
        self.table.pack(fill="x", padx=24, pady=(0, 8))

        self.table.tag_configure("online", foreground="#00ff9c")
        self.table.tag_configure("offline", foreground="#ff6b6b")
        self.table.tag_configure("unknown", foreground="#6a7a8a")

        # Events log
        ctk.CTkLabel(parent, text="Events:", font=ctk.CTkFont(size=12, weight="bold"), text_color="#c8d6e5").pack(pady=(8, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(parent, fg_color="#05080c", text_color="#7dffb0", font=ctk.CTkFont(family="Consolas", size=10), height=180)
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _add(self):
        ip = self.ip_entry.get().strip()
        if not ip: return
        self.monitor.add_camera(ip, self.name_entry.get().strip(), self.vendor_entry.get().strip())
        self.ip_entry.delete(0, "end")
        self.name_entry.delete(0, "end")
        self.vendor_entry.delete(0, "end")
        self._refresh()

    def _add_samples(self):
        for ip, name, vendor in [("192.168.1.100", "Front Door", "Hikvision"), ("192.168.1.101", "Back Yard", "Dahua")]:
            self.monitor.add_camera(ip, name, vendor)
        self._refresh()

    def _start(self):
        self.monitor.start()
        self._safe_out("[+] monitoring started")
        self._start_refresh_loop()

    def _stop(self):
        self.monitor.stop()
        self._safe_out("[■] monitoring stopped")

    def _start_refresh_loop(self):
        if self.refresh_timer and self._parent:
            self._parent.after_cancel(self.refresh_timer)
        def tick():
            self._refresh()
            if self.monitor.running and self._parent:
                self.refresh_timer = self._parent.after(2000, tick)
        tick()

    def _refresh(self):
        if not self.table or not self.table.winfo_exists(): return
        status = self.monitor.get_status()
        if self.summary_label and self.summary_label.winfo_exists():
            self.summary_label.configure(text=f"Total: {status['total']}   |   Online: {status['online']}   |   Offline: {status['offline']}")
        for iid in self.table.get_children(): self.table.delete(iid)
        for ip, cam in status["cameras"].items():
            self.table.insert("", "end", values=(ip, cam["name"], cam["vendor"], cam["status"].upper(), f"{cam['uptime_pct']}%", cam["last_check"] or "never"), tags=(cam["status"],))

    def _export(self):
        import tkinter.filedialog as fd
        path = fd.asksaveasfilename(defaultextension=".json", initialfile="cctv_monitor.json")
        if not path: return
        with open(path, "w") as f:
            json.dump(self.monitor.get_status(), f, indent=2, default=str)
        self._safe_out(f"[+] exported → {path}")

    def _on_event(self, ev):
        def update():
            self._safe_out(f"[{datetime.now().strftime('%H:%M:%S')}] {ev['type'].upper()}: {ev['ip']} ({ev['name']})")
            self._refresh()
        if self._parent: self._parent.after(0, update)

    def _safe_out(self, text):
        if not self._parent: return
        def _u():
            if self.out and self.out.winfo_exists():
                self.out.insert("end", text + "\n")
                self.out.see("end")
        self._parent.after(0, _u)
