# language: Python, file: modules/sso_admin.py
# SSO admin — configure Okta, Azure AD, Google providers
import customtkinter as ctk
import threading
import asyncio
import os
import json
import asyncpg
from teamserver.sso import SSOManager


class SSOAdminModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "sso_admin"
        self.manager = None

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="SSO PROVIDERS",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="OIDC · SAML · Okta · Azure AD · Google · SCIM",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        r1 = ctk.CTkFrame(cfg, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=8)
        self.tid = ctk.CTkEntry(r1, placeholder_text="tenant id",
                                 width=340, height=32,
                                 fg_color="#05080c", border_color="#1a2332")
        self.tid.pack(side="left", padx=(0, 6))
        ctk.CTkButton(r1, text="▸ List", width=90, height=32,
                      fg_color="#0d2818", hover_color="#1a4a2e",
                      text_color="#00ff9c",
                      command=self._list).pack(side="left")

        # ---- quick presets ----
        ctk.CTkLabel(parent, text="Quick add provider:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        grid = ctk.CTkFrame(parent, fg_color="transparent")
        grid.pack(fill="x", padx=24)
        for i, label in enumerate([
            "Okta (OIDC)", "Okta (SAML)",
            "Azure AD (OIDC)", "Azure AD (SAML)",
            "Google Workspace", "Keycloak", "Auth0", "Onelogin",
            "Ping Identity", "JumpCloud",
        ]):
            ctk.CTkButton(
                grid, text=label, width=180, height=32,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11),
                command=lambda l=label: self._preset(l)
            ).grid(row=i // 4, column=i % 4, padx=4, pady=4)

        ctk.CTkLabel(parent, text="Providers:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10)
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    async def _mgr(self):
        if not self.manager:
            dsn = os.getenv("AL-BARON_DSN",
                            "postgresql://shadow:shadow@postgres:5432/albaron")
            pool = await asyncpg.create_pool(dsn, min_size=1, max_size=4)
            self.manager = SSOManager(pool)
        return self.manager

    def _run_async(self, coro_fn, label):
        def run():
            try:
                result = asyncio.run(coro_fn())
                if isinstance(result, (dict, list)):
                    self._out(f"\n=== {label} ===\n" +
                              json.dumps(result, indent=2, default=str)[:8000])
                else:
                    self._out(f"\n=== {label} ===\n{result}")
            except Exception as e:
                self._out(f"[!] {e}")
        threading.Thread(target=run, daemon=True).start()

    def _list(self):
        tid = self.tid.get().strip()
        if not tid:
            return
        async def fn():
            m = await self._mgr()
            return await m.list_providers(tid)
        self._run_async(fn, "providers")

    def _preset(self, label):
        tid = self.tid.get().strip()
        if not tid:
            self._out("[!] enter tenant id")
            return
        # open dialog with pre-filled fields
        import tkinter.simpledialog as sd
        if "OIDC" in label:
            client_id = sd.askstring("OIDC", "Client ID:")
            client_secret = sd.askstring("OIDC", "Client Secret:", show="*")
            issuer = sd.askstring("OIDC", "Issuer URL:",
                                    initialvalue=self._default_issuer(label))
            if not client_id or not issuer:
                return
            cfg = {
                "authorize_url": f"{issuer}/v1/authorize" if "okta" in label.lower()
                                  else f"{issuer}/oauth2/v2.0/authorize",
                "token_url": f"{issuer}/v1/token" if "okta" in label.lower()
                              else f"{issuer}/oauth2/v2.0/token",
                "userinfo_url": f"{issuer}/v1/userinfo" if "okta" in label.lower()
                                 else "https://graph.microsoft.com/oidc/userinfo",
                "client_id": client_id,
                "client_secret": client_secret,
                "scope": "openid email profile groups",
                "default_role": "operator",
            }
            async def fn():
                m = await self._mgr()
                return await m.add_provider(tid, "oidc", label, cfg)
            self._run_async(fn, "add oidc")
        else:
            self._out("[!] SAML presets need IdP metadata — upload in UI")

    def _default_issuer(self, label):
        if "okta" in label.lower():
            return "https://your-tenant.okta.com/oauth2/default"
        if "azure" in label.lower():
            return "https://login.microsoftonline.com/your-tenant-id"
        if "google" in label.lower():
            return "https://accounts.google.com"
        return "https://"
