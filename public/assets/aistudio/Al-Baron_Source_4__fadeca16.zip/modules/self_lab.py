# language: Python, file: modules/self_lab.py
# Self-Lab — one-click Docker lab setup
import customtkinter as ctk
import threading
import subprocess
import os
import json
import time
from utils.progress import ProgressTracker


DOCKER_COMPOSE = """version: '3.8'

services:
  dvwa:
    image: vulnerables/web-dvwa
    ports:
      - "8081:80"
    networks:
      - lab

  juiceshop:
    image: bkimminich/juice-shop
    ports:
      - "8082:3000"
    networks:
      - lab

  webgoat:
    image: webgoat/webgoat
    ports:
      - "8083:8080"
    environment:
      - WEBGOAT_PORT=8080
    networks:
      - lab

  mutillidae:
    image: citizenstig/nowasp
    ports:
      - "8084:80"
    networks:
      - lab

  vulhub-ssrf:
    image: vulhub/ssrf
    ports:
      - "8085:80"
    networks:
      - lab

  bwapp:
    image: raesene/bwapp
    ports:
      - "8086:80"
    networks:
      - lab

networks:
  lab:
    driver: bridge
    ipam:
      config:
        - subnet: 172.30.0.0/24
"""


class SelfLabModule:
    """One-click lab setup — يبني بيئة تدريب معزولة بـ Docker"""
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "self_lab"
        self.app = app
        self.progress = ProgressTracker(log_queue)
        self.lab_dir = "labs"
        self.containers = []

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="SELF-LAB",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="one-click docker labs · DVWA · JuiceShop · WebGoat · BWAPP",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ── info ──
        info = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        info.pack(fill="x", padx=24)
        ctk.CTkLabel(
            info,
            text="⚠ This will launch 6 vulnerable web apps on your machine\n"
                  "   Ports: 8081, 8082, 8083, 8084, 8085, 8086\n"
                  "   Network: 172.30.0.0/24 (isolated)",
            font=ctk.CTkFont(family="Consolas", size=10),
            text_color="#ffaa00", justify="left"
        ).pack(anchor="w", padx=12, pady=8)

        # ── actions ──
        ctk.CTkLabel(
            parent, text="Lab control:",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#c8d6e5"
        ).pack(pady=(16, 4), padx=24, anchor="w")

        grid = ctk.CTkFrame(parent, fg_color="transparent")
        grid.pack(fill="x", padx=24)
        actions = [
            ("⚡ Deploy lab", self._deploy),
            ("⚡ Start lab", self._start),
            ("■ Stop lab", self._stop),
            ("⚡ Rebuild lab", self._rebuild),
            ("⌖ List containers", self._list),
            ("⌖ Show lab IPs", self._show_ips),
            ("⌖ Check Docker", self._check_docker),
            ("⚡ Purge lab", self._purge),
            ("▤ Export lab info", self._export),
            ("▤ Import lab", self._import),
        ]
        for i, (label, fn) in enumerate(actions):
            ctk.CTkButton(
                grid, text=label, width=200, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).grid(row=i // 3, column=i % 3, padx=4, pady=4)

        # ── output ──
        ctk.CTkLabel(
            parent, text="Output:",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#c8d6e5"
        ).pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=400
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _run(self, cmd, tag="lab"):
        self._out(f"$ {cmd}")
        try:
            p = subprocess.Popen(
                cmd, shell=True, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, text=True, bufsize=1
            )
            for line in p.stdout:
                self._out(f"  {line.rstrip()}")
            p.wait()
            return p.returncode
        except Exception as e:
            self._out(f"[!] {e}")
            return -1

    def _write_compose(self):
        os.makedirs(self.lab_dir, exist_ok=True)
        path = os.path.join(self.lab_dir, "docker-compose.yml")
        with open(path, "w") as f:
            f.write(DOCKER_COMPOSE)
        self._out(f"[+] compose → {path}")
        return path

    def _check_docker(self):
        rc = self._run("docker --version", "docker")
        if rc == 0:
            self._out("[+] Docker OK")
        else:
            self._out("[!] Docker not installed — run: sudo apt install docker.io docker-compose")

    def _deploy(self):
        def run():
            self._check_docker()
            self._write_compose()
            self._out("\n[*] Building lab (first time may take 5-10 min)...")
            self._run(
                f"cd {self.lab_dir} && docker compose up -d --build",
                "compose")
            self._out("\n[*] Waiting for services...")
            time.sleep(15)
            self._show_ips()
            self._list()
        threading.Thread(target=run, daemon=True).start()

    def _start(self):
        def run():
            self._run(f"cd {self.lab_dir} && docker compose start", "compose")
            self._list()
        threading.Thread(target=run, daemon=True).start()

    def _stop(self):
        def run():
            self._run(f"cd {self.lab_dir} && docker compose stop", "compose")
        threading.Thread(target=run, daemon=True).start()

    def _rebuild(self):
        def run():
            self._run(f"cd {self.lab_dir} && docker compose down -v", "compose")
            self._deploy()
        threading.Thread(target=run, daemon=True).start()

    def _list(self):
        def run():
            self._run("docker ps --format 'table {{.Names}}\\t{{.Status}}\\t{{.Ports}}'")
        threading.Thread(target=run, daemon=True).start()

    def _show_ips(self):
        def run():
            self._out("\n=== LAB IPs (172.30.0.0/24) ===")
            self._run(
                "docker network inspect lab_lab --format '{{range .Containers}}{{.Name}} {{.IPv4Address}}{{\"\\n\"}}{{end}}'"
            )
        threading.Thread(target=run, daemon=True).start()

    def _purge(self):
        import tkinter.messagebox as mb
        if not mb.askyesno("Purge", "Remove lab + all volumes?"):
            return
        def run():
            self._run(f"cd {self.lab_dir} && docker compose down -v", "compose")
            self._out("[+] lab purged")
        threading.Thread(target=run, daemon=True).start()

    def _export(self):
        import tkinter.filedialog as fd
        path = fd.asksaveasfilename(
            defaultextension=".json",
            initialfile="lab_config.json")
        if not path:
            return
        config = {
            "compose_file": os.path.join(self.lab_dir, "docker-compose.yml"),
            "services": ["dvwa", "juiceshop", "webgoat",
                          "mutillidae", "vulhub-ssrf", "bwapp"],
            "ports": [8081, 8082, 8083, 8084, 8085, 8086],
            "network": "172.30.0.0/24",
        }
        with open(path, "w") as f:
            json.dump(config, f, indent=2)
        self._out(f"[+] exported → {path}")

    def _import(self):
        import tkinter.filedialog as fd
        path = fd.askopenfilename(filetypes=[("JSON", "*.json")])
        if not path:
            return
        with open(path) as f:
            config = json.load(f)
        self._out(f"[+] imported: {config.get('services')}")
        self._out("[*] to apply, deploy the lab")
