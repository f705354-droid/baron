# language: Python, file: modules/time_travel.py
# Time-Travel UI
import customtkinter as ctk
from core.timetravel.snapshots import snapshot_manager, rewind


class TimeTravelModule:
    def __init__(self, log_queue, app=None):
        self.log = log_queue
        self.name = "time_travel"
        self.app = app

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="TIME-TRAVEL",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="snapshots · rewind · diff · query past state",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24)
        for label, fn in [
            ("⚡ Take snapshot", self._snapshot),
            ("▸ List snapshots", self._list),
            ("▸ Diff two", self._diff),
            ("▸ Start auto", lambda: snapshot_manager.start()),
            ("■ Stop auto", lambda: snapshot_manager.stop()),
        ]:
            ctk.CTkButton(
                row, text=label, width=170, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).pack(side="left", padx=(0, 4))

        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=500
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(12, 12))

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _snapshot(self):
        path = snapshot_manager.snapshot("manual")
        self._out(f"[+] snapshot: {path}")

    def _list(self):
        snaps = snapshot_manager.list_snapshots()
        self._out(f"=== {len(snaps)} snapshots ===")
        for s in snaps:
            meta = s["meta"]
            self._out(f"  {s['file']}")
            self._out(f"    {meta.get('created', '?')[:19]}")
            self._out(f"    stats: {meta.get('graph_stats')}")

    def _diff(self):
        import tkinter.simpledialog as sd
        a = sd.askstring("Diff", "file A:")
        b = sd.askstring("Diff", "file B:")
        if not a or not b:
            return
        try:
            d = rewind.diff(a, b)
            self._out(f"\n=== Diff {a} ↔ {b} ===")
            for k, v in d.items():
                self._out(f"\n{k}: {len(v)}")
                for item in v[:10]:
                    self._out(f"  {item}")
        except Exception as e:
            self._out(f"[!] {e}")
