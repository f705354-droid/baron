# language: Python, file: core/blue/detection_engine.py
# Blue Team detection engine — rules + alerting
import json
import re
import os
from datetime import datetime
from typing import List, Dict, Optional


class DetectionRule:
    """
    قاعدة كشف — تشبه Sigma rules
    """
    def __init__(self, rule_id: str, title: str, severity: str,
                  description: str, detection: dict):
        self.rule_id = rule_id
        self.title = title
        self.severity = severity     # critical/high/medium/low/info
        self.description = description
        self.detection = detection   # {"field": "value"} matching

    def matches(self, log_entry: dict) -> bool:
        """يتحقق إن كانت السجلة تطابق القاعدة"""
        for field, expected in self.detection.items():
            # dot notation for nested: "user.name"
            value = log_entry
            for part in field.split("."):
                if isinstance(value, dict):
                    value = value.get(part)
                else:
                    value = None
                    break

            if value is None:
                return False

            # if expected is a string, use case-insensitive contains
            if isinstance(expected, str):
                if expected.lower() not in str(value).lower():
                    return False
            elif isinstance(expected, list):
                if not any(e.lower() in str(value).lower()
                            for e in expected):
                    return False
            elif value != expected:
                return False
        return True

    def to_dict(self):
        return {
            "id": self.rule_id,
            "title": self.title,
            "severity": self.severity,
            "description": self.description,
            "detection": self.detection,
        }


class DetectionEngine:
    """
    محرك كشف — يدير rules ويطلق alerts
    """
    def __init__(self):
        self.rules: List[DetectionRule] = []
        self.alerts: List[dict] = []
        self.on_alert = None
        self._load_builtin_rules()

    def _load_builtin_rules(self):
        """يحمّل قواعد جاهزة"""
        builtin = [
            DetectionRule(
                "T1059.001-PS",
                "Suspicious PowerShell Command",
                "high",
                "Detects obfuscated PowerShell",
                {"process.command_line": ["-EncodedCommand", "-enc",
                                            "-nop -w hidden", "IEX"]}
            ),
            DetectionRule(
                "T1003.001-LSASS",
                "LSASS Memory Access",
                "critical",
                "Detects credential dumping attempts",
                {"process.name": ["procdump", "mimikatz", "rundll32"]}
            ),
            DetectionRule(
                "T1547.001-REG",
                "Registry Run Key Persistence",
                "medium",
                "Detects Run key modifications",
                {"event.id": "13",
                  "registry.path": ["\\CurrentVersion\\Run"]}
            ),
            DetectionRule(
                "T1053.005-SCHTASK",
                "Scheduled Task Creation",
                "medium",
                "Detects schtasks /create",
                {"process.command_line": "schtasks /create"}
            ),
            DetectionRule(
                "T1021.002-SMB",
                "SMB Lateral Movement",
                "high",
                "Detects PsExec-style lateral movement",
                {"event.id": ["5140", "5145"],
                  "logon.type": "3"}
            ),
            DetectionRule(
                "T1071.001-C2",
                "Suspicious HTTPS Beacon",
                "high",
                "Detects regular HTTPS beaconing",
                {"network.protocol": "https",
                  "network.duration": ">300"}
            ),
            DetectionRule(
                "T1110-BRUTE",
                "Brute Force Login",
                "high",
                "Detects multiple failed logins",
                {"event.id": "4625"}
            ),
            DetectionRule(
                "T1486-RANSOM",
                "Mass File Encryption",
                "critical",
                "Detects ransomware behavior",
                {"file.extension": [".locked", ".encrypted", ".crypto"]}
            ),
        ]
        self.rules.extend(builtin)

    def add_rule(self, rule: DetectionRule):
        self.rules.append(rule)

    def evaluate(self, log_entry: dict) -> List[dict]:
        """
        يمرر السجلة على كل القواعد.
        يعيد alerts للمطابقات.
        """
        matches = []
        for rule in self.rules:
            try:
                if rule.matches(log_entry):
                    alert = {
                        "rule_id": rule.rule_id,
                        "title": rule.title,
                        "severity": rule.severity,
                        "description": rule.description,
                        "log": log_entry,
                        "detected_at": datetime.now().isoformat(),
                    }
                    matches.append(alert)
                    self.alerts.append(alert)
                    if self.on_alert:
                        try:
                            self.on_alert(alert)
                        except Exception:
                            pass
            except Exception as e:
                print(f"[detection] {rule.rule_id}: {e}")

        return matches

    def get_alerts(self, severity: str = None) -> list:
        if severity:
            return [a for a in self.alerts
                     if a["severity"] == severity]
        return self.alerts

    def clear(self):
        self.alerts.clear()

    def import_sigma(self, path: str):
        """يستورد Sigma rule (subset)"""
        try:
            import yaml
            with open(path) as f:
                rules_yaml = yaml.safe_load_all(f)
                for r in rules_yaml:
                    if not r:
                        continue
                    rule = DetectionRule(
                        r.get("id", "unknown"),
                        r.get("title", "unknown"),
                        r.get("level", "medium"),
                        r.get("description", ""),
                        r.get("detection", {}),
                    )
                    self.add_rule(rule)
        except Exception as e:
            print(f"[sigma] {e}")


# singleton
engine = DetectionEngine()
