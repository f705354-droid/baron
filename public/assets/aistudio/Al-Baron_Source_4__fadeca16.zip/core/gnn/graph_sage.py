# language: Python, file: core/gnn/graph_sage.py
# GraphSAGE — Graph Neural Network for attack path prediction
import os
import json
import numpy as np
import sqlite3
import threading
from datetime import datetime
from typing import List, Dict, Tuple, Optional

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


NODE_FEATURES = 16   # عدد الخصائص لكل node
HIDDEN_DIM = 64
EMBED_DIM = 32


def node_to_features(node: dict) -> np.ndarray:
    """
    يحول node properties إلى متجه 16-dim
    """
    v = np.zeros(NODE_FEATURES, dtype=np.float32)
    props = node.get("properties", {})
    t = node.get("type", "")

    # type one-hot (8 خانات)
    types = ["host", "session", "credential", "vulnerability",
              "technique", "task", "artifact", "subnet"]
    if t in types:
        v[types.index(t)] = 1.0

    # props-based features (8 خانات)
    v[8] = 1.0 if props.get("compromised") else 0.0
    v[9] = 1.0 if props.get("root") else 0.0
    v[10] = min(props.get("cvss", 0) / 10.0, 1.0)
    v[11] = min(len(props.get("ports", [])) / 20.0, 1.0)
    v[12] = 1.0 if props.get("is_dc") else 0.0
    v[13] = 1.0 if props.get("is_admin") else 0.0
    v[14] = 1.0 if props.get("public") else 0.0
    v[15] = min(props.get("age_days", 0) / 365.0, 1.0)

    return v


if HAS_TORCH:
    class GraphSAGEConv(nn.Module):
        """طبقة GraphSAGE: concatenate(self, mean(neighbors))"""
        def __init__(self, in_dim: int, out_dim: int):
            super().__init__()
            self.self_linear = nn.Linear(in_dim, out_dim)
            self.neighbor_linear = nn.Linear(in_dim, out_dim)

        def forward(self, x, edge_index):
            """x: (N, in_dim), edge_index: (2, E)"""
            src, dst = edge_index[0], edge_index[1]
            N = x.size(0)
            # aggregate neighbors (mean)
            agg = torch.zeros_like(x)
            count = torch.zeros(N, 1, device=x.device)
            agg.index_add_(0, dst, x[src])
            count.index_add_(0, dst, torch.ones(src.size(0), 1,
                                                  device=x.device))
            count = count.clamp(min=1)
            agg = agg / count
            # combine
            h = self.self_linear(x) + self.neighbor_linear(agg)
            return F.relu(h)


    class AttackGNN(nn.Module):
        """
        GraphSAGE-style GNN:
        - 2 conv layers
        - node embeddings
        - path prediction head
        """
        def __init__(self, in_dim=NODE_FEATURES, hidden=HIDDEN_DIM,
                      embed=EMBED_DIM):
            super().__init__()
            self.conv1 = GraphSAGEConv(in_dim, hidden)
            self.conv2 = GraphSAGEConv(hidden, embed)
            # predictor: given pair of node embeddings, predict attack feasibility
            self.edge_predictor = nn.Sequential(
                nn.Linear(embed * 2, 128),
                nn.ReLU(),
                nn.Dropout(0.2),
                nn.Linear(128, 64),
                nn.ReLU(),
                nn.Linear(64, 1),
            )

        def forward(self, x, edge_index):
            h = self.conv1(x, edge_index)
            h = self.conv2(h, edge_index)
            return h  # node embeddings

        def predict_edge(self, node_emb, src_idx, dst_idx):
            """يتنبأ باحتمال أن src يمكنه استغلال dst"""
            src = node_emb[src_idx]
            dst = node_emb[dst_idx]
            pair = torch.cat([src, dst], dim=-1)
            return torch.sigmoid(self.edge_predictor(pair))
