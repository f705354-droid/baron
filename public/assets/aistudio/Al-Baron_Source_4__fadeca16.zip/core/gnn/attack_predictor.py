# language: Python, file: core/gnn/attack_predictor.py
# Attack path predictor — يستخدم GNN للتنبؤ بمسارات هجوم جديدة
import os
import json
import numpy as np
import threading
from datetime import datetime
from core.graph.graph_db import graph

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from core.gnn.graph_sage import (
        AttackGNN, node_to_features, NODE_FEATURES, HAS_TORCH)
    HAS_TORCH_GNN = HAS_TORCH
except ImportError:
    HAS_TORCH_GNN = False


class AttackPredictor:
    """
    يتدرب على graph الحالي ويتنبأ بمسارات هجوم.
    - Training: يستخدم techniques المعروفة كـ labels
    - Inference: يتنبأ بأي edges قد تحمل هجوماً
    """
    def __init__(self, model_path: str = "~/.albaron/attack_gnn.pt"):
        self.model_path = os.path.expanduser(model_path)
        self.model = None
        self.optimizer = None
        if HAS_TORCH_GNN:
            self.model = AttackGNN()
            self.optimizer = torch.optim.Adam(
                self.model.parameters(), lr=1e-3)
            if os.path.exists(self.model_path):
                try:
                    self.model.load_state_dict(
                        torch.load(self.model_path))
                except Exception:
                    pass

    def build_graph_tensors(self):
        """يبني x, edge_index من UnifiedGraph"""
        nodes = graph.list_nodes()
        if not nodes:
            return None, None, nodes

        node_id_to_idx = {n["id"]: i for i, n in enumerate(nodes)}

        # features
        x = np.array([node_to_features(n) for n in nodes],
                      dtype=np.float32)
        x = torch.from_numpy(x)

        # edges
        edges = graph.db.execute(
            "SELECT src_id, dst_id FROM edges").fetchall()
        edge_list = []
        for src, dst in edges:
            if src in node_id_to_idx and dst in node_id_to_idx:
                edge_list.append([node_id_to_idx[src],
                                    node_id_to_idx[dst]])
        if not edge_list:
            edge_index = torch.zeros((2, 0), dtype=torch.long)
        else:
            edge_index = torch.tensor(edge_list, dtype=torch.long).t()

        return x, edge_index, nodes

    def train(self, epochs: int = 100) -> dict:
        """يدرب GNN على graph الحالي"""
        if not HAS_TORCH_GNN:
            return {"error": "torch not available"}

        x, edge_index, nodes = self.build_graph_tensors()
        if x is None or edge_index.size(1) == 0:
            return {"error": "not enough graph data"}

        # نستخدم edges الحالية كـ positive samples
        # ونولّد negative samples (edges غير موجودة)
        pos_pairs = edge_index.t()

        # negative sampling: random node pairs
        N = len(nodes)
        neg_pairs = []
        existing = set((int(s), int(d)) for s, d in pos_pairs)
        for _ in range(len(pos_pairs)):
            while True:
                s, d = np.random.randint(0, N, 2)
                if s != d and (s, d) not in existing:
                    neg_pairs.append([s, d])
                    break
        neg_pairs = torch.tensor(neg_pairs, dtype=torch.long)

        # training loop
        losses = []
        for epoch in range(epochs):
            self.optimizer.zero_grad()
            node_emb = self.model(x, edge_index)

            # positive predictions
            pos_src = pos_pairs[:, 0]
            pos_dst = pos_pairs[:, 1]
            pos_pred = self.model.predict_edge(
                node_emb, pos_src, pos_dst)
            pos_loss = F.binary_cross_entropy(
                pos_pred, torch.ones_like(pos_pred))

            # negative predictions
            neg_src = neg_pairs[:, 0]
            neg_dst = neg_pairs[:, 1]
            neg_pred = self.model.predict_edge(
                node_emb, neg_src, neg_dst)
            neg_loss = F.binary_cross_entropy(
                neg_pred, torch.zeros_like(neg_pred))

            loss = pos_loss + neg_loss
            loss.backward()
            self.optimizer.step()
            losses.append(float(loss.item()))

        # save
        torch.save(self.model.state_dict(), self.model_path)
        return {
            "epochs": epochs,
            "final_loss": losses[-1],
            "initial_loss": losses[0],
            "nodes": N,
            "edges": len(pos_pairs),
            "model_path": self.model_path,
        }

    def predict_attack_paths(self, top_k: int = 20) -> list:
        """
        يتنبأ بأفضل (src, dst) pairs التي يمكن أن تحمل هجوماً
        """
        if not HAS_TORCH_GNN:
            return []

        x, edge_index, nodes = self.build_graph_tensors()
        if x is None:
            return []

        with torch.no_grad():
            node_emb = self.model(x, edge_index)

        # candidates: لكل host, كل vulnerability
        host_idxs = []
        vuln_idxs = []
        for i, n in enumerate(nodes):
            if n["type"] == "host":
                host_idxs.append(i)
            elif n["type"] == "vulnerability":
                vuln_idxs.append(i)

        results = []
        for hi in host_idxs:
            for vi in vuln_idxs:
                with torch.no_grad():
                    score = self.model.predict_edge(
                        node_emb,
                        torch.tensor([hi]),
                        torch.tensor([vi])).item()
                results.append({
                    "host": nodes[hi]["key"],
                    "vuln": nodes[vi]["key"],
                    "score": score,
                    "predicted": score > 0.5,
                })

        results.sort(key=lambda x: -x["score"])
        return results[:top_k]


predictor = AttackPredictor()
