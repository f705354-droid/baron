# language: Python, file: core/opsboard/kanban.py
# Kanban board for red team operations
import sqlite3
import os
import json
import uuid
from datetime import datetime
from typing import List, Optional


class KanbanBoard:
    """
    لوحة Kanban لعدة engagements.
    Columns: Backlog → Recon → Exploit → Post → Report → Done
    """
    COLUMNS = ["Backlog", "Recon", "Exploit", "Post", "Report", "Done"]
    PRIORITIES = ["critical", "high", "medium", "low"]

    def __init__(self, db_path: str = "~/.albaron/kanban.db"):
        self.db_path = os.path.expanduser(db_path)
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self.db = sqlite3.connect(self.db_path, check_same_thread=False)
        self._init_schema()

    def _init_schema(self):
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS engagements (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            client TEXT,
            scope TEXT,
            status TEXT DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            due_at TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS tasks (
            id TEXT PRIMARY KEY,
            engagement_id TEXT,
            title TEXT NOT NULL,
            description TEXT,
            assignee TEXT,
            priority TEXT DEFAULT 'medium',
            column_name TEXT DEFAULT 'Backlog',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(engagement_id) REFERENCES engagements(id)
        );

        CREATE TABLE IF NOT EXISTS task_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id TEXT,
            actor TEXT,
            action TEXT,
            details TEXT,
            ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)
        self.db.commit()

    # ==================== engagements ====================
    def create_engagement(self, name: str, client: str = "",
                            scope: str = "") -> dict:
        eid = str(uuid.uuid4())[:12]
        self.db.execute("""
            INSERT INTO engagements (id, name, client, scope)
            VALUES (?, ?, ?, ?)
        """, (eid, name, client, scope))
        self.db.commit()
        return {"id": eid, "name": name}

    def list_engagements(self) -> list:
        rows = self.db.execute("""
            SELECT id, name, client, status, created_at
            FROM engagements ORDER BY created_at DESC
        """).fetchall()
        return [
            {"id": r[0], "name": r[1], "client": r[2],
              "status": r[3], "created_at": r[4]}
            for r in rows
        ]

    def delete_engagement(self, eid: str):
        self.db.execute("DELETE FROM tasks WHERE engagement_id=?", (eid,))
        self.db.execute("DELETE FROM engagements WHERE id=?", (eid,))
        self.db.commit()

    # ==================== tasks ====================
    def create_task(self, engagement_id: str, title: str,
                     description: str = "", assignee: str = "",
                     priority: str = "medium",
                     column: str = "Backlog") -> dict:
        tid = str(uuid.uuid4())[:12]
        self.db.execute("""
            INSERT INTO tasks
            (id, engagement_id, title, description, assignee,
             priority, column_name)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (tid, engagement_id, title, description,
                assignee, priority, column))
        self.db.commit()
        return {"id": tid, "title": title, "column": column}

    def move_task(self, tid: str, new_column: str,
                    actor: str = "operator"):
        if new_column not in self.COLUMNS:
            return {"error": "invalid column"}
        self.db.execute("""
            UPDATE tasks SET column_name=?, updated_at=CURRENT_TIMESTAMP
            WHERE id=?
        """, (new_column, tid))
        self.db.execute("""
            INSERT INTO task_logs (task_id, actor, action, details)
            VALUES (?, ?, ?, ?)
        """, (tid, actor, "move", json.dumps({"to": new_column})))
        self.db.commit()
        return {"status": "moved"}

    def update_task(self, tid: str, **kwargs):
        allowed = ["title", "description", "assignee", "priority"]
        updates = {k: v for k, v in kwargs.items() if k in allowed}
        if not updates:
            return
        sets = ", ".join(f"{k}=?" for k in updates)
        self.db.execute(f"""
            UPDATE tasks SET {sets}, updated_at=CURRENT_TIMESTAMP
            WHERE id=?
        """, list(updates.values()) + [tid])
        self.db.commit()

    def delete_task(self, tid: str):
        self.db.execute("DELETE FROM tasks WHERE id=?", (tid,))
        self.db.commit()

    def get_task(self, tid: str) -> Optional[dict]:
        row = self.db.execute("""
            SELECT id, engagement_id, title, description, assignee,
                   priority, column_name, created_at, updated_at
            FROM tasks WHERE id=?
        """, (tid,)).fetchone()
        if not row:
            return None
        return {
            "id": row[0], "engagement_id": row[1], "title": row[2],
            "description": row[3], "assignee": row[4],
            "priority": row[5], "column": row[6],
            "created_at": row[7], "updated_at": row[8],
        }

    def get_board(self, engagement_id: str) -> dict:
        """يرجع board كامل مجمّع بأعمدة"""
        rows = self.db.execute("""
            SELECT id, title, description, assignee, priority,
                   column_name, created_at
            FROM tasks WHERE engagement_id=?
            ORDER BY priority DESC, created_at DESC
        """, (engagement_id,)).fetchall()

        board = {col: [] for col in self.COLUMNS}
        for r in rows:
            col = r[5] if r[5] in board else "Backlog"
            board[col].append({
                "id": r[0], "title": r[1], "description": r[2],
                "assignee": r[3], "priority": r[4],
                "created": r[6],
            })
        return board

    def get_stats(self, engagement_id: str) -> dict:
        """إحصائيات board"""
        rows = self.db.execute("""
            SELECT column_name, COUNT(*) FROM tasks
            WHERE engagement_id=? GROUP BY column_name
        """, (engagement_id,)).fetchall()
        stats = {col: 0 for col in self.COLUMNS}
        for col, count in rows:
            stats[col] = count
        return stats


kanban = KanbanBoard()
