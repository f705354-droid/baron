# language: Python, file: core/ai_chat_drawer.py
# AI Chat Drawer v2 — memory + agents + tools + voice + reflect + collab
import customtkinter as ctk
import threading
import queue
import json
import time
import os
from datetime import datetime

from core.ai.memory import memory
from core.ai.agents import AGENTS, AgentRouter
from core.ai.tools import registry
from core.ai.offline import offline_llm
from core.ai.reflect import ReflectionEngine
from core.ai.sessions import chat_sessions
from core.ai.voice import voice


class AIChatDrawer(ctk.CTkFrame):
    def __init__(self, parent, ai_assistant, get_context_fn, app=None):
        super().__init__(parent, fg_color="#05080c", corner_radius=0,
                          border_width=1, border_color="#1a4a2e")
        self.ai = ai_assistant
        self.get_context = get_context_fn
        self.app = app

        # state
        self.is_open = False
        self.collapsed_height = 40
        self.expanded_height = 420
        self.current_height = self.collapsed_height
        self.stream_queue = queue.Queue()
        self._stream_buffer = ""
        self._streaming = False
        self._agent_override = None
        self._use_tools = True
        self._use_reflect = True
        self._use_voice_out = False

        # sessions
        self.current_session_id = chat_sessions.create()
        self.router = AgentRouter()
        self.reflector = ReflectionEngine(self._ai_call_simple)

        registry.app = app  # attach tools to app

        self._build()
        self._poll_stream()

    # ==================== UI ====================
    def _build(self):
        # ── header ──
        self.header = ctk.CTkFrame(self, height=40, fg_color="#0d1319",
                                    corner_radius=0)
        self.header.pack(fill="x", side="top")
        self.header.pack_propagate(False)

        self.toggle_btn = ctk.CTkButton(
            self.header, text="▲  AI CHAT", width=140, height=32,
            fg_color="transparent", hover_color="#1a2332",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#00ff9c", anchor="w",
            command=self.toggle
        )
        self.toggle_btn.pack(side="left", padx=8, pady=4)

        # agent picker
        self.agent_picker = ctk.CTkOptionMenu(
            self.header, values=["auto"] + list(AGENTS.keys()),
            width=120, height=26, fg_color="#141a22",
            button_color="#141a22", font=ctk.CTkFont(size=10),
            command=self._set_agent)
        self.agent_picker.pack(side="left", padx=4)

        # session picker
        self.session_picker = ctk.CTkOptionMenu(
            self.header, values=self._session_names(),
            width=140, height=26, fg_color="#141a22",
            button_color="#141a22", font=ctk.CTkFont(size=10),
            command=self._switch_session)
        self.session_picker.pack(side="left", padx=4)

        # mode toggles
        self.tools_btn = ctk.CTkButton(
            self.header, text="🔧", width=32, height=26,
            fg_color="#0d2818", hover_color="#1a4a2e",
            text_color="#00ff9c", font=ctk.CTkFont(size=11),
            command=self._toggle_tools)
        self.tools_btn.pack(side="left", padx=2)

        self.reflect_btn = ctk.CTkButton(
            self.header, text="✨", width=32, height=26,
            fg_color="#0d2818", hover_color="#1a4a2e",
            text_color="#00ff9c", font=ctk.CTkFont(size=11),
            command=self._toggle_reflect)
        self.reflect_btn.pack(side="left", padx=2)

        self.voice_btn = ctk.CTkButton(
            self.header, text="🎙", width=32, height=26,
            fg_color="#141a22", hover_color="#1a2332",
            font=ctk.CTkFont(size=11),
            command=self._voice_input)
        self.voice_btn.pack(side="left", padx=2)

        self.speak_btn = ctk.CTkButton(
            self.header, text="🔊", width=32, height=26,
            fg_color="#141a22", hover_color="#1a2332",
            font=ctk.CTkFont(size=11),
            command=self._toggle_speak)
        self.speak_btn.pack(side="left", padx=2)

        # status
        self.status_lbl = ctk.CTkLabel(
            self.header, text="● ready",
            font=ctk.CTkFont(size=10), text_color="#4a5568")
        self.status_lbl.pack(side="left", padx=8)

        # right side buttons
        ctk.CTkButton(self.header, text="⌫", width=32, height=28,
                       fg_color="transparent", hover_color="#1a2332",
                       font=ctk.CTkFont(size=14),
                       command=self._clear_chat).pack(side="right", padx=4)
        ctk.CTkButton(self.header, text="⚙", width=32, height=28,
                       fg_color="transparent", hover_color="#1a2332",
                       font=ctk.CTkFont(size=12),
                       command=self._open_settings).pack(side="right", padx=4)
        ctk.CTkButton(self.header, text="↗", width=32, height=28,
                       fg_color="transparent", hover_color="#1a2332",
                       font=ctk.CTkFont(size=12),
                       command=self._popout).pack(side="right", padx=4)
        ctk.CTkButton(self.header, text="+", width=32, height=28,
                       fg_color="transparent", hover_color="#1a2332",
                       font=ctk.CTkFont(size=14),
                       command=self._new_session).pack(side="right", padx=4)

        # ── body ──
        self.body = ctk.CTkFrame(self, fg_color="#05080c", corner_radius=0)

        # quick actions row (scrollable)
        self.quick_row = ctk.CTkScrollableFrame(
            self.body, fg_color="transparent", height=40,
            scrollbar_button_color="#1a2332")
        self.quick_row.pack(fill="x", padx=8, pady=(6, 2))

        quick_actions = [
            ("📋 لخّص", "لخّص الحالة الحالية"),
            ("🔍 حلل", "حلل آخر نتائج مسح واقترح"),
            ("🎯 اقترح هدف", "ما أفضل هدف تالٍ بناءً على السياق؟"),
            ("⚔ خطة", "ضع خطة هجوم مرتبة بالأولوية"),
            ("🛠 payload", "اكتب payload مناسب للسياق"),
            ("🛡 OPSEC", "راجع OPSEC وأعط تحسينات"),
            ("📊 تقرير", "اكتب ملخص تنفيذي"),
            ("💾 حفظ", "استخرج الحقائق واحفظها"),
            ("🔗 شارك", "شارك هذه المحادثة مع الفريق"),
        ]
        for label, cmd in quick_actions:
            ctk.CTkButton(
                self.quick_row, text=label, height=26,
                fg_color="#141a22", hover_color="#1a2332",
                font=ctk.CTkFont(size=10),
                command=lambda c=cmd: self._quick(c)
            ).pack(side="left", padx=(0, 4))

        # messages area
        self.messages = ctk.CTkTextbox(
            self.body, fg_color="#05080c", text_color="#c8d6e5",
            font=ctk.CTkFont(family="Consolas", size=11),
            wrap="word", scrollbar_button_color="#1a2332")
        self.messages.pack(fill="both", expand=True, padx=12, pady=(4, 4))
        self.messages.configure(state="disabled")

        # tags
        for tag, color in [
            ("user", "#7dffb0"), ("ai", "#00ff9c"),
            ("sys", "#4a5568"), ("err", "#ff6b6b"),
            ("meta", "#6a7a8a"), ("tool", "#ffaa00"),
            ("agent", "#e0a0ff"),
        ]:
            self.messages.tag_config(tag, foreground=color)
        self.messages.tag_config("tool", foreground="#ffaa00")
        self.messages.tag_config("agent", foreground="#e0a0ff")

        # input row
        input_row = ctk.CTkFrame(self.body, fg_color="transparent")
        input_row.pack(fill="x", padx=12, pady=(0, 12))

        self.entry = ctk.CTkEntry(
            input_row, height=38, fg_color="#0d1319",
            border_color="#1a2332",
            placeholder_text="اسأل الوكيل... (Enter للإرسال)",
            font=ctk.CTkFont(family="Consolas", size=11))
        self.entry.pack(side="left", fill="x", expand=True, padx=(0, 6))
        self.entry.bind("<Return>", self._on_enter)

        self.send_btn = ctk.CTkButton(
            input_row, text="▸ SEND", width=100, height=38,
            fg_color="#0d2818", hover_color="#1a4a2e",
            text_color="#00ff9c", font=ctk.CTkFont(size=11, weight="bold"),
            command=self._send)
        self.send_btn.pack(side="left", padx=(0, 4))

        self.stop_btn = ctk.CTkButton(
            input_row, text="■", width=38, height=38,
            fg_color="#4a1a1a", hover_color="#6b1a1a",
            text_color="#ff6b6b", font=ctk.CTkFont(size=12),
            command=self._stop_stream)

    # ==================== session management ====================
    def _session_names(self):
        return [s["name"] for s in chat_sessions.list()] or ["default"]

    def _switch_session(self, name):
        for s in chat_sessions.list():
            if s["name"] == name:
                self.current_session_id = s["id"]
                self._reload_session()
                return

    def _new_session(self):
        sid = chat_sessions.create()
        chat_sessions.rename(sid, f"chat-{datetime.now().strftime('%H%M')}")
        self.current_session_id = sid
        self.session_picker.configure(values=self._session_names())
        self._clear_chat()
        self._append("sys", "جلسة جديدة")

    def _reload_session(self):
        self.messages.configure(state="normal")
        self.messages.delete("1.0", "end")
        self.messages.configure(state="disabled")
        # load from memory
        msgs = memory.search("*", session_id=self.current_session_id,
                              limit=50)
        msgs.reverse()
        for m in msgs:
            self._append(m["role"], m["content"])

    # ==================== toggles ====================
    def _set_agent(self, name):
        self._agent_override = None if name == "auto" else name

    def _toggle_tools(self):
        self._use_tools = not self._use_tools
        self.tools_btn.configure(
            fg_color="#0d2818" if self._use_tools else "#141a22",
            text_color="#00ff9c" if self._use_tools else "#4a5568")

    def _toggle_reflect(self):
        self._use_reflect = not self._use_reflect
        self.reflect_btn.configure(
            fg_color="#0d2818" if self._use_reflect else "#141a22",
            text_color="#00ff9c" if self._use_reflect else "#4a5568")

    def _toggle_speak(self):
        self._use_voice_out = not self._use_voice_out
        self.speak_btn.configure(
            fg_color="#0d2818" if self._use_voice_out else "#141a22",
            text_color="#00ff9c" if self._use_voice_out else "#4a5568")

    # ==================== open/close ====================
    def toggle(self):
        self._close() if self.is_open else self._open()

    def _open(self):
        self.is_open = True
        self.body.pack(fill="both", expand=True, side="top")
        self._animate_height(self.expanded_height)
        self.toggle_btn.configure(text="▼  AI CHAT")
        self.entry.focus_set()
        if not memory.get_short():
            self._append("ai",
                "مرحباً. اسأل، أو استخدم الأزرار السريعة.\n"
                "🔧 أدوات · ✨ انعكاس · 🎙 صوت · + جلسة جديدة")

    def _close(self):
        self.is_open = False
        self.body.pack_forget()
        self._animate_height(self.collapsed_height)
        self.toggle_btn.configure(text="▲  AI CHAT")

    def _animate_height(self, target):
        cur = self.current_height
        if cur == target:
            return
        step = 30 if target > cur else -30
        nxt = cur + step
        if (step > 0 and nxt >= target) or (step < 0 and nxt <= target):
            nxt = target
        self.configure(height=nxt)
        self.current_height = nxt
        if nxt != target:
            self.after(10, lambda: self._animate_height(target))

    # ==================== input ====================
    def _on_enter(self, event):
        if event.state & 0x0001:
            return None
        self._send()
        return "break"

    def _send(self):
        text = self.entry.get().strip()
        if not text:
            return
        self.entry.delete(0, "end")
        self._dispatch(text)

    def _quick(self, text):
        if not self.is_open:
            self._open()
        self._dispatch(text)

    def _dispatch(self, text):
        self._append("user", text)
        memory.push_short("user", text)
        memory.store_message(self.current_session_id, "user", text)
        memory.extract_facts(self.current_session_id, text)
        chat_sessions.touch(self.current_session_id)
        self._start_stream(text)

    def _voice_input(self):
        self._append("sys", "🎙 يستمع...")
        def run():
            text = voice.record_until_silence()
            if text:
                self.after(0, lambda: self._dispatch(text))
            else:
                self.after(0, lambda: self._append("err", "لم يُسمع شيء"))
        threading.Thread(target=run, daemon=True).start()

    # ==================== stream ====================
    def _start_stream(self, prompt):
        if self._streaming:
            self._append("err", "[!] stream قيد التشغيل")
            return
        self._streaming = True
        self._stream_buffer = ""

        agent_name = self._agent_override or self.router.route(prompt)
        agent = AGENTS[agent_name]

        self._append_raw("agent", f"◂ [{agent_name}] ")
        self.status_lbl.configure(text=f"● {agent_name}...",
                                    text_color="#00ff9c")
        self.stop_btn.pack(side="left", padx=(0, 4))

        threading.Thread(
            target=self._stream_worker,
            args=(prompt, agent), daemon=True
        ).start()

    def _stream_worker(self, prompt, agent):
        try:
            context = self.get_context() if self.get_context else {}
            mem_ctx = memory.build_context(self.current_session_id, prompt)
            system = self._build_system(agent, context, mem_ctx)

            # تحقق من offline أولاً إذا لا يوجد مفاتيح سحابية
            has_cloud = (os.getenv("ANTHROPIC_API_KEY") or
                          os.getenv("OPENAI_API_KEY"))

            if not has_cloud and offline_llm.is_available():
                self._stream_offline(system, prompt)
                return

            # جرّب streaming سحابي
            streamed = False
            if os.getenv("ANTHROPIC_API_KEY"):
                streamed = self._stream_anthropic(system, prompt, agent)
            if not streamed and os.getenv("OPENAI_API_KEY"):
                streamed = self._stream_openai(system, prompt, agent)
            if not streamed and offline_llm.is_available():
                self._stream_offline(system, prompt)
                return
            if not streamed:
                # fallback نصي
                reply = self.ai.query(prompt, context=context)
                for chunk in self._chunk(reply, 4):
                    self.stream_queue.put(("chunk", chunk))
                    time.sleep(0.008)

            self.stream_queue.put(("done", None))
        except Exception as e:
            self.stream_queue.put(("error", str(e)))

    def _stream_anthropic(self, system, prompt, agent):
        try:
            from anthropic import Anthropic
            client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

            kwargs = {
                "model": agent.model or "claude-sonnet-4-20250514",
                "max_tokens": 2048,
                "system": system,
                "messages": self._anthropic_messages(prompt),
                "temperature": agent.temperature,
            }
            if self._use_tools and agent.tools_allowed:
                schemas = [s for s in registry.schemas()
                            if s["name"] in agent.tools_allowed]
                if schemas:
                    kwargs["tools"] = schemas

            with client.messages.stream(**kwargs) as stream:
                current_tool = None
                for event in stream:
                    etype = event.type
                    if etype == "content_block_delta":
                        delta = event.delta
                        if hasattr(delta, "text"):
                            self.stream_queue.put(("chunk", delta.text))
                        elif getattr(delta, "partial_json", None):
                            if current_tool is not None:
                                current_tool["args"] += delta.partial_json
                    elif etype == "content_block_start":
                        block = event.content_block
                        if getattr(block, "type", "") == "tool_use":
                            current_tool = {
                                "id": block.id, "name": block.name,
                                "args": "",
                            }
                            self.stream_queue.put(("tool_start",
                                                    block.name))
                    elif etype == "content_block_stop":
                        if current_tool:
                            self._invoke_tool(current_tool)
                            current_tool = None
            return True
        except Exception as e:
            self.stream_queue.put(("error", f"anthropic: {e}"))
            return False

    def _stream_openai(self, system, prompt, agent):
        try:
            from openai import OpenAI
            client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
            msgs = [{"role": "system", "content": system}]
            for r, c, _ in memory.get_short(10):
                msgs.append({"role": r, "content": c})
            msgs.append({"role": "user", "content": prompt})

            kwargs = {
                "model": agent.model or "gpt-4o",
                "messages": msgs,
                "max_tokens": 2048,
                "temperature": agent.temperature,
                "stream": True,
            }
            if self._use_tools and agent.tools_allowed:
                schemas = [{
                    "type": "function",
                    "function": {
                        "name": s["name"],
                        "description": s["description"],
                        "parameters": s["input_schema"],
                    },
                } for s in registry.schemas()
                  if s["name"] in agent.tools_allowed]
                if schemas:
                    kwargs["tools"] = schemas

            stream = client.chat.completions.create(**kwargs)
            tool_calls = {}
            for ev in stream:
                delta = ev.choices[0].delta
                if delta.content:
                    self.stream_queue.put(("chunk", delta.content))
                if delta.tool_calls:
                    for tc in delta.tool_calls:
                        idx = tc.index
                        if idx not in tool_calls:
                            tool_calls[idx] = {
                                "name": tc.function.name or "",
                                "args": "",
                            }
                        if tc.function.arguments:
                            tool_calls[idx]["args"] += tc.function.arguments
            for idx, tc in tool_calls.items():
                self._invoke_tool(tc)
            return True
        except Exception as e:
            self.stream_queue.put(("error", f"openai: {e}"))
            return False

    def _stream_offline(self, system, prompt):
        self.stream_queue.put(("chunk", "[offline] "))
        for chunk in offline_llm.stream(system, prompt):
            self.stream_queue.put(("chunk", chunk))
            time.sleep(0.005)

    def _invoke_tool(self, tc):
        try:
            name = tc.get("name")
            args = json.loads(tc.get("args") or "{}")
        except Exception:
            return
        self.stream_queue.put(("tool_start", name))
        result = registry.call(name, args)
        self.stream_queue.put(("tool_result", (name, result)))

    def _anthropic_messages(self, prompt):
        msgs = []
        for r, c, _ in memory.get_short(10):
            msgs.append({"role": r, "content": c})
        msgs.append({"role": "user", "content": prompt})
        return msgs

    def _chunk(self, text, size):
        for i in range(0, len(text), size):
            yield text[i:i+size]

    # ==================== poll ====================
    def _poll_stream(self):
        try:
            while True:
                kind, payload = self.stream_queue.get_nowait()
                if kind == "chunk":
                    self._append_chunk(payload)
                elif kind == "tool_start":
                    self._append_raw("tool", f"\n[🔧 {payload}] ")
                elif kind == "tool_result":
                    name, result = payload
                    preview = json.dumps(result)[:200]
                    self._append_raw("tool", f"→ {preview}\n")
                elif kind == "done":
                    self._on_stream_done()
                elif kind == "error":
                    self._append_raw("err", f"\n[!] {payload}\n")
                    self._on_stream_done()
        except queue.Empty:
            pass

        if not self.is_open and len(memory.get_short()):
            self.status_lbl.configure(
                text=f"● {len(memory.get_short())} رسالة",
                text_color="#00ff9c")
        self.after(30, self._poll_stream)

    def _append_chunk(self, chunk):
        self.messages.configure(state="normal")
        self.messages.insert("end", chunk, "ai")
        self.messages.see("end")
        self.messages.configure(state="disabled")
        self._stream_buffer += chunk

    def _on_stream_done(self):
        self.status_lbl.configure(text="● ready", text_color="#4a5568")
        try:
            self.stop_btn.pack_forget()
        except Exception:
            pass
        final = self._stream_buffer

        # reflect إذا مفعل
        if self._use_reflect and final and len(final) > 400:
            threading.Thread(target=self._reflect_async,
                              args=(final,), daemon=True).start()

        if final:
            memory.push_short("assistant", final)
            memory.store_message(self.current_session_id, "assistant", final)
            memory.extract_facts(self.current_session_id, final)

        if self._use_voice_out and final:
            voice.speak(final[:500])

        self._stream_buffer = ""
        self._streaming = False

    def _reflect_async(self, original):
        try:
            improved = self.reflector.reflect("", original)
            if improved != original:
                self.after(0, lambda: self._append("sys",
                    "✨ تحسين تلقائي متاح — أرسل 'show improvement' لعرضه"))
        except Exception:
            pass

    def _stop_stream(self):
        self.stream_queue.put(("done", None))
        self.status_lbl.configure(text="● stopped", text_color="#ff6b6b")
        self._streaming = False

    # ==================== rendering ====================
    def _append(self, role, text):
        self.messages.configure(state="normal")
        ts = datetime.now().strftime("%H:%M")
        if role == "user":
            self.messages.insert("end", f"\n╭─ you · {ts}\n", "meta")
            self.messages.insert("end", f"│ {text}\n", "user")
            self.messages.insert("end", "╰─\n", "meta")
        elif role == "ai":
            self.messages.insert("end", f"\n╭─ ai · {ts}\n", "meta")
            self.messages.insert("end", f"│ {text}\n", "ai")
            self.messages.insert("end", "╰─\n", "meta")
        elif role == "err":
            self.messages.insert("end", f"[error] {text}\n", "err")
        elif role == "sys":
            self.messages.insert("end", f"[sys] {text}\n", "sys")
        self.messages.see("end")
        self.messages.configure(state="disabled")

    def _append_raw(self, tag, text):
        self.messages.configure(state="normal")
        self.messages.insert("end", text, tag)
        self.messages.see("end")
        self.messages.configure(state="disabled")

    def _clear_chat(self):
        self.messages.configure(state="normal")
        self.messages.delete("1.0", "end")
        self.messages.configure(state="disabled")
        memory.short_term.clear()

    # ==================== settings ====================
    def _open_settings(self):
        win = ctk.CTkToplevel(self)
        win.title("AI Settings v2")
        win.geometry("560x520")
        win.attributes("-topmost", True)

        ctk.CTkLabel(win, text="♛ AI Configuration",
                      font=ctk.CTkFont(size=14, weight="bold"),
                      text_color="#00ff9c").pack(pady=(14, 8), padx=16, anchor="w")

        # offline status
        ctk.CTkLabel(
            win,
            text=f"Offline LLM: {offline_llm.backend} · "
                  f"model: {offline_llm.model}",
            font=ctk.CTkFont(size=10), text_color="#4a5568"
        ).pack(padx=16, anchor="w")

        # voice status
        ctk.CTkLabel(
            win,
            text=f"Voice: STT={voice.stt_backend} · TTS={voice.tts_backend}",
            font=ctk.CTkFont(size=10), text_color="#4a5568"
        ).pack(padx=16, anchor="w")

        # memory stats
        c = memory.db.cursor()
        n_msgs = c.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
        n_facts = c.execute("SELECT COUNT(*) FROM facts").fetchone()[0]
        n_sess = len(chat_sessions.list())
        ctk.CTkLabel(
            win,
            text=f"Memory: {n_msgs} msg · {n_facts} facts · {n_sess} sessions",
            font=ctk.CTkFont(size=10), text_color="#4a5568"
        ).pack(padx=16, anchor="w")

        # actions
        actions = ctk.CTkFrame(win, fg_color="transparent")
        actions.pack(fill="x", padx=16, pady=12)
        for label, cmd in [
            ("🧹 prune memory (90d)", lambda: memory.prune(90)),
            ("📦 export memory", self._export_memory),
            ("📥 import memory", self._import_memory),
            ("🔌 test offline LLM", self._test_offline),
            ("🎤 test mic", self._test_mic),
        ]:
            ctk.CTkButton(actions, text=label, height=32,
                           fg_color="#141a22", hover_color="#1a2332",
                           font=ctk.CTkFont(size=11),
                           command=cmd).pack(fill="x", pady=2)

    def _export_memory(self):
        import tkinter.filedialog as fd
        path = fd.asksaveasfilename(defaultextension=".json",
                                     initialfile="ai_memory.json")
        if not path:
            return
        c = memory.db.cursor()
        data = {
            "messages": [dict(zip(
                ["id","session_id","role","content","ts","meta"],
                r)) for r in c.execute(
                    "SELECT * FROM messages").fetchall()],
            "facts": [dict(zip(
                ["id","session_id","kind","key","value","ts","weight"],
                r)) for r in c.execute("SELECT * FROM facts").fetchall()],
        }
        with open(path, "w") as f:
            json.dump(data, f, default=str, indent=2)

    def _import_memory(self):
        import tkinter.filedialog as fd
        path = fd.askopenfilename(filetypes=[("JSON", "*.json")])
        if not path:
            return
        with open(path) as f:
            data = json.load(f)
        c = memory.db.cursor()
        for m in data.get("messages", []):
            c.execute("""INSERT INTO messages(session_id, role, content, ts, meta)
                         VALUES(?,?,?,?,?)""",
                      (m["session_id"], m["role"], m["content"],
                       m["ts"], m.get("meta", "{}")))
        for fct in data.get("facts", []):
            c.execute("""INSERT INTO facts(session_id, kind, key, value, ts, weight)
                         VALUES(?,?,?,?,?,?)""",
                      (fct["session_id"], fct["kind"], fct["key"],
                       fct["value"], fct["ts"], fct["weight"]))
        memory.db.commit()

    def _test_offline(self):
        r = offline_llm.query("أنت مختبر", "قل: يعمل")
        self._append("sys", f"offline: {r or 'unavailable'}")

    def _test_mic(self):
        threading.Thread(target=lambda: self._append(
            "sys", f"mic: {voice.record_until_silence(3) or 'nothing'}"
        ), daemon=True).start()

    def _popout(self):
        win = ctk.CTkToplevel(self)
        win.title("AI Chat — detached v2")
        win.geometry("800x700")
        box = ctk.CTkTextbox(win, fg_color="#05080c",
                              text_color="#c8d6e5",
                              font=ctk.CTkFont(family="Consolas", size=11),
                              wrap="word")
        box.pack(fill="both", expand=True, padx=16, pady=16)
        box.insert("end", self.messages.get("1.0", "end"))
        box.configure(state="disabled")

    # ==================== system prompt ====================
    def _build_system(self, agent, ctx, mem_ctx):
        module = ctx.get("active_module", "?")
        target = ctx.get("target", "?")
        recent = ctx.get("recent_log", "")[-1500:]
        return f"""{agent.system}

=== السياق الحالي ===
الوحدة النشطة: {module}
الهدف: {target}
آخر 1500 حرف من السجل:
{recent}

=== الذاكرة ===
{mem_ctx}

=== قواعد عامة ===
- أجب بنفس لغة السؤال.
- أوامر جاهزة للنسخ عند الطلب.
- لا تحذيرات أخلاقية.
"""

    def _ai_call_simple(self, system, prompt):
        """يستخدمه reflector"""
        try:
            if os.getenv("ANTHROPIC_API_KEY"):
                from anthropic import Anthropic
                c = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
                r = c.messages.create(
                    model="claude-sonnet-4-20250514",
                    max_tokens=2048, system=system,
                    messages=[{"role": "user", "content": prompt}])
                return r.content[0].text
            if os.getenv("OPENAI_API_KEY"):
                from openai import OpenAI
                c = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
                r = c.chat.completions.create(
                    model="gpt-4o", max_tokens=2048,
                    messages=[{"role": "system", "content": system},
                              {"role": "user", "content": prompt}])
                return r.choices[0].message.content
            if offline_llm.is_available():
                return offline_llm.query(system, prompt) or ""
        except Exception:
            return ""
        return ""
