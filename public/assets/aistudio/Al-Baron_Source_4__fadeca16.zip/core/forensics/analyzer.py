# language: Python, file: core/forensics/analyzer.py
# Evidence analyzer — IOC extraction, anomaly detection
import re
import json
from datetime import datetime
from typing import List, Dict


class EvidenceAnalyzer:
    """
    يحلل الأدلة:
      - يستخرج IOCs (IPs, hashes, URLs, emails)
      - يكشف anomalies (brute force, reverse shells, persistence)
    """

    IOC_PATTERNS = {
        "ipv4": r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
        "ipv6": r"\b(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}\b",
        "sha256": r"\b[a-fA-F0-9]{64}\b",
        "sha1": r"\b[a-fA-F0-9]{40}\b",
        "md5": r"\b[a-fA-F0-9]{32}\b",
        "domain": r"\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}\b",
        "email": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b",
        "url": r"https?://[^\s]+",
        "cve": r"CVE-\d{4}-\d{4,7}",
    }

    ANOMALY_PATTERNS = {
        "brute_force": [
            r"Failed password for .* from (\S+)",
            r"authentication failure.*rhost=(\S+)",
        ],
        "reverse_shell": [
            r"bash -i .*>&.*\/dev\/tcp",
            r"nc .* -e \/bin\/(?:ba)?sh",
            r"python.*socket.*connect",
        ],
        "persistence": [
            r"crontab.*@reboot",
            r"systemd.*\[Service\].*ExecStart",
            r"reg add.*\\Run",
        ],
        "lateral_movement": [
            r"Accepted.*for .* from (\S+)",
            r"smb.*\$\s+Admin",
        ],
        "credential_dump": [
            r"mimikatz.*sekurlsa",
            r"procdump.*lsass",
        ],
    }

    def extract_iocs(self, content: str) -> Dict[str, List[str]]:
        """يستخرج IOCs من نص"""
        iocs = {}
        for kind, pattern in self.IOC_PATTERNS.items():
            matches = set(re.findall(pattern, content))
            # filter out obvious false positives
            if kind == "ipv4":
                matches = {m for m in matches
                             if not m.startswith(("127.", "0.", "255."))}
            if matches:
                iocs[kind] = sorted(matches)
        return iocs

    def detect_anomalies(self, content: str) -> List[dict]:
        """يكشف anomalies في نص"""
        anomalies = []
        for kind, patterns in self.ANOMALY_PATTERNS.items():
            for pattern in patterns:
                matches = re.findall(pattern, content, re.IGNORECASE)
                if matches:
                    anomalies.append({
                        "type": kind,
                        "pattern": pattern,
                        "matches": matches[:10],
                        "count": len(matches),
                    })
        return anomalies

    def analyze_case(self, case: dict) -> dict:
        """يحلل case كامل"""
        all_iocs = {}
        all_anomalies = []

        for evidence in case.get("evidence", []):
            path = evidence.get("stored_path")
            if not path:
                continue
            try:
                with open(path, "r", errors="ignore") as f:
                    content = f.read()

                # extract iocs
                iocs = self.extract_iocs(content)
                for kind, values in iocs.items():
                    all_iocs.setdefault(kind, set()).update(values)

                # detect anomalies
                anomalies = self.detect_anomalies(content)
                for a in anomalies:
                    a["source"] = evidence.get("name", "?")
                    all_anomalies.append(a)
            except Exception:
                continue

        # dedupe iocs
        iocs_result = {
            k: sorted(list(v)) for k, v in all_iocs.items()
        }

        # group anomalies by type
        anomaly_groups = {}
        for a in all_anomalies:
            anomaly_groups.setdefault(a["type"], []).append(a)

        return {
            "case_id": case.get("id"),
            "host": case.get("host"),
            "analyzed_at": datetime.now().isoformat(),
            "iocs": iocs_result,
            "anomalies": {
                kind: {
                    "count": sum(a["count"] for a in items),
                    "sources": list(set(a["source"] for a in items)),
                    "samples": [m for a in items for m in a["matches"]][:10],
                }
                for kind, items in anomaly_groups.items()
            },
            "risk_score": self._compute_risk(anomaly_groups),
            "risk_level": self._risk_level(anomaly_groups),
        }

    def _compute_risk(self, anomaly_groups: dict) -> int:
        """يحسب risk score 0-100"""
        score = 0
        weights = {
            "credential_dump": 40,
            "reverse_shell": 35,
            "lateral_movement": 25,
            "persistence": 20,
            "brute_force": 15,
        }
        for kind, items in anomaly_groups.items():
            score += weights.get(kind, 10) * len(items)
        return min(score, 100)

    def _risk_level(self, anomaly_groups: dict) -> str:
        score = self._compute_risk(anomaly_groups)
        if score >= 70:
            return "critical"
        elif score >= 40:
            return "high"
        elif score >= 20:
            return "medium"
        elif score > 0:
            return "low"
        return "clean"


analyzer = EvidenceAnalyzer()
