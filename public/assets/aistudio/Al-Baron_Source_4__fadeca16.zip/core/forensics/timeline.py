# language: Python, file: core/forensics/timeline.py
# Timeline builder — reconstructs events from evidence
import re
import os
import json
from datetime import datetime
from typing import List, Dict, Optional


class TimelineBuilder:
    """
    يبني timeline من الأدلة:
      - log entries (auth.log, syslog, wtmp)
      - file mtimes
      - process starts
    """

    # common log patterns
    LOG_PATTERNS = {
        "linux_auth": [
            # "Jan 15 10:23:45 host sshd[123]: Accepted password for root"
            (r"(\w+\s+\d+\s+\d+:\d+:\d+).*?(\S+)\s+(\S+?)(?:\[(\d+)\])?: (.+)",
             "auth"),
        ],
        "linux_generic": [
            (r"(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}).*?(\S+): (.+)",
             "generic"),
        ],
        "windows_event": [
            (r"(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}).*?(EventID[:\s]+(\d+))",
             "windows"),
        ],
    }

    def __init__(self):
        self.events: List[dict] = []

    def parse_log(self, content: str, source: str,
                    pattern_set: str = "linux_generic") -> List[dict]:
        """يستخرج events من log"""
        events = []
        patterns = self.LOG_PATTERNS.get(pattern_set, [])

        for line in content.splitlines():
            for pattern, kind in patterns:
                m = re.search(pattern, line)
                if m:
                    event = {
                        "time": m.group(1),
                        "source": source,
                        "kind": kind,
                        "raw": line[:500],
                        "parsed": list(m.groups()),
                    }
                    events.append(event)
                    break
            else:
                # unparsed line
                if line.strip() and any(
                    kw in line.lower() for kw in [
                        "error", "warn", "fail", "denied",
                        "success", "accept", "login"
                    ]):
                    events.append({
                        "time": "unknown",
                        "source": source,
                        "kind": "unparsed",
                        "raw": line[:500],
                    })

        return events

    def build_from_case(self, case: dict) -> List[dict]:
        """يبني timeline من case"""
        events = []

        for evidence in case.get("evidence", []):
            try:
                # read content
                path = evidence.get("stored_path")
                if not path or not os.path.exists(path):
                    continue

                with open(path, "r", errors="ignore") as f:
                    content = f.read()

                # detect type
                kind = self._detect_log_type(evidence["name"])
                if kind:
                    parsed = self.parse_log(content, evidence["name"], kind)
                    events.extend(parsed)

                # add collection event
                events.append({
                    "time": evidence["collected_at"][:19],
                    "source": evidence["name"],
                    "kind": "collected",
                    "raw": f"Evidence collected ({evidence['size']} bytes)",
                })
            except Exception:
                continue

        # sort by time
        def _parse_time(t):
            try:
                # try multiple formats
                for fmt in [
                    "%Y-%m-%d %H:%M:%S",
                    "%Y-%m-%dT%H:%M:%S",
                    "%b %d %H:%M:%S",
                ]:
                    try:
                        return datetime.strptime(t[:19], fmt)
                    except Exception:
                        continue
                return datetime.max
            except Exception:
                return datetime.max

        events.sort(key=lambda e: _parse_time(e.get("time", "")))
        self.events = events
        return events

    def _detect_log_type(self, filename: str) -> str:
        """يحدد نوع log من اسم الملف"""
        name_lower = filename.lower()
        if "auth" in name_lower or "secure" in name_lower:
            return "linux_auth"
        if "syslog" in name_lower or "messages" in name_lower:
            return "linux_generic"
        if "event" in name_lower or "evtx" in name_lower:
            return "windows_event"
        return "linux_generic"

    def filter(self, **kwargs) -> List[dict]:
        """يصفّي events"""
        result = []
        for e in self.events:
            match = True
            for k, v in kwargs.items():
                if k == "source" and v not in e.get("source", ""):
                    match = False
                elif k == "kind" and v != e.get("kind"):
                    match = False
                elif k == "keyword":
                    if v.lower() not in e.get("raw", "").lower():
                        match = False
            if match:
                result.append(e)
        return result

    def export(self, path: str):
        """يصدّر timeline"""
        with open(path, "w") as f:
            json.dump(self.events, f, indent=2, default=str)


timeline_builder = TimelineBuilder()
