# language: Python, file: core/intel/misp.py
# MISP integration — threat intel sharing
import json
import os
from typing import List, Dict, Optional
from datetime import datetime


class MISPClient:
    """
    MISP (Malware Information Sharing Platform) client.
    - pull events
    - push findings
    """
    def __init__(self, url: str = None, api_key: str = None,
                  verify_ssl: bool = False):
        self.url = (url or os.getenv("MISP_URL", "")).rstrip("/")
        self.api_key = api_key or os.getenv("MISP_API_KEY", "")
        self.verify_ssl = verify_ssl
        self.session = None

    def _get(self, path: str, **params) -> dict:
        try:
            import httpx
            if not self.session:
                self.session = httpx.Client(
                    headers={"Authorization": self.api_key,
                              "Accept": "application/json"},
                    verify=self.verify_ssl, timeout=30)
            r = self.session.get(f"{self.url}{path}", params=params)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            return {"error": str(e)}

    def _post(self, path: str, payload: dict) -> dict:
        try:
            import httpx
            if not self.session:
                self.session = httpx.Client(
                    headers={"Authorization": self.api_key,
                              "Accept": "application/json",
                              "Content-Type": "application/json"},
                    verify=self.verify_ssl, timeout=30)
            r = self.session.post(f"{self.url}{path}", json=payload)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            return {"error": str(e)}

    def test_connection(self) -> dict:
        """يتحقق من الاتصال"""
        result = self._get("/users/view/me")
        if "error" in result:
            return {"connected": False, "error": result["error"]}
        return {
            "connected": True,
            "user": result.get("User", {}).get("email", "?"),
            "org": result.get("Organisation", {}).get("name", "?"),
        }

    def search_ioc(self, value: str, ioc_type: str = "ip") -> List[dict]:
        """يبحث عن IOC في MISP"""
        r = self._get("/attributes/restSearch", value=value, type=ioc_type)
        if "error" in r:
            return []
        return r.get("response", {}).get("Attribute", [])

    def search_cve(self, cve: str) -> List[dict]:
        return self.search_ioc(cve, "vulnerability")

    def push_event(self, title: str, info: str,
                    attributes: List[dict]) -> dict:
        """ينشئ event في MISP"""
        payload = {
            "Event": {
                "info": title,
                "distribution": "0",
                "threat_level_id": "2",
                "analysis": "2",
                "Attribute": attributes,
            }
        }
        return self._post("/events/add", payload)

    def recent_events(self, limit: int = 20) -> List[dict]:
        r = self._get("/events/restSearch", limit=limit, page=1)
        if "error" in r:
            return []
        return r.get("response", [])


class VirusTotalClient:
    """VirusTotal API — hash/IP/domain reputation"""
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv("VT_API_KEY", "")
        self.session = None

    def _get(self, path: str) -> dict:
        try:
            import httpx
            if not self.session:
                self.session = httpx.Client(
                    headers={"x-apikey": self.api_key},
                    timeout=30)
            r = self.session.get(f"https://www.virustotal.com/api/v3{path}")
            r.raise_for_status()
            return r.json()
        except Exception as e:
            return {"error": str(e)}

    def test_connection(self) -> dict:
        result = self._get("/users/current")
        if "error" in result:
            return {"connected": False, "error": result["error"]}
        data = result.get("data", {}).get("attributes", {})
        return {
            "connected": True,
            "quotas": data.get("quotas", {}),
        }

    def lookup_ip(self, ip: str) -> dict:
        return self._get(f"/ip_addresses/{ip}")

    def lookup_domain(self, domain: str) -> dict:
        return self._get(f"/domains/{domain}")

    def lookup_file(self, hash: str) -> dict:
        return self._get(f"/files/{hash}")

    def lookup_url(self, url: str) -> dict:
        import base64
        url_id = base64.urlsafe_b64encode(url.encode()).decode().rstrip("=")
        return self._get(f"/urls/{url_id}")


class ShodanClient:
    """Shodan API — internet-facing asset discovery"""
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv("SHODAN_API_KEY", "")
        self.session = None

    def _get(self, path: str, **params) -> dict:
        try:
            import httpx
            if not self.session:
                self.session = httpx.Client(timeout=30)
            params["key"] = self.api_key
            r = self.session.get(f"https://api.shodan.io{path}", params=params)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            return {"error": str(e)}

    def test_connection(self) -> dict:
        result = self._get("/api-info")
        if "error" in result:
            return {"connected": False, "error": result["error"]}
        return {
            "connected": True,
            "query_credits": result.get("query_credits"),
            "scan_credits": result.get("scan_credits"),
        }

    def host_info(self, ip: str) -> dict:
        return self._get(f"/shodan/host/{ip}")

    def search(self, query: str, limit: int = 100) -> dict:
        return self._get("/shodan/host/search",
                          query=query, limit=limit)

    def dns_resolve(self, hostnames: List[str]) -> dict:
        return self._get("/dns/resolve",
                          hostnames=",".join(hostnames))

    def my_ip(self) -> dict:
        return self._get("/tools/myip")
