# language: Python, file: core/intel/aggregator.py
# Intel aggregator — combines MISP + VT + Shodan
from typing import List, Dict
from datetime import datetime


class IntelAggregator:
    """يجمع معلومات من كل المصادر"""
    def __init__(self):
        from core.intel.misp import MISPClient, VirusTotalClient, ShodanClient
        self.misp = MISPClient()
        self.vt = VirusTotalClient()
        self.shodan = ShodanClient()
        self.cache = {}

    def lookup_ip(self, ip: str) -> dict:
        """lookup IP في كل المصادر"""
        if ip in self.cache:
            return self.cache[ip]

        result = {
            "ip": ip,
            "looked_up": datetime.now().isoformat(),
            "sources": {},
        }

        # MISP
        try:
            misp_results = self.misp.search_ioc(ip, "ip-dst")
            if misp_results:
                result["sources"]["misp"] = {
                    "count": len(misp_results),
                    "events": [r.get("Event", {}).get("info", "")
                                for r in misp_results[:5]],
                }
        except Exception as e:
            result["sources"]["misp"] = {"error": str(e)}

        # VT
        try:
            vt = self.vt.lookup_ip(ip)
            if "error" not in vt:
                attrs = vt.get("data", {}).get("attributes", {})
                stats = attrs.get("last_analysis_stats", {})
                result["sources"]["virustotal"] = {
                    "malicious": stats.get("malicious", 0),
                    "suspicious": stats.get("suspicious", 0),
                    "harmless": stats.get("harmless", 0),
                    "reputation": attrs.get("reputation", 0),
                }
        except Exception as e:
            result["sources"]["virustotal"] = {"error": str(e)}

        # Shodan
        try:
            sh = self.shodan.host_info(ip)
            if "error" not in sh:
                result["sources"]["shodan"] = {
                    "os": sh.get("os"),
                    "org": sh.get("org"),
                    "ports": sh.get("ports", []),
                    "hostnames": sh.get("hostnames", []),
                    "vulns": sh.get("vulns", []),
                }
        except Exception as e:
            result["sources"]["shodan"] = {"error": str(e)}

        # aggregate score
        score = 0
        if "virustotal" in result["sources"]:
            vt = result["sources"]["virustotal"]
            score += vt.get("malicious", 0) * 10
            score += vt.get("suspicious", 0) * 5
        if "misp" in result["sources"]:
            score += result["sources"]["misp"].get("count", 0) * 15
        result["threat_score"] = min(score, 100)
        result["verdict"] = (
            "malicious" if score > 50 else
            "suspicious" if score > 20 else
            "clean" if score == 0 else
            "unknown"
        )

        self.cache[ip] = result
        return result

    def test_all(self) -> dict:
        return {
            "misp": self.misp.test_connection(),
            "virustotal": self.vt.test_connection(),
            "shodan": self.shodan.test_connection(),
        }
