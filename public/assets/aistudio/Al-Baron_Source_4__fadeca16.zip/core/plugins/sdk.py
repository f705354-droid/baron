# language: Python, file: core/plugins/sdk.py
# Plugin SDK — base classes + helpers for plugin authors
import json
import os
from datetime import datetime


class Al-BaronPlugin:
    """
    Base class for all plugins.
    Override any hook method.
    """
    # metadata (required)
    name = "unnamed"
    version = "0.0.0"
    author = "unknown"
    description = "no description"
    permissions = []  # ["sessions:read", "graph:write", ...]

    def __init__(self, ctx: dict):
        self.ctx = ctx
        self.log = ctx.get("log", print)

    # ==================== lifecycle ====================
    def register(self, ctx: dict):
        """called once when plugin loads"""
        pass

    def unload(self):
        """called on shutdown"""
        pass

    # ==================== hooks ====================
    def on_host_discovered(self, host_ip: str, props: dict):
        """called when a new host appears in graph"""
        pass

    def on_session_opened(self, sid: str, host_ip: str):
        """called when C2 session opens"""
        pass

    def on_credential_found(self, user: str, source: str):
        """called when credential is harvested"""
        pass

    def on_vuln_found(self, cve: str, host_ip: str):
        """called when vulnerability is identified"""
        pass

    def on_task_sent(self, sid: str, task: str):
        """called when task dispatched to session"""
        pass

    def on_task_result(self, sid: str, result: str):
        """called when task returns"""
        pass

    def on_report_generated(self, path: str):
        """called after PDF report is created"""
        pass

    # ==================== extension hooks ====================
    def add_ui_tab(self) -> dict:
        """
        Returns a dict describing a UI tab.
        {"title": str, "render": callable}
        """
        return None

    def get_detection_rules(self) -> list:
        """Returns additional detection rules for blue team"""
        return []

    def get_apt_profile(self) -> dict:
        """Returns an APT profile to add to emulator"""
        return None
