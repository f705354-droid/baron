# language: Python, file: core/plugins/loader.py
# Plugin loader — dynamic loading + sandboxing
import os
import json
import importlib.util
import inspect
import hashlib
from typing import List, Dict


PLUGIN_DIR = "plugins"


class PluginLoader:
    """
    - يكتشف plugins في plugins/*/
    - يحمّل plugin.json
    - يتحقق من الصلاحيات
    - ينشئ instance من Al-BaronPlugin
    - يسجل hooks
    """
    def __init__(self, app=None):
        self.app = app
        self.plugins: Dict[str, dict] = {}
        os.makedirs(PLUGIN_DIR, exist_ok=True)

    def discover(self) -> List[dict]:
        """يجد كل plugin في plugins/"""
        found = []
        for name in os.listdir(PLUGIN_DIR):
            plugin_dir = os.path.join(PLUGIN_DIR, name)
            if not os.path.isdir(plugin_dir):
                continue
            manifest_path = os.path.join(plugin_dir, "plugin.json")
            if not os.path.exists(manifest_path):
                continue
            try:
                with open(manifest_path) as f:
                    manifest = json.load(f)
                manifest["_dir"] = plugin_dir
                manifest["_name"] = name
                found.append(manifest)
            except Exception as e:
                print(f"[plugin] {name}: {e}")
        return found

    def load(self, name: str, app=None) -> Optional[dict]:
        """يحمّل plugin واحد"""
        plugin_dir = os.path.join(PLUGIN_DIR, name)
        if not os.path.isdir(plugin_dir):
            return {"error": "plugin not found"}

        manifest_path = os.path.join(plugin_dir, "plugin.json")
        if not os.path.exists(manifest_path):
            return {"error": "no plugin.json"}

        with open(manifest_path) as f:
            manifest = json.load(f)

        # validate
        required = ["name", "version", "entrypoint", "permissions"]
        for field in required:
            if field not in manifest:
                return {"error": f"missing field: {field}"}

        entrypoint = os.path.join(plugin_dir, manifest["entrypoint"])
        if not os.path.exists(entrypoint):
            return {"error": f"entrypoint not found: {entrypoint}"}

        # dynamic import
        try:
            spec = importlib.util.spec_from_file_location(
                f"plugin_{name}", entrypoint)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
        except Exception as e:
            return {"error": f"import failed: {e}"}

        # find plugin class
        plugin_class = None
        for _, obj in inspect.getmembers(module, inspect.isclass):
            if issubclass(obj, module.__dict__.get("Al-BaronPlugin",
                                                     object)) and \
               obj.__name__ != "Al-BaronPlugin":
                plugin_class = obj
                break

        if not plugin_class:
            # fallback: check for hooks directly in module
            plugin_class = _ModuleAsPlugin(module)

        # create context
        ctx = self._build_context(manifest, app)

        # instantiate
        try:
            instance = plugin_class(ctx) if isinstance(
                plugin_class, type) else plugin_class
        except Exception as e:
            return {"error": f"init failed: {e}"}

        # register
        try:
            if hasattr(instance, "register"):
                instance.register(ctx)
        except Exception as e:
            return {"error": f"register failed: {e}"}

        self.plugins[name] = {
            "manifest": manifest,
            "instance": instance,
            "loaded_at": __import__("datetime").datetime.now().isoformat(),
        }
        return {"status": "loaded", "name": name}

    def _build_context(self, manifest: dict, app=None) -> dict:
        """ينشئ context محدود للـplugin"""
        perms = set(manifest.get("permissions", []))
        ctx = {
            "log": lambda msg: print(f"[{manifest['name']}] {msg}"),
            "app": app,
        }

        if "graph:read" in perms:
            from core.graph.graph_db import graph
            ctx["graph"] = graph

        if "graph:write" in perms:
            from core.graph.graph_db import graph
            ctx["graph_write"] = graph

        if "detection:write" in perms:
            from core.blue.detection_engine import engine
            ctx["detection_engine"] = engine

        if "ai:query" in perms:
            try:
                from core.ai_assistant import AIAssistant
                ctx["ai"] = AIAssistant()
            except Exception:
                pass

        return ctx

    def dispatch_hook(self, hook_name: str, *args, **kwargs):
        """يستدعي hook على كل plugin"""
        for name, plugin in self.plugins.items():
            instance = plugin["instance"]
            method = getattr(instance, hook_name, None)
            if method:
                try:
                    method(*args, **kwargs)
                except Exception as e:
                    print(f"[plugin:{name}] {hook_name}: {e}")

    def unload_all(self):
        for name, plugin in self.plugins.items():
            try:
                instance = plugin["instance"]
                if hasattr(instance, "unload"):
                    instance.unload()
            except Exception:
                pass
        self.plugins.clear()

    def list_loaded(self) -> list:
        return [
            {
                "name": name,
                "manifest": plugin["manifest"],
                "loaded_at": plugin["loaded_at"],
            }
            for name, plugin in self.plugins.items()
        ]


class _ModuleAsPlugin:
    """يحول module to plugin instance"""
    def __init__(self, module):
        self.module = module

    def __getattr__(self, name):
        return getattr(self.module, name, None)


loader = PluginLoader()
