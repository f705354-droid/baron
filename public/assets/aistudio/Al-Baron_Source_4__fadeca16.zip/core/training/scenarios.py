# language: Python, file: core/training/scenarios.py
# Training scenarios — CTF-style challenges
from datetime import datetime
from typing import List, Dict


class Scenario:
    """
    سيناريو تدريبي كامل
    """
    def __init__(self, name: str, difficulty: str, category: str,
                  description: str, objectives: List[dict],
                  docker_compose: str = "", hints: List[str] = None):
        self.name = name
        self.difficulty = difficulty     # easy, medium, hard, expert
        self.category = category         # web, ad, network, forensics
        self.description = description
        self.objectives = objectives
        self.docker_compose = docker_compose
        self.hints = hints or []
        self.created = datetime.now().isoformat()

    def to_dict(self):
        return {
            "name": self.name,
            "difficulty": self.difficulty,
            "category": self.category,
            "description": self.description,
            "objectives": self.objectives,
            "hints": self.hints,
        }


SCENARIOS = {
    "web_easy_sqli": Scenario(
        name="Web - SQL Injection Basics",
        difficulty="easy",
        category="web",
        description="Find and exploit a SQL injection vulnerability to "
                     "retrieve the admin password hash from the database.",
        objectives=[
            {"id": 1, "task": "Identify vulnerable parameter",
              "points": 20},
            {"id": 2, "task": "Confirm SQL injection",
              "points": 20},
            {"id": 3, "task": "Extract table names",
              "points": 20},
            {"id": 4, "task": "Extract admin password hash",
              "points": 30},
            {"id": 5, "task": "Crack the password hash",
              "points": 10},
        ],
        docker_compose='''
services:
  vulnweb:
    image: vulnerables/web-dvwa
    ports:
      - "8081:80"
  db:
    image: mysql:5.7
    environment:
      MYSQL_ROOT_PASSWORD: root
''',
        hints=[
            "Start with a single quote in login field",
            "Try: ' OR 1=1-- -",
            "Check the Login page and the vulnerable parameter",
        ],
    ),

    "web_medium_ssrf": Scenario(
        name="Web - SSRF to Cloud",
        difficulty="medium",
        category="web",
        description="Exploit SSRF in a URL fetcher to reach internal "
                     "cloud metadata and steal AWS credentials.",
        objectives=[
            {"id": 1, "task": "Discover SSRF endpoint", "points": 20},
            {"id": 2, "task": "Fetch IMDSv1 metadata", "points": 30},
            {"id": 3, "task": "Steal AWS credentials", "points": 30},
            {"id": 4, "task": "Use credentials to access S3", "points": 20},
        ],
        docker_compose='''
services:
  ssrfweb:
    image: vulhub/ssrf
    ports:
      - "8082:80"
  # optional: localstack for cloud simulation
''',
        hints=[
            "The URL fetcher has no blacklist for internal IPs",
            "AWS metadata: 169.254.169.254",
            "Try: http://169.254.169.254/latest/meta-data/",
        ],
    ),

    "ad_hard_kerberoast": Scenario(
        name="Active Directory - Kerberoasting",
        difficulty="hard",
        category="ad",
        description="Enumerate AD, identify service accounts with SPNs, "
                     "request TGS tickets, and crack them to gain access.",
        objectives=[
            {"id": 1, "task": "Enumerate domain users", "points": 15},
            {"id": 2, "task": "Find Kerberoastable accounts", "points": 20},
            {"id": 3, "task": "Request TGS tickets", "points": 25},
            {"id": 4, "task": "Crack service account password", "points": 30},
            {"id": 5, "task": "Use cracked creds to pivot", "points": 10},
        ],
        docker_compose='''
# Use GOAD (Game of Active Directory) or similar
# Or use this: https://github.com/Orange-Cyberdefense/GOAD
''',
        hints=[
            "Use impacket-GetUserSPNs or Rubeus",
            "Service accounts with SPNs are vulnerable",
            "Crack the hash with hashcat -m 13100",
        ],
    ),

    "network_medium_mitm": Scenario(
        name="Network - MITM & Credential Capture",
        difficulty="medium",
        category="network",
        description="Perform ARP poisoning to MITM traffic, capture "
                     "plaintext credentials, and use them for access.",
        objectives=[
            {"id": 1, "task": "Enable IP forwarding", "points": 10},
            {"id": 2, "task": "Perform ARP poisoning", "points": 20},
            {"id": 3, "task": "Capture HTTP traffic", "points": 25},
            {"id": 4, "task": "Extract credentials", "points": 25},
            {"id": 5, "task": "Use creds to access target", "points": 20},
        ],
        docker_compose='''
services:
  victim:
    image: ubuntu:22.04
    command: sleep infinity
  target:
    image: vulnerables/web-dvwa
    ports:
      - "8083:80"
''',
        hints=[
            "Sysctl net.ipv4.ip_forward=1",
            "Try arpspoof or bettercap",
            "Filter traffic: tcp port 80",
        ],
    ),

    "expert_full_chain": Scenario(
        name="Expert - Full Attack Chain",
        difficulty="expert",
        category="network",
        description="Complete chain: recon → web exploit → lateral → "
                     "domain admin. Everything in one scenario.",
        objectives=[
            {"id": 1, "task": "Initial recon", "points": 10},
            {"id": 2, "task": "Web RCE", "points": 15},
            {"id": 3, "task": "Reverse shell", "points": 15},
            {"id": 4, "task": "Privilege escalation", "points": 20},
            {"id": 5, "task": "Lateral movement to DC", "points": 20},
            {"id": 6, "task": "DCSync or Kerberoast", "points": 20},
        ],
        docker_compose='''
# Complex setup - multiple VMs
# See: https://github.com/Orange-Cyberdefense/GOAD
''',
        hints=[
            "Start with nmap full scan",
            "Web app first, then pivot",
            "Check BloodHound for attack paths",
        ],
    ),
}
