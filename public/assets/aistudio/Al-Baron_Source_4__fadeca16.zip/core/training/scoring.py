# language: Python, file: core/training/scoring.py
# Training scoring — track objectives, time, progress
import sqlite3
import os
from datetime import datetime


class ScoreTracker:
    """
    يتتبع تقدم المتدرب في كل سيناريو
    """
    def __init__(self, db_path: str = "~/.albaron/training.db"):
        self.db_path = os.path.expanduser(db_path)
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self.db = sqlite3.connect(self.db_path, check_same_thread=False)
        self._init_schema()

    def _init_schema(self):
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS attempts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scenario TEXT,
            operator TEXT,
            started_at TIMESTAMP,
            completed_at TIMESTAMP,
            score INTEGER,
            total_points INTEGER,
            status TEXT DEFAULT 'in_progress'
        );

        CREATE TABLE IF NOT EXISTS objective_completions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            attempt_id INTEGER,
            objective_id INTEGER,
            points INTEGER,
            completed_at TIMESTAMP,
            FOREIGN KEY(attempt_id) REFERENCES attempts(id)
        );
        """)
        self.db.commit()

    def start_attempt(self, scenario: str, operator: str,
                       total_points: int) -> int:
        self.db.execute("""
            INSERT INTO attempts (scenario, operator, started_at, total_points)
            VALUES (?, ?, ?, ?)
        """, (scenario, operator, datetime.now().isoformat(),
                total_points))
        self.db.commit()
        return self.db.execute(
            "SELECT last_insert_rowid()").fetchone()[0]

    def complete_objective(self, attempt_id: int,
                            objective_id: int,
                            points: int) -> dict:
        # check if already completed
        existing = self.db.execute("""
            SELECT id FROM objective_completions
            WHERE attempt_id=? AND objective_id=?
        """, (attempt_id, objective_id)).fetchone()

        if existing:
            return {"status": "already_completed"}

        self.db.execute("""
            INSERT INTO objective_completions
            (attempt_id, objective_id, points, completed_at)
            VALUES (?, ?, ?, ?)
        """, (attempt_id, objective_id, points,
                datetime.now().isoformat()))
        self.db.commit()

        # get current score
        total = self.db.execute("""
            SELECT SUM(points) FROM objective_completions
            WHERE attempt_id=?
        """, (attempt_id,)).fetchone()[0] or 0

        return {"status": "completed", "current_score": total}

    def finish_attempt(self, attempt_id: int) -> dict:
        # compute total
        total = self.db.execute("""
            SELECT SUM(points) FROM objective_completions
            WHERE attempt_id=?
        """, (attempt_id,)).fetchone()[0] or 0

        self.db.execute("""
            UPDATE attempts
            SET completed_at=?, score=?, status='completed'
            WHERE id=?
        """, (datetime.now().isoformat(), total, attempt_id))
        self.db.commit()

        attempt = self.db.execute("""
            SELECT scenario, operator, started_at, total_points
            FROM attempts WHERE id=?
        """, (attempt_id,)).fetchone()

        return {
            "attempt_id": attempt_id,
            "scenario": attempt[0],
            "operator": attempt[1],
            "score": total,
            "total_points": attempt[3],
            "percentage": round(total / attempt[3] * 100, 1) if attempt[3] else 0,
        }

    def get_leaderboard(self, limit: int = 10) -> list:
        rows = self.db.execute("""
            SELECT operator, scenario, score, total_points,
                   started_at, completed_at
            FROM attempts WHERE status='completed'
            ORDER BY score DESC LIMIT ?
        """, (limit,)).fetchall()

        return [
            {
                "operator": r[0],
                "scenario": r[1],
                "score": r[2],
                "total": r[3],
                "percentage": round(r[2] / r[3] * 100, 1) if r[3] else 0,
                "started": r[4],
                "completed": r[5],
            }
            for r in rows
        ]

    def get_attempt_status(self, attempt_id: int) -> dict:
        row = self.db.execute("""
            SELECT scenario, operator, score, total_points, status
            FROM attempts WHERE id=?
        """, (attempt_id,)).fetchone()

        if not row:
            return {"error": "not found"}

        completed = self.db.execute("""
            SELECT objective_id FROM objective_completions
            WHERE attempt_id=?
        """, (attempt_id,)).fetchall()

        return {
            "attempt_id": attempt_id,
            "scenario": row[0],
            "operator": row[1],
            "score": row[2],
            "total_points": row[3],
            "status": row[4],
            "completed_objectives": [c[0] for c in completed],
        }


tracker = ScoreTracker()
