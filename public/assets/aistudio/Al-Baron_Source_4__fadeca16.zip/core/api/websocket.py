# language: Python, file: core/api/websocket.py
# WebSocket handlers
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
import json
import asyncio
from datetime import datetime

router = APIRouter()


class WSHub:
    def __init__(self):
        self.connections = {}

    async def connect(self, channel: str, ws: WebSocket):
        await ws.accept()
        self.connections.setdefault(channel, set()).add(ws)

    def disconnect(self, channel: str, ws: WebSocket):
        conns = self.connections.get(channel, set())
        conns.discard(ws)
        if not conns:
            self.connections.pop(channel, None)

    async def broadcast(self, channel: str, event: dict):
        dead = []
        for ws in self.connections.get(channel, set()):
            try:
                await ws.send_json(event)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(channel, ws)


ws_hub = WSHub()


@router.websocket("/ws/events")
async def events_ws(websocket: WebSocket):
    """WebSocket للأحداث الحية"""
    await ws_hub.connect("events", websocket)
    try:
        # send initial state
        from core.graph.graph_db import graph
        await websocket.send_json({
            "type": "connected",
            "timestamp": datetime.now().isoformat(),
            "stats": graph.get_attack_surface(),
        })

        # periodic updates
        while True:
            try:
                # receive client messages
                msg = await asyncio.wait_for(
                    websocket.receive_text(), timeout=5)
                data = json.loads(msg)
                if data.get("type") == "ping":
                    await websocket.send_json({"type": "pong"})
            except asyncio.TimeoutError:
                # send stats update
                from core.graph.graph_db import graph
                await websocket.send_json({
                    "type": "stats",
                    "timestamp": datetime.now().isoformat(),
                    "data": graph.get_attack_surface(),
                })
    except WebSocketDisconnect:
        pass
    finally:
        ws_hub.disconnect("events", websocket)


@router.websocket("/ws/terminal/{sid}")
async def terminal_ws(websocket: WebSocket, sid: str):
    """WebSocket للتحكم في الجلسة"""
    await ws_hub.connect(f"terminal:{sid}", websocket)
    try:
        # initial
        await websocket.send_json({
            "type": "connected",
            "session_id": sid,
        })

        while True:
            msg = await websocket.receive_text()
            data = json.loads(msg)
            if data.get("type") == "command":
                cmd = data.get("command", "")
                # dispatch to C2
                # in production: call c2_bridge
                await websocket.send_json({
                    "type": "output",
                    "command": cmd,
                    "output": f"[simulated] {cmd}",
                    "timestamp": datetime.now().isoformat(),
                })
    except WebSocketDisconnect:
        pass
    finally:
        ws_hub.disconnect(f"terminal:{sid}", websocket)


websocket_router = router
