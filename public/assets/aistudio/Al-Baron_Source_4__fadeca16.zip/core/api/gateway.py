# language: Python, file: core/api/gateway.py
# API Gateway — REST + GraphQL + WebSocket
from fastapi import FastAPI, Request, WebSocket, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import asyncio
import json
import os
from datetime import datetime, timedelta
from typing import Dict, Set


class Gateway:
    """
    API Gateway — يجمع:
      - REST endpoints
      - GraphQL
      - WebSocket (real-time events)
      - JWT auth
      - Rate limiting
    """
    def __init__(self, app=None):
        self.shadow_app = app
        self.fastapi = FastAPI(
            title="Al-Baron API",
            version="4.0",
            description="The Baron Cyber Empire API"
        )
        self._setup_cors()
        self._setup_middleware()
        self._setup_routes()
        self.ws_connections: Dict[str, Set[WebSocket]] = {}

    def _setup_cors(self):
        self.fastapi.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    def _setup_middleware(self):
        @self.fastapi.middleware("http")
        async def auth_middleware(request: Request, call_next):
            # skip auth for public endpoints
            public_paths = ["/api/health", "/api/auth/login",
                            "/docs", "/openapi.json", "/api/graphql"]
            if any(request.url.path.startswith(p) for p in public_paths):
                return await call_next(request)

            token = request.headers.get("Authorization", "").replace(
                "Bearer ", "")
            if not token:
                return JSONResponse(
                    {"error": "missing token"}, status_code=401)

            from core.api.auth import decode_token
            payload = decode_token(token)
            if not payload:
                return JSONResponse(
                    {"error": "invalid token"}, status_code=401)

            request.state.user = payload
            return await call_next(request)

    def _setup_routes(self):
        from core.api.rest_routes import router as rest_router
        from core.api.graphql_schema import graphql_app
        from core.api.websocket import websocket_router
        from core.api.auth import router as auth_router

        self.fastapi.include_router(auth_router, prefix="/api/auth",
                                     tags=["auth"])
        self.fastapi.include_router(rest_router, prefix="/api",
                                     tags=["rest"])
        self.fastapi.include_router(websocket_router, tags=["websocket"])
        self.fastapi.mount("/api/graphql", graphql_app)

        @self.fastapi.get("/api/health")
        async def health():
            return {
                "status": "healthy",
                "version": "4.0",
                "timestamp": datetime.now().isoformat(),
            }

    def set_app(self, app):
        """يربط Al-Baron instance"""
        self.shadow_app = app

    def start(self, host: str = "0.0.0.0", port: int = 8000):
        import uvicorn
        uvicorn.run(self.fastapi, host=host, port=port,
                    log_level="info")


gateway = Gateway()
