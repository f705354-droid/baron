# language: Python, file: core/api/graphql_schema.py
# GraphQL schema
import strawberry
from strawberry.fastapi import GraphQLRouter
from typing import List, Optional
from core.graph.graph_db import graph


@strawberry.type
class Node:
    id: int
    type: str
    key: str
    properties: str


@strawberry.type
class GraphStats:
    hosts: int
    sessions: int
    creds: int
    vulns: int
    techniques: int


@strawberry.type
class Query:
    @strawberry.field
    def sessions(self) -> List[Node]:
        return [
            Node(id=n["id"], type=n["type"], key=n["key"],
                  properties=str(n["properties"]))
            for n in graph.list_nodes("session")
        ]

    @strawberry.field
    def hosts(self) -> List[Node]:
        return [
            Node(id=n["id"], type=n["type"], key=n["key"],
                  properties=str(n["properties"]))
            for n in graph.list_nodes("host")
        ]

    @strawberry.field
    def vulnerabilities(self) -> List[Node]:
        return [
            Node(id=n["id"], type=n["type"], key=n["key"],
                  properties=str(n["properties"]))
            for n in graph.list_nodes("vulnerability")
        ]

    @strawberry.field
    def stats(self) -> GraphStats:
        s = graph.get_attack_surface()
        return GraphStats(
            hosts=s.get("hosts", 0),
            sessions=s.get("sessions", 0),
            creds=s.get("creds", 0),
            vulns=s.get("vulns", 0),
            techniques=s.get("techniques", 0),
        )


@strawberry.type
class Mutation:
    @strawberry.mutation
    def register_host(self, ip: str, hostname: str = "") -> Node:
        nid = graph.register_host(ip, hostname=hostname)
        n = graph.get_node("host", ip)
        return Node(id=nid, type="host", key=ip,
                      properties=str(n["properties"] if n else {}))


@strawberry.type
class Subscription:
    @strawberry.subscription
    async def session_updates(self) -> Node:
        """يرسل تحديثات الجلسات الحية"""
        import asyncio
        while True:
            await asyncio.sleep(2)
            # placeholder: emit latest session
            sessions = graph.list_nodes("session")
            if sessions:
                n = sessions[0]
                yield Node(id=n["id"], type=n["type"], key=n["key"],
                            properties=str(n["properties"]))


schema = strawberry.Schema(
    query=Query,
    mutation=Mutation,
    subscription=Subscription,
)

graphql_app = GraphQLRouter(schema)
