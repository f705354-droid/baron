# language: Python, file: core/api/rest_routes.py
# REST endpoints
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from core.api.auth import get_current_user
from core.rbac.permissions import require_permission
from core.rbac.roles import Permission

router = APIRouter()


class TaskCreate(BaseModel):
    session_id: str
    task: str


class ScopeCreate(BaseModel):
    targets: List[str]
    hours: int = 8


# ==================== sessions ====================
@router.get("/sessions")
async def list_sessions(
    user: dict = Depends(require_permission(
        Permission.SESSIONS_READ))
):
    from core.graph.graph_db import graph
    sessions = graph.list_nodes("session")
    return {"sessions": sessions, "count": len(sessions)}


@router.get("/sessions/{sid}")
async def get_session(
    sid: str,
    user: dict = Depends(require_permission(
        Permission.SESSIONS_READ))
):
    from core.graph.graph_db import graph
    s = graph.get_node("session", sid)
    if not s:
        raise HTTPException(404, "session not found")
    return s


@router.delete("/sessions/{sid}")
async def delete_session(
    sid: str,
    user: dict = Depends(require_permission(
        Permission.SESSIONS_DELETE))
):
    from core.graph.graph_db import graph
    # kill session via C2
    return {"status": "killed", "sid": sid}


# ==================== tasks ====================
@router.post("/tasks")
async def create_task(
    payload: TaskCreate,
    user: dict = Depends(require_permission(
        Permission.TASKS_WRITE))
):
    # dispatch to C2
    from core.graph.graph_db import graph
    import uuid
    tid = str(uuid.uuid4())[:8]
    graph.register_task(tid, "manual", payload.session_id,
                          task=payload.task, actor=user["username"])
    return {"task_id": tid, "status": "queued"}


@router.get("/tasks")
async def list_tasks(
    limit: int = 50,
    user: dict = Depends(require_permission(
        Permission.TASKS_READ))
):
    from core.graph.graph_db import graph
    tasks = graph.list_nodes("task")[:limit]
    return {"tasks": tasks}


# ==================== graph ====================
@router.get("/graph/summary")
async def graph_summary(
    user: dict = Depends(require_permission(
        Permission.GRAPH_READ))
):
    from core.graph.graph_db import graph
    return graph.get_attack_surface()


@router.get("/graph/nodes")
async def graph_nodes(
    node_type: Optional[str] = None,
    user: dict = Depends(require_permission(
        Permission.GRAPH_READ))
):
    from core.graph.graph_db import graph
    return {"nodes": graph.list_nodes(node_type)}


# ==================== scope ====================
@router.get("/scope")
async def get_scope(
    user: dict = Depends(require_permission(
        Permission.SESSIONS_READ))
):
    from core.safety.scope import scope_manager
    return scope_manager.report()


@router.post("/scope")
async def create_scope(
    payload: ScopeCreate,
    user: dict = Depends(require_permission(
        Permission.SCOPE_WRITE))
):
    from core.safety.scope import scope_manager
    try:
        result = scope_manager.declare(
            targets=payload.targets,
            hours=payload.hours,
            acknowledgment="I have authorization for these targets."
        )
        return result
    except Exception as e:
        raise HTTPException(400, str(e))


# ==================== alerts ====================
@router.get("/alerts")
async def list_alerts(
    limit: int = 50,
    user: dict = Depends(require_permission(
        Permission.SESSIONS_READ))
):
    from core.blue.detection_engine import engine
    return {"alerts": engine.get_alerts()[-limit:]}


# ==================== kill switch ====================
@router.post("/kill-switch")
async def trigger_kill(
    user: dict = Depends(require_permission(
        Permission.KILL_SWITCH))
):
    from core.safety.kill_switch import kill_switch
    kill_switch.trigger(f"api:{user['username']}")
    return {"status": "triggered", "by": user["username"]}


# ==================== reports ====================
@router.get("/reports")
async def list_reports(
    user: dict = Depends(require_permission(
        Permission.REPORTS_READ))
):
    import os
    reports_dir = "reports"
    if not os.path.isdir(reports_dir):
        return {"reports": []}
    files = [f for f in os.listdir(reports_dir) if f.endswith(".pdf")]
    return {"reports": files}


@router.post("/reports/generate")
async def generate_report(
    user: dict = Depends(require_permission(
        Permission.REPORTS_WRITE))
):
    from core.reports.composer import report_composer
    from core.graph.graph_db import graph
    findings = []
    for h in graph.list_nodes("host"):
        vulns = graph.neighbors("host", h["key"],
                                  edge_type="vulnerable_to",
                                  direction="out")
        for v in vulns:
            findings.append({
                "severity": "high",
                "title": f"{v['key']} on {h['key']}",
                "host": h["key"],
                "cve": v["key"],
            })
    result = report_composer.generate_engagement_report(
        {"client": "API Client", "name": "API Engagement",
          "tester": user["username"], "start": "today", "end": "today"},
        findings)
    return result


# ==================== users ====================
@router.get("/users")
async def list_users(
    user: dict = Depends(require_permission(
        Permission.USERS_READ))
):
    from core.api.auth import USERS
    return {
        "users": [
            {"username": u, "role": d["role"]}
            for u, d in USERS.items()
        ]
    }
