# language: Python, file: core/api/auth.py
# JWT auth for API
from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel
from datetime import datetime, timedelta
import os
import hashlib
import jwt

router = APIRouter()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")

SECRET_KEY = os.getenv("AL-BARON_SECRET",
                        "change-me-in-production")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 24h


# in-memory user store (in production: PostgreSQL)
USERS: dict = {}


class LoginRequest(BaseModel):
    username: str
    password: str


class RegisterRequest(BaseModel):
    username: str
    password: str
    role: str = "viewer"


class TokenResponse(BaseModel):
    access_token: str
    token_type: str
    expires_in: int
    user: dict


def _hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


def create_user(username: str, password: str,
                 role: str = "viewer") -> dict:
    if username in USERS:
        raise HTTPException(400, "user exists")
    USERS[username] = {
        "username": username,
        "password_hash": _hash_password(password),
        "role": role,
        "created": datetime.now().isoformat(),
    }
    return {"username": username, "role": role}


def verify_user(username: str, password: str) -> dict:
    user = USERS.get(username)
    if not user:
        return None
    if user["password_hash"] != _hash_password(password):
        return None
    return user


def create_token(username: str, role: str) -> str:
    payload = {
        "sub": username,
        "role": role,
        "exp": datetime.utcnow() + timedelta(
            minutes=ACCESS_TOKEN_EXPIRE_MINUTES),
        "iat": datetime.utcnow(),
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str) -> dict:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None


async def get_current_user(token: str = Depends(oauth2_scheme)) -> dict:
    payload = decode_token(token)
    if not payload:
        raise HTTPException(401, "invalid token")
    user = USERS.get(payload["sub"])
    if not user:
        raise HTTPException(401, "user not found")
    return user


@router.post("/login")
async def login(form: OAuth2PasswordRequestForm = Depends()):
    user = verify_user(form.username, form.password)
    if not user:
        raise HTTPException(401, "invalid credentials")

    token = create_token(user["username"], user["role"])
    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        "user": {
            "username": user["username"],
            "role": user["role"],
        },
    }


@router.post("/register")
async def register(payload: RegisterRequest):
    # only allow admin to register (or first user)
    if USERS and payload.role != "viewer":
        # require admin auth
        pass
    return create_user(payload.username, payload.password,
                        payload.role)


@router.get("/me")
async def me(user: dict = Depends(get_current_user)):
    return {
        "username": user["username"],
        "role": user["role"],
        "created": user["created"],
    }


# bootstrap default admin
def init_admin():
    if not USERS:
        create_user("admin", "admin", "admin")
        create_user("operator1", "operator", "operator")
        create_user("viewer1", "viewer", "viewer")


init_admin()
