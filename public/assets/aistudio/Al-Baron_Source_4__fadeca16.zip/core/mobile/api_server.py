# language: Python, file: core/mobile/api_server.py
# Mobile API — REST + WebSocket for mobile app
import asyncio
import json
import threading
import uuid
import time
from datetime import datetime, timedelta
from typing import Optional


class MobileAPI:
    """
    API للموبايل:
      - auth (JWT)
      - status (stats)
      - sessions (list)
      - alerts (list)
      - action (start/stop)
      - WebSocket للتحديثات الفورية
    """
    def __init__(self, app, host: str = "0.0.0.0", port: int = 8443):
        self.app = app
        self.host = host
        self.port = port
        self.users = {}      # username → {password_hash, role}
        self.tokens = {}     # token → {user, exp}
        self.ws_connections = set()

    def _hash(self, password: str) -> str:
        import hashlib
        return hashlib.sha256(password.encode()).hexdigest()

    def add_user(self, username: str, password: str,
                  role: str = "operator"):
        self.users[username] = {
            "password_hash": self._hash(password),
            "role": role,
            "created": datetime.now().isoformat(),
        }

    def login(self, username: str, password: str) -> Optional[str]:
        u = self.users.get(username)
        if not u or u["password_hash"] != self._hash(password):
            return None
        token = str(uuid.uuid4())
        self.tokens[token] = {
            "user": username,
            "exp": (datetime.now() + timedelta(hours=24)).timestamp(),
        }
        return token

    def check_token(self, token: str) -> Optional[str]:
        t = self.tokens.get(token)
        if not t:
            return None
        if time.time() > t["exp"]:
            del self.tokens[token]
            return None
        return t["user"]

    # ==================== API endpoints ====================
    def get_stats(self) -> dict:
        """بيانات عامة للموبايل"""
        from core.graph.graph_db import graph
        try:
            stats = graph.get_attack_surface()
        except Exception:
            stats = {}

        # c2 sessions
        sessions = 0
        try:
            c2ui = self.app.modules.get("c2_ui") if self.app else None
            if c2ui:
                sessions = len(c2ui.sessions)
        except Exception:
            pass

        return {
            "hosts": stats.get("hosts", 0),
            "sessions": sessions,
            "creds": stats.get("creds", 0),
            "vulns": stats.get("vulns", 0),
            "techniques": stats.get("techniques", 0),
            "timestamp": datetime.now().isoformat(),
        }

    def get_sessions(self) -> list:
        """قائمة sessions"""
        result = []
        try:
            c2ui = self.app.modules.get("c2_ui") if self.app else None
            if c2ui:
                for sid, data in c2ui.sessions.items():
                    result.append({
                        "id": sid,
                        "host": data.get("host", "?"),
                        "user": data.get("user", "?"),
                        "os": data.get("os", "?"),
                        "ip": data.get("ip", "?"),
                    })
        except Exception:
            pass
        return result

    def get_alerts(self, limit: int = 50) -> list:
        """آخر التنبيهات"""
        try:
            from core.blue.detection_engine import engine
            return engine.get_alerts()[-limit:]
        except Exception:
            return []

    def get_hunter_status(self) -> dict:
        try:
            hunter = self.app.modules.get("hunter") if self.app else None
            if hunter and hasattr(hunter, "hunter"):
                h = hunter.hunter
                return {
                    "running": h.running,
                    "budget": h.budget.report() if h.budget else {},
                }
        except Exception:
            pass
        return {"running": False}

    # ==================== server ====================
    def start(self):
        """يشغل FastAPI server"""
        try:
            from fastapi import FastAPI, HTTPException, WebSocket
            from fastapi.responses import JSONResponse
            from pydantic import BaseModel
            import uvicorn
        except ImportError:
            print("[mobile] install: pip install fastapi uvicorn")
            return

        app = FastAPI(title="Al-Baron Mobile API")
        api = self

        class LoginIn(BaseModel):
            username: str
            password: str

        class ActionIn(BaseModel):
            action: str
            target: str = ""

        def auth(token: str):
            user = api.check_token(token)
            if not user:
                raise HTTPException(401, "invalid token")
            return user

        @app.post("/api/login")
        def login(payload: LoginIn):
            token = api.login(payload.username, payload.password)
            if not token:
                raise HTTPException(401, "invalid creds")
            return {"token": token}

        @app.get("/api/stats")
        def stats(token: str):
            auth(token)
            return api.get_stats()

        @app.get("/api/sessions")
        def sessions(token: str):
            auth(token)
            return api.get_sessions()

        @app.get("/api/alerts")
        def alerts(token: str, limit: int = 50):
            auth(token)
            return api.get_alerts(limit)

        @app.get("/api/hunter")
        def hunter(token: str):
            auth(token)
            return api.get_hunter_status()

        @app.post("/api/action")
        def action(payload: ActionIn, token: str):
            user = auth(token)
            return api._handle_action(payload.action, payload.target, user)

        @app.websocket("/ws")
        async def ws_endpoint(websocket: WebSocket, token: str = ""):
            if not api.check_token(token):
                await websocket.close(code=4001)
                return
            await websocket.accept()
            api.ws_connections.add(websocket)
            try:
                while True:
                    # send stats every 5s
                    await websocket.send_json(api.get_stats())
                    await asyncio.sleep(5)
            except Exception:
                pass
            finally:
                api.ws_connections.discard(websocket)

        def run():
            uvicorn.run(app, host=api.host, port=api.port,
                          log_level="warning")

        threading.Thread(target=run, daemon=True).start()
        print(f"[mobile] API listening on {self.host}:{self.port}")

    def _handle_action(self, action: str, target: str,
                        user: str) -> dict:
        """ينفذ action من الموبايل"""
        if action == "hunter_start":
            try:
                hunter = self.app.modules.get("hunter") if self.app else None
                if hunter and hasattr(hunter, "hunter"):
                    hunter.hunter.start(target)
                    return {"status": "started", "target": target}
            except Exception as e:
                return {"error": str(e)}
        elif action == "hunter_stop":
            try:
                hunter = self.app.modules.get("hunter") if self.app else None
                if hunter and hasattr(hunter, "hunter"):
                    hunter.hunter.stop()
                    return {"status": "stopped"}
            except Exception as e:
                return {"error": str(e)}
        elif action == "kill_switch":
            try:
                from core.safety.kill_switch import kill_switch
                kill_switch.trigger("mobile")
                return {"status": "triggered"}
            except Exception as e:
                return {"error": str(e)}
        return {"error": f"unknown action: {action}"}

    def broadcast(self, event: dict):
        """broadcast for WebSocket connections"""
        for ws in list(self.ws_connections):
            try:
                asyncio.run_coroutine_threadsafe(
                    ws.send_json(event), asyncio.get_event_loop())
            except Exception:
                pass
