"""Session management."""

from uuid import uuid4
from datetime import datetime, timezone


class Session:
    def __init__(self):
        self.session_id = str(uuid4())
        self.created_at = datetime.now(timezone.utc).isoformat()
        self.metadata = {}

    def set_metadata(self, key: str, value):
        self.metadata[key] = value
