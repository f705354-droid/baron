# language: Python, file: core/ui/stats_panel.py
# Real-time target stats — country, ISP, top ports
import customtkinter as ctk
import threading
import json
import urllib.request
from collections import Counter
from core.ui.theme import Colors, F, Spacing


class TargetStats(ctk.CTkFrame):
    """
    لوحة إحصائيات فورية للهدف:
      - country / ISP (من ip-api.com — يعمل offline → skip)
      - top open ports
      - hosts count
      - unique services
    """
    def __init__(self, parent, **kwargs):
        super().__init__(parent, fg_color=Colors.PANEL,
                          corner_radius=8, border_width=1,
                          border_color=Colors.BORDER, **kwargs)

        ctk.CTkLabel(
            self, text="TARGET STATS",
            font=F(10, "bold"), text_color=Colors.ACCENT,
            anchor="w").pack(fill="x", padx=Spacing.MD,
                              pady=(Spacing.SM, 0))

        # country
        row1 = ctk.CTkFrame(self, fg_color="transparent")
        row1.pack(fill="x", padx=Spacing.MD, pady=(Spacing.SM, 0))
        ctk.CTkLabel(row1, text="Country:", font=F(9),
                      text_color=Colors.FG_DIM, anchor="w").pack(side="left")
        self.country_lbl = ctk.CTkLabel(
            row1, text="—", font=F(9, "bold"),
            text_color=Colors.FG, anchor="e")
        self.country_lbl.pack(side="right")

        # ISP
        row2 = ctk.CTkFrame(self, fg_color="transparent")
        row2.pack(fill="x", padx=Spacing.MD, pady=2)
        ctk.CTkLabel(row2, text="ISP:", font=F(9),
                      text_color=Colors.FG_DIM, anchor="w").pack(side="left")
        self.isp_lbl = ctk.CTkLabel(
            row2, text="—", font=F(9),
            text_color=Colors.FG, anchor="e")
        self.isp_lbl.pack(side="right")

        # top ports
        ctk.CTkLabel(
            self, text="TOP PORTS",
            font=F(9, "bold"), text_color=Colors.FG_DIM,
            anchor="w").pack(fill="x", padx=Spacing.MD, pady=(Spacing.SM, 2))

        self.ports_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.ports_frame.pack(fill="x", padx=Spacing.MD)

        self._port_counts = Counter()
        self._render_ports()

        # counters
        ctk.CTkLabel(
            self, text="AGGREGATE",
            font=F(9, "bold"), text_color=Colors.FG_DIM,
            anchor="w").pack(fill="x", padx=Spacing.MD, pady=(Spacing.SM, 2))

        counts = ctk.CTkFrame(self, fg_color="transparent")
        counts.pack(fill="x", padx=Spacing.MD, pady=(0, Spacing.SM))

        self.hosts_lbl = self._counter(counts, "HOSTS", "0")
        self.services_lbl = self._counter(counts, "SVCS", "0")
        self.vulns_lbl = self._counter(counts, "VULNS", "0",
                                         color=Colors.DANGER)

    def _counter(self, parent, label: str, initial: str,
                  color: str = Colors.ACCENT):
        frame = ctk.CTkFrame(parent, fg_color=Colors.BG_2,
                              corner_radius=4)
        frame.pack(side="left", fill="x", expand=True, padx=2)
        ctk.CTkLabel(frame, text=label, font=F(7),
                      text_color=Colors.FG_DARK).pack(pady=(4, 0))
        lbl = ctk.CTkLabel(frame, text=initial,
                            font=F(14, "bold"), text_color=color)
        lbl.pack(pady=(0, 4))
        return lbl

    def _render_ports(self):
        for w in self.ports_frame.winfo_children():
            w.destroy()
        for port, count in self._port_counts.most_common(5):
            row = ctk.CTkFrame(self.ports_frame, fg_color="transparent")
            row.pack(fill="x", pady=1)
            ctk.CTkLabel(
                row, text=str(port), font=F(9),
                text_color=Colors.ACCENT_2, anchor="w",
                width=60).pack(side="left")
            bar = ctk.CTkProgressBar(
                row, height=4, progress_color=Colors.ACCENT,
                fg_color=Colors.PANEL_3)
            bar.set(min(count / 10, 1.0))
            bar.pack(side="left", fill="x", expand=True)
            ctk.CTkLabel(
                row, text=str(count), font=F(8),
                text_color=Colors.FG_DIM, width=20,
                anchor="e").pack(side="right")

    def update_ip_info(self, ip: str):
        """يجلب country/ISP من ip-api (offline → silently fail)"""
        def fetch():
            try:
                url = f"http://ip-api.com/json/{ip}?fields=status,country,isp"
                with urllib.request.urlopen(url, timeout=3) as r:
                    data = json.loads(r.read().decode())
                if data.get("status") == "success":
                    self.after(0, lambda: self._set_ip_info(
                        data.get("country", "—"),
                        data.get("isp", "—")))
            except Exception:
                pass
        threading.Thread(target=fetch, daemon=True).start()

    def _set_ip_info(self, country: str, isp: str):
        self.country_lbl.configure(text=country)
        self.isp_lbl.configure(text=isp[:25])

    def add_port(self, port: int):
        self._port_counts[port] += 1
        self._render_ports()

    def set_aggregate(self, hosts: int = None, services: int = None,
                        vulns: int = None):
        if hosts is not None:
            self.hosts_lbl.configure(text=str(hosts))
        if services is not None:
            self.services_lbl.configure(text=str(services))
        if vulns is not None:
            self.vulns_lbl.configure(text=str(vulns),
                                       text_color=Colors.DANGER if vulns > 0
                                       else Colors.ACCENT)
