# language: Python, file: core/ui/notifications.py
# Alert center — overlay notifications, critical alerts with flash
import customtkinter as ctk
import tkinter as tk
from datetime import datetime
from core.ui.theme import Colors, F, Spacing


class Alert:
    def __init__(self, title: str, message: str, level: str = "info",
                  duration: int = 5000, source: str = ""):
        self.title = title
        self.message = message
        self.level = level   # info / warn / error / success / critical
        self.duration = duration
        self.source = source
        self.ts = datetime.now()


class AlertCenter(ctk.CTkFrame):
    """
    Toast notifications في الزاوية العلوية اليمنى.
    Critical alerts تظهر كميض + تبقى حتى تُغلق يدوياً.
    """
    def __init__(self, parent, width: int = 320, **kwargs):
        super().__init__(parent, width=width, fg_color="transparent", **kwargs)
        self.width = width
        self.alerts = []   # list of Alert

    def push(self, title: str, message: str, level: str = "info",
              duration: int = 5000, source: str = ""):
        alert = Alert(title, message, level, duration, source)
        self._show(alert)

    def _show(self, alert: Alert):
        level_colors = {
            "info": Colors.INFO,
            "warn": Colors.WARN,
            "error": Colors.DANGER,
            "success": Colors.SUCCESS,
            "critical": Colors.DANGER,
        }
        color = level_colors.get(alert.level, Colors.FG)

        # toast frame
        toast = ctk.CTkFrame(
            self, fg_color=Colors.PANEL,
            border_width=2 if alert.level == "critical" else 1,
            border_color=color, corner_radius=6)
        toast.pack(fill="x", pady=(0, 6))

        # header
        hdr = ctk.CTkFrame(toast, fg_color="transparent")
        hdr.pack(fill="x", padx=10, pady=(8, 2))

        # icon
        icons = {
            "info": "ℹ",
            "warn": "⚠",
            "error": "✗",
            "success": "✓",
            "critical": "⚡",
        }
        ctk.CTkLabel(
            hdr, text=icons.get(alert.level, "•"),
            font=F(14, "bold"), text_color=color,
            width=20).pack(side="left")

        # title
        ctk.CTkLabel(
            hdr, text=alert.title,
            font=F(11, "bold"), text_color=color,
            anchor="w").pack(side="left", padx=(6, 0), fill="x",
                              expand=True)

        # close btn
        def close():
            toast.destroy()
        ctk.CTkButton(
            hdr, text="×", width=20, height=20,
            fg_color="transparent", hover_color=Colors.PANEL_2,
            text_color=Colors.FG_DIM, font=F(11, "bold"),
            command=close).pack(side="right")

        # message
        if alert.message:
            ctk.CTkLabel(
                toast, text=alert.message,
                font=F(9), text_color=Colors.FG,
                anchor="w", justify="left",
                wraplength=self.width - 40).pack(
                    fill="x", padx=10, pady=(0, 4))

        # timestamp
        ctk.CTkLabel(
            toast, text=alert.ts.strftime("%H:%M:%S"),
            font=F(8), text_color=Colors.FG_DARK,
            anchor="e").pack(fill="x", padx=10, pady=(0, 6))

        # flash for critical
        if alert.level == "critical":
            self._flash(toast, color)

        # auto-dismiss
        if alert.duration > 0:
            self.after(alert.duration, lambda: self._safe_destroy(toast))

    def _safe_destroy(self, widget):
        try:
            widget.destroy()
        except Exception:
            pass

    def _flash(self, widget, color: str):
        """flash effect for critical alerts"""
        state = {"phase": 0}

        def tick():
            try:
                if not widget.winfo_exists():
                    return
                phase = state["phase"] % 4
                border = color if phase < 2 else Colors.WARN
                widget.configure(border_color=border)
                state["phase"] += 1
                widget.after(400, tick)
            except Exception:
                pass

        tick()


class NotificationBadge(ctk.CTkFrame):
    """نقطة حمراء صغيرة على عنصر — للإشارات غير المقروءة"""
    def __init__(self, parent, count: int = 0, **kwargs):
        super().__init__(parent, width=16, height=16,
                          fg_color=Colors.DANGER, corner_radius=8, **kwargs)
        self.pack_propagate(False)
        self.count = count
        self._label = ctk.CTkLabel(
            self, text=str(count), font=F(8, "bold"),
            text_color="white", anchor="center")
        self._label.pack(expand=True)
        if count == 0:
            self.pack_forget()

    def set_count(self, count: int):
        self.count = count
        if count > 0:
            self._label.configure(text=str(count))
            try:
                self.pack()
            except Exception:
                pass
        else:
            try:
                self.pack_forget()
            except Exception:
                pass
