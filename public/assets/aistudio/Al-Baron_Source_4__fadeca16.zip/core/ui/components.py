# language: Python, file: core/ui/components.py
# Reusable UI components — NeonCard, Chip, StatusDot, SectionTitle
import customtkinter as ctk
from core.ui.theme import Colors, F, Spacing


class NeonCard(ctk.CTkFrame):
    """
    بطاقة بحدود نيون خفيفة + hover effect.
    تدعم click callback (تحولها لزر كبير).
    """
    def __init__(self, parent, title: str = "", on_click=None, **kwargs):
        super().__init__(parent, fg_color=Colors.PANEL,
                          corner_radius=8, border_width=1,
                          border_color=Colors.BORDER, **kwargs)

        self.title = title
        self.on_click = on_click
        self._normal_border = Colors.BORDER
        self._hover_border = Colors.ACCENT

        if title:
            self.title_frame = ctk.CTkFrame(self, fg_color="transparent",
                                              height=28)
            self.title_frame.pack(fill="x", padx=Spacing.MD,
                                    pady=(Spacing.SM, 0))
            self.title_frame.pack_propagate(False)
            self.title_lbl = ctk.CTkLabel(
                self.title_frame, text=title.upper(),
                font=F(10, "bold"), text_color=Colors.ACCENT,
                anchor="w")
            self.title_lbl.pack(side="left")
            self.title_accent = ctk.CTkFrame(
                self.title_frame, fg_color=Colors.ACCENT,
                width=2, height=14)
            self.title_accent.pack(side="left", padx=(Spacing.SM, 0))

        self.body = ctk.CTkFrame(self, fg_color="transparent")
        self.body.pack(fill="both", expand=True, padx=Spacing.MD,
                        pady=Spacing.SM)

        # bind hover
        self._bind_hover()

    def _bind_hover(self):
        def on_enter(e):
            try:
                self.configure(border_color=self._hover_border)
            except Exception:
                pass

        def on_leave(e):
            try:
                self.configure(border_color=self._normal_border)
            except Exception:
                pass

        def recurse(widget):
            widget.bind("<Enter>", on_enter, add="+")
            widget.bind("<Leave>", on_leave, add="+")
            for child in widget.winfo_children():
                recurse(child)

        recurse(self)

        if self.on_click:
            def click(e):
                self.on_click()
            recurse_click(self, click)


def recurse_click(widget, callback):
    widget.bind("<Button-1>", lambda e: callback(), add="+")
    for child in widget.winfo_children():
        recurse_click(child, callback)


class Chip(ctk.CTkButton):
    """
    Chip toggle — يشبه GitHub labels.
    Active: خلفية accent + نص أسود.
    Inactive: خلفية شفافة + border رمادي.
    """
    def __init__(self, parent, text: str, command=None, active=False, **kwargs):
        self._active = active
        super().__init__(
            parent, text=text, height=28, width=0,
            font=F(10, "bold"),
            corner_radius=14,
            command=self._toggle_cmd(command),
            **kwargs)
        self._apply_style()

    def _toggle_cmd(self, user_command):
        def wrapped():
            if user_command:
                user_command(self._active)
            self.set_active(not self._active)
        return wrapped

    def set_active(self, active: bool):
        self._active = active
        self._apply_style()

    def _apply_style(self):
        if self._active:
            self.configure(
                fg_color=Colors.ACCENT,
                hover_color=Colors.ACCENT_2,
                text_color=Colors.BG,
                border_width=0)
        else:
            self.configure(
                fg_color="transparent",
                hover_color=Colors.PANEL_2,
                text_color=Colors.FG,
                border_width=1,
                border_color=Colors.BORDER)


class StatusDot(ctk.CTkFrame):
    """
    نقطة حالة دائرية.
    Status: online/offline/warning/error.
    """
    def __init__(self, parent, status: str = "online",
                  size: int = 8, **kwargs):
        super().__init__(parent, width=size, height=size,
                          corner_radius=size // 2, **kwargs)
        self.pack_propagate(False)
        self.set_status(status)

    def set_status(self, status: str):
        colors = {
            "online": Colors.SUCCESS,
            "offline": Colors.FG_DARK,
            "warning": Colors.WARN,
            "error": Colors.DANGER,
            "idle": Colors.FG_DIM,
            "active": Colors.ACCENT,
        }
        self.configure(fg_color=colors.get(status, Colors.FG_DIM))


class SectionTitle(ctk.CTkFrame):
    """عنوان قسم مع خط accent"""
    def __init__(self, parent, text: str, subtitle: str = "", **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)
        top = ctk.CTkFrame(self, fg_color="transparent")
        top.pack(fill="x")
        ctk.CTkLabel(
            top, text=text.upper(),
            font=F(11, "bold"), text_color=Colors.ACCENT,
            anchor="w").pack(side="left")
        ctk.CTkFrame(top, fg_color=Colors.ACCENT,
                      width=20, height=2).pack(side="left",
                                                padx=(Spacing.SM, 0))
        if subtitle:
            ctk.CTkLabel(self, text=subtitle, font=F(9),
                          text_color=Colors.FG_DARK,
                          anchor="w").pack(fill="x", pady=(2, 0))


class MetricCard(ctk.CTkFrame):
    """بطاقة رقم واحد كبير + label"""
    def __init__(self, parent, label: str, value: str = "0",
                  unit: str = "", color: str = None, **kwargs):
        super().__init__(parent, fg_color=Colors.PANEL_2,
                          corner_radius=6, **kwargs)
        self._color = color or Colors.ACCENT

        ctk.CTkLabel(
            self, text=label.upper(), font=F(9),
            text_color=Colors.FG_DIM, anchor="w"
        ).pack(fill="x", padx=Spacing.SM, pady=(Spacing.SM, 0))

        row = ctk.CTkFrame(self, fg_color="transparent")
        row.pack(fill="x", padx=Spacing.SM, pady=(0, Spacing.SM))

        self.value_lbl = ctk.CTkLabel(
            row, text=value, font=F(22, "bold"),
            text_color=self._color, anchor="w")
        self.value_lbl.pack(side="left")

        if unit:
            self.unit_lbl = ctk.CTkLabel(
                row, text=unit, font=F(10),
                text_color=Colors.FG_DIM, anchor="sw")
            self.unit_lbl.pack(side="left", padx=(Spacing.XS, 0),
                                pady=(0, 4))

    def set_value(self, value, color: str = None):
        self.value_lbl.configure(
            text=str(value),
            text_color=color or self._color)


class IconLabel(ctk.CTkFrame):
    """
    SVG-style icon — نستخدم Unicode symbols بدل SVG حقيقي.
    يوحد الأحجام والأنماط في sidebar.
    """
    ICONS = {
        "recon":    "◎",
        "exploit":  "⚔",
        "lan":      "⊞",
        "mitm":     "⇌",
        "ad":       "♛",
        "adcs":     "♜",
        "cloud":    "☁",
        "exfil":    "⇪",
        "firmware": "⚙",
        "iot":      "⊛",
        "mobile":   "▣",
        "c2":       "☢",
        "phish":    "✉",
        "ai":       "♛",
        "report":   "▤",
        "k8s":      "⎈",
        "safety":   "🛡",
        "backup":   "💾",
        "home":     "⌂",
        "settings": "⚙",
    }

    def __init__(self, parent, icon: str, size: int = 16,
                  color: str = None, **kwargs):
        super().__init__(parent, fg_color="transparent",
                          width=size+4, height=size+4, **kwargs)
        self.pack_propagate(False)
        symbol = self.ICONS.get(icon, icon)
        ctk.CTkLabel(
            self, text=symbol, font=F(size, "bold"),
            text_color=color or Colors.ACCENT,
            width=size+4, height=size+4,
            anchor="center").pack(expand=True)
