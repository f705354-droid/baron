# language: Python, file: core/ui/terminal_panel.py
# Terminal panel — tabs, syntax highlighting, export, resizable
import customtkinter as ctk
import tkinter as tk
import re
import os
import json
from datetime import datetime
from core.ui.theme import Colors, F, Spacing


class TerminalTab:
    """تبويب واحد — نص + حالة + export"""
    def __init__(self, parent, name: str):
        self.name = name
        self.frame = ctk.CTkFrame(parent, fg_color=Colors.BG_2,
                                    corner_radius=0)
        self.textbox = ctk.CTkTextbox(
            self.frame, fg_color=Colors.BG_2,
            text_color=Colors.FG,
            font=ctk.CTkFont(family="JetBrains Mono", size=11),
            wrap="word", border_width=0)
        self.textbox.pack(fill="both", expand=True, padx=4, pady=4)

        # syntax tags
        self._setup_tags()
        self.line_count = 0

    def _setup_tags(self):
        family = self.textbox.cget("font")
        self.textbox.tag_config("success", foreground=Colors.SUCCESS)
        self.textbox.tag_config("error", foreground=Colors.DANGER)
        self.textbox.tag_config("warn", foreground=Colors.WARN)
        self.textbox.tag_config("info", foreground=Colors.INFO)
        self.textbox.tag_config("dim", foreground=Colors.FG_DARK)
        self.textbox.tag_config("accent", foreground=Colors.ACCENT)
        self.textbox.tag_config("cmd", foreground=Colors.ACCENT_2)

    def write(self, text: str, tag: str = None):
        self.textbox.configure(state="normal")
        if tag:
            self.textbox.insert("end", text, tag)
        else:
            # auto-detect tag
            tag = self._detect_tag(text)
            self.textbox.insert("end", text, tag)
        self.textbox.see("end")
        self.textbox.configure(state="disabled")
        self.line_count += text.count("\n")

    def _detect_tag(self, text: str) -> str:
        tl = text.lower()
        if any(w in tl for w in ["error", "failed", "exception",
                                    "cannot", "denied"]):
            return "error"
        if any(w in tl for w in ["warning", "warn:", "deprecated"]):
            return "warn"
        if any(w in tl for w in ["found", "open", "success", "done",
                                    "complete", "→"]):
            return "success"
        if text.strip().startswith("$"):
            return "cmd"
        if any(w in tl for w in ["info", "note", "…", "loading"]):
            return "info"
        return None

    def clear(self):
        self.textbox.configure(state="normal")
        self.textbox.delete("1.0", "end")
        self.textbox.configure(state="disabled")

    def export(self, path: str, fmt: str = "txt"):
        content = self.textbox.get("1.0", "end")
        if fmt == "json":
            data = {
                "tab": self.name,
                "exported": datetime.now().isoformat(),
                "lines": content.splitlines(),
                "line_count": self.line_count,
            }
            with open(path, "w") as f:
                json.dump(data, f, indent=2)
        elif fmt == "pdf":
            try:
                from fpdf import FPDF
                pdf = FPDF()
                pdf.add_page()
                pdf.set_font("Courier", size=9)
                for line in content.splitlines():
                    pdf.multi_cell(0, 4, line)
                pdf.output(path)
            except ImportError:
                with open(path.replace(".pdf", ".txt"), "w") as f:
                    f.write(content)
        else:
            with open(path, "w") as f:
                f.write(content)


class TerminalPanel(ctk.CTkFrame):
    """
    Terminal with tabs + export + resizable height.
    Drag top edge to resize.
    """
    def __init__(self, parent, **kwargs):
        super().__init__(parent, fg_color=Colors.PANEL,
                          corner_radius=0, **kwargs)
        self.tabs = {}
        self.active_tab = None
        self._resize_start_y = None
        self._start_height = None

        # ── drag handle (top) ──
        self.handle = ctk.CTkFrame(
            self, height=4, fg_color=Colors.BORDER,
            corner_radius=0, cursor="sb_v_double_arrow")
        self.handle.pack(fill="x", side="top")
        self.handle.bind("<Button-1>", self._start_resize)
        self.handle.bind("<B1-Motion>", self._do_resize)
        self.handle.bind("<Enter>", lambda e: self.handle.configure(
            fg_color=Colors.ACCENT))
        self.handle.bind("<Leave>", lambda e: self.handle.configure(
            fg_color=Colors.BORDER))

        # ── header ──
        header = ctk.CTkFrame(self, height=32,
                                fg_color=Colors.PANEL_2,
                                corner_radius=0)
        header.pack(fill="x")
        header.pack_propagate(False)

        ctk.CTkLabel(
            header, text="▸ TERMINAL",
            font=F(10, "bold"), text_color=Colors.ACCENT,
            anchor="w").pack(side="left", padx=Spacing.SM)

        # ── tabs container ──
        self.tabs_frame = ctk.CTkFrame(header, fg_color="transparent")
        self.tabs_frame.pack(side="left", fill="x", expand=True,
                               padx=Spacing.SM)

        # ── buttons ──
        btn_frame = ctk.CTkFrame(header, fg_color="transparent")
        btn_frame.pack(side="right", padx=4)

        for label, cmd in [
            ("+", self._add_tab),
            ("×", self._close_active),
            ("↓", self._export_active),
            ("⌫", self._clear_active),
            ("⌃", self._toggle_collapse),
        ]:
            ctk.CTkButton(
                btn_frame, text=label, width=24, height=24,
                fg_color="transparent", hover_color=Colors.PANEL_3,
                text_color=Colors.FG, font=F(11, "bold"),
                corner_radius=4, command=cmd
            ).pack(side="left", padx=1)

        # ── body ──
        self.body = ctk.CTkFrame(self, fg_color=Colors.BG_2,
                                  corner_radius=0)
        self.body.pack(fill="both", expand=True)

        self._collapsed = False
        self._last_height = 220

        # add initial tab
        self._add_tab(name="main")

    def _start_resize(self, event):
        self._resize_start_y = event.y_root
        self._start_height = self.winfo_height()

    def _do_resize(self, event):
        if self._resize_start_y is None:
            return
        delta = self._resize_start_y - event.y_root
        new_height = max(80, min(self._start_height + delta,
                                    self.winfo_toplevel().winfo_height() - 200))
        try:
            self.configure(height=new_height)
        except Exception:
            pass

    def _add_tab(self, name: str = None):
        if not name:
            name = f"term-{len(self.tabs) + 1}"
        if name in self.tabs:
            name = f"{name}-{len(self.tabs)}"

        tab = TerminalTab(self.body, name)
        self.tabs[name] = tab
        self._render_tab_buttons()
        self._activate_tab(name)

    def _render_tab_buttons(self):
        for w in self.tabs_frame.winfo_children():
            w.destroy()
        for name in self.tabs:
            active = name == self.active_tab
            btn = ctk.CTkButton(
                self.tabs_frame, text=name[:12], width=0, height=24,
                fg_color=Colors.ACCENT if active else "transparent",
                hover_color=Colors.PANEL_3,
                text_color=Colors.BG if active else Colors.FG_DIM,
                font=F(9, "bold" if active else "normal"),
                corner_radius=4,
                command=lambda n=name: self._activate_tab(n))
            btn.pack(side="left", padx=2)

    def _activate_tab(self, name: str):
        if name not in self.tabs:
            return
        for tname, tab in self.tabs.items():
            tab.frame.pack_forget()
        self.tabs[name].frame.pack(fill="both", expand=True)
        self.active_tab = name
        self._render_tab_buttons()

    def _close_active(self):
        if not self.active_tab:
            return
        name = self.active_tab
        if name in self.tabs:
            self.tabs[name].frame.destroy()
            del self.tabs[name]
        if self.tabs:
            self._activate_tab(next(iter(self.tabs)))
        else:
            self._add_tab(name="main")

    def _clear_active(self):
        if self.active_tab:
            self.tabs[self.active_tab].clear()

    def _export_active(self):
        if not self.active_tab:
            return
        import tkinter.filedialog as fd
        path = fd.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text", "*.txt"), ("JSON", "*.json"),
                        ("PDF", "*.pdf")])
        if path:
            fmt = "txt"
            if path.endswith(".json"):
                fmt = "json"
            elif path.endswith(".pdf"):
                fmt = "pdf"
            self.tabs[self.active_tab].export(path, fmt)

    def _toggle_collapse(self):
        if self._collapsed:
            self.body.pack(fill="both", expand=True)
            self._collapsed = False
        else:
            self._last_height = self.winfo_height()
            self.body.pack_forget()
            self._collapsed = True

    # ── public API ──
    def log(self, text: str, tab: str = None, tag: str = None):
        if not tab:
            tab = self.active_tab
        if tab in self.tabs:
            self.tabs[tab].write(text + "\n", tag)

    def log_any(self, text: str, tag: str = None):
        """يكتب في كل التبويبات (للرسائل العامة)"""
        for tab in self.tabs.values():
            tab.write(text + "\n", tag)
