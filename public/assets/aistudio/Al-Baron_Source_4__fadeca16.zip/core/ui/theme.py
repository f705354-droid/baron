# language: Python, file: core/ui/theme.py
# Al-Baron Theme — Royal Black, Gold, and Crimson
import customtkinter as ctk
import os

class Colors:
    # الخلفيات (أسود إمبراطوري)
    BG = "#050505"
    BG_2 = "#0a0a0a"
    PANEL = "#111111"
    PANEL_2 = "#1a1a1a"
    PANEL_3 = "#222222"
    BORDER = "#2a2a2a"
    
    # النصوص
    FG = "#e0e0e0"
    FG_DIM = "#8a8a8a"
    FG_DARK = "#555555"
    
    # ألوان البارون (الذهبي والياقوت)
    ACCENT = "#ffd700"       # ذهبي (للأزرار الرئيسية)
    ACCENT_2 = "#ffed8a"     # ذهبي فاتح
    ACCENT_DIM = "#332b00"   # ذهبي داكن للخلفيات
    
    DANGER = "#ff3333"       # أحمر ياقوتي
    WARN = "#ff8c00"         # برتقالي
    INFO = "#00bfff"         # أزرق
    SUCCESS = "#00ff9c"      # أخضر

    GLOW_1 = "#332b00"
    GLOW_2 = "#554400"

def font_family() -> str:
    candidates = ["JetBrains Mono", "Fira Code", "Cascadia Code", "Consolas"]
    try:
        import tkinter.font as tkfont
        available = set(tkfont.families())
        for c in candidates:
            if c in available:
                return c
    except Exception:
        pass
    return "Courier"

FONT_FAMILY = None

def F(size: int = 12, weight: str = "normal") -> ctk.CTkFont:
    global FONT_FAMILY
    if FONT_FAMILY is None:
        FONT_FAMILY = font_family()
    return ctk.CTkFont(family=FONT_FAMILY, size=size, weight=weight)

class Spacing:
    XS = 4
    SM = 8
    MD = 12
    LG = 16
    XL = 24
    XXL = 32

def add_glow(widget, color: str = Colors.ACCENT, intensity: str = "low"):
    try:
        widget.configure(
            border_width=1,
            border_color=color if intensity == "high" else Colors.BORDER,
        )
    except Exception:
        pass
