# language: Python, file: core/ui/gauges.py
# Live gauges — CPU, RAM, GPU, network, AI progress
import tkinter as tk
import psutil
import threading
import time
import shutil
import subprocess
from core.ui.theme import Colors, F


class CircularGauge(tk.Canvas):
    """دائرة تحيط بها نسبة — يشبه سرعة عدّاد"""
    def __init__(self, parent, label: str = "", unit: str = "%",
                  size: int = 100, color: str = None, **kwargs):
        super().__init__(parent, width=size, height=size,
                          bg=Colors.PANEL, highlightthickness=0, **kwargs)
        self.size = size
        self.label = label
        self.unit = unit
        self.color = color or Colors.ACCENT
        self.value = 0
        self.max = 100
        self._draw()

    def set(self, value: float, max_value: float = 100):
        self.value = max(0, min(value, max_value))
        self.max = max_value
        self._draw()

    def _draw(self):
        self.delete("all")
        cx = cy = self.size / 2
        r = self.size / 2 - 14
        # background arc
        self.create_arc(
            cx - r, cy - r, cx + r, cy + r,
            start=225, extent=-270,
            outline=Colors.PANEL_3, width=8, style="arc")
        # value arc
        ratio = self.value / self.max if self.max > 0 else 0
        extent = -270 * ratio
        if extent < 0:
            self.create_arc(
                cx - r, cy - r, cx + r, cy + r,
                start=225, extent=extent,
                outline=self.color, width=8, style="arc")

        # value text
        font_family = F(10).cget("family")
        self.create_text(cx, cy - 4, text=f"{self.value:.0f}",
                          fill=self.color,
                          font=(font_family, 18, "bold"))
        self.create_text(cx, cy + 14, text=self.unit,
                          fill=Colors.FG_DIM,
                          font=(font_family, 8))
        # label below
        self.create_text(cx, self.size - 6, text=self.label.upper(),
                          fill=Colors.FG_DARK,
                          font=(font_family, 8, "bold"))


class LinearGauge(tk.Canvas):
    """شريط أفقي مع label"""
    def __init__(self, parent, label: str = "", height: int = 24,
                  color: str = None, **kwargs):
        super().__init__(parent, height=height,
                          bg=Colors.PANEL, highlightthickness=0, **kwargs)
        self.label = label
        self.color = color or Colors.ACCENT
        self.value = 0
        self._draw()

    def set(self, value: float, max_value: float = 100):
        self.value = max(0, min(value, max_value))
        self.max = max_value
        self._draw()

    def _draw(self):
        self.delete("all")
        w = self.winfo_width() or 200
        if w < 50:
            self.after(50, self._draw)
            return
        label_w = 90
        bar_x = label_w + 8
        bar_w = w - bar_x - 50

        font_family = F(9).cget("family")

        # label
        self.create_text(4, 12, text=self.label.upper(),
                          fill=Colors.FG_DIM, anchor="w",
                          font=(font_family, 8))

        # background bar
        self.create_rectangle(bar_x, 6, bar_x + bar_w, 18,
                                fill=Colors.PANEL_3, outline="")

        # value bar
        ratio = self.value / self.max if self.max > 0 else 0
        self.create_rectangle(bar_x, 6,
                                bar_x + bar_w * ratio, 18,
                                fill=self.color, outline="")

        # value text
        self.create_text(bar_x + bar_w + 4, 12,
                          text=f"{self.value:.0f}",
                          fill=self.color, anchor="w",
                          font=(font_family, 9, "bold"))


class NetworkSparkline(tk.Canvas):
    """رسم بياني حي لمعدل الشبكة"""
    def __init__(self, parent, height: int = 60, points: int = 60,
                  **kwargs):
        super().__init__(parent, height=height,
                          bg=Colors.BG, highlightthickness=0, **kwargs)
        self.points = points
        self.tx_history = [0] * points
        self.rx_history = [0] * points
        self._draw()
        self.after(1000, self._poll)

    def _poll(self):
        try:
            net = psutil.net_io_counters()
            self.tx_history.append(net.bytes_sent / 1024)  # KB
            self.rx_history.append(net.bytes_recv / 1024)
            if len(self.tx_history) > self.points:
                self.tx_history = self.tx_history[-self.points:]
                self.rx_history = self.rx_history[-self.points:]
            self._draw()
        except Exception:
            pass
        self.after(1000, self._poll)

    def _draw(self):
        self.delete("all")
        w = self.winfo_width() or 200
        h = self.winfo_height() or 60
        if w < 50:
            self.after(50, self._draw)
            return

        max_val = max(max(self.tx_history), max(self.rx_history), 1)

        def draw_line(data, color):
            if len(data) < 2:
                return
            step = w / (len(data) - 1)
            prev_x = 0
            prev_y = h - (data[0] / max_val) * (h - 8) - 4
            for i in range(1, len(data)):
                x = i * step
                y = h - (data[i] / max_val) * (h - 8) - 4
                self.create_line(prev_x, prev_y, x, y,
                                  fill=color, width=2)
                prev_x, prev_y = x, y

        draw_line(self.tx_history, Colors.ACCENT)
        draw_line(self.rx_history, Colors.INFO)

        # labels
        font_family = F(8).cget("family")
        self.create_text(4, 4, text="TX", fill=Colors.ACCENT,
                          anchor="nw", font=(font_family, 7))
        self.create_text(w - 4, 4, text="RX", fill=Colors.INFO,
                          anchor="ne", font=(font_family, 7))
        self.create_text(4, h - 4,
                          text=f"{self.tx_history[-1]:.0f}KB/s",
                          fill=Colors.FG_DIM, anchor="sw",
                          font=(font_family, 7))


class SystemMonitor:
    """
    يجمع CPU/RAM/GPU في thread واحد.
    callbacks تُستدعى كل ثانية.
    """
    def __init__(self):
        self.running = False
        self._thread = None
        self.callbacks = []

    def register(self, cb):
        self.callbacks.append(cb)

    def start(self):
        if self.running:
            return
        self.running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self.running = False

    def _loop(self):
        while self.running:
            try:
                cpu = psutil.cpu_percent(interval=0.5)
                mem = psutil.virtual_memory().percent
                gpu = self._get_gpu_usage()
                data = {
                    "cpu": cpu,
                    "ram": mem,
                    "gpu": gpu,
                    "net_tx": psutil.net_io_counters().bytes_sent,
                    "net_rx": psutil.net_io_counters().bytes_recv,
                }
                for cb in self.callbacks:
                    try:
                        cb(data)
                    except Exception:
                        pass
            except Exception:
                pass
            time.sleep(1)

    def _get_gpu_usage(self):
        """يقرأ GPU إن توفر (NVIDIA/AMD)"""
        try:
            if shutil.which("nvidia-smi"):
                r = subprocess.run(
                    ["nvidia-smi", "--query-gpu=utilization.gpu",
                     "--format=csv,noheader,nounits"],
                    capture_output=True, text=True, timeout=2)
                if r.returncode == 0:
                    return float(r.stdout.strip().split("\n")[0])
        except Exception:
            pass
        return 0.0


system_monitor = SystemMonitor()
