# language: Python, file: core/ui/activity_log.py
# Activity log — filterable table with search
import customtkinter as ctk
from tkinter import ttk
from datetime import datetime
from core.ui.theme import Colors, F, Spacing


class ActivityLog(ctk.CTkFrame):
    """
    جدول سجل العمليات — filterable + search.
    columns: time, module, action, target, status
    """
    COLUMNS = [
        ("time", "TIME", 70),
        ("module", "MODULE", 100),
        ("action", "ACTION", 180),
        ("target", "TARGET", 180),
        ("status", "STATUS", 80),
    ]

    def __init__(self, parent, **kwargs):
        super().__init__(parent, fg_color=Colors.PANEL,
                          corner_radius=8, border_width=1,
                          border_color=Colors.BORDER, **kwargs)
        self.entries = []          # all entries
        self.filtered = []         # after filter

        # ── header ──
        hdr = ctk.CTkFrame(self, fg_color="transparent", height=32)
        hdr.pack(fill="x", padx=Spacing.MD, pady=(Spacing.SM, 0))
        hdr.pack_propagate(False)

        ctk.CTkLabel(hdr, text="ACTIVITY LOG",
                      font=F(10, "bold"), text_color=Colors.ACCENT,
                      anchor="w").pack(side="left")

        # filter controls
        filters = ctk.CTkFrame(hdr, fg_color="transparent")
        filters.pack(side="right")

        self.search = ctk.CTkEntry(
            filters, placeholder_text="filter...",
            width=140, height=22, fg_color=Colors.BG_2,
            border_width=1, border_color=Colors.BORDER,
            font=F(9))
        self.search.pack(side="left", padx=(0, Spacing.XS))
        self.search.bind("<KeyRelease>", lambda e: self._apply_filter())

        self.module_filter = ctk.CTkOptionMenu(
            filters, values=["all", "recon", "exploit", "lan",
                              "ad", "cloud", "ai", "c2"],
            width=90, height=22, fg_color=Colors.BG_2,
            button_color=Colors.BORDER, font=F(9),
            command=lambda v: self._apply_filter())
        self.module_filter.pack(side="left")

        # ── treeview ──
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Cyber.Treeview",
                          background=Colors.BG_2,
                          foreground=Colors.FG,
                          fieldbackground=Colors.BG_2,
                          borderwidth=0,
                          font=F(9).cget("family"),
                          rowheight=22)
        style.configure("Cyber.Treeview.Heading",
                          background=Colors.PANEL_2,
                          foreground=Colors.ACCENT,
                          borderwidth=0,
                          font=(F(9).cget("family"), 8, "bold"))
        style.map("Cyber.Treeview",
                    background=[("selected", Colors.ACCENT_DIM)],
                    foreground=[("selected", Colors.ACCENT)])

        self.tree = ttk.Treeview(
            self, columns=[c[0] for c in self.COLUMNS],
            show="headings", style="Cyber.Treeview", height=8)
        for col_id, col_name, col_w in self.COLUMNS:
            self.tree.heading(col_id, text=col_name)
            self.tree.column(col_id, width=col_w)

        self.tree.pack(fill="both", expand=True, padx=Spacing.MD,
                        pady=(Spacing.XS, Spacing.SM))

        # ── status tags ──
        self.tree.tag_configure("success", foreground=Colors.SUCCESS)
        self.tree.tag_configure("error", foreground=Colors.DANGER)
        self.tree.tag_configure("warn", foreground=Colors.WARN)
        self.tree.tag_configure("info", foreground=Colors.INFO)

    def add(self, module: str, action: str, target: str = "",
             status: str = "info"):
        entry = {
            "time": datetime.now().strftime("%H:%M:%S"),
            "module": module,
            "action": action,
            "target": target,
            "status": status,
        }
        self.entries.append(entry)
        if len(self.entries) > 500:
            self.entries = self.entries[-500:]
        self._apply_filter()

    def _apply_filter(self):
        query = self.search.get().strip().lower()
        module_filter = self.module_filter.get()

        filtered = []
        for e in self.entries:
            if module_filter != "all" and e["module"] != module_filter:
                continue
            if query:
                text = " ".join(str(v) for v in e.values()).lower()
                if query not in text:
                    continue
            filtered.append(e)

        self.filtered = filtered[-200:]
        self._render()

    def _render(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        for e in self.filtered:
            tag = e["status"] if e["status"] in (
                "success", "error", "warn", "info") else ""
            self.tree.insert("", "end", values=(
                e["time"], e["module"], e["action"],
                e["target"], e["status"]), tags=(tag,))
        # scroll to end
        children = self.tree.get_children()
        if children:
            self.tree.see(children[-1])
