# language: Python, file: core/ui/topology.py
# Network topology — force-directed graph of discovered hosts
import tkinter as tk
import math
import random
from collections import defaultdict
from core.ui.theme import Colors, F


class TopologyCanvas(tk.Canvas):
    """
    يعرض hosts كـnodes واتصالاتها كـedges.
    - force-directed layout (مثل D3، لكن يدوي)
    - colors حسب حالة الجهاز (compromised/normal/DC)
    - click node → callback
    - hover → highlight
    """
    def __init__(self, parent, on_node_click=None, **kwargs):
        super().__init__(parent, bg=Colors.BG, highlightthickness=0,
                          **kwargs)
        self.nodes = {}          # id → {x, y, vx, vy, data, type}
        self.edges = []          # (src, dst)
        self.selected = None
        self.hovered = None
        self.on_node_click = on_node_click
        self._animation = None
        self._fps = 30
        self.bind("<Button-1>", self._on_click)
        self.bind("<Motion>", self._on_motion)
        self.bind("<Leave>", lambda e: self._set_hover(None))

    def add_node(self, node_id: str, label: str, data: dict = None,
                  node_type: str = "host"):
        """node_type: host / dc / server / compromised / router"""
        if node_id in self.nodes:
            self.nodes[node_id]["data"] = data or {}
            self.nodes[node_id]["label"] = label
            return
        w = self.winfo_width() or 400
        h = self.winfo_height() or 300
        self.nodes[node_id] = {
            "x": w / 2 + random.uniform(-80, 80),
            "y": h / 2 + random.uniform(-80, 80),
            "vx": 0, "vy": 0,
            "label": label,
            "type": node_type,
            "data": data or {},
        }
        self._ensure_animation()

    def add_edge(self, src: str, dst: str):
        if src in self.nodes and dst in self.nodes and (src, dst) not in self.edges:
            self.edges.append((src, dst))

    def remove_node(self, node_id: str):
        self.nodes.pop(node_id, None)
        self.edges = [(a, b) for a, b in self.edges
                       if a != node_id and b != node_id]

    def _ensure_animation(self):
        if self._animation is None:
            self._animate()

    def _animate(self):
        self._step()
        self._draw()
        self._animation = self.after(int(1000 / self._fps), self._animate)

    def _step(self):
        if not self.nodes:
            return
        w = self.winfo_width() or 400
        h = self.winfo_height() or 300
        k = math.sqrt((w * h) / max(len(self.nodes), 1)) * 0.6

        # repulsion
        for a_id, a in self.nodes.items():
            a["vx"] = a["vy"] = 0
            for b_id, b in self.nodes.items():
                if a_id == b_id:
                    continue
                dx = a["x"] - b["x"]
                dy = a["y"] - b["y"]
                d = max(math.hypot(dx, dy), 1)
                f = k * k / d
                a["vx"] += (dx / d) * f
                a["vy"] += (dy / d) * f

        # attraction
        for src, dst in self.edges:
            if src not in self.nodes or dst not in self.nodes:
                continue
            a = self.nodes[src]
            b = self.nodes[dst]
            dx = a["x"] - b["x"]
            dy = a["y"] - b["y"]
            d = max(math.hypot(dx, dy), 1)
            f = d * d / k
            a["vx"] -= (dx / d) * f
            a["vy"] -= (dy / d) * f

        # apply
        for n in self.nodes.values():
            n["vx"] += (w / 2 - n["x"]) * 0.008
            n["vy"] += (h / 2 - n["y"]) * 0.008
            n["x"] += n["vx"] * 0.08
            n["y"] += n["vy"] * 0.08
            n["x"] = max(24, min(w - 24, n["x"]))
            n["y"] = max(24, min(h - 24, n["y"]))

    def _draw(self):
        self.delete("all")
        # edges
        for src, dst in self.edges:
            if src in self.nodes and dst in self.nodes:
                a, b = self.nodes[src], self.nodes[dst]
                self.create_line(a["x"], a["y"], b["x"], b["y"],
                                  fill=Colors.ACCENT_DIM, width=1)

        # nodes
        type_colors = {
            "dc": Colors.DANGER,
            "server": Colors.INFO,
            "compromised": Colors.ACCENT,
            "host": Colors.FG_DIM,
            "router": Colors.WARN,
        }
        for node_id, n in self.nodes.items():
            selected = node_id == self.selected
            hovered = node_id == self.hovered
            radius = 18 if selected or hovered else 12
            color = type_colors.get(n["type"], Colors.FG_DIM)

            # glow ring
            if selected or hovered:
                self.create_oval(
                    n["x"] - radius - 4, n["y"] - radius - 4,
                    n["x"] + radius + 4, n["y"] + radius + 4,
                    outline=color, width=1, fill="")

            # body
            self.create_oval(
                n["x"] - radius, n["y"] - radius,
                n["x"] + radius, n["y"] + radius,
                fill=Colors.PANEL_2, outline=color,
                width=2 if selected else 1)

            # label inside
            self.create_text(
                n["x"], n["y"],
                text=n["label"][:3], fill=color,
                font=(F(9).cget("family"), 8, "bold"))

            # host below
            self.create_text(
                n["x"], n["y"] + radius + 10,
                text=n["label"][:20], fill=Colors.FG_DIM,
                font=(F(8).cget("family"), 7))

    def _on_click(self, event):
        for node_id, n in self.nodes.items():
            if math.hypot(event.x - n["x"], event.y - n["y"]) < 20:
                self.selected = node_id
                if self.on_node_click:
                    self.on_node_click(node_id, n["data"])
                return
        self.selected = None

    def _on_motion(self, event):
        for node_id, n in self.nodes.items():
            if math.hypot(event.x - n["x"], event.y - n["y"]) < 20:
                self._set_hover(node_id)
                return
        self._set_hover(None)

    def _set_hover(self, node_id):
        if self.hovered != node_id:
            self.hovered = node_id
            try:
                self.configure(cursor="hand2" if node_id else "")
            except Exception:
                pass

    def clear(self):
        self.nodes.clear()
        self.edges.clear()
        self.selected = None
        self.delete("all")
