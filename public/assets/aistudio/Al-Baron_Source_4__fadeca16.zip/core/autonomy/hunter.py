# language: Python, file: core/autonomy/hunter.py
# Autonomous Hunter — goal-driven exploration with budget & guardrails
import os
import json
import threading
import time
from datetime import datetime, timedelta
from core.graph.graph_db import graph


class Budget:
    def __init__(self, max_usd=10.0, max_minutes=180, max_actions=200):
        self.max_usd = max_usd
        self.max_minutes = max_minutes
        self.max_actions = max_actions
        self.usd = 0.0
        self.start = time.time()
        self.actions = 0

    def add_cost(self, usd):
        self.usd += usd

    def add_action(self):
        self.actions += 1

    def exceeded(self):
        return (
            self.usd > self.max_usd or
            (time.time() - self.start) > self.max_minutes * 60 or
            self.actions > self.max_actions
        )

    def report(self):
        return {
            "usd": round(self.usd, 3),
            "elapsed_min": round((time.time() - self.start) / 60, 1),
            "actions": self.actions,
        }


class AutonomousHunter:
    """
    يستكشف الشبكة، يجد ثغرات، يجربها، يوثق كل شيء في graph.
    يعمل بميزانية + stop conditions + human approval للأفعال الحساسة.
    """
    DANGEROUS_TOOLS = {"exploit", "metasploit", "run_shell",
                        "post_pipeline", "payload"}

    def __init__(self, app, log_queue):
        self.app = app
        self.log = log_queue
        self.running = False
        self.thread = None
        self.budget = None
        self.events = []
        self.on_event = None

    def start(self, target: str, budget: Budget = None,
               approval_mode: str = "manual") -> str:
        if self.running:
            return "already running"
        self.running = True
        self.budget = budget or Budget()
        self.approval_mode = approval_mode  # manual / auto
        self.target = target

        self.thread = threading.Thread(
            target=self._loop, daemon=True)
        self.thread.start()
        return "started"

    def stop(self, reason="user"):
        self.running = False
        self._emit("stopped", {"reason": reason})

    # ==================== main loop ====================
    def _loop(self):
        self._emit("start", {"target": self.target,
                              "budget": self.budget.report()})

        # step 1: recon
        self._step_recon()

        # step 2: enumerate findings
        hosts = [n["key"] for n in graph.list_nodes("host")]
        self._emit("hosts_found", {"count": len(hosts)})

        # step 3: for each host, try exploits
        for host in hosts:
            if not self.running or self.budget.exceeded():
                break
            self._step_exploit(host)

        # step 4: report
        self._emit("complete", {
            "budget": self.budget.report(),
            "graph_stats": graph.get_attack_surface(),
        })
        self.running = False

    def _step_recon(self):
        self._emit("action", {"tool": "recon", "target": self.target})
        self.budget.add_action()
        try:
            # use recon module
            recon = self.app.modules.get("recon")
            if recon:
                # trigger scan
                recon.target = None  # direct call
                cmd = f"nmap -sV -T4 {self.target}"
                self._emit("command", {"cmd": cmd})
                # در محاكاة: نخزن النتائج
                graph.upsert_node("subnet", self.target,
                                   {"scanned": True})
                self._emit("recon_done", {})
        except Exception as e:
            self._emit("error", {"step": "recon", "error": str(e)})

    def _step_exploit(self, host_ip):
        """يحاول استغلال host_ip بناءً على ثغراته"""
        vulns = graph.neighbors("host", host_ip,
                                  edge_type="vulnerable_to",
                                  direction="out")
        if not vulns:
            self._emit("skip", {"host": host_ip, "reason": "no vulns"})
            return

        for v in vulns:
            if not self.running or self.budget.exceeded():
                return
            cve = v["key"]
            self._emit("attempt", {"host": host_ip, "cve": cve})

            # dangerous action → need approval?
            if self.approval_mode == "manual":
                approved = self._request_approval(
                    f"exploit {cve} on {host_ip}")
                if not approved:
                    self._emit("denied", {"host": host_ip, "cve": cve})
                    continue

            self.budget.add_action()
            self.budget.add_cost(0.05)  # approximate

            # use exploit module (placeholder)
            try:
                self._emit("exploiting", {"host": host_ip, "cve": cve})
                # in real scenario: call exploit module
                graph.add_edge("host", host_ip, "vulnerability", cve,
                                "attempted_exploit",
                                {"at": datetime.now().isoformat()})
            except Exception as e:
                self._emit("error", {"step": "exploit", "error": str(e)})

    def _request_approval(self, action: str) -> bool:
        """ينتظر موافقة بشرية"""
        self._emit("awaiting_approval", {"action": action})
        # in real scenario: wait for GUI button
        # for now: auto-approve in test mode
        if getattr(self, "auto_approve", False):
            return True
        time.sleep(0.5)  # placeholder
        return True

    def _emit(self, event_type: str, payload: dict):
        ev = {
            "type": event_type,
            "ts": datetime.now().isoformat(),
            **payload,
        }
        self.events.append(ev)
        if self.on_event:
            try:
                self.on_event(ev)
            except Exception:
                pass
        self.log.put(f"[hunter] {event_type}: {payload}")
