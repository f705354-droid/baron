# language: Python, file: core/executor.py
# Core Executor — runs real CLI tools async without freezing UI
import subprocess
import threading
import shlex
import re

class ToolExecutor:
    def __init__(self, log_queue, ui_callback=None):
        self.log = log_queue
        self.ui_callback = ui_callback # دالة لتحديث الواجهة (progress bar, terminal)
        self.active_procs = {}

    def run(self, tool_name, cmd, on_complete=None):
        """يشغل أداة ويعيد النتائج للـ UI"""
        if isinstance(cmd, str):
            cmd = shlex.split(cmd)

        self.log.put(f"[{tool_name}] $ {' '.join(cmd)}")

        def _worker():
            try:
                proc = subprocess.Popen(
                    cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, bufsize=1
                )
                self.active_procs[tool_name] = proc
                
                output = []
                for line in proc.stdout:
                    line = line.rstrip()
                    output.append(line)
                    self.log.put(f"[{tool_name}] {line}")
                    if self.ui_callback:
                        self.ui_callback(line)
                
                proc.wait()
                if on_complete:
                    on_complete('\n'.join(output))
                return '\n'.join(output)
            except FileNotFoundError:
                self.log.put(f"[{tool_name}] ERROR: tool not installed.")
            except Exception as e:
                self.log.put(f"[{tool_name}] EXEC ERROR: {e}")
            finally:
                self.active_procs.pop(tool_name, None)

        threading.Thread(target=_worker, daemon=True).start()

    def kill(self, tool_name):
        proc = self.active_procs.get(tool_name)
        if proc:
            proc.terminate()
            self.log.put(f"[{tool_name}] terminated by user.")

# Singleton
EXECUTOR = ToolExecutor
