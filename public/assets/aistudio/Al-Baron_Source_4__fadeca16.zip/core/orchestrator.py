# language: Python, file: core/orchestrator.py
# chains module outputs; runs jobs async, routes to log queue
import threading
import subprocess
import shlex


class Orchestrator:
    def __init__(self, log_queue):
        self.log = log_queue
        self.jobs = {}

    def run(self, name, cmd, timeout=None):
        """run a shell command async, stream output to log"""
        self.log.put(f"[exec] {name}: {cmd}")
        t = threading.Thread(
            target=self._exec, args=(name, cmd, timeout), daemon=True
        )
        t.start()
        self.jobs[name] = t
        return t

    def _exec(self, name, cmd, timeout):
        try:
            proc = subprocess.Popen(
                shlex.split(cmd) if isinstance(cmd, str) else cmd,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1,
            )
            for line in proc.stdout:
                self.log.put(f"[{name}] {line.rstrip()}")
            proc.wait(timeout=timeout)
            self.log.put(f"[{name}] exit {proc.returncode}")
        except subprocess.TimeoutExpired:
            proc.kill()
            self.log.put(f"[{name}] timeout — killed")
        except Exception as e:
            self.log.put(f"[{name}] error: {e}")

    def chain(self, steps):
        """steps: list of (name, cmd). runs sequentially."""
        def run_chain():
            for name, cmd in steps:
                self.run(name, cmd)
        threading.Thread(target=run_chain, daemon=True).start()
