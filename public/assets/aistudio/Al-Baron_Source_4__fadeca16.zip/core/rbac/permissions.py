# language: Python, file: core/rbac/permissions.py
# Permission checker for FastAPI
from fastapi import Depends, HTTPException, Request
from typing import List
from core.rbac.roles import Permission, has_permission


def require_permission(*permissions: Permission):
    """dependency — يتحقق من permissions"""
    async def checker(request: Request):
        user = getattr(request.state, "user", None)
        if not user:
            raise HTTPException(401, "not authenticated")

        role = user.get("role", "viewer")
        for perm in permissions:
            if not has_permission(role, perm):
                raise HTTPException(
                    403,
                    f"missing permission: {perm} for role: {role}"
                )
        return user
    return checker
