# language: Python, file: core/rbac/roles.py
# RBAC — role-based access control
from enum import Enum
from typing import List, Set


class Permission(str, Enum):
    # sessions
    SESSIONS_READ = "sessions:read"
    SESSIONS_WRITE = "sessions:write"
    SESSIONS_DELETE = "sessions:delete"

    # tasks
    TASKS_READ = "tasks:read"
    TASKS_WRITE = "tasks:write"

    # graph
    GRAPH_READ = "graph:read"
    GRAPH_WRITE = "graph:write"

    # modules
    MODULE_RECON = "module:recon"
    MODULE_EXPLOIT = "module:exploit"
    MODULE_LAN = "module:lan"
    MODULE_AD = "module:ad"
    MODULE_CLOUD = "module:cloud"
    MODULE_POST = "module:post"
    MODULE_EXFIL = "module:exfil"
    MODULE_C2 = "module:c2"

    # reports
    REPORTS_READ = "reports:read"
    REPORTS_WRITE = "reports:write"

    # admin
    TENANTS_READ = "tenants:read"
    TENANTS_WRITE = "tenants:write"
    USERS_READ = "users:read"
    USERS_WRITE = "users:write"
    SETTINGS_READ = "settings:read"
    SETTINGS_WRITE = "settings:write"

    # dangerous
    KILL_SWITCH = "kill_switch:trigger"
    SCOPE_WRITE = "scope:write"
    INTEGRATIONS_WRITE = "integrations:write"


class Role(str, Enum):
    ADMIN = "admin"
    OPERATOR = "operator"
    ANALYST = "analyst"
    VIEWER = "viewer"


ROLE_PERMISSIONS: dict = {
    Role.ADMIN: set(Permission),  # all
    Role.OPERATOR: {
        Permission.SESSIONS_READ,
        Permission.SESSIONS_WRITE,
        Permission.SESSIONS_DELETE,
        Permission.TASKS_READ,
        Permission.TASKS_WRITE,
        Permission.GRAPH_READ,
        Permission.GRAPH_WRITE,
        Permission.MODULE_RECON,
        Permission.MODULE_EXPLOIT,
        Permission.MODULE_LAN,
        Permission.MODULE_AD,
        Permission.MODULE_CLOUD,
        Permission.MODULE_POST,
        Permission.MODULE_EXFIL,
        Permission.MODULE_C2,
        Permission.REPORTS_READ,
        Permission.REPORTS_WRITE,
        Permission.SCOPE_WRITE,
        Permission.KILL_SWITCH,
    },
    Role.ANALYST: {
        Permission.SESSIONS_READ,
        Permission.TASKS_READ,
        Permission.GRAPH_READ,
        Permission.MODULE_RECON,
        Permission.REPORTS_READ,
        Permission.REPORTS_WRITE,
    },
    Role.VIEWER: {
        Permission.SESSIONS_READ,
        Permission.TASKS_READ,
        Permission.GRAPH_READ,
        Permission.REPORTS_READ,
    },
}


def get_permissions(role: str) -> Set[Permission]:
    """يرجع permissions لدور"""
    try:
        r = Role(role)
        return ROLE_PERMISSIONS.get(r, set())
    except ValueError:
        return set()


def has_permission(role: str, permission: Permission) -> bool:
    """يتحقق إن كان الدور يملك الصلاحية"""
    return permission in get_permissions(role)


def require(*permissions: Permission):
    """decorator للـendpoints"""
    def decorator(func):
        func._required_permissions = list(permissions)
        return func
    return decorator
