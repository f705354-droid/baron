# language: Python, file: core/threat/threat_model.py
# Threat Model Generator — from graph to STRIDE-style threat models
import json
import os
from datetime import datetime
from typing import List, Dict
from core.graph.graph_db import graph


class ThreatModel:
    """نموذج تهديد لكل host"""

    STRIDE_CATEGORIES = [
        "Spoofing", "Tampering", "Repudiation",
        "Information Disclosure", "Denial of Service",
        "Elevation of Privilege"
    ]

    def __init__(self, host_ip: str):
        self.host_ip = host_ip
        self.threats = []
        self.attack_surfaces = []
        self.recommended_controls = []

    def to_dict(self) -> dict:
        return {
            "host": self.host_ip,
            "generated": datetime.now().isoformat(),
            "threats": self.threats,
            "attack_surfaces": self.attack_surfaces,
            "controls": self.recommended_controls,
        }


class ThreatModelGenerator:
    """
    يبني threat model لكل host من graph:
      1. يجمع كل vulnerabilities المتصلة بالـ host
      2. يجمع كل credentials
      3. يجمع sessions
      4. يستنتج STRIDE threats
      5. يقترح mitigations
    """

    CONTROL_LIBRARY = {
        "CVE-2021-44228": "Upgrade log4j to 2.17.1+, block JNDI lookups",
        "CVE-2021-34527": "Disable Print Spooler or apply patch",
        "CVE-2020-1472": "Apply Zerologon patch + enforce secure RPC",
        "CVE-2017-0144": "Patch MS17-010, disable SMBv1",
        "CVE-2019-0708": "Patch BlueKeep, restrict RDP",
        "kerberoastable": "Rotate service account passwords, use gMSA",
        "unconstrained_delegation": "Remove unconstrained delegation",
        "asrep_roastable": "Disable pre-auth bypass, use strong passwords",
        "smb_signing_off": "Enable SMB signing",
        "rdp_exposed": "Restrict RDP to VPN only",
        "ssh_root_login": "Disable PermitRootLogin",
        "default_creds": "Change default credentials immediately",
    }

    def generate(self, host_ip: str) -> ThreatModel:
        tm = ThreatModel(host_ip)

        host = graph.get_node("host", host_ip)
        if not host:
            tm.threats.append({
                "type": "Unknown",
                "detail": "host not in graph",
            })
            return tm

        # collect vulnerabilities
        vulns = graph.neighbors("host", host_ip,
                                  edge_type="vulnerable_to",
                                  direction="out")
        for v in vulns:
            cve = v["key"]
            tm.attack_surfaces.append({
                "surface": f"vulnerability:{cve}",
                "details": v["properties"],
            })
            tm.threats.append({
                "stride": "Elevation of Privilege",
                "cve": cve,
                "likelihood": "high",
                "impact": "critical" if "2021" in cve or "2020" in cve else "high",
            })
            if cve in self.CONTROL_LIBRARY:
                tm.recommended_controls.append({
                    "control": self.CONTROL_LIBRARY[cve],
                    "cve": cve,
                })

        # collect credentials
        creds = graph.neighbors("host", host_ip,
                                  edge_type="has_cred",
                                  direction="out")
        for c in creds:
            tm.attack_surfaces.append({
                "surface": "credential",
                "details": {"user": c["properties"].get("user"),
                              "source": c["key"]},
            })
            tm.threats.append({
                "stride": "Spoofing",
                "detail": f"exposed credential for {c['properties'].get('user')}",
                "likelihood": "high",
                "impact": "high",
            })
            tm.recommended_controls.append({
                "control": "Rotate exposed credentials, enable MFA",
            })

        # sessions
        sessions = graph.neighbors("host", host_ip,
                                     edge_type="has_session",
                                     direction="in")
        for s in sessions:
            tm.threats.append({
                "stride": "Repudiation",
                "detail": f"active session: {s['key']}",
                "likelihood": "confirmed",
                "impact": "critical",
            })
            tm.recommended_controls.append({
                "control": f"Terminate session {s['key']}, "
                          f"review logs, force logout",
            })

        # check known patterns
        props = host["properties"]
        if props.get("is_dc"):
            tm.threats.append({
                "stride": "Elevation of Privilege",
                "detail": "Domain Controller — critical asset",
                "likelihood": "high",
                "impact": "critical",
            })
            tm.recommended_controls.append({
                "control": "Tier-0 isolation, PAW only, Credential Guard",
            })

        if props.get("public"):
            tm.threats.append({
                "stride": "Information Disclosure",
                "detail": "internet-facing host",
                "likelihood": "high",
                "impact": "high",
            })
            tm.recommended_controls.append({
                "control": "WAF + rate limiting + monitoring",
            })

        return tm

    def generate_all(self) -> List[ThreatModel]:
        hosts = [n["key"] for n in graph.list_nodes("host")]
        return [self.generate(h) for h in hosts]
