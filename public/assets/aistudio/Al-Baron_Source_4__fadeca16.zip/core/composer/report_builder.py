# language: Python, file: core/composer/report_builder.py
# Report composer — builds PDF from graph + user selections
import os
import json
from datetime import datetime
from typing import List, Dict
from core.graph.graph_db import graph

try:
    from fpdf import FPDF
    HAS_FPDF = True
except ImportError:
    HAS_FPDF = False


class ReportSection:
    """قسم في التقرير"""
    def __init__(self, title: str, kind: str = "text",
                  data: any = None):
        self.title = title
        self.kind = kind        # text / table / graph / findings / image
        self.data = data


class ReportComposer:
    """
    يبني تقرير PDF من graph + اختيارات المستخدم.
    """
    def __init__(self):
        self.sections: List[ReportSection] = []
        self.metadata = {
            "title": "Al-Baron Engagement Report",
            "client": "",
            "tester": "",
            "classification": "CONFIDENTIAL",
            "generated": datetime.now().isoformat(),
        }

    def add_section(self, title: str, kind: str = "text",
                     data=None):
        self.sections.append(ReportSection(title, kind, data))

    def remove_section(self, index: int):
        if 0 <= index < len(self.sections):
            self.sections.pop(index)

    def move_section(self, from_idx: int, to_idx: int):
        if 0 <= from_idx < len(self.sections):
            section = self.sections.pop(from_idx)
            self.sections.insert(to_idx, section)

    def set_metadata(self, **kwargs):
        self.metadata.update(kwargs)

    # ==================== render ====================
    def render_pdf(self, output_path: str) -> dict:
        if not HAS_FPDF:
            return {"error": "fpdf2 not installed — pip install fpdf2"}

        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=15)

        # cover page
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 28)
        pdf.ln(50)
        pdf.cell(0, 15, self.metadata.get("title", "Report"),
                  align="C", new_x="LMARGIN", new_y="NEXT")
        pdf.ln(20)
        pdf.set_font("Helvetica", "", 14)
        for k, v in [
            ("Client", self.metadata.get("client")),
            ("Tester", self.metadata.get("tester")),
            ("Classification", self.metadata.get("classification")),
            ("Generated", self.metadata.get("generated")[:19]),
        ]:
            if v:
                pdf.cell(0, 8, f"{k}: {v}", align="C",
                          new_x="LMARGIN", new_y="NEXT")

        # sections
        for section in self.sections:
            pdf.add_page()
            pdf.set_font("Helvetica", "B", 16)
            pdf.cell(0, 10, section.title, new_x="LMARGIN",
                      new_y="NEXT")
            pdf.ln(4)

            if section.kind == "text":
                pdf.set_font("Helvetica", "", 10)
                text = section.data or ""
                pdf.multi_cell(0, 5, str(text))

            elif section.kind == "findings":
                pdf.set_font("Helvetica", "", 9)
                for finding in section.data or []:
                    pdf.multi_cell(0, 4,
                        f"• {finding.get('severity', '?')}: "
                        f"{finding.get('title', '?')}")
                    pdf.ln(1)

            elif section.kind == "table":
                pdf.set_font("Courier", "", 8)
                data = section.data or {}
                headers = data.get("headers", [])
                rows = data.get("rows", [])
                # header
                w = 180 / max(len(headers), 1)
                for h in headers:
                    pdf.cell(w, 5, str(h)[:20], border=1)
                pdf.ln()
                for row in rows:
                    for cell in row:
                        pdf.cell(w, 5, str(cell)[:20], border=1)
                    pdf.ln()

            elif section.kind == "graph":
                pdf.set_font("Helvetica", "", 10)
                stats = graph.get_attack_surface()
                pdf.cell(0, 6, "Graph Summary:", new_x="LMARGIN",
                          new_y="NEXT")
                for k, v in stats.items():
                    pdf.cell(0, 5, f"  {k}: {v}", new_x="LMARGIN",
                              new_y="NEXT")
                pdf.ln(4)
                pdf.cell(0, 5, "Hosts:", new_x="LMARGIN",
                          new_y="NEXT")
                for n in graph.list_nodes("host"):
                    pdf.multi_cell(0, 4, f"  • {n['key']}")

            elif section.kind == "image":
                path = section.data
                if path and os.path.exists(path):
                    pdf.image(path, x=10, w=180)

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        pdf.output(output_path)
        return {
            "path": output_path,
            "size": os.path.getsize(output_path),
            "sections": len(self.sections),
        }

    # ==================== templates ====================
    def auto_populate(self, template: str = "full"):
        """يملأ التقرير تلقائياً من graph"""
        self.sections.clear()

        if template == "full":
            self.sections.append(ReportSection(
                "Executive Summary", "text",
                "This report documents the penetration testing engagement "
                "conducted by Al-Baron. All findings were obtained within "
                "the authorized scope and timeframe."))
            self.sections.append(ReportSection(
                "Methodology", "text",
                "The engagement followed a structured approach: "
                "reconnaissance, exploitation, post-exploitation, and "
                "reporting. All actions were logged and auditable."))
            self.sections.append(ReportSection(
                "Graph Summary", "graph"))
            # findings
            hosts = graph.list_nodes("host")
            findings = []
            for h in hosts:
                vulns = graph.neighbors("host", h["key"],
                                          edge_type="vulnerable_to",
                                          direction="out")
                for v in vulns:
                    findings.append({
                        "severity": "high" if "2021" in v["key"]
                                     or "2020" in v["key"] else "medium",
                        "title": f"{v['key']} on {h['key']}",
                    })
            if findings:
                self.sections.append(ReportSection(
                    "Findings", "findings", findings))

            # recommendations
            self.sections.append(ReportSection(
                "Recommendations", "text",
                "1. Patch all critical CVEs within 30 days.\n"
                "2. Enable SMB signing and LDAP signing.\n"
                "3. Rotate all credentials exposed during the engagement.\n"
                "4. Enable MFA for all administrative accounts.\n"
                "5. Deploy EDR with behavioral detection."))

        elif template == "executive":
            self.sections.append(ReportSection(
                "Summary", "text",
                "Brief overview of the engagement and key findings."))
            self.sections.append(ReportSection(
                "Findings", "findings",
                [{"severity": "high", "title": "extracted from graph"}]))

        elif template == "technical":
            self.sections.append(ReportSection(
                "Graph Summary", "graph"))
            self.sections.append(ReportSection(
                "Detailed Findings", "text",
                "Full technical detail of each finding."))
