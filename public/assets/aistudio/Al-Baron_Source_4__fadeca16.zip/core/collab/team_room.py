# language: Python, file: core/collab/team_room.py
# Team Room — multi-operator collaboration over WebSocket
import asyncio
import json
import threading
import queue
import os
import time
from datetime import datetime
from collections import defaultdict


class TeamRoom:
    """
    غرفة عمليات مشتركة:
      - chat
      - shared findings
      - notification broadcast
      - active operators
    """
    def __init__(self, log_queue):
        self.log = log_queue
        self.messages = []          # chat messages
        self.operators = {}         # username → {joined_at, last_seen}
        self.ws = None
        self.connected = False
        self.room_id = "default"
        self.on_event = None

    def connect(self, url: str, username: str, room: str = "default"):
        """يتصل بغرفة عبر WebSocket"""
        self.username = username
        self.room_id = room

        def run():
            try:
                import websockets
                asyncio.run(self._ws_loop(url))
            except ImportError:
                self.log.put("[team] websockets not installed")
            except Exception as e:
                self.log.put(f"[team] connect error: {e}")

        self._thread = threading.Thread(target=run, daemon=True)
        self._thread.start()

    async def _ws_loop(self, url):
        import websockets
        async with websockets.connect(url) as ws:
            self.ws = ws
            self.connected = True
            self.log.put(f"[team] connected to {url}")

            # announce join
            await ws.send(json.dumps({
                "type": "join",
                "room": self.room_id,
                "username": self.username,
            }))

            async for message in ws:
                try:
                    data = json.loads(message)
                    self._handle(data)
                except Exception:
                    pass

    def _handle(self, data: dict):
        t = data.get("type")
        if t == "chat":
            msg = {
                "from": data.get("from", "?"),
                "text": data.get("text", ""),
                "ts": data.get("ts", datetime.now().isoformat()),
            }
            self.messages.append(msg)
            self._emit("chat", msg)
        elif t == "operator_join":
            self.operators[data["username"]] = {
                "joined_at": datetime.now().isoformat(),
                "last_seen": datetime.now().isoformat(),
            }
            self._emit("operator_join", {"username": data["username"]})
        elif t == "operator_leave":
            self.operators.pop(data.get("username"), None)
            self._emit("operator_leave", {"username": data.get("username")})
        elif t == "findings":
            self._emit("findings", data)
        elif t == "cursor":
            self._emit("cursor", data)

    def send_message(self, text: str):
        if not self.connected:
            self.log.put("[team] not connected")
            return
        import asyncio

        async def send():
            await self.ws.send(json.dumps({
                "type": "chat",
                "room": self.room_id,
                "from": self.username,
                "text": text,
                "ts": datetime.now().isoformat(),
            }))
        asyncio.run_coroutine_threadsafe(send(), self._loop)

    def broadcast_finding(self, finding: dict):
        if not self.connected:
            return
        import asyncio

        async def send():
            await self.ws.send(json.dumps({
                "type": "findings",
                "room": self.room_id,
                "from": self.username,
                "finding": finding,
            }))
        asyncio.run_coroutine_threadsafe(send(), self._loop)

    def _emit(self, event_type: str, payload):
        if self.on_event:
            try:
                self.on_event({"type": event_type, **payload})
            except Exception:
                pass
