# language: Python, file: core/perf/batch.py
# Batch AI requests — يجمع N طلبات في طلب واحد كبير لتوفير tokens
# مفيد لتحليل آلاف hosts من مسح واحد
import asyncio
import json
from typing import List, Dict, Callable
from datetime import datetime


class BatchProcessor:
    """
    يستقبل items، يجمعها، يعالجها bulk.
    - dynamic batch size (حسب queue depth)
    - timeout-flush (مثل 2 ثانية) لتجنب الانتظار الطويل
    - retries مع exponential backoff
    """
    def __init__(self, process_fn: Callable, max_batch: int = 20,
                  flush_interval: float = 2.0, max_retries: int = 3):
        self.process_fn = process_fn
        self.max_batch = max_batch
        self.flush_interval = flush_interval
        self.max_retries = max_retries
        self.queue: List[tuple] = []
        self._lock = asyncio.Lock()
        self._task = None

    async def add(self, item: dict, callback: Callable = None):
        async with self._lock:
            self.queue.append((item, callback))
            if len(self.queue) >= self.max_batch:
                await self._flush()
            elif self._task is None:
                self._task = asyncio.create_task(self._delayed_flush())

    async def _delayed_flush(self):
        await asyncio.sleep(self.flush_interval)
        async with self._lock:
            if self.queue:
                await self._flush()
        self._task = None

    async def _flush(self):
        if not self.queue:
            return
        batch = self.queue[:self.max_batch]
        self.queue = self.queue[self.max_batch:]

        items = [item for item, _ in batch]
        callbacks = [cb for _, cb in batch]

        for attempt in range(self.max_retries):
            try:
                results = await self.process_fn(items)
                for cb, res in zip(callbacks, results):
                    if cb:
                        try:
                            cb(res)
                        except Exception:
                            pass
                return
            except Exception as e:
                if attempt == self.max_retries - 1:
                    for cb in callbacks:
                        if cb:
                            try:
                                cb({"error": str(e)})
                            except Exception:
                                pass
                else:
                    await asyncio.sleep(2 ** attempt)


async def batch_ai_analyze(items: List[dict]) -> List[dict]:
    """
    Batch analysis لأكثر من host في طلب واحد.
    يوفر 70-80% من tokens مقابل ~3x سرعة.
    """
    import os
    if not items:
        return []

    # ابنِ prompt واحد
    prompt_parts = []
    for i, item in enumerate(items):
        prompt_parts.append(f"[{i+1}] {json.dumps(item, ensure_ascii=False)}")
    prompt = "\n".join(prompt_parts)
    full = f"""حلل كل هدف من الأهداف التالية وأعد مصفوفة JSON بنفس العدد:

{prompt}

أعد فقط:
[
  {{"index": 1, "severity": "...", "findings": [...], "next_steps": [...]}},
  ...
]
بدون شرح خارجي."""

    try:
        if os.getenv("ANTHROPIC_API_KEY"):
            from anthropic import Anthropic
            c = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
            r = c.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=4096,
                messages=[{"role": "user", "content": full}])
            text = r.content[0].text
        elif os.getenv("OPENAI_API_KEY"):
            from openai import OpenAI
            c = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
            r = c.chat.completions.create(
                model="gpt-4o", max_tokens=4096,
                messages=[{"role": "user", "content": full}])
            text = r.choices[0].message.content
        else:
            return [{"error": "no api key"} for _ in items]

        # parse
        if "```" in text:
            text = text.split("```")[1]
            if text.startswith("json"):
                text = text[4:]
        parsed = json.loads(text.strip())
        # fill gaps
        out = []
        for i in range(len(items)):
            match = next((p for p in parsed if p.get("index") == i+1), None)
            out.append(match or {"error": "not parsed"})
        return out
    except Exception as e:
        return [{"error": str(e)} for _ in items]
