# language: Python, file: core/perf/memory.py
# Memory guard — يحمي VM المختبر من OOM
import os
import gc
import psutil
import threading
import time
from typing import Optional


class MemoryGuard:
    """
    يراقب الذاكرة، يطلق GC عند الضغط، يمنع تشغيل مهام كبيرة.
    حماية ضرورية على VM بـ4-8GB RAM.
    """
    def __init__(self, soft_limit_pct: float = 75.0,
                  hard_limit_pct: float = 90.0,
                  check_interval: float = 5.0):
        self.soft = soft_limit_pct
        self.hard = hard_limit_pct
        self.interval = check_interval
        self._stop = threading.Event()
        self._thread = None
        self.events = []

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()

    def _loop(self):
        while not self._stop.is_set():
            try:
                pct = psutil.virtual_memory().percent
                if pct >= self.hard:
                    self._hard_release()
                elif pct >= self.soft:
                    self._soft_release()
            except Exception:
                pass
            self._stop.wait(self.interval)

    def _soft_release(self):
        gc.collect()
        self.events.append({
            "ts": time.time(), "level": "soft", "action": "gc",
        })

    def _hard_release(self):
        gc.collect()
        # أخبر الوحدات الكبيرة بالتخفيف
        try:
            from core.perf.cache import semantic_cache
            semantic_cache._evict_if_needed()
        except Exception:
            pass
        self.events.append({
            "ts": time.time(), "level": "hard", "action": "evict+gc",
        })

    def can_start_heavy_task(self) -> bool:
        """قبل تشغيل fine-tune أو world model، تحقق من الذاكرة"""
        mem = psutil.virtual_memory()
        return mem.percent < self.soft

    def report(self) -> dict:
        mem = psutil.virtual_memory()
        return {
            "total_gb": round(mem.total / 1e9, 2),
            "available_gb": round(mem.available / 1e9, 2),
            "percent": mem.percent,
            "events": self.events[-20:],
        }


memory_guard = MemoryGuard()
