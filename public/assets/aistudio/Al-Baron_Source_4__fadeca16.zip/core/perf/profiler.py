# language: Python, file: core/perf/profiler.py
# Profiler — يحدد بطء المنصة: أي دالة، أي module، أي عملية
import cProfile
import pstats
import io
import time
import functools
import threading
from typing import Callable, Dict
from collections import defaultdict
from contextlib import contextmanager


class Profiler:
    """
    - Decorator @profile لتتبع دوال محددة
    - cProfile context manager للـdeep profiling
    - hotspot report (top N الدوال الأبطأ)
    - memory tracking
    """
    def __init__(self):
        self.timings: Dict[str, list] = defaultdict(list)
        self._lock = threading.Lock()

    def profile(self, func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            t0 = time.perf_counter()
            try:
                return func(*args, **kwargs)
            finally:
                elapsed = time.perf_counter() - t0
                with self._lock:
                    self.timings[func.__qualname__].append(elapsed)
        return wrapper

    @contextmanager
    def measure(self, label: str):
        t0 = time.perf_counter()
        try:
            yield
        finally:
            elapsed = time.perf_counter() - t0
            with self._lock:
                self.timings[label].append(elapsed)

    def deep_profile(self, func: Callable, *args, **kwargs) -> tuple:
        """يرجع (result، profile_string)"""
        pr = cProfile.Profile()
        pr.enable()
        result = func(*args, **kwargs)
        pr.disable()
        s = io.StringIO()
        ps = pstats.Stats(pr, stream=s).sort_stats("cumulative")
        ps.print_stats(20)
        return result, s.getvalue()

    def report(self, top_n: int = 20) -> list:
        """يرجع hotspot report"""
        report = []
        with self._lock:
            for name, times in self.timings.items():
                if not times:
                    continue
                report.append({
                    "function": name,
                    "calls": len(times),
                    "total_sec": sum(times),
                    "avg_ms": (sum(times) / len(times)) * 1000,
                    "max_ms": max(times) * 1000,
                    "p95_ms": sorted(times)[int(len(times) * 0.95)] * 1000
                        if len(times) > 1 else max(times) * 1000,
                })
        report.sort(key=lambda x: -x["total_sec"])
        return report[:top_n]

    def reset(self):
        with self._lock:
            self.timings.clear()


profiler = Profiler()
