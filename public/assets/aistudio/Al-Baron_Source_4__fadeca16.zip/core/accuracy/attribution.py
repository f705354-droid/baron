# language: Python, file: core/accuracy/attribution.py
# MITRE ATT&CK attribution — يربط كل finding بتقنية معروفة
# يسمح بتقارير متوافقة مع frameworks المستخدمة في الصناعة
from typing import Dict, List, Optional


ATTACK_MAP = {
    # reconnaissance
    "nmap_scan": {"id": "T1046", "tactic": "Discovery", "name": "Network Service Discovery"},
    "dns_enum": {"id": "T1590.002", "tactic": "Reconnaissance", "name": "DNS Lookups"},
    "subdomain_scan": {"id": "T1590.001", "tactic": "Reconnaissance", "name": "Domain Trust Discovery"},

    # initial access
    "phishing": {"id": "T1566", "tactic": "Initial Access", "name": "Phishing"},
    "valid_accounts": {"id": "T1078", "tactic": "Initial Access", "name": "Valid Accounts"},
    "exploit_public": {"id": "T1190", "tactic": "Initial Access", "name": "Exploit Public-Facing App"},
    "smb_relay": {"id": "T1557.001", "tactic": "Credential Access", "name": "LLMNR/NBT-NS Poisoning"},

    # execution
    "powershell": {"id": "T1059.001", "tactic": "Execution", "name": "PowerShell"},
    "shell_command": {"id": "T1059.004", "tactic": "Execution", "name": "Unix Shell"},

    # persistence
    "schtask": {"id": "T1053.005", "tactic": "Persistence", "name": "Scheduled Task"},
    "systemd_service": {"id": "T1543.002", "tactic": "Persistence", "name": "Systemd Service"},
    "registry_run": {"id": "T1547.001", "tactic": "Persistence", "name": "Registry Run Keys"},

    # privilege escalation
    "kerberoast": {"id": "T1558.003", "tactic": "Credential Access", "name": "Kerberoasting"},
    "asrep_roast": {"id": "T1558.004", "tactic": "Credential Access", "name": "AS-REP Roasting"},
    "adcs_esc1": {"id": "T1649", "tactic": "Credential Access", "name": "Steal or Forge Authentication Certificates"},

    # defense evasion
    "amsi_patch": {"id": "T1562.001", "tactic": "Defense Evasion", "name": "Disable or Modify Tools"},
    "process_injection": {"id": "T1055", "tactic": "Defense Evasion", "name": "Process Injection"},
    "obfuscated_file": {"id": "T1027", "tactic": "Defense Evasion", "name": "Obfuscated Files or Information"},

    # credential access
    "dcsync": {"id": "T1003.006", "tactic": "Credential Access", "name": "DCSync"},
    "lsass_dump": {"id": "T1003.001", "tactic": "Credential Access", "name": "LSASS Memory"},

    # discovery
    "bloodhound": {"id": "T1087.002", "tactic": "Discovery", "name": "Domain Account"},
    "local_users": {"id": "T1087.001", "tactic": "Discovery", "name": "Local Account"},

    # lateral movement
    "psexec": {"id": "T1021.002", "tactic": "Lateral Movement", "name": "SMB/Windows Admin Shares"},
    "wmi": {"id": "T1047", "tactic": "Lateral Movement", "name": "Windows Management Instrumentation"},
    "ssh_lateral": {"id": "T1021.004", "tactic": "Lateral Movement", "name": "SSH"},

    # collection
    "screen_capture": {"id": "T1113", "tactic": "Collection", "name": "Screen Capture"},
    "keylog": {"id": "T1056.001", "tactic": "Collection", "name": "Keylogging"},

    # c2
    "https_c2": {"id": "T1071.001", "tactic": "Command and Control", "name": "Web Protocols"},
    "dns_c2": {"id": "T1071.004", "tactic": "Command and Control", "name": "DNS"},

    # exfiltration
    "exfil_c2": {"id": "T1041", "tactic": "Exfiltration", "name": "Exfiltration Over C2 Channel"},
    "exfil_alt": {"id": "T1048", "tactic": "Exfiltration", "name": "Exfiltration Over Alternative Protocol"},

    # impact
    "ransomware": {"id": "T1486", "tactic": "Impact", "name": "Data Encrypted for Impact"},
    "service_stop": {"id": "T1489", "tactic": "Impact", "name": "Service Stop"},
}


class ATTACKAttributor:
    """
    يربط findings و actions بتقنيات MITRE.
    يرجع coverage report كامل.
    """
    def __init__(self):
        self.map = ATTACK_MAP
        self.observed: Dict[str, int] = {}

    def attribute(self, action: str, count: int = 1) -> Optional[dict]:
        tech = self.map.get(action)
        if tech:
            self.observed[tech["id"]] = self.observed.get(tech["id"], 0) + count
        return tech

    def attribute_findings(self, findings: List[dict]) -> List[dict]:
        out = []
        for f in findings:
            action = f.get("action") or f.get("type")
            tech = self.attribute(action) if action else None
            out.append({**f, "attack": tech})
        return out

    def coverage(self) -> dict:
        """تغطية MITRE — أي tactics جُرّبت"""
        tactics = {}
        for tid, count in self.observed.items():
            tech = next((t for t in self.map.values() if t["id"] == tid), None)
            if tech:
                tac = tech["tactic"]
                tactics.setdefault(tac, {"count": 0, "techniques": set()})
                tactics[tac]["count"] += count
                tactics[tac]["techniques"].add(tid)

        return {
            "total_techniques": len(self.observed),
            "tactics": {
                k: {
                    "count": v["count"],
                    "techniques": sorted(v["techniques"]),
                } for k, v in tactics.items()
            },
        }

    def reset(self):
        self.observed.clear()


attack_attributor = ATTACKAttributor()
