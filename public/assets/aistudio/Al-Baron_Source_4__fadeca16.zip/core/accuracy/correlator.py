# language: Python, file: core/accuracy/correlator.py
# يربط نتائج من أدوات مختلفة — أدق من أي أداة وحدها
import re
from typing import List, Dict, Set, Optional
from collections import defaultdict


class FindingCorrelator:
    """
    يستقبل نتائج من nmap + nxc + certipy + bloodhound، ينتج findings موحّدة.
    - يدمج hosts مكررة (نفس IP من مصادر متعددة)
    - يربط CVE بـservice version
    - يرفع severity عند تأكيد متعدد الأدوات
    """
    def __init__(self):
        self.hosts: Dict[str, dict] = {}       # ip → merged
        self.services: Dict[str, List[dict]] = defaultdict(list)  # ip:port → findings
        self.findings: List[dict] = []

    def ingest(self, source: str, data: dict):
        """يستقبل finding من أداة معينة"""
        ip = data.get("ip") or data.get("host") or data.get("target")
        if not ip:
            return

        # merge host
        if ip not in self.hosts:
            self.hosts[ip] = {
                "ip": ip, "sources": set(), "hostnames": set(),
                "os": None, "ports": {},
            }
        h = self.hosts[ip]
        h["sources"].add(source)
        if data.get("hostname"):
            h["hostnames"].add(data["hostname"])
        if data.get("os") and not h["os"]:
            h["os"] = data["os"]

        # merge ports
        port = data.get("port")
        if port:
            key = f"{ip}:{port}"
            h["ports"][port] = {
                "port": port,
                "service": data.get("service"),
                "version": data.get("version"),
                "banner": data.get("banner"),
                "sources": h["ports"].get(port, {}).get("sources", set()) | {source},
            }
            self.services[key].append({
                "source": source, "data": data,
            })

        # keep finding
        self.findings.append({"source": source, **data})

    def correlate(self) -> Dict:
        """
        يرجع {hosts، correlated_findings، cves}
        """
        correlated = []
        for ip, h in self.hosts.items():
            # حدد severity بناءً على عدد المصادر
            source_count = len(h["sources"])
            for port, svc in h["ports"].items():
                # جمع CVEs لهذا service من كل المصادر
                cves = set()
                versions = set()
                for f in self.findings:
                    if f.get("ip") == ip and f.get("port") == port:
                        if f.get("cve"):
                            cves.update(f["cve"] if isinstance(f["cve"], list) else [f["cve"]])
                        if f.get("version"):
                            versions.add(f["version"])

                severity = self._compute_severity(source_count, cves, svc)
                correlated.append({
                    "ip": ip,
                    "port": port,
                    "service": svc.get("service"),
                    "version": svc.get("version") or (versions.pop() if versions else None),
                    "cves": sorted(cves),
                    "source_count": source_count,
                    "sources": sorted(svc.get("sources", [])),
                    "severity": severity,
                    "hostnames": sorted(h["hostnames"]),
                    "os": h["os"],
                })

        # ملخص CVEs
        cve_summary = defaultdict(list)
        for c in correlated:
            for cve in c["cves"]:
                cve_summary[cve].append({
                    "ip": c["ip"], "port": c["port"], "service": c["service"],
                })

        return {
            "hosts": [{
                "ip": ip, "hostnames": sorted(h["hostnames"]),
                "os": h["os"], "sources": sorted(h["sources"]),
                "port_count": len(h["ports"]),
            } for ip, h in self.hosts.items()],
            "correlated": correlated,
            "cves": dict(cve_summary),
        }

    def _compute_severity(self, source_count: int, cves: Set[str],
                            svc: dict) -> str:
        if cves:
            # CVE معروف + متعدد المصادر → critical
            if source_count >= 2:
                return "CRITICAL"
            return "HIGH"
        service = (svc.get("service") or "").lower()
        if source_count >= 3:
            return "MEDIUM"
        if source_count == 2:
            return "MEDIUM"
        if service in ("rdp", "smb", "ssh", "winrm"):
            return "MEDIUM"
        return "LOW"


finding_correlator = FindingCorrelator()
