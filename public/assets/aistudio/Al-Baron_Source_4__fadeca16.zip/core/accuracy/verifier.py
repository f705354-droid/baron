# language: Python, file: core/accuracy/verifier.py
# Verifier — يتحقق من findings قبل حفظها، يقلل false positives
import socket
import subprocess
from typing import Dict, Optional, List


class Verifier:
    """
    قبل قبول أي finding، يتحقق منه بأداة ثانية أو اختبار فعلي.
    هذا ما يفرق تقريراً موثوقاً من قائمة أخطاء.
    """
    def __init__(self):
        self.verified: List[dict] = []

    def verify_port_open(self, ip: str, port: int, timeout: float = 2.0) -> bool:
        """TCP connect verify"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(timeout)
            result = s.connect_ex((ip, port))
            s.close()
            return result == 0
        except Exception:
            return False

    def verify_http_service(self, ip: str, port: int) -> Optional[dict]:
        """يتحقق أن http فعلاً يعمل"""
        try:
            import urllib.request
            url = f"http://{ip}:{port}/"
            req = urllib.request.Request(url, method="HEAD")
            with urllib.request.urlopen(req, timeout=3) as r:
                server = r.headers.get("Server", "")
                return {
                    "verified": True,
                    "status": r.status,
                    "server": server,
                }
        except Exception:
            try:
                # جرب https
                import urllib.request, ssl
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                url = f"https://{ip}:{port}/"
                req = urllib.request.Request(url, method="HEAD")
                with urllib.request.urlopen(req, timeout=3, context=ctx) as r:
                    return {"verified": True, "status": r.status,
                            "server": r.headers.get("Server", ""), "tls": True}
            except Exception:
                return None

    def verify_smb(self, ip: str) -> Optional[dict]:
        try:
            r = subprocess.run(
                ["nxc", "smb", ip, "--no-bruteforce"],
                capture_output=True, text=True, timeout=8)
            out = r.stdout + r.stderr
            if "SMB" in out or "signing" in out.lower():
                return {"verified": True, "output": out[:300]}
        except Exception:
            pass
        return None

    def verify_version(self, ip: str, port: int, claimed_version: str) -> bool:
        """يتحقق أن الإصدار المزعوم يطابق البانر الحقيقي"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(3)
            s.connect((ip, port))
            s.send(b"\r\n")
            banner = s.recv(1024).decode(errors="ignore")
            s.close()
            if claimed_version and claimed_version[:4] in banner:
                return True
        except Exception:
            pass
        return False

    def verify_finding(self, finding: dict) -> dict:
        """
        يتحقق من finding ويضيف status:
          verified، unverified، false_positive
        """
        ip = finding.get("ip")
        port = finding.get("port")
        service = (finding.get("service") or "").lower()

        if not ip or not port:
            return {**finding, "status": "unverifiable"}

        # 1. تحقق من port
        if not self.verify_port_open(ip, port):
            return {**finding, "status": "false_positive",
                    "reason": "port_closed_on_recheck"}

        # 2. تحقق حسب النوع
        verified_extra = {}
        if service in ("http", "https", "http-proxy"):
            http_check = self.verify_http_service(ip, port)
            if http_check:
                verified_extra["http_check"] = http_check
            else:
                return {**finding, "status": "false_positive",
                        "reason": "http_not_responding"}
        elif service in ("smb", "microsoft-ds", "netbios-ssn"):
            smb_check = self.verify_smb(ip)
            if smb_check:
                verified_extra["smb_check"] = smb_check

        result = {
            **finding,
            "status": "verified",
            **verified_extra,
        }
        self.verified.append(result)
        return result

    def verify_batch(self, findings: List[dict],
                      max_concurrent: int = 10) -> List[dict]:
        """verification متوازية"""
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(
                max_workers=max_concurrent) as ex:
            return list(ex.map(self.verify_finding, findings))


verifier = Verifier()
