# language: Python, file: core/accuracy/confidence.py
# يضيف درجة ثقة لكل finding — يقلل false positives في التقارير
import re
from typing import Dict, List
from dataclasses import dataclass


@dataclass
class ConfidentFinding:
    finding: dict
    confidence: float          # 0.0-1.0
    evidence_count: int
    evidence_types: List[str]
    contradicts: List[str]


class ConfidenceScorer:
    """
    لكل finding، يجمع الأدلة:
      - عدد الأدلة المستقلة (evidence)
      - جودة المصادر (nmap < certipy < multi-tool)
      - تعارضات (contradictions)
      - شدة الأثر التقني
    يرجع درجة ثقة نهائية.
    """
    SOURCE_WEIGHTS = {
        "nmap": 0.7,
        "nxc": 0.85,
        "certipy": 0.9,
        "bloodhound": 0.85,
        "impacket": 0.9,
        "manual": 0.5,
        "ai_analysis": 0.6,
        "correlated": 1.0,      # مستنتج من عدة مصادر
    }

    def score(self, finding: dict,
               source: str = "nmap",
               related_findings: List[dict] = None) -> ConfidentFinding:
        related = related_findings or []
        evidence_types = []
        confidence = 0.0

        # 1. base confidence من المصدر
        base = self.SOURCE_WEIGHTS.get(source, 0.5)
        confidence = base

        # 2. أدلة مساندة
        supporting = 0
        for r in related:
            if self._supports(finding, r):
                supporting += 1
                evidence_types.append(r.get("source", "unknown"))
        if supporting > 0:
            # كل دليل مساند يرفع الثقة بمعامل متناقص
            confidence += sum(0.15 / (i + 1) for i in range(supporting))
            confidence = min(1.0, confidence)

        # 3. تعارضات
        contradicts = []
        for r in related:
            if self._contradicts(finding, r):
                contradicts.append(r.get("source", "unknown"))
                confidence -= 0.3
        confidence = max(0.0, confidence)

        # 4. جودة الحقل (evidence strength)
        if "cve" in finding and finding["cve"]:
            confidence += 0.05
        if finding.get("exploit_verified"):
            confidence += 0.2
        if not finding.get("detail"):
            confidence -= 0.1

        confidence = min(1.0, max(0.0, confidence))

        return ConfidentFinding(
            finding=finding,
            confidence=confidence,
            evidence_count=supporting + 1,
            evidence_types=evidence_types,
            contradicts=contradicts,
        )

    def _supports(self, f1: dict, f2: dict) -> bool:
        # نفس host + نفس port + نفس service → أدلة مساندة
        keys = ["host", "ip", "port", "cve", "service"]
        matches = 0
        for k in keys:
            if f1.get(k) and f1.get(k) == f2.get(k):
                matches += 1
        return matches >= 2

    def _contradicts(self, f1: dict, f2: dict) -> bool:
        # نفس port لكن service مختلف جذرياً
        if f1.get("port") == f2.get("port") and \
           f1.get("service") and f2.get("service") and \
           f1["service"] != f2["service"]:
            return True
        # نفس CVE لكن verified vs refuted
        if f1.get("cve") == f2.get("cve"):
            v1 = f1.get("exploit_verified", False)
            v2 = f2.get("refuted", False)
            if v2 and v1:
                return True
        return False

    def score_batch(self, findings: List[dict], source: str = "nmap") -> List[ConfidentFinding]:
        return [self.score(f, source, findings) for f in findings]


confidence_scorer = ConfidenceScorer()
