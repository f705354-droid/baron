# language: Python, file: core/integrations/splunk.py
# Splunk HEC integration
from core.integrations.base import Integration
from datetime import datetime


class SplunkIntegration(Integration):
    def __init__(self, hec_url: str = None, hec_token: str = None,
                  index: str = "albaron"):
        super().__init__("splunk", {
            "hec_url": hec_url,
            "hec_token": hec_token,
            "index": index,
        })
        self.hec_url = hec_url
        self.hec_token = hec_token
        self.index = index
        self.client = None

    def _client(self):
        if not self.client:
            import httpx
            self.client = httpx.Client(
                headers={"Authorization": f"Splunk {self.hec_token}"},
                verify=False, timeout=10)
        return self.client

    def test_connection(self) -> dict:
        if not self.hec_url or not self.hec_token:
            return {"error": "hec_url and hec_token required"}
        try:
            c = self._client()
            r = c.post(
                f"{self.hec_url}/services/collector/event",
                json={"event": "connection_test",
                        "sourcetype": "albaron:test"})
            self.enabled = r.status_code < 400
            return {
                "connected": self.enabled,
                "status_code": r.status_code,
            }
        except Exception as e:
            return {"error": str(e)}

    def send_event(self, event: dict) -> dict:
        if not self.enabled:
            self.test_connection()
        if not self.enabled:
            return {"error": "not connected"}

        try:
            c = self._client()
            payload = {
                "time": datetime.now().timestamp(),
                "host": "albaron",
                "source": "albaron:platform",
                "sourcetype": "albaron:event",
                "index": self.index,
                "event": event,
            }
            r = c.post(f"{self.hec_url}/services/collector/event",
                        json=payload)
            return {"status_code": r.status_code, "sent": True}
        except Exception as e:
            return {"error": str(e)}
