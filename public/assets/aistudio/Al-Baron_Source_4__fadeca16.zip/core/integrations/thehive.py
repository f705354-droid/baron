# language: Python, file: core/integrations/thehive.py
# TheHive integration
from core.integrations.base import Integration
from datetime import datetime


class TheHiveIntegration(Integration):
    def __init__(self, url: str = None, api_key: str = None):
        super().__init__("thehive", {"url": url, "api_key": api_key})
        self.url = url
        self.api_key = api_key
        self.client = None

    def _client(self):
        if not self.client:
            import httpx
            self.client = httpx.Client(
                headers={"Authorization": f"Bearer {self.api_key}"},
                verify=False, timeout=10)
        return self.client

    def test_connection(self) -> dict:
        if not self.url:
            return {"error": "url required"}
        try:
            c = self._client()
            r = c.get(f"{self.url}/api/v1/status")
            self.enabled = r.status_code == 200
            return {
                "connected": self.enabled,
                "version": r.json().get("versions", {}).get("TheHive"),
            }
        except Exception as e:
            return {"error": str(e)}

    def send_event(self, event: dict) -> dict:
        if not self.enabled:
            self.test_connection()
        if not self.enabled:
            return {"error": "not connected"}

        try:
            c = self._client()
            # create alert in TheHive
            alert = {
                "type": "albaron",
                "source": "albaron",
                "sourceRef": f"albaron-{datetime.now().timestamp()}",
                "title": event.get("title", "Al-Baron Alert"),
                "description": str(event),
                "severity": 2,
                "tags": ["albaron", "security"],
                "date": int(datetime.now().timestamp() * 1000),
            }
            r = c.post(f"{self.url}/api/alert", json=alert)
            return {
                "status_code": r.status_code,
                "sent": r.status_code < 400,
            }
        except Exception as e:
            return {"error": str(e)}


class IntegrationHub:
    """
    يدير كل integrations
    """
    def __init__(self):
        self.integrations = {}
        self.event_queue = []

    def register(self, integration):
        self.integrations[integration.name] = integration

    def broadcast(self, event: dict) -> list:
        """يرسل event لكل integrations مفعّلة"""
        results = []
        for name, integration in self.integrations.items():
            if not integration.enabled:
                continue
            try:
                result = integration.send_event(event)
                results.append({"integration": name, "result": result})
            except Exception as e:
                results.append({
                    "integration": name,
                    "error": str(e),
                })
        return results


hub = IntegrationHub()
