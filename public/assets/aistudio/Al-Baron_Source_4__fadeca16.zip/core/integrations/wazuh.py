# language: Python, file: core/integrations/wazuh.py
# Wazuh integration (via REST API)
from core.integrations.base import Integration
import base64
from datetime import datetime


class WazuhIntegration(Integration):
    def __init__(self, url: str = None, username: str = None,
                  password: str = None):
        super().__init__("wazuh", {
            "url": url, "username": username, "password": password,
        })
        self.url = url
        self.username = username
        self.password = password
        self.jwt = None
        self.client = None

    def _client(self):
        if not self.client:
            import httpx
            self.client = httpx.Client(verify=False, timeout=10)
        return self.client

    def _auth(self) -> bool:
        try:
            c = self._client()
            creds = base64.b64encode(
                f"{self.username}:{self.password}".encode()).decode()
            r = c.post(
                f"{self.url}/security/user/authenticate",
                headers={"Authorization": f"Basic {creds}"})
            if r.status_code == 200:
                self.jwt = r.json().get("data", {}).get("token")
                return True
        except Exception:
            pass
        return False

    def test_connection(self) -> dict:
        if not self.url or not self._auth():
            return {"error": "auth failed"}
        try:
            c = self._client()
            r = c.get(
                f"{self.url}/manager/info",
                headers={"Authorization": f"Bearer {self.jwt}"})
            self.enabled = r.status_code == 200
            return {
                "connected": self.enabled,
                "version": r.json().get("data", {}).get("version"),
            }
        except Exception as e:
            return {"error": str(e)}

    def send_event(self, event: dict) -> dict:
        if not self.jwt:
            self._auth()
        if not self.jwt:
            return {"error": "auth failed"}

        try:
            c = self._client()
            # Wazuh: create alert via API
            payload = {
                "rule_id": 100001,
                "log": str(event),
                "location": "albaron",
                "source_ip": event.get("source_ip", "0.0.0.0"),
            }
            r = c.post(
                f"{self.url}/events",
                headers={"Authorization": f"Bearer {self.jwt}"},
                json=payload)
            return {
                "status_code": r.status_code,
                "sent": r.status_code < 400,
            }
        except Exception as e:
            return {"error": str(e)}
