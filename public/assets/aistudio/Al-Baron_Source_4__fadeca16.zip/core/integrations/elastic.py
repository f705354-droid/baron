# language: Python, file: core/integrations/elastic.py
# Elasticsearch integration
from core.integrations.base import Integration
from datetime import datetime


class ElasticIntegration(Integration):
    def __init__(self, url: str = None, username: str = None,
                  password: str = None, index: str = "albaron-events"):
        super().__init__("elastic", {
            "url": url, "username": username,
            "password": password, "index": index,
        })
        self.url = url
        self.index = index
        self.client = None
        self.auth = (username, password) if username else None

    def _client(self):
        if not self.client:
            import httpx
            self.client = httpx.Client(
                auth=self.auth, verify=False, timeout=10)
        return self.client

    def test_connection(self) -> dict:
        if not self.url:
            return {"error": "url required"}
        try:
            c = self._client()
            r = c.get(f"{self.url}/_cluster/health")
            self.enabled = r.status_code == 200
            return {
                "connected": self.enabled,
                "status": r.json().get("status"),
            }
        except Exception as e:
            return {"error": str(e)}

    def send_event(self, event: dict) -> dict:
        if not self.enabled:
            self.test_connection()
        if not self.enabled:
            return {"error": "not connected"}

        try:
            c = self._client()
            doc = {
                "@timestamp": datetime.utcnow().isoformat() + "Z",
                "source": "albaron",
                "event": event,
            }
            r = c.post(f"{self.url}/{self.index}/_doc", json=doc)
            return {
                "status_code": r.status_code,
                "sent": r.status_code < 400,
            }
        except Exception as e:
            return {"error": str(e)}
