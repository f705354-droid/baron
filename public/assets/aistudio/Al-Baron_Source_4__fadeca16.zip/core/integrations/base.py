# language: Python, file: core/integrations/base.py
# Base integration — abstract SIEM / SOAR integration
from abc import ABC, abstractmethod
import json
from datetime import datetime


class Integration(ABC):
    """
    كل integration يرث من هذا.
    يوفر:
      - test_connection
      - send_event
      - send_finding
      - close
    """
    def __init__(self, name: str, config: dict = None):
        self.name = name
        self.config = config or {}
        self.enabled = False

    @abstractmethod
    def test_connection(self) -> dict:
        pass

    @abstractmethod
    def send_event(self, event: dict) -> dict:
        pass

    def send_finding(self, finding: dict) -> dict:
        """default: convert to event"""
        event = {
            "type": "finding",
            "timestamp": datetime.now().isoformat(),
            "finding": finding,
        }
        return self.send_event(event)

    def close(self):
        pass
