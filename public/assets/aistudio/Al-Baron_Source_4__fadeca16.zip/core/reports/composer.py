# language: Python, file: core/reports/composer.py
# Red Team Report Generator — full client-ready PDFs
import os
import json
from datetime import datetime
from core.graph.graph_db import graph

try:
    from fpdf import FPDF
    HAS_FPDF = True
except ImportError:
    HAS_FPDF = False


class ReportComposer:
    """
    يبني تقارير PDF احترافية:
      - Executive Summary
      - Methodology
      - Findings (with severity)
      - MITRE ATT&CK coverage
      - Recommendations
      - Appendix (evidence, IOCs)
    """
    def __init__(self):
        self.reports_dir = "reports"
        os.makedirs(self.reports_dir, exist_ok=True)

    def generate_engagement_report(self, engagement: dict,
                                     findings: List[dict] = None,
                                     output: str = None) -> dict:
        """
        engagement = {
            "name": str, "client": str, "tester": str,
            "start": str, "end": str, "scope": str,
        }
        """
        if not HAS_FPDF:
            return {"error": "fpdf2 not installed"}

        output = output or f"{self.reports_dir}/report_{int(datetime.now().timestamp())}.pdf"

        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=15)

        # ── cover page ──
        pdf.add_page()
        pdf.set_fill_color(20, 25, 40)
        pdf.rect(0, 0, 210, 297, "F")

        pdf.set_text_color(0, 255, 156)
        pdf.set_font("Helvetica", "B", 36)
        pdf.ln(80)
        pdf.cell(0, 20, "PENETRATION TEST", align="C",
                  new_x="LMARGIN", new_y="NEXT")
        pdf.cell(0, 20, "REPORT", align="C",
                  new_x="LMARGIN", new_y="NEXT")

        pdf.ln(20)
        pdf.set_text_color(200, 214, 229)
        pdf.set_font("Helvetica", "", 14)
        for line in [
            engagement.get("client", ""),
            f"Engagement: {engagement.get('name', '')}",
            f"Testers: {engagement.get('tester', '')}",
            f"Period: {engagement.get('start', '')} → {engagement.get('end', '')}",
        ]:
            pdf.cell(0, 10, line, align="C",
                      new_x="LMARGIN", new_y="NEXT")

        pdf.ln(30)
        pdf.set_font("Helvetica", "B", 11)
        pdf.set_text_color(255, 107, 107)
        pdf.cell(0, 10, "CONFIDENTIAL", align="C",
                  new_x="LMARGIN", new_y="NEXT")

        pdf.set_text_color(0, 0, 0)

        # ── executive summary ──
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 20)
        pdf.cell(0, 12, "Executive Summary", new_x="LMARGIN", new_y="NEXT")
        pdf.ln(6)
        pdf.set_font("Helvetica", "", 11)

        # severity breakdown
        severity_count = self._count_severities(findings or [])
        summary = (
            f"This report documents the penetration testing engagement "
            f"conducted against {engagement.get('client', 'the client')} "
            f"between {engagement.get('start', 'N/A')} and "
            f"{engagement.get('end', 'N/A')}.\n\n"
            f"A total of {len(findings or [])} findings were identified:\n"
            f"  • Critical: {severity_count.get('critical', 0)}\n"
            f"  • High: {severity_count.get('high', 0)}\n"
            f"  • Medium: {severity_count.get('medium', 0)}\n"
            f"  • Low: {severity_count.get('low', 0)}\n"
            f"  • Info: {severity_count.get('info', 0)}\n\n"
            f"The most significant findings are detailed in the "
            f"Technical Findings section."
        )
        pdf.multi_cell(0, 6, summary)

        # ── methodology ──
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 20)
        pdf.cell(0, 12, "Methodology", new_x="LMARGIN", new_y="NEXT")
        pdf.ln(6)
        pdf.set_font("Helvetica", "", 11)
        methodology = (
            "The engagement followed a structured red team methodology "
            "aligned with industry standards (PTES, OWASP, MITRE ATT&CK):\n\n"
            "1. Reconnaissance — passive and active information gathering\n"
            "2. Enumeration — service and asset discovery\n"
            "3. Exploitation — targeted vulnerability exploitation\n"
            "4. Post-Exploitation — privilege escalation, lateral movement\n"
            "5. Exfiltration — data extraction simulation\n"
            "6. Reporting — findings documentation and recommendations\n\n"
            "All activities were conducted within the authorized scope "
            "and timeframe. Every action is documented in the audit trail."
        )
        pdf.multi_cell(0, 6, methodology)

        # ── findings ──
        if findings:
            pdf.add_page()
            pdf.set_font("Helvetica", "B", 20)
            pdf.cell(0, 12, "Technical Findings",
                      new_x="LMARGIN", new_y="NEXT")
            pdf.ln(4)

            severity_order = ["critical", "high", "medium", "low", "info"]
            for sev in severity_order:
                sev_findings = [f for f in findings
                                  if f.get("severity", "").lower() == sev]
                if not sev_findings:
                    continue

                pdf.set_font("Helvetica", "B", 14)
                pdf.set_text_color(*self._severity_color(sev))
                pdf.cell(0, 10, f"{sev.upper()} ({len(sev_findings)})",
                          new_x="LMARGIN", new_y="NEXT")
                pdf.set_text_color(0, 0, 0)

                for f in sev_findings:
                    pdf.set_font("Helvetica", "B", 11)
                    pdf.multi_cell(0, 5, f"• {f.get('title', '?')}")
                    pdf.set_font("Helvetica", "", 9)
                    if f.get("host"):
                        pdf.multi_cell(0, 4, f"  Host: {f['host']}")
                    if f.get("cve"):
                        pdf.multi_cell(0, 4, f"  CVE: {f['cve']}")
                    if f.get("description"):
                        pdf.multi_cell(0, 4, f"  {f['description'][:500]}")
                    if f.get("evidence"):
                        pdf.multi_cell(0, 4, f"  Evidence: {f['evidence'][:200]}")
                    pdf.ln(3)

        # ── MITRE coverage ──
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 20)
        pdf.cell(0, 12, "MITRE ATT&CK Coverage",
                  new_x="LMARGIN", new_y="NEXT")
        pdf.ln(4)
        pdf.set_font("Helvetica", "", 10)

        techniques = graph.list_nodes("technique")
        by_tactic = {}
        for t in techniques:
            tactic = t["properties"].get("tactic", "Unknown")
            by_tactic.setdefault(tactic, []).append(t)

        for tactic, techs in sorted(by_tactic.items()):
            pdf.set_font("Helvetica", "B", 11)
            pdf.cell(0, 7, f"{tactic} ({len(techs)})",
                      new_x="LMARGIN", new_y="NEXT")
            pdf.set_font("Helvetica", "", 9)
            for t in techs:
                pdf.cell(0, 5, f"  {t['key']} — "
                                f"{t['properties'].get('name', '?')}",
                          new_x="LMARGIN", new_y="NEXT")
            pdf.ln(2)

        # ── recommendations ──
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 20)
        pdf.cell(0, 12, "Recommendations", new_x="LMARGIN", new_y="NEXT")
        pdf.ln(4)
        pdf.set_font("Helvetica", "", 10)

        recommendations = [
            "IMMEDIATE (0-30 days):",
            "  • Patch all critical and high CVEs",
            "  • Rotate all credentials exposed during the engagement",
            "  • Enable MFA on all administrative accounts",
            "",
            "SHORT-TERM (30-90 days):",
            "  • Implement EDR with behavioral detection",
            "  • Segment network into security zones",
            "  • Deploy LAPS and disable unconstrained delegation",
            "",
            "LONG-TERM (90+ days):",
            "  • Implement Zero Trust architecture",
            "  • Continuous red team/purple team exercises",
            "  • Security awareness training",
        ]
        for rec in recommendations:
            pdf.multi_cell(0, 5, rec)

        # ── footer on every page ──
        pdf.output(output)

        return {
            "path": output,
            "size": os.path.getsize(output),
            "pages": pdf.pages_count,
            "findings": len(findings or []),
        }

    def _count_severities(self, findings: list) -> dict:
        counts = {}
        for f in findings:
            sev = f.get("severity", "info").lower()
            counts[sev] = counts.get(sev, 0) + 1
        return counts

    def _severity_color(self, sev: str) -> tuple:
        colors = {
            "critical": (200, 0, 0),
            "high": (220, 80, 80),
            "medium": (220, 150, 0),
            "low": (0, 120, 200),
            "info": (80, 80, 80),
        }
        return colors.get(sev.lower(), (0, 0, 0))


report_composer = ReportComposer()
