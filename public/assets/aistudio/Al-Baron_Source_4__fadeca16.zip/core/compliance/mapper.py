# language: Python, file: core/compliance/mapper.py
# Map findings to compliance controls
import re


class ComplianceMapper:
    """
    يربط findings (CVEs، weaknesses) بالضوابط.
    """
    # keyword → controls (across frameworks)
    KEYWORD_TO_CONTROLS = {
        "sqli": {
            "ISO 27001": ["A.8.28"],
            "NIST CSF": ["PR.IP-1"],
            "PCI DSS": ["6.5.1"],
        },
        "xss": {
            "ISO 27001": ["A.8.28"],
            "NIST CSF": ["PR.IP-1"],
            "PCI DSS": ["6.5.6"],
        },
        "sql": {
            "ISO 27001": ["A.8.28"],
            "PCI DSS": ["6.5.1"],
        },
        "ssrf": {
            "ISO 27001": ["A.8.28"],
            "PCI DSS": ["6.5.1"],
        },
        "rce": {
            "ISO 27001": ["A.8.28"],
            "NIST CSF": ["PR.IP-1"],
            "PCI DSS": ["6.3.2"],
        },
        "command injection": {
            "ISO 27001": ["A.8.28"],
            "PCI DSS": ["6.5.1"],
        },
        "deserialization": {
            "ISO 27001": ["A.8.28"],
            "PCI DSS": ["6.3.2"],
        },
        "kerberoast": {
            "ISO 27001": ["A.8.5"],
            "NIST CSF": ["PR.AC-1", "PR.AC-7"],
            "PCI DSS": ["8.3.1"],
        },
        "dcsync": {
            "ISO 27001": ["A.8.2"],
            "NIST CSF": ["PR.AC-4"],
            "PCI DSS": ["8.3.1"],
        },
        "smb signing": {
            "ISO 27001": ["A.8.20", "A.8.21"],
            "NIST CSF": ["PR.PT-4"],
            "PCI DSS": ["1.3.1"],
        },
        "default credentials": {
            "ISO 27001": ["A.8.5"],
            "NIST CSF": ["PR.AC-7"],
            "PCI DSS": ["8.3.1"],
        },
        "unpatched": {
            "ISO 27001": ["A.8.8"],
            "NIST CSF": ["ID.RA-1"],
            "PCI DSS": ["6.3.2"],
        },
        "no mfa": {
            "ISO 27001": ["A.8.5"],
            "NIST CSF": ["PR.AC-7"],
            "PCI DSS": ["8.4.1"],
        },
        "rdp exposed": {
            "ISO 27001": ["A.8.20", "A.8.22"],
            "NIST CSF": ["PR.PT-4"],
            "PCI DSS": ["1.3.1"],
        },
        "ldap signing": {
            "ISO 27001": ["A.8.20"],
            "NIST CSF": ["PR.PT-4"],
            "PCI DSS": ["1.3.1"],
        },
        "unconstrained delegation": {
            "ISO 27001": ["A.8.2"],
            "NIST CSF": ["PR.AC-4"],
            "PCI DSS": ["8.3.1"],
        },
    }

    def map_finding(self, finding: dict) -> dict:
        """يربط finding بكل frameworks"""
        text = " ".join([
            finding.get("title", ""),
            finding.get("description", ""),
            finding.get("cve", ""),
        ]).lower()

        mappings = {}
        for keyword, framework_map in self.KEYWORD_TO_CONTROLS.items():
            if keyword in text:
                for framework, controls in framework_map.items():
                    mappings.setdefault(framework, set()).update(controls)

        return {
            "finding": finding.get("title", ""),
            "controls": {k: sorted(v) for k, v in mappings.items()},
        }

    def map_all(self, findings: list) -> dict:
        """يربط كل findings"""
        results = [self.map_finding(f) for f in findings]

        # aggregate
        by_framework = {}
        for r in results:
            for framework, controls in r["controls"].items():
                by_framework.setdefault(framework, set()).update(controls)

        return {
            "per_finding": results,
            "summary": {
                fw: sorted(controls)
                for fw, controls in by_framework.items()
            },
        }


mapper = ComplianceMapper()
