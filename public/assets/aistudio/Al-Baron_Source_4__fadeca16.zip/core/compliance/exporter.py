# language: Python, file: core/compliance/exporter.py
# Compliance report exporter
import json
import os
from datetime import datetime
from core.compliance.frameworks import ALL_FRAMEWORKS


class ComplianceExporter:
    """
    ينتج تقارير compliance لكل framework
    """

    def export_pdf(self, framework_name: str, findings: list,
                    output: str = None) -> str:
        try:
            from fpdf import FPDF
        except ImportError:
            return ""

        fw = ALL_FRAMEWORKS.get(framework_name)
        if not fw:
            return ""

        from core.compliance.mapper import mapper
        mapped = mapper.map_all(findings)

        pdf = FPDF()
        pdf.add_page()

        # cover
        pdf.set_font("Helvetica", "B", 24)
        pdf.ln(30)
        pdf.cell(0, 15, f"{fw.name} v{fw.version}",
                  align="C", new_x="LMARGIN", new_y="NEXT")
        pdf.cell(0, 15, "Compliance Report", align="C",
                  new_x="LMARGIN", new_y="NEXT")
        pdf.ln(20)
        pdf.set_font("Helvetica", "", 12)
        pdf.cell(0, 8, f"Generated: {datetime.now().isoformat()[:19]}",
                  align="C", new_x="LMARGIN", new_y="NEXT")
        pdf.cell(0, 8, f"Total findings: {len(findings)}",
                  align="C", new_x="LMARGIN", new_y="NEXT")

        # controls affected
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 18)
        pdf.cell(0, 12, "Affected Controls",
                  new_x="LMARGIN", new_y="NEXT")
        pdf.ln(4)

        affected = mapped["summary"].get(framework_name, [])
        pdf.set_font("Helvetica", "", 11)
        pdf.cell(0, 6, f"{len(affected)} controls affected",
                  new_x="LMARGIN", new_y="NEXT")
        pdf.ln(4)

        for cid in affected:
            control = fw.controls.get(cid, {})
            pdf.set_font("Helvetica", "B", 10)
            pdf.cell(0, 6, f"{cid} — {control.get('title', '?')}",
                      new_x="LMARGIN", new_y="NEXT")
            pdf.set_font("Helvetica", "", 9)
            pdf.cell(0, 5, f"  Category: {control.get('category',
                                                    control.get('function',
                                                                 control.get('req', '?')))}",
                      new_x="LMARGIN", new_y="NEXT")
            pdf.ln(2)

        # per-finding mapping
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 18)
        pdf.cell(0, 12, "Finding-to-Control Mapping",
                  new_x="LMARGIN", new_y="NEXT")
        pdf.ln(4)

        for r in mapped["per_finding"]:
            controls = r["controls"].get(framework_name, [])
            if not controls:
                continue
            pdf.set_font("Helvetica", "B", 10)
            pdf.multi_cell(0, 6, f"• {r['finding'][:100]}")
            pdf.set_font("Helvetica", "", 9)
            pdf.multi_cell(0, 5, f"  Controls: {', '.join(controls)}")
            pdf.ln(2)

        output = output or f"reports/compliance_{framework_name.replace(' ', '_')}.pdf"
        os.makedirs(os.path.dirname(output) or ".", exist_ok=True)
        pdf.output(output)
        return output


exporter = ComplianceExporter()
