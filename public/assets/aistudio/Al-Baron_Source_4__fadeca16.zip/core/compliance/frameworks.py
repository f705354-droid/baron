# language: Python, file: core/compliance/frameworks.py
# Compliance frameworks — ISO 27001, NIST CSF, PCI-DSS
from typing import Dict, List


class ComplianceFramework:
    def __init__(self, name: str, version: str,
                  controls: Dict[str, dict]):
        self.name = name
        self.version = version
        self.controls = controls

    def to_dict(self):
        return {
            "name": self.name,
            "version": self.version,
            "controls_count": len(self.controls),
        }


ISO_27001 = ComplianceFramework(
    "ISO/IEC 27001",
    "2022",
    {
        "A.5.1": {
            "title": "Policies for information security",
            "category": "Organizational controls",
        },
        "A.5.7": {
            "title": "Threat intelligence",
            "category": "Organizational controls",
        },
        "A.8.2": {
            "title": "Privileged access rights",
            "category": "Technological controls",
        },
        "A.8.3": {
            "title": "Information access restriction",
            "category": "Technological controls",
        },
        "A.8.5": {
            "title": "Secure authentication",
            "category": "Technological controls",
        },
        "A.8.7": {
            "title": "Protection against malware",
            "category": "Technological controls",
        },
        "A.8.8": {
            "title": "Management of technical vulnerabilities",
            "category": "Technological controls",
        },
        "A.8.9": {
            "title": "Configuration management",
            "category": "Technological controls",
        },
        "A.8.12": {
            "title": "Data leakage prevention",
            "category": "Technological controls",
        },
        "A.8.16": {
            "title": "Monitoring activities",
            "category": "Technological controls",
        },
        "A.8.20": {
            "title": "Networks security",
            "category": "Technological controls",
        },
        "A.8.21": {
            "title": "Security of network services",
            "category": "Technological controls",
        },
        "A.8.22": {
            "title": "Segregation of networks",
            "category": "Technological controls",
        },
        "A.8.23": {
            "title": "Web filtering",
            "category": "Technological controls",
        },
        "A.8.24": {
            "title": "Use of cryptography",
            "category": "Technological controls",
        },
        "A.8.28": {
            "title": "Secure coding",
            "category": "Technological controls",
        },
    },
)

NIST_CSF = ComplianceFramework(
    "NIST Cybersecurity Framework",
    "2.0",
    {
        "ID.AM-1": {
            "title": "Inventory of physical devices",
            "function": "IDENTIFY",
        },
        "ID.AM-2": {
            "title": "Inventory of software platforms",
            "function": "IDENTIFY",
        },
        "ID.RA-1": {
            "title": "Asset vulnerabilities identified",
            "function": "IDENTIFY",
        },
        "ID.RA-5": {
            "title": "Threats, vulnerabilities, likelihoods",
            "function": "IDENTIFY",
        },
        "PR.AC-1": {
            "title": "Identities and credentials managed",
            "function": "PROTECT",
        },
        "PR.AC-4": {
            "title": "Access permissions managed",
            "function": "PROTECT",
        },
        "PR.AC-7": {
            "title": "Users, devices, and assets authenticated",
            "function": "PROTECT",
        },
        "PR.DS-1": {
            "title": "Data-at-rest protected",
            "function": "PROTECT",
        },
        "PR.DS-2": {
            "title": "Data-in-transit protected",
            "function": "PROTECT",
        },
        "PR.IP-1": {
            "title": "Baseline configuration",
            "function": "PROTECT",
        },
        "PR.PT-4": {
            "title": "Communications and control networks protected",
            "function": "PROTECT",
        },
        "DE.AE-1": {
            "title": "Baseline of network operations",
            "function": "DETECT",
        },
        "DE.CM-1": {
            "title": "Network monitored",
            "function": "DETECT",
        },
        "DE.CM-4": {
            "title": "Malicious code detected",
            "function": "DETECT",
        },
        "DE.DP-4": {
            "title": "Event detection information communicated",
            "function": "DETECT",
        },
        "RS.AN-1": {
            "title": "Notifications investigated",
            "function": "RESPOND",
        },
        "RS.MI-1": {
            "title": "Incidents contained",
            "function": "RESPOND",
        },
    },
)

PCI_DSS = ComplianceFramework(
    "PCI DSS",
    "4.0",
    {
        "1.2.1": {
            "title": "Restrict inbound and outbound traffic",
            "req": "1.2",
        },
        "1.3.1": {
            "title": "Network access to CDE restricted",
            "req": "1.3",
        },
        "2.2.1": {
            "title": "Configuration standards implemented",
            "req": "2.2",
        },
        "4.1.1": {
            "title": "Strong cryptography for data-in-transit",
            "req": "4.1",
        },
        "5.2.1": {
            "title": "Anti-malware deployed",
            "req": "5.2",
        },
        "6.3.1": {
            "title": "Security vulnerabilities identified",
            "req": "6.3",
        },
        "6.3.2": {
            "title": "Critical patches installed",
            "req": "6.3",
        },
        "6.5.1": {
            "title": "Injection flaws addressed",
            "req": "6.5",
        },
        "6.5.4": {
            "title": "Insecure direct object references",
            "req": "6.5",
        },
        "6.5.6": {
            "title": "Cross-site scripting",
            "req": "6.5",
        },
        "6.5.7": {
            "title": "Improper access control",
            "req": "6.5",
        },
        "8.3.1": {
            "title": "Strong authentication implemented",
            "req": "8.3",
        },
        "8.4.1": {
            "title": "MFA implemented",
            "req": "8.4",
        },
        "10.2.1": {
            "title": "Audit logs enabled",
            "req": "10.2",
        },
    },
)


ALL_FRAMEWORKS = {
    "ISO 27001": ISO_27001,
    "NIST CSF": NIST_CSF,
    "PCI DSS": PCI_DSS,
}
