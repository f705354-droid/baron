# language: Python, file: core/hunting/hunter.py
# Threat Hunter — proactive hunting with hypotheses
import threading
import time
import json
import re
from datetime import datetime, timedelta
from core.graph.graph_db import graph


class Hypothesis:
    """
    فرضية صيد.
    مثال: "إذا كان SMB signing معطلاً، يمكن أن يكون هناك relay attack"
    """
    def __init__(self, name: str, description: str,
                  technique: str, query_fn=None):
        self.name = name
        self.description = description
        self.technique = technique     # T-ID
        self.query_fn = query_fn
        self.matches = []
        self.last_run = None
        self.status = "idle"

    def run(self, graph_db) -> list:
        """ينفذ الفرضية"""
        self.last_run = datetime.now().isoformat()
        self.status = "running"
        try:
            self.matches = self.query_fn(graph_db) if self.query_fn else []
            self.status = "completed"
        except Exception as e:
            self.status = f"error: {e}"
            self.matches = []
        return self.matches

    def to_dict(self):
        return {
            "name": self.name,
            "description": self.description,
            "technique": self.technique,
            "matches": len(self.matches),
            "last_run": self.last_run,
            "status": self.status,
        }


class ThreatHunter:
    """
    يصطاد التهديدات بناءً على hypotheses.
    يعمل دورياً، يبحث عن أنماط لم تُرصد بعد.
    """
    def __init__(self, log_queue=None):
        self.log = log_queue
        self.hypotheses: list = []
        self.findings: list = []
        self.running = False
        self.thread = None
        self.interval = 300  # 5 min
        self._load_default_hypotheses()

    def _load_default_hypotheses(self):
        """يحمّل hypotheses جاهزة"""

        # H1: hosts with exposed SMB
        def h1(graph_db):
            hosts = []
            for h in graph_db.list_nodes("host"):
                ports = h["properties"].get("ports", [])
                if 445 in [p[0] if isinstance(p, tuple) else p
                            for p in ports]:
                    hosts.append({"host": h["key"],
                                    "reason": "SMB exposed (445)"})
            return hosts

        # H2: credentials used across multiple hosts (lateral)
        def h2(graph_db):
            lateral = []
            for cred in graph_db.list_nodes("credential"):
                # find hosts this cred connects to
                hosts = graph_db.neighbors("credential", cred["key"],
                                              direction="both")
                host_count = sum(1 for n in hosts if n["type"] == "host")
                if host_count > 1:
                    lateral.append({
                        "credential": cred["key"],
                        "hosts": [n["key"] for n in hosts if n["type"] == "host"],
                    })
            return lateral

        # H3: sessions that outlived expected
        def h3(graph_db):
            long_running = []
            now = datetime.now()
            for session in graph_db.list_nodes("session"):
                created = session["properties"].get("created")
                if created:
                    try:
                        age_hours = (now - datetime.fromisoformat(created)).total_seconds() / 3600
                        if age_hours > 24:
                            long_running.append({
                                "session": session["key"],
                                "age_hours": round(age_hours, 1),
                            })
                    except Exception:
                        pass
            return long_running

        # H4: hosts with multiple critical CVEs
        def h4(graph_db):
            risky = []
            for h in graph_db.list_nodes("host"):
                vulns = graph_db.neighbors("host", h["key"],
                                              edge_type="vulnerable_to",
                                              direction="out")
                critical = [v for v in vulns if v["properties"].get("cvss", 0) >= 9.0]
                if len(critical) >= 2:
                    risky.append({
                        "host": h["key"],
                        "critical_count": len(critical),
                        "cves": [v["key"] for v in critical],
                    })
            return risky

        self.hypotheses.append(Hypothesis(
            "Exposed SMB",
            "Hosts with SMB (445) exposed on the network — potential relay target",
            "T1210",
            h1,
        ))
        self.hypotheses.append(Hypothesis(
            "Lateral Credentials",
            "Credentials used across multiple hosts — indicates lateral movement",
            "T1078",
            h2,
        ))
        self.hypotheses.append(Hypothesis(
            "Long-Running Sessions",
            "Sessions active > 24 hours — potential persistent threat",
            "T1078",
            h3,
        ))
        self.hypotheses.append(Hypothesis(
            "Multiple Critical CVEs",
            "Hosts with 2+ critical vulnerabilities — high-value target",
            "T1203",
            h4,
        ))

    def add_hypothesis(self, hypothesis: Hypothesis):
        self.hypotheses.append(hypothesis)

    def run_all(self) -> list:
        """ينفذ كل الفرضيات"""
        results = []
        for h in self.hypotheses:
            matches = h.run(graph)
            if matches:
                finding = {
                    "hypothesis": h.name,
                    "description": h.description,
                    "technique": h.technique,
                    "matches": matches,
                    "found_at": datetime.now().isoformat(),
                }
                results.append(finding)
                self.findings.append(finding)
                if self.log:
                    self.log.put(
                        f"[hunt] {h.name}: {len(matches)} matches")
        return results

    def start(self):
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()
        if self.log:
            self.log.put("[hunt] continuous hunting started")

    def stop(self):
        self.running = False
        if self.log:
            self.log.put("[hunt] hunting stopped")

    def _loop(self):
        while self.running:
            try:
                self.run_all()
            except Exception as e:
                if self.log:
                    self.log.put(f"[hunt] {e}")
            for _ in range(self.interval):
                if not self.running:
                    return
                time.sleep(1)

    def get_findings(self) -> list:
        return self.findings


hunter = ThreatHunter()
