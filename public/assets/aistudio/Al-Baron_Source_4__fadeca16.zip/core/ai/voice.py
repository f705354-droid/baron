# language: Python, file: core/ai/voice.py
# Voice input (Whisper via local) + TTS output (piper / espeak)
import os
import subprocess
import tempfile
import threading


class VoiceIO:
    def __init__(self):
        self.stt_backend = self._detect_stt()
        self.tts_backend = self._detect_tts()

    def _detect_stt(self) -> str:
        # whisper.cpp / openai whisper / vosk
        if os.path.exists("/usr/local/bin/whisper"):
            return "whisper-cli"
        try:
            import whisper
            return "openai-whisper"
        except ImportError:
            pass
        try:
            import vosk
            return "vosk"
        except ImportError:
            pass
        return "none"

    def _detect_tts(self) -> str:
        for cmd in ["piper", "espeak-ng", "espeak", "say"]:
            if subprocess.run(["which", cmd],
                                capture_output=True).returncode == 0:
                return cmd
        return "none"

    def record_until_silence(self, max_sec: int = 15) -> str:
        """يسجّل من الميكروفون ويرجع نص"""
        try:
            import sounddevice as sd
            import numpy as np
            import scipy.io.wavfile as wav

            fs = 16000
            print("[voice] recording... (silence stops)")
            audio = sd.rec(int(max_sec * fs), samplerate=fs,
                            channels=1, dtype="int16")
            sd.wait()

            tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
            wav.write(tmp.name, fs, audio)
            return self.transcribe(tmp.name)
        except Exception as e:
            return f""

    def transcribe(self, wav_path: str) -> str:
        if self.stt_backend == "openai-whisper":
            try:
                import whisper
                model = whisper.load_model("base")
                result = model.transcribe(wav_path, language="ar")
                return result.get("text", "").strip()
            except Exception:
                return ""
        if self.stt_backend == "whisper-cli":
            try:
                out = subprocess.run(
                    ["whisper", "--model", "base", "--language", "ar",
                     "--output_format", "txt", "--output_dir", "/tmp",
                     wav_path],
                    capture_output=True, text=True, timeout=60)
                txt = wav_path.replace(".wav", ".txt")
                if os.path.exists(txt):
                    with open(txt) as f:
                        return f.read().strip()
            except Exception:
                pass
        return ""

    def speak(self, text: str):
        """يقرأ النص بصوت عالٍ في thread منفصل"""
        if self.tts_backend == "none":
            return
        def _run():
            try:
                if self.tts_backend == "piper":
                    p = subprocess.Popen(
                        ["piper", "--model", "ar_JO-kareem-medium"],
                        stdin=subprocess.PIPE)
                    p.communicate(text.encode())
                else:
                    subprocess.run([self.tts_backend, text],
                                    timeout=60)
            except Exception:
                pass
        threading.Thread(target=_run, daemon=True).start()

    def stop_speaking(self):
        subprocess.run(["pkill", "-f", self.tts_backend],
                        capture_output=True)


voice = VoiceIO()
