#!/bin/bash
# language: bash, file: core/ai/formal/coq_runtime/build.sh
# build Coq spec + extract OCaml + compile wrapper

set -e
cd "$(dirname "$0")"

echo "[*] compiling Coq..."
coqc ../Guardrails.v
coqc ../extraction.v

echo "[*] moving extracted OCaml..."
mv guardrails.ml ./

echo "[*] compiling OCaml wrapper..."
ocamlfind ocamlopt -package ctypes -linkpkg \
  guardrails.ml wrapper_stubs.ml main.ml \
  -o guardrails_runner

echo "[+] build complete: guardrails_runner"
