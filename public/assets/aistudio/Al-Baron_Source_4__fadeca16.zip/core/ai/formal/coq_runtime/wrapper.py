# language: Python, file: core/ai/formal/coq_runtime/wrapper.py
# Python ↔ OCaml bridge via subprocess JSON
import os
import json
import subprocess
from typing import Optional


class CoqRuntime:
    """
    يشغّل guardrails المبرهن عليها في Coq → مستخرجة لـOCaml.
    كل قرار autonomous يمر هنا كـfinal gate.
    """
    def __init__(self, binary_path: str = None):
        self.binary = binary_path or os.path.join(
            os.path.dirname(__file__), "guardrails_runner")
        self.available = os.path.exists(self.binary)

    def check(self, state: dict, action: dict) -> dict:
        """
        يستدعي الـOCaml binary بقرار.
        returns: {"allowed": bool, "source": "coq-runtime"}
        """
        if not self.available:
            return {"allowed": None, "source": "coq-unavailable"}

        # map limits
        max_iter = state.get("max_iterations", 50)
        max_tok = state.get("max_tokens", 500_000)
        max_min = state.get("max_minutes", 60)

        payload = {
            "iteration": state.get("iteration", 0),
            "tokens_used": state.get("tokens_used", 0),
            "minutes_elapsed": state.get("minutes_elapsed", 0),
            "auto_approve": state.get("auto_approve", False),
            "goal_reached": state.get("goal_reached", False),
            "max_iterations": max_iter,
            "max_tokens": max_tok,
            "max_minutes": max_min,
            "tool": action.get("tool", ""),
        }

        try:
            p = subprocess.run(
                [self.binary],
                input=json.dumps(payload) + "\n",
                capture_output=True, text=True, timeout=5)
            if p.returncode != 0:
                return {"allowed": None, "source": "coq-error",
                         "stderr": p.stderr[-500:]}
            out = json.loads(p.stdout.strip())
            return {
                "allowed": out.get("allowed", False),
                "source": "coq-runtime",
            }
        except subprocess.TimeoutExpired:
            return {"allowed": None, "source": "coq-timeout"}
        except Exception as e:
            return {"allowed": None, "source": "coq-error", "error": str(e)}


coq_runtime = CoqRuntime()
