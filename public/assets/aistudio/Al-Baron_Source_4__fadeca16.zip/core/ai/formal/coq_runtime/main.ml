(* language: OCaml, file: core/ai/formal/coq_runtime/main.ml *)
(* Guardrails runtime — reads JSON from stdin, outputs verdict *)
let () =
  (* Simple JSON parsing — expects:
     {"iteration": N, "tokens_used": N, "minutes_elapsed": N,
      "auto_approve": bool, "approvals": [...], "goal_reached": bool,
      "max_iterations": N, "max_tokens": N, "max_minutes": N,
      "tool": "shell|dispatch|write_file|other"} *)

  let read_line_opt () =
    try Some (input_line stdin) with End_of_file -> None
  in
  let json_str = match read_line_opt () with
    | Some s -> s
    | None -> "{}"
  in

  (* quick and dirty extraction — in production use Yojson *)
  let get_int key s =
    try
      let re = Str.regexp ("\"" ^ key ^ "\"[ \t]*:[ \t]*\\([0-9]+\\)") in
      ignore (Str.search_forward re s 0);
      int_of_string (Str.matched_group 1 s)
    with _ -> 0
  in
  let get_bool key s =
    try
      let re = Str.regexp ("\"" ^ key ^ "\"[ \t]*:[ \t]*\\(true\\|false\\)") in
      ignore (Str.search_forward re s 0);
      Str.matched_group 1 s = "true"
    with _ -> false
  in
  let get_str key s =
    try
      let re = Str.regexp ("\"" ^ key ^ "\"[ \t]*:[ \t]*\"\\([^\"]+\\)\"") in
      ignore (Str.search_forward re s 0);
      Str.matched_group 1 s
    with _ -> ""
  in

  let iteration = get_int "iteration" json_str in
  let tokens = get_int "tokens_used" json_str in
  let minutes = get_int "minutes_elapsed" json_str in
  let auto_ap = get_bool "auto_approve" json_str in
  let goal = get_bool "goal_reached" json_str in
  let max_iter = get_int "max_iterations" json_str in
  let max_tok = get_int "max_tokens" json_str in
  let max_min = get_int "max_minutes" json_str in
  let tool_str = get_str "tool" json_str in

  (* Map tool string to Tool *)
  let tool = match tool_str with
    | "run_shell" | "shell" -> Guardrails.Shell
    | "dispatch_task" | "dispatch" -> Guardrails.Dispatch
    | "write_file" -> Guardrails.WriteFile
    | "get_sessions" -> Guardrails.GetSessions
    | "read_log" -> Guardrails.ReadLog
    | "search_memory" -> Guardrails.SearchMemory
    | _ -> Guardrails.Done
  in

  (* Build state *)
  let state : Guardrails.agent_state = {
    Guardrails.iteration = iteration;
    Guardrails.tokens_used = tokens;
    Guardrails.minutes_elapsed = minutes;
    Guardrails.st = Guardrails.Running;
    Guardrails.auto_approve = auto_ap;
    Guardrails.approvals = [];  (* simplified *)
    Guardrails.goal_reached = goal;
  } in

  let limits : Guardrails.limits = {
    Guardrails.max_iterations = max_iter;
    Guardrails.max_tokens = max_tok;
    Guardrails.max_minutes = max_min;
  } in

  let result = Guardrails.should_execute state limits tool in

  Printf.printf "{\"allowed\": %s}\n"
    (if result then "true" else "false")
