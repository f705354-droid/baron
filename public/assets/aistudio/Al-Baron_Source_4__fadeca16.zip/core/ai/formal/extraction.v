(* language: Coq, file: core/ai/formal/extraction.v *)
Require Import Guardrails.
Require Import Coq.extraction.Extraction.
Require Import Coq.extraction.ExtrOcamlBasic.
Require Import Coq.extraction.ExtrOcamlNatInt.
Require Import Coq.extraction.ExtrOcamlString.

Extraction Language OCaml.

(* Mapping للمكتبات القياسية *)
Extract Inductive bool => "bool" [ "true" "false" ].
Extract Inductive list => "list" [ "[]" "(::)" ].
Extract Inductive nat => "int"
  [ "0" "(fun x -> x + 1)" ]
  "(fun zero succ n -> if n=0 then zero () else succ (n-1))".

(* Extract الdecision function *)
Extraction "guardrails.ml" should_execute is_dangerous safe_decision.

(* Extraction للـnatural numbers كـint للمرونة *)
Extract Constant Pos.add => "fun a b -> a + b".
Extract Constant Pos.succ => "fun n -> n + 1".
