# language: Python, file: core/ai/formal/model_checker.py
# TLA+ model checker — runs TLC, parses results, maps to runtime
import os
import subprocess
import json
import tempfile
from typing import Dict, Optional


class TLAModelChecker:
    """
    يشغّل TLC على Guardrails.tla.
    يتحقق أن invariants الأمان تصمد لكل الحالات الممكنة ضمن الحدود.
    """
    def __init__(self, tla_dir: str = "core/ai/formal"):
        self.tla_dir = tla_dir
        self.tla_path = os.path.join(tla_dir, "Guardrails.tla")
        self.cfg_path = os.path.join(tla_dir, "Guardrails.cfg")

    def check(self, timeout: int = 300) -> Dict:
        # اكتشف java + tla2tools
        jar = self._find_tla_jar()
        if not jar:
            return {"error": "tla2tools.jar not found. download from "
                              "https://github.com/tlaplus/tlaplus/releases"}
        java = self._find_java()
        if not java:
            return {"error": "java not found"}

        cmd = [java, "-XX:+UseParallelGC", "-cp", jar,
                "tlc2.TLC", "-config", self.cfg_path, self.tla_path]
        try:
            p = subprocess.run(cmd, capture_output=True, text=True,
                                timeout=timeout)
        except subprocess.TimeoutExpired:
            return {"error": "TLC timeout"}

        out = p.stdout + p.stderr
        return {
            "returncode": p.returncode,
            "raw": out[-4000:],
            "passed": "No error has been found" in out or
                       "Model checking completed" in out and
                       p.returncode == 0,
            "invariant_violation": "Invariant" in out and
                                     "violated" in out.lower(),
        }

    def _find_tla_jar(self) -> Optional[str]:
        candidates = [
            os.path.join(self.tla_dir, "tla2tools.jar"),
            os.path.expanduser("~/.albaron/tla2tools.jar"),
            "/usr/local/lib/tla2tools.jar",
            "/opt/tla/tla2tools.jar",
        ]
        for c in candidates:
            if os.path.exists(c):
                return c
        return None

    def _find_java(self) -> Optional[str]:
        for p in ["java", "/usr/bin/java", "/usr/local/bin/java"]:
            try:
                r = subprocess.run([p, "-version"], capture_output=True,
                                    timeout=10)
                if r.returncode == 0 or b"version" in r.stderr:
                    return p
            except Exception:
                continue
        return None


class RuntimeInvariantChecker:
    """
    يفرض نفس invariants TLA+ في زمن التشغيل.
    كل قرار autonomous يمر هنا أولاً.
    """
    def __init__(self):
        self.violations: list = []

    def check_invariants(self, state: dict, action: dict) -> Dict:
        """
        state = {
            iteration, tokens_used, minutes_elapsed, state_str,
            auto_approve, approvals, goal_reached
        }
        action = {"tool": ..., "args": ...}
        """
        violations = []

        # S2: budget
        if state.get("tokens_used", 0) > state.get("max_tokens", 1e9):
            violations.append("S2_budget_exceeded")

        # S3: iterations
        if state.get("iteration", 0) > state.get("max_iterations", 1e9):
            violations.append("S3_iterations_exceeded")

        # S4: time
        if state.get("minutes_elapsed", 0) > state.get("max_minutes", 1e9):
            violations.append("S4_time_exceeded")

        # S5: after goal
        if state.get("goal_reached") and action.get("tool") != "done":
            violations.append("S5_action_after_goal")

        # S1: dangerous tool requires approval
        from core.ai.guardrails import DANGEROUS_TOOLS
        tool = action.get("tool", "")
        if (tool in DANGEROUS_TOOLS and
            not state.get("auto_approve") and
            tool not in state.get("approvals", set())):
            violations.append("S1_dangerous_without_approval")

        if violations:
            self.violations.append({
                "state": state, "action": action,
                "violations": violations,
            })

        return {
            "ok": len(violations) == 0,
            "violations": violations,
        }


runtime_checker = RuntimeInvariantChecker()
