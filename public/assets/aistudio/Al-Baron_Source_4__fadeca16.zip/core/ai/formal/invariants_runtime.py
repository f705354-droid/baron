# language: Python, file: core/ai/formal/invariants_runtime.py
# Combined invariant checker — TLA+ logic + Coq binary
from core.ai.formal.model_checker import runtime_checker
from core.ai.formal.coq_runtime.wrapper import coq_runtime


class CombinedInvariantChecker:
    """
    Three-tier verification:
      1. TLA+ extracted invariants (Python runtime)
      2. Coq-proven decision function (OCaml binary)
      3. Heuristic fallback (rules)
    """
    def check(self, state: dict, action: dict) -> dict:
        results = {}

        # Tier 1: TLA+ runtime
        py_result = runtime_checker.check_invariants(state, action)
        results["tla_runtime"] = py_result

        # Tier 2: Coq binary
        coq_result = coq_runtime.check(state, action)
        results["coq_binary"] = coq_result

        # Tier 3: heuristic
        heuristic = self._heuristic(state, action)
        results["heuristic"] = heuristic

        # aggregate: minimum prudence
        allowed = True
        reasons = []
        if py_result and not py_result.get("ok", True):
            allowed = False
            reasons.extend(py_result.get("violations", []))
        if coq_result.get("allowed") is False:
            allowed = False
            reasons.append("coq_runtime_denied")
        if not heuristic:
            allowed = False
            reasons.append("heuristic_denied")

        return {
            "allowed": allowed,
            "reasons": reasons,
            "tiers": results,
        }

    def _heuristic(self, state: dict, action: dict) -> bool:
        tool = action.get("tool", "")
        # قواعد بديهية
        if tool == "run_shell":
            cmd = action.get("args", {}).get("cmd", "")
            if any(bad in cmd for bad in ["rm -rf /", "mkfs", ":(){"]):
                return False
        if tool == "write_file":
            path = action.get("args", {}).get("path", "")
            if path in ("/", "/etc", "/boot") or path.startswith("/etc/"):
                return False
        return True


combined_checker = CombinedInvariantChecker()
