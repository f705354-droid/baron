---------------------------- MODULE Guardrails ----------------------------
(************************************************************************)
(* Formal spec لـautonomous guardrails.                                *)
(* يتحقق TLC من أن الاستقلال الذاتي لا يخرق invariants الأمان.         *)
(*                                                                      *)
(* Safety properties (invariants):                                     *)
(*   S1: لا تنفيذ أداة خطرة بدون موافقة بشرية (إذا auto_approve=false)  *)
(*   S2: الميزانية لا تتجاوز الحد الأقصى                                *)
(*   S3: عدد التكرارات لا يتجاوز الحد                                   *)
(*   S4: الوقت لا يتجاوز الحد الأقصى                                    *)
(*   S5: الوكيل لا يستمر بعد goal_reached                              *)
(* Liveness:                                                            *)
(*   L1: إذا توقفت كل الأدوات، الوكيل يتوقف خلال T                      *)
(************************************************************************)

EXTENDS Integers, TLC, Sequences

CONSTANTS
    MaxIterations,          \* الحد الأقصى للتكرارات
    MaxMinutes,             \* الحد الزمني
    MaxBudgetTokens,        \* حد التوكنز
    DangerousTools,         \* مجموعة الأدوات الخطرة
    AllTools                \* كل الأدوات المتاحة

VARIABLES
    iteration,              \* العداد الحالي
    tokensUsed,             \* التوكنز المستهلكة
    minutesElapsed,         \* الدقائق المنقضية
    state,                  \* "running" | "awaiting_approval" | "done" | "stopped"
    toolLast,               \* آخر أداة
    approvals,              \* مجموعة الموافقات
    autoApprove,            \* هل الموافقة التلقائية مفعلة
    goalReached             \* هل تحقق الهدف

vars == <<iteration, tokensUsed, minutesElapsed, state, toolLast,
          approvals, autoApprove, goalReached>>

TypeOK ==
    /\ iteration \in 0..MaxIterations
    /\ tokensUsed \in 0..MaxBudgetTokens
    /\ minutesElapsed \in 0..MaxMinutes
    /\ state \in {"running", "awaiting_approval", "done", "stopped"}
    /\ toolLast \in AllTools \cup {"none"}
    /\ autoApprove \in BOOLEAN
    /\ goalReached \in BOOLEAN

\* ─── Init ───
Init ==
    /\ iteration = 0
    /\ tokensUsed = 0
    /\ minutesElapsed = 0
    /\ state = "running"
    /\ toolLast = "none"
    /\ approvals = {}
    /\ autoApprove = FALSE
    /\ goalReached = FALSE

\* ─── Actions ───

\* الوكيل يقرر أداة
Decide(tool) ==
    /\ state = "running"
    /\ tool \in AllTools
    /\ iteration < MaxIterations
    /\ tokensUsed < MaxBudgetTokens
    /\ minutesElapsed < MaxMinutes
    /\ ~goalReached
    /\ IF tool \in DangerousTools /\ ~autoApprove
       THEN state' = "awaiting_approval"
       ELSE state' = "running"
    /\ toolLast' = tool
    /\ iteration' = iteration + 1
    /\ tokensUsed' = tokensUsed + 100
    /\ minutesElapsed' = minutesElapsed + 1
    /\ UNCHANGED <<approvals, autoApprove, goalReached>>

\* موافقة بشرية
Approve(tool) ==
    /\ state = "awaiting_approval"
    /\ tool \in DangerousTools
    /\ toolLast = tool
    /\ approvals' = approvals \cup {tool}
    /\ state' = "running"
    /\ UNCHANGED <<iteration, tokensUsed, minutesElapsed, toolLast,
                     autoApprove, goalReached>>

\* رفض
Deny(tool) ==
    /\ state = "awaiting_approval"
    /\ toolLast = tool
    /\ state' = "stopped"
    /\ UNCHANGED <<iteration, tokensUsed, minutesElapsed, toolLast,
                     approvals, autoApprove, goalReached>>

\* تنفيذ أداة آمنة
ExecuteSafe(tool) ==
    /\ state = "running"
    /\ tool \in AllTools \ DangerousTools
    /\ toolLast = tool
    /\ UNCHANGED <<iteration, tokensUsed, minutesElapsed, state, toolLast,
                     approvals, autoApprove, goalReached>>

\* الهدف تحقق
ReachGoal ==
    /\ state = "running"
    /\ goalReached = FALSE
    /\ goalReached' = TRUE
    /\ state' = "done"
    /\ UNCHANGED <<iteration, tokensUsed, minutesElapsed, toolLast,
                     approvals, autoApprove>>

\* التوقف عند تجاوز الحد
Timeout ==
    /\ state = "running"
    /\ (iteration >= MaxIterations \/
        tokensUsed >= MaxBudgetTokens \/
        minutesElapsed >= MaxMinutes)
    /\ state' = "stopped"
    /\ UNCHANGED <<iteration, tokensUsed, minutesElapsed, toolLast,
                     approvals, autoApprove, goalReached>>

\* ─── Next ───
Next ==
    \/ \E tool \in AllTools : Decide(tool)
    \/ \E tool \in DangerousTools : Approve(tool)
    \/ \E tool \in DangerousTools : Deny(tool)
    \/ \E tool \in AllTools \ DangerousTools : ExecuteSafe(tool)
    \/ ReachGoal
    \/ Timeout

Spec == Init /\ [][Next]_vars

\* ─── Safety Invariants ───

\* S1: لا أداة خطرة تُنفذ بدون موافقة (إذا auto_approve=false)
S1_NoDangerousWithoutApproval ==
    (state = "running" /\ ~autoApprove /\ toolLast \in DangerousTools)
    => toolLast \in approvals

\* S2: التوكنز لا تتجاوز الحد
S2_BudgetNotExceeded ==
    tokensUsed <= MaxBudgetTokens

\* S3: التكرارات لا تتجاوز الحد
S3_IterationsNotExceeded ==
    iteration <= MaxIterations

\* S4: الوقت لا يتجاوز الحد
S4_TimeNotExceeded ==
    minutesElapsed <= MaxMinutes

\* S5: بعد الهدف، لا مزيد من القرارات
S5_StopAfterGoal ==
    goalReached => state \in {"done", "stopped"}

\* S6: الموافقات تتراكم فقط
S6_ApprovalsMonotonic ==
    approvals \subseteq DangerousTools

SafetyInvariants ==
    /\ S1_NoDangerousWithoutApproval
    /\ S2_BudgetNotExceeded
    /\ S3_IterationsNotExceeded
    /\ S4_TimeNotExceeded
    /\ S5_StopAfterGoal
    /\ S6_ApprovalsMonotonic

\* ─── Liveness ───

\* L1: إذا استُنفدت الموارد، الوكيل يتوقف خلال خطوة واحدة
L1_Termination ==
    (iteration >= MaxIterations \/ tokensUsed >= MaxBudgetTokens \/
     minutesElapsed >= MaxMinutes) ~> (state \in {"done", "stopped"})

\* L2: إذا تحقق الهدف، لا مزيد من القرارات
L2_GoalLeadsToStop ==
    goalReached ~> (state \in {"done", "stopped"})

=============================================================================
