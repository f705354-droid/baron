# language: Python, file: core/ai/federated/client.py
# Federated client — trains LoRA locally, sends masked update
import os
import json
import base64
import pickle
import numpy as np
from typing import List, Dict, Optional
from core.ai.federated.secure_agg import SecureAggregator, ChaChaWrapper


class FederatedClient:
    """
    كل tenant = client.
    - يدرّب LoRA على dataset محلي
    - يقنّع الأوزان
    - يرسل للـserver
    - يستقبل aggregate model
    لا يشارك أي بيانات خام.
    """
    def __init__(self, tenant_id: str, server_url: str,
                  api_key: str, client_id: int = None):
        self.tenant_id = tenant_id
        self.server_url = server_url.rstrip("/")
        self.api_key = api_key
        self.client_id = client_id or hash(tenant_id) % 10000
        self.secagg = SecureAggregator(clip_norm=1.0, noise_mult=0.3)
        self.lora_weights: Dict[str, np.ndarray] = {}

    # ==================== local training ====================
    def train_local(self, base_model: str = "unsloth/llama-3.1-8b-instruct",
                     epochs: int = 1, lora_r: int = 8) -> Dict:
        """يدرّب LoRA محلياً بدون data sharing"""
        from core.ai.finetune import pipeline
        adapter_dir = pipeline.train_lora_local(
            base_model=base_model, epochs=epochs, lora_r=lora_r)
        if not adapter_dir:
            return {"error": "local training failed"}
        # extract weights
        self.lora_weights = self._load_lora_weights(adapter_dir)
        return {"adapter_dir": adapter_dir,
                 "param_count": sum(w.size for w in self.lora_weights.values())}

    def _load_lora_weights(self, adapter_dir: str) -> Dict[str, np.ndarray]:
        import safetensors.torch
        path = os.path.join(adapter_dir, "adapter_model.safetensors")
        if not os.path.exists(path):
            return {}
        weights = safetensors.torch.load_file(path)
        return {k: v.cpu().numpy() for k, v in weights.items()}

    # ==================== round participation ====================
    def participate(self, round_seed: int, peer_ids: List[int]) -> Dict:
        """يشارك في جولة: يقنّع، يرسل"""
        if not self.lora_weights:
            return {"error": "no local weights — train first"}

        # اربط الأسماء بترتيب ثابت
        keys = sorted(self.lora_weights.keys())
        weight_list = [self.lora_weights[k] for k in keys]

        masked = self.secagg.mask_weights(
            weight_list, self.client_id, peer_ids, round_seed)

        # serialize
        payload = {
            "client_id": self.client_id,
            "tenant_id": self.tenant_id,
            "round_seed": round_seed,
            "keys": keys,
            "shapes": [w.shape for w in masked],
            "masked": [base64.b64encode(w.astype(np.float32).tobytes()).decode()
                        for w in masked],
        }
        import httpx
        try:
            r = httpx.post(
                f"{self.server_url}/federated/round",
                json=payload,
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=120)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            return {"error": str(e)}

    def receive_global(self, round_id: str) -> Dict:
        import httpx
        try:
            r = httpx.get(
                f"{self.server_url}/federated/round/{round_id}",
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=120)
            r.raise_for_status()
            data = r.json()
            if "global" not in data:
                return data
            # decode weights
            agg = {}
            for k, blob in zip(data["keys"], data["global"]):
                arr = np.frombuffer(base64.b64decode(blob), dtype=np.float32)
                agg[k] = arr.reshape(data["shapes"][data["keys"].index(k)])
            return {"round_id": round_id, "weights": agg}
        except Exception as e:
            return {"error": str(e)}
