# language: Python, file: core/ai/federated/server.py
# Federated server — round coordination, aggregation, tenant isolation
import os
import json
import time
import uuid
import base64
import numpy as np
from datetime import datetime
from typing import Dict, List, Optional


class FederatedServer:
    """
    يدير جولات FedAvg.
    - لا يرى أي بيانات خام
    - يقنّع updates بضجيج SecAgg
    - يفرض عزل tenants (كل tenant له model lineage)
    """
    def __init__(self, pool=None):
        self.pool = pool
        self.rounds: Dict[str, dict] = {}         # round_id → round data
        self.global_models: Dict[str, dict] = {}   # tenant_id → global weights
        self.min_clients = int(os.getenv("FED_MIN_CLIENTS", "3"))
        self.round_timeout_min = int(os.getenv("FED_TIMEOUT", "30"))

    # ==================== round lifecycle ====================
    def start_round(self, tenant_id: str, base_model: str) -> str:
        rid = uuid.uuid4().hex[:8]
        self.rounds[rid] = {
            "id": rid,
            "tenant_id": tenant_id,
            "base_model": base_model,
            "started": datetime.utcnow().isoformat(),
            "state": "collecting",
            "clients": {},
            "peer_ids": [],
            "round_seed": int(time.time()),
        }
        return rid

    def join(self, round_id: str, client_id: int, tenant_id: str) -> dict:
        r = self.rounds.get(round_id)
        if not r:
            return {"error": "round not found"}
        if r["tenant_id"] != tenant_id:
            return {"error": "tenant mismatch"}   # عزل
        r["clients"][client_id] = {
            "joined": datetime.utcnow().isoformat(),
            "submitted": None,
        }
        r["peer_ids"] = sorted(r["clients"].keys())
        return {"round_id": round_id, "peer_ids": r["peer_ids"],
                 "round_seed": r["round_seed"]}

    def submit(self, round_id: str, tenant_id: str,
                payload: dict) -> dict:
        r = self.rounds.get(round_id)
        if not r:
            return {"error": "round not found"}
        if r["tenant_id"] != tenant_id:
            return {"error": "tenant mismatch"}
        if r["state"] != "collecting":
            return {"error": f"round is {r['state']}"}

        cid = payload["client_id"]
        if cid not in r["clients"]:
            return {"error": "client not joined"}

        r["clients"][cid]["submitted"] = {
            "keys": payload["keys"],
            "shapes": payload["shapes"],
            "masked": payload["masked"],
        }

        # check if enough clients
        n_ready = sum(1 for c in r["clients"].values() if c["submitted"])
        if n_ready >= self.min_clients:
            self._aggregate(round_id)

        return {"round_id": round_id, "n_ready": n_ready,
                 "state": r["state"]}

    # ==================== aggregation ====================
    def _aggregate(self, round_id: str):
        r = self.rounds[round_id]
        submissions = [c["submitted"] for c in r["clients"].values()
                        if c["submitted"]]
        if not submissions:
            r["state"] = "empty"
            return

        # check key consistency
        ref_keys = submissions[0]["keys"]
        valid = [s for s in submissions if s["keys"] == ref_keys]
        if len(valid) < self.min_clients:
            r["state"] = "insufficient_consistent"
            return

        # decode
        decoded = []
        for s in valid:
            arrays = []
            for blob, shape in zip(s["masked"], s["shapes"]):
                arr = np.frombuffer(base64.b64decode(blob),
                                     dtype=np.float32).reshape(shape)
                arrays.append(arr)
            decoded.append(arrays)

        # sum + average
        n = len(decoded)
        summed = decoded[0]
        for d in decoded[1:]:
            for i in range(len(summed)):
                summed[i] = summed[i] + d[i]
        averaged = [s / n for s in summed]

        # store
        r["state"] = "aggregated"
        r["global"] = {
            "keys": ref_keys,
            "shapes": valid[0]["shapes"],
            "values": [base64.b64encode(w.astype(np.float32).tobytes()).decode()
                        for w in averaged],
            "n_clients": n,
            "completed": datetime.utcnow().isoformat(),
        }

        # persist as new global for tenant
        tid = r["tenant_id"]
        if tid not in self.global_models:
            self.global_models[tid] = []
        self.global_models[tid].append({
            "round_id": round_id,
            "n_clients": n,
            "completed": r["global"]["completed"],
        })

    # ==================== retrieval ====================
    def get_round(self, round_id: str, tenant_id: str) -> dict:
        r = self.rounds.get(round_id)
        if not r or r["tenant_id"] != tenant_id:
            return {"error": "not found or forbidden"}
        out = {
            "round_id": round_id,
            "state": r["state"],
            "n_clients": len(r["clients"]),
            "started": r["started"],
        }
        if "global" in r:
            out.update(r["global"])
        return out

    def list_rounds(self, tenant_id: str) -> list:
        return [{
            "round_id": rid,
            "state": r["state"],
            "started": r["started"],
            "clients": len(r["clients"]),
        } for rid, r in self.rounds.items()
            if r["tenant_id"] == tenant_id]

    def get_global_history(self, tenant_id: str) -> list:
        return self.global_models.get(tenant_id, [])


federated_server = FederatedServer()
