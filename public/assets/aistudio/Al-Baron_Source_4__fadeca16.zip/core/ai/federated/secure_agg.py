# language: Python, file: core/ai/federated/secure_agg.py
# Secure aggregation + differential privacy for federated LoRA
import os
import hashlib
import numpy as np
from typing import List, Dict
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305


class SecureAggregator:
    """
    Secure aggregation:
      1. كل client يقنّع LoRA weights بضجيج pairwise
      2. Server يجمع المقنّع → يقنّع cancel out
      3. النتيجة = مجموع حقيقي بدون كشف فردي
    + Differential privacy: clip + noise
    """
    def __init__(self, clip_norm: float = 1.0, noise_mult: float = 0.5):
        self.clip_norm = clip_norm
        self.noise_mult = noise_mult

    # ==================== DP ====================
    def clip(self, weights: List[np.ndarray]) -> List[np.ndarray]:
        """global norm clipping"""
        total_norm = np.sqrt(sum(float(np.sum(w ** 2)) for w in weights))
        scale = min(1.0, self.clip_norm / (total_norm + 1e-8))
        return [w * scale for w in weights]

    def add_noise(self, weights: List[np.ndarray],
                    sensitivity: float = None) -> List[np.ndarray]:
        """Gaussian mechanism"""
        sens = sensitivity or self.clip_norm
        sigma = self.noise_mult * sens
        return [w + np.random.normal(0, sigma, w.shape)
                for w in weights]

    # ==================== SecAgg ====================
    def pairwise_mask(self, weights: List[np.ndarray],
                        my_id: int, peer_ids: List[int],
                        round_seed: int) -> List[np.ndarray]:
        """
        يولّد قناع pairwise مع كل peer.
        Sum of masks for i = -Sum for j إذا الاتجاه معاكس.
        """
        masks = [np.zeros_like(w, dtype=np.float64) for w in weights]
        for peer in peer_ids:
            if peer == my_id:
                continue
            # derive seed مشترك
            seed = self._shared_seed(my_id, peer, round_seed)
            rng = np.random.default_rng(seed)
            sign = 1 if my_id < peer else -1
            for i, w in enumerate(weights):
                mask = rng.normal(0, 1, w.shape)
                masks[i] += sign * mask
        return masks

    def _shared_seed(self, a: int, b: int, round_seed: int) -> int:
        key = f"{min(a,b)}-{max(a,b)}-{round_seed}"
        return int(hashlib.sha256(key.encode()).hexdigest()[:16], 16)

    def mask_weights(self, weights: List[np.ndarray],
                       my_id: int, peer_ids: List[int],
                       round_seed: int) -> List[np.ndarray]:
        masks = self.pairwise_mask(weights, my_id, peer_ids, round_seed)
        masked = []
        for w, m in zip(weights, masks):
            # clip + noise قبل القناع
            clipped = self.clip([w])[0]
            noisy = clipped + np.random.normal(
                0, self.noise_mult * self.clip_norm, w.shape)
            masked.append(noisy + m)
        return masked

    # ==================== Combine ====================
    def aggregate(self, masked_list: List[List[np.ndarray]]) -> List[np.ndarray]:
        """FedAvg بعد فك الأقنعة"""
        n = len(masked_list)
        if n == 0:
            return []
        summed = masked_list[0]
        for m in masked_list[1:]:
            for i in range(len(summed)):
                summed[i] = summed[i] + m[i]
        return [s / n for s in summed]


class ChaChaWrapper:
    """تشفير عالي السرعة لتبادل الوزن"""
    @staticmethod
    def encrypt(key: bytes, plaintext: bytes, aad: bytes = b"") -> bytes:
        aead = ChaCha20Poly1305(key)
        nonce = os.urandom(12)
        ct = aead.encrypt(nonce, plaintext, aad)
        return nonce + ct

    @staticmethod
    def decrypt(key: bytes, blob: bytes, aad: bytes = b"") -> bytes:
        aead = ChaCha20Poly1305(key)
        nonce, ct = blob[:12], blob[12:]
        return aead.decrypt(nonce, ct, aad)
