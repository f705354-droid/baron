# language: Python, file: core/ai/finetune.py
# Fine-tuning pipeline — dataset builder + LoRA/QLoRA + K8s job dispatch
import os
import json
import sqlite3
import subprocess
import uuid
from datetime import datetime
from typing import List, Dict, Optional


class FinetunePipeline:
    """
    يحوّل engagement history إلى dataset ويدرب LoRA adapter.
    Output: adapter يُحمَّل فوق base model (Anthropic لا يدعم fine-tune —
    نستخدم open models: llama 3.1, qwen 2.5, mistral عبر unsloth).
    """
    def __init__(self, db_path: str = "~/.albaron/ai_memory.db",
                  output_dir: str = "~/.albaron/finetune"):
        self.db_path = os.path.expanduser(db_path)
        self.output_dir = os.path.expanduser(output_dir)
        os.makedirs(self.output_dir, exist_ok=True)

    # ==================== dataset builder ====================
    def build_dataset(self, min_pairs: int = 100,
                       filter_agent: str = None) -> Optional[str]:
        """
        يستخرج (prompt, response) pairs عالية الجودة من الذاكرة.
        فلترة:
          - assistant responses > 200 حرف
          - user prompts غير trivial
          - إزالة المكرر
        """
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        c = conn.cursor()

        rows = c.execute("""
            SELECT session_id, role, content, ts, meta
            FROM messages
            ORDER BY session_id, id
        """).fetchall()
        conn.close()

        # group by session, build pairs
        sessions = {}
        for sid, role, content, ts, meta in rows:
            sessions.setdefault(sid, []).append({
                "role": role, "content": content, "ts": ts,
                "meta": json.loads(meta or "{}"),
            })

        pairs = []
        seen = set()
        for sid, msgs in sessions.items():
            for i in range(len(msgs) - 1):
                if msgs[i]["role"] == "user" and msgs[i+1]["role"] == "assistant":
                    u = msgs[i]["content"].strip()
                    a = msgs[i+1]["content"].strip()
                    if len(u) < 8 or len(a) < 200:
                        continue
                    # filter agent
                    if filter_agent:
                        agent = msgs[i]["meta"].get("agent", "unknown")
                        if agent != filter_agent:
                            continue
                    # dedupe on hash
                    h = hash(u[:200] + a[:200])
                    if h in seen:
                        continue
                    seen.add(h)
                    pairs.append({
                        "messages": [
                            {"role": "system", "content": msgs[i]["meta"].get(
                                "system", "أنت وكيل Al-Baron.")},
                            {"role": "user", "content": u},
                            {"role": "assistant", "content": a},
                        ],
                    })

        if len(pairs) < min_pairs:
            print(f"[finetune] only {len(pairs)} pairs — need {min_pairs}")
            return None

        # split train/eval
        import random
        random.shuffle(pairs)
        split = int(len(pairs) * 0.95)
        train, eval_ = pairs[:split], pairs[split:]

        train_path = os.path.join(self.output_dir, "train.jsonl")
        eval_path = os.path.join(self.output_dir, "eval.jsonl")
        with open(train_path, "w") as f:
            for p in train:
                f.write(json.dumps(p, ensure_ascii=False) + "\n")
        with open(eval_path, "w") as f:
            for p in eval_:
                f.write(json.dumps(p, ensure_ascii=False) + "\n")

        meta_path = os.path.join(self.output_dir, "meta.json")
        with open(meta_path, "w") as f:
            json.dump({
                "train": len(train), "eval": len(eval_),
                "created": datetime.utcnow().isoformat(),
                "filter_agent": filter_agent,
            }, f, indent=2)

        print(f"[finetune] dataset: {len(train)} train · {len(eval_)} eval")
        return train_path

    # ==================== training (local) ====================
    def train_lora_local(self, base_model: str = "unsloth/llama-3.1-8b-instruct",
                          epochs: int = 3, batch_size: int = 2,
                          lr: float = 2e-4, lora_r: int = 16) -> str:
        """
        QLoRA محلي عبر unsloth (يحتاج GPU).
        يرجع مسار الـadapter.
        """
        try:
            from unsloth import FastLanguageModel
            import torch
            from datasets import load_dataset
            from trl import SFTTrainer
            from transformers import TrainingArguments
        except ImportError:
            print("[finetune] unsloth/trl/transformers missing — run: "
                  "pip install unsloth trl transformers datasets")
            return ""

        train_path = os.path.join(self.output_dir, "train.jsonl")
        if not os.path.exists(train_path):
            train_path = self.build_dataset()
            if not train_path:
                return ""

        run_id = str(uuid.uuid4())[:8]
        adapter_dir = os.path.join(self.output_dir, f"adapter-{run_id}")
        os.makedirs(adapter_dir, exist_ok=True)

        # ── load model ──
        model, tokenizer = FastLanguageModel.from_pretrained(
            model_name=base_model,
            max_seq_length=4096,
            load_in_4bit=True,
        )
        model = FastLanguageModel.get_peft_model(
            model, r=lora_r,
            target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                            "gate_proj", "up_proj", "down_proj"],
            lora_alpha=lora_r * 2, lora_dropout=0.05,
            bias="none", use_gradient_checkpointing="unsloth",
        )

        dataset = load_dataset("json", data_files={"train": train_path})["train"]

        def fmt(ex):
            text = tokenizer.apply_chat_template(
                ex["messages"], tokenize=False,
                add_generation_prompt=False)
            return {"text": text}
        dataset = dataset.map(fmt)

        trainer = SFTTrainer(
            model=model, tokenizer=tokenizer,
            train_dataset=dataset,
            dataset_text_field="text",
            max_seq_length=4096,
            args=TrainingArguments(
                per_device_train_batch_size=batch_size,
                gradient_accumulation_steps=4,
                warmup_steps=10,
                num_train_epochs=epochs,
                learning_rate=lr,
                fp16=not torch.cuda.is_bf16_supported(),
                bf16=torch.cuda.is_bf16_supported(),
                logging_steps=5,
                optim="adamw_8bit",
                weight_decay=0.01,
                lr_scheduler_type="cosine",
                output_dir=adapter_dir,
                save_steps=50,
                report_to="none",
            ),
        )
        trainer.train()
        model.save_pretrained(adapter_dir)
        tokenizer.save_pretrained(adapter_dir)

        # metadata
        with open(os.path.join(adapter_dir, "albaron_meta.json"), "w") as f:
            json.dump({
                "base": base_model, "epochs": epochs, "lora_r": lora_r,
                "lr": lr, "created": datetime.utcnow().isoformat(),
                "run_id": run_id,
            }, f, indent=2)

        print(f"[finetune] adapter saved: {adapter_dir}")
        return adapter_dir

    # ==================== K8s dispatch ====================
    def dispatch_k8s_job(self, base_model: str, epochs: int = 3,
                          gpu_type: str = "a100-40gb",
                          namespace: str = "albaron") -> str:
        """
        يشغّل fine-tuning كـK8s Job على GPU pool.
        يرجع اسم الـjob.
        """
        train_path = os.path.join(self.output_dir, "train.jsonl")
        if not os.path.exists(train_path):
            self.build_dataset()

        job_name = f"finetune-{uuid.uuid4().hex[:8]}"
        manifest = {
            "apiVersion": "batch/v1",
            "kind": "Job",
            "metadata": {
                "name": job_name,
                "namespace": namespace,
                "labels": {"app": "albaron-finetune"},
            },
            "spec": {
                "ttlSecondsAfterFinished": 86400,
                "backoffLimit": 1,
                "template": {
                    "metadata": {"labels": {"app": "albaron-finetune"}},
                    "spec": {
                        "restartPolicy": "Never",
                        "nodeSelector": {"gpu": gpu_type},
                        "tolerations": [{
                            "key": "nvidia.com/gpu",
                            "operator": "Exists",
                            "effect": "NoSchedule",
                        }],
                        "containers": [{
                            "name": "trainer",
                            "image": "albaron/finetune:latest",
                            "command": ["python", "-m", "core.ai.finetune_worker"],
                            "env": [
                                {"name": "BASE_MODEL", "value": base_model},
                                {"name": "EPOCHS", "value": str(epochs)},
                                {"name": "TRAIN_PATH", "value": "/data/train.jsonl"},
                                {"name": "OUTPUT_DIR", "value": "/out"},
                                {"name": "WANDB_DISABLED", "value": "true"},
                            ],
                            "volumeMounts": [
                                {"name": "data", "mountPath": "/data"},
                                {"name": "out", "mountPath": "/out"},
                            ],
                            "resources": {
                                "limits": {"nvidia.com/gpu": 1,
                                            "memory": "64Gi", "cpu": "8"},
                                "requests": {"nvidia.com/gpu": 1,
                                              "memory": "32Gi", "cpu": "4"},
                            },
                        }],
                        "volumes": [
                            {"name": "data", "persistentVolumeClaim":
                             {"claimName": "albaron-ai-data"}},
                            {"name": "out", "persistentVolumeClaim":
                             {"claimName": "albaron-ai-adapters"}},
                        ],
                    },
                },
            },
        }

        path = os.path.join(self.output_dir, f"{job_name}.yaml")
        import yaml
        with open(path, "w") as f:
            yaml.safe_dump(manifest, f)

        try:
            subprocess.run(["kubectl", "apply", "-f", path],
                            check=True, capture_output=True)
            print(f"[finetune] job dispatched: {job_name}")
        except Exception as e:
            print(f"[finetune] kubectl failed: {e}")
        return job_name

    # ==================== load adapter ====================
    def load_adapter(self, adapter_dir: str, base_model: str):
        """يحمّل adapter للاستخدام المباشر (offline inference)"""
        try:
            from unsloth import FastLanguageModel
            model, tokenizer = FastLanguageModel.from_pretrained(
                model_name=adapter_dir,
                max_seq_length=4096,
                load_in_4bit=True,
            )
            FastLanguageModel.for_inference(model)
            return model, tokenizer
        except Exception as e:
            print(f"[finetune] load failed: {e}")
            return None, None

    # ==================== merge ====================
    def merge_adapter(self, adapter_dir: str, out_dir: str = None):
        """يدمج الـadapter مع base → نموذج كامل للتصدير"""
        out_dir = out_dir or adapter_dir + "-merged"
        try:
            from peft import PeftModel
            from transformers import AutoModelForCausalLM, AutoTokenizer
            import json as _j
            meta = _j.load(open(os.path.join(adapter_dir, "albaron_meta.json")))
            base = meta["base"]
            model = AutoModelForCausalLM.from_pretrained(base)
            model = PeftModel.from_pretrained(model, adapter_dir)
            model = model.merge_and_unload()
            model.save_pretrained(out_dir)
            AutoTokenizer.from_pretrained(adapter_dir).save_pretrained(out_dir)
            print(f"[finetune] merged: {out_dir}")
            return out_dir
        except Exception as e:
            print(f"[finetune] merge failed: {e}")
            return ""


pipeline = FinetunePipeline()
