# language: Python, file: core/ai/rl/reward.py
# Reward shaping — converts engagement outcomes into scalar rewards
import os
import json
import math
from datetime import datetime, timedelta
from typing import Dict, Optional
from dataclasses import dataclass, field


@dataclass
class RewardSignal:
    """مكافأة واحدة مرتبطة بـevent"""
    kind: str                # session_new, cred_hit, task_success, task_fail,
                             # detected, escalated, goal_reached, goal_missed
    value: float
    context: dict = field(default_factory=dict)
    ts: str = field(default_factory=lambda: datetime.utcnow().isoformat())


class RewardShaper:
    """
    يحوّل أحداث engagement إلى مكافآت numeric.
    الهدف: policy تحسّن قرارات الوكيل بمرور الوقت.

    مبادئ shaping:
      - مكافأة أعلى للاكتشافات الحرجة (DA, kerberoast, dcsync)
      - عقوبة على الكشف (defender alert, honeypot)
      - مكافأة متوسطة على خطوات مفيدة (recon, enum, lateral)
      - عقوبة على عدم الكفاءة (تكرار، استهلاك tokens بلا نتيجة)
    """
    # القيم الأساسية لكل نوع حدث
    BASE_REWARDS = {
        # ── نجاحات عالية ──
        "domain_admin":        +100.0,
        "dcsync":              +120.0,
        "golden_ticket":       +150.0,
        "adcs_da_cert":        +90.0,
        "cloud_admin":         +80.0,

        # ── اكتشافات متوسطة ──
        "session_new":         +10.0,
        "cred_hit":            +20.0,
        "kerberoast_hash":     +25.0,
        "asrep_hash":          +25.0,
        "vuln_confirmed":      +15.0,
        "lateral_move":        +30.0,
        "persistence_set":     +35.0,

        # ── خطوات مفيدة ──
        "recon_done":          +2.0,
        "enum_done":           +3.0,
        "port_open":           +0.5,
        "service_identified":  +1.0,

        # ── عقوبات ──
        "task_fail":           -2.0,
        "detected":            -50.0,   # defender alert
        "honeypot_tripped":    -80.0,
        "session_lost":        -10.0,
        "burned_identity":     -30.0,
        "excessive_noise":     -15.0,
        "repeated_action":     -1.0,
        "tokens_wasted":       -0.1,    # per 1k tokens بلا نتيجة

        # ── نهايات ──
        "goal_reached":        +200.0,
        "goal_missed":         -100.0,
        "engagement_aborted":  -20.0,
    }

    # multipliers حسب السياق
    CONTEXT_MULT = {
        "stealth_mode":     1.5,     # في وضع التخفي، الكشف أسوأ
        "time_pressure":    1.2,
        "ad_environment":   1.3,     # AD targets تستحق أكثر
        "cloud":            1.2,
        "ot_iot":           2.0,     # OT حساس جداً — detection = disaster
    }

    def __init__(self):
        self.history: list[RewardSignal] = []

    def compute(self, event: dict, context: dict = None) -> RewardSignal:
        """يحوّل event إلى RewardSignal"""
        kind = event.get("kind") or event.get("type", "unknown")
        base = self.BASE_REWARDS.get(kind, 0.0)

        # تعديلات سياقية
        ctx = context or {}
        mult = 1.0
        for k, v in self.CONTEXT_MULT.items():
            if ctx.get(k):
                mult *= v

        # تعديلات حسب التكرار
        repeat_count = self._count_recent(kind, minutes=10)
        if repeat_count > 3:
            base *= max(0.2, 1.0 - 0.15 * (repeat_count - 3))

        # تعديل حسب tokens المستهلكة
        tokens = event.get("tokens_used", 0)
        if tokens > 0:
            token_penalty = (tokens / 1000) * self.BASE_REWARDS["tokens_wasted"]
            base += token_penalty

        # تعديل حسب الوقت منذ آخر مكافأة
        time_discount = self._time_discount()

        value = base * mult * time_discount
        sig = RewardSignal(kind=kind, value=value, context=ctx)
        self.history.append(sig)
        return sig

    def _count_recent(self, kind: str, minutes: int) -> int:
        cutoff = datetime.utcnow() - timedelta(minutes=minutes)
        n = 0
        for s in reversed(self.history):
            if s.ts < cutoff.isoformat():
                break
            if s.kind == kind:
                n += 1
        return n

    def _time_discount(self) -> float:
        """كلما طال الوقت بدون progress، المكافأة تقل"""
        if not self.history:
            return 1.0
        last_positive = None
        for s in reversed(self.history):
            if s.value > 0:
                last_positive = s
                break
        if not last_positive:
            return 1.0
        elapsed = (datetime.utcnow()
                    - datetime.fromisoformat(last_positive.ts)).total_seconds()
        # decay بعد 5 دقائق
        if elapsed < 300:
            return 1.0
        return max(0.5, math.exp(-(elapsed - 300) / 900))

    def trajectory_return(self, gamma: float = 0.95) -> float:
        """cumulative discounted return للtrajectory كامل"""
        total = 0.0
        for i, s in enumerate(reversed(self.history)):
            total += (gamma ** i) * s.value
        return total


reward_shaper = RewardShaper()
