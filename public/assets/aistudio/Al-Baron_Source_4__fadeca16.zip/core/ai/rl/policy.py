# language: Python, file: core/ai/rl/policy.py
# Policy — hybrid neural + bandit action selection
import os
import json
import pickle
import numpy as np
from typing import List, Tuple, Dict, Optional
from collections import defaultdict

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


STATE_DIM = 64
ACTION_VOCAB_SIZE = 512


def featurize_state(ctx: dict) -> np.ndarray:
    """يحوّل سياق engagement إلى متجه 64-dim"""
    v = np.zeros(STATE_DIM, dtype=np.float32)

    # module one-hot (16 خانات)
    modules = ["recon", "exploit", "lan", "ad", "adcs", "cloud",
                "exfil", "post", "c2", "phishing", "firmware", "iot_ot",
                "mobile", "covert_c2", "unknown", "idle"]
    mod = ctx.get("module", "unknown")
    if mod in modules:
        v[modules.index(mod)] = 1.0

    # counters (16 خانات)
    v[16] = min(ctx.get("sessions_count", 0) / 20, 1.0)
    v[17] = min(ctx.get("hosts_count", 0) / 100, 1.0)
    v[18] = min(ctx.get("creds_count", 0) / 50, 1.0)
    v[19] = min(ctx.get("findings_count", 0) / 100, 1.0)
    v[20] = min(ctx.get("step", 0) / 50, 1.0)
    v[21] = min(ctx.get("cumulative_reward", 0) / 500, 1.0)
    v[22] = min(ctx.get("tokens_used", 0) / 100_000, 1.0)
    v[23] = min(ctx.get("time_elapsed_min", 0) / 60, 1.0)

    # flags (16 خانات)
    v[24] = 1.0 if ctx.get("ad_environment") else 0.0
    v[25] = 1.0 if ctx.get("cloud") else 0.0
    v[26] = 1.0 if ctx.get("ot_iot") else 0.0
    v[27] = 1.0 if ctx.get("stealth_mode") else 0.0
    v[28] = 1.0 if ctx.get("detected") else 0.0
    v[29] = 1.0 if ctx.get("has_domain_admin") else 0.0
    v[30] = 1.0 if ctx.get("has_kerberoast_hash") else 0.0
    v[31] = 1.0 if ctx.get("has_session") else 0.0

    # tool frequencies (16 خانات) — normalized
    freqs = ctx.get("tool_freqs", {})
    tools = ["run_shell", "get_sessions", "dispatch_task", "write_file",
              "read_log", "query_cve", "search_memory", "get_facts",
              "read_file", "compile_check", "search_web", "spawn_agent",
              "call_siem", "exfil_file", "pivot", "escalate"]
    for i, t in enumerate(tools):
        v[32 + i] = min(freqs.get(t, 0) / 10, 1.0)

    # reward signals (16 خانات)
    v[48] = np.tanh(ctx.get("last_reward", 0) / 50)
    v[49] = np.tanh(ctx.get("avg_reward_10", 0) / 50)
    v[50] = 1.0 if ctx.get("last_success") else 0.0
    v[51] = 1.0 if ctx.get("last_detected") else 0.0
    v[52] = min(len(ctx.get("recent_actions", [])), 10) / 10
    v[53] = ctx.get("repeat_count", 0) / 5
    v[54] = min(ctx.get("pending_approvals", 0) / 3, 1.0)
    v[55] = ctx.get("failure_streak", 0) / 5

    # padding (8 خانات محجوزة للتوسعة)
    return v


if HAS_TORCH:
    class PolicyNet(nn.Module):
        """Actor-Critic لاختيار الأدوات"""
        def __init__(self, state_dim=STATE_DIM, action_dim=ACTION_VOCAB_SIZE,
                      hidden=256):
            super().__init__()
            self.trunk = nn.Sequential(
                nn.Linear(state_dim, hidden),
                nn.LayerNorm(hidden),
                nn.ReLU(),
                nn.Linear(hidden, hidden),
                nn.LayerNorm(hidden),
                nn.ReLU(),
            )
            self.actor = nn.Linear(hidden, action_dim)
            self.critic = nn.Linear(hidden, 1)

        def forward(self, s):
            h = self.trunk(s)
            logits = self.actor(h)
            value = self.critic(h).squeeze(-1)
            return logits, value


class HybridPolicy:
    """
    Policy هجين:
      - Neural actor يوزّع على action classes (لاول 512 action)
      - Bandit (Thompson sampling) للأدوات الفعلية
      - Fallback rule-based إذا لا torch
    Action encoding:
      action_id = hash(tool_name) % 128 + hash_arg_bucket % 384
    """
    def __init__(self, model_path: str = "~/.albaron/policy.pt"):
        self.model_path = os.path.expanduser(model_path)
        self.net = None
        self.optimizer = None
        if HAS_TORCH:
            self.net = PolicyNet()
            self.optimizer = torch.optim.Adam(self.net.parameters(), lr=3e-4)
            if os.path.exists(self.model_path):
                try:
                    self.net.load_state_dict(torch.load(self.model_path))
                except Exception:
                    pass

        # Thompson sampling per tool
        self.tool_alpha: Dict[str, float] = defaultdict(lambda: 1.0)
        self.tool_beta: Dict[str, float] = defaultdict(lambda: 1.0)

        # action encoding
        self.tool_list = [
            "run_shell", "get_sessions", "dispatch_task", "write_file",
            "read_log", "query_cve", "search_memory", "get_facts",
            "read_file", "compile_check", "search_web", "spawn_agent",
            "call_siem", "exfil_file", "pivot", "escalate", "done",
        ]
        self.tool_to_id = {t: i for i, t in enumerate(self.tool_list)}

    def encode_action(self, tool: str, args: dict) -> int:
        tid = self.tool_to_id.get(tool, len(self.tool_list)) * 32
        arg_hash = hash(json.dumps(args, sort_keys=True)) % 32
        return min(tid + arg_hash, ACTION_VOCAB_SIZE - 1)

    # ==================== select ====================
    def select(self, state_vec: np.ndarray, available_tools: List[str],
                temperature: float = 0.7, epsilon: float = 0.05) -> Tuple[str, dict]:
        """يرجع (tool, args) — args يُملأ لاحقاً بـLLM"""
        if not available_tools:
            return "done", {}

        # epsilon-greedy
        if np.random.rand() < epsilon:
            return str(np.random.choice(available_tools)), {}

        # Thompson sampling للأدوات
        samples = {}
        for t in available_tools:
            samples[t] = np.random.beta(self.tool_alpha[t], self.tool_beta[t])

        # دمج مع neural policy إذا متاح
        if HAS_TORCH and self.net:
            with torch.no_grad():
                s = torch.from_numpy(state_vec).float().unsqueeze(0)
                logits, _ = self.net(s)
                probs = torch.softmax(logits / temperature, dim=-1).squeeze(0)
            combined = {}
            for t in available_tools:
                t_id = self.tool_to_id.get(t, 0) * 32
                neural_p = float(probs[t_id:t_id+32].sum())
                combined[t] = neural_p * 0.6 + samples[t] * 0.4
            best = max(combined, key=combined.get)
            return best, {}

        best = max(samples, key=samples.get)
        return best, {}

    # ==================== update ====================
    def update_bandit(self, tool: str, reward: float):
        """يحدّث Thompson priors"""
        if reward > 0:
            self.tool_alpha[tool] += min(reward, 10.0) / 10.0
        else:
            self.tool_beta[tool] += min(-reward, 10.0) / 10.0

    def update_neural(self, batch: List[dict], gamma: float = 0.95):
        """A2C-style update على batch من transitions"""
        if not HAS_TORCH or not self.net:
            return
        states = torch.tensor([b["state"] for b in batch], dtype=torch.float32)
        next_states = torch.tensor([b["next_state"] for b in batch],
                                     dtype=torch.float32)
        rewards = torch.tensor([b["reward"] for b in batch],
                                 dtype=torch.float32)
        dones = torch.tensor([b["done"] for b in batch], dtype=torch.float32)
        is_weights = torch.tensor([b.get("is_weight", 1.0) for b in batch],
                                    dtype=torch.float32)

        # action ids
        action_ids = []
        for b in batch:
            tool = b["action"].split(":", 1)[0]
            try:
                args = json.loads(b["action"].split(":", 1)[1])
            except Exception:
                args = {}
            action_ids.append(self.encode_action(tool, args))
        actions = torch.tensor(action_ids, dtype=torch.long)

        logits, values = self.net(states)
        with torch.no_grad():
            _, next_values = self.net(next_states)
            targets = rewards + gamma * (1 - dones) * next_values

        advantages = targets - values
        log_probs = torch.log_softmax(logits, dim=-1)
        selected_log_probs = log_probs.gather(1, actions.unsqueeze(1)).squeeze(1)

        policy_loss = -(selected_log_probs * advantages.detach() * is_weights).mean()
        value_loss = F.mse_loss(values, targets)
        entropy = -(torch.softmax(logits, -1) * log_probs).sum(-1).mean()

        loss = policy_loss + 0.5 * value_loss - 0.01 * entropy

        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.net.parameters(), 1.0)
        self.optimizer.step()

        # update priorities
        td_errors = advantages.detach().abs().cpu().numpy().tolist()
        return td_errors

    # ==================== persist ====================
    def save(self):
        if HAS_TORCH and self.net:
            try:
                torch.save(self.net.state_dict(), self.model_path)
            except Exception:
                pass
        # bandit state
        bpath = self.model_path + ".bandit"
        with open(bpath, "wb") as f:
            pickle.dump({
                "alpha": dict(self.tool_alpha),
                "beta": dict(self.tool_beta),
            }, f)

    def load(self):
        if HAS_TORCH and self.net and os.path.exists(self.model_path):
            try:
                self.net.load_state_dict(torch.load(self.model_path))
            except Exception:
                pass
        bpath = self.model_path + ".bandit"
        if os.path.exists(bpath):
            with open(bpath, "rb") as f:
                data = pickle.load(f)
                self.tool_alpha.update(data.get("alpha", {}))
                self.tool_beta.update(data.get("beta", {}))


policy = HybridPolicy()
policy.load()
