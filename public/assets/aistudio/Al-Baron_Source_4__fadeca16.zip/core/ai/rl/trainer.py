# language: Python, file: core/ai/rl/trainer.py
# RL training — DPO (offline) + PPO (online) + reward model
import os
import json
import time
import threading
from datetime import datetime
from typing import List, Optional
from core.ai.rl.replay import replay
from core.ai.rl.policy import policy, HAS_TORCH
from core.ai.rl.reward import reward_shaper


class RLTrainer:
    """
    يدرّب policy دورياً من replay buffer.
    استراتيجيتان:
      1. Online: كل N خطوات → batch update
      2. Offline DPO: من engagement history → preference pairs
    """
    def __init__(self, batch_size: int = 64, update_every_n: int = 32,
                  min_replay_size: int = 200):
        self.batch_size = batch_size
        self.update_every_n = update_every_n
        self.min_replay_size = min_replay_size
        self.steps_since_update = 0
        self.training_log: List[dict] = []
        self._lock = threading.Lock()

    # ==================== online ====================
    def step(self, state_vec, action, reward, next_state_vec, done=False,
              run_id=None, session_id=None, meta=None):
        """يُسجّل خطوة ويدرب إن حان الوقت"""
        replay.store(state_vec, action, reward, next_state_vec, done,
                      run_id=run_id, session_id=session_id, meta=meta)
        # bandit update
        policy.update_bandit(action[0], reward)

        self.steps_since_update += 1
        if self.steps_since_update >= self.update_every_n:
            self.steps_since_update = 0
            self._async_update()

    def _async_update(self):
        threading.Thread(target=self._update, daemon=True).start()

    def _update(self):
        with self._lock:
            stats = replay.stats()
            if stats["total"] < self.min_replay_size:
                return
            batch = replay.sample(self.batch_size)
            if not batch:
                return
            td_errors = policy.update_neural(batch)
            if td_errors:
                ids = [b["id"] for b in batch]
                replay.update_priorities(ids, td_errors)
            self.training_log.append({
                "ts": datetime.utcnow().isoformat(),
                "batch": len(batch),
                "avg_reward": sum(b["reward"] for b in batch) / len(batch),
            })
            if len(self.training_log) > 1000:
                self.training_log = self.training_log[-500:]
            policy.save()

    # ==================== offline DPO ====================
    def build_dpo_pairs(self, min_pairs: int = 100) -> List[dict]:
        """
        يبني preference pairs: (prompt, chosen, rejected).
        chosen = action مع reward أعلى
        rejected = action مع reward أقل
        نفس الـstate، تشابه في الـaction type.
        """
        c = replay.db.cursor()
        rows = c.execute("""
            SELECT id, state_vec, action, reward, run_id
            FROM transitions
            WHERE reward != 0
            ORDER BY run_id, id
        """).fetchall()

        # group by run_id
        by_run = {}
        for r in rows:
            by_run.setdefault(r[4], []).append({
                "id": r[0], "state": json.loads(r[1]),
                "action": r[2], "reward": r[3],
            })

        pairs = []
        import random
        for run_id, traj in by_run.items():
            if len(traj) < 2:
                continue
            for i in range(len(traj)):
                for j in range(i + 1, len(traj)):
                    a, b = traj[i], traj[j]
                    # تحقق من تشابه الحالة
                    sim = self._state_similarity(a["state"], b["state"])
                    if sim < 0.7:
                        continue
                    if abs(a["reward"] - b["reward"]) < 1.0:
                        continue
                    chosen, rejected = (a, b) if a["reward"] > b["reward"] else (b, a)
                    pairs.append({
                        "state": a["state"],
                        "chosen_action": chosen["action"],
                        "rejected_action": rejected["action"],
                        "reward_diff": chosen["reward"] - rejected["reward"],
                    })
                    if len(pairs) >= min_pairs * 10:
                        break
            if len(pairs) >= min_pairs * 10:
                break

        random.shuffle(pairs)
        return pairs[:min_pairs]

    def _state_similarity(self, a, b) -> float:
        import numpy as np
        va, vb = np.array(a), np.array(b)
        na, nb = np.linalg.norm(va), np.linalg.norm(vb)
        if na == 0 or nb == 0:
            return 0.0
        return float(np.dot(va, vb) / (na * nb))

    def train_dpo(self, epochs: int = 3, beta: float = 0.1) -> dict:
        """
        DPO training على preference pairs.
        يستخدم policy net نفسه + loss DPO.
        """
        if not HAS_TORCH:
            return {"error": "torch not available"}
        import torch
        import torch.nn.functional as F

        pairs = self.build_dpo_pairs()
        if len(pairs) < 50:
            return {"error": f"need >=50 pairs, have {len(pairs)}"}

        net = policy.net
        optimizer = policy.optimizer

        def action_id(action_str):
            parts = action_str.split(":", 1)
            tool = parts[0]
            try:
                args = json.loads(parts[1]) if len(parts) > 1 else {}
            except Exception:
                args = {}
            return policy.encode_action(tool, args)

        losses = []
        for epoch in range(epochs):
            epoch_loss = 0.0
            n_batches = 0
            for i in range(0, len(pairs), 16):
                batch = pairs[i:i+16]
                states = torch.tensor([p["state"] for p in batch],
                                        dtype=torch.float32)
                chosen_ids = torch.tensor([action_id(p["chosen_action"])
                                            for p in batch],
                                            dtype=torch.long)
                rejected_ids = torch.tensor([action_id(p["rejected_action"])
                                              for p in batch],
                                              dtype=torch.long)

                logits, _ = net(states)
                logp = F.log_softmax(logits, dim=-1)
                chosen_logp = logp.gather(1, chosen_ids.unsqueeze(1)).squeeze(1)
                rejected_logp = logp.gather(1, rejected_ids.unsqueeze(1)).squeeze(1)

                # DPO loss
                diff = beta * (chosen_logp - rejected_logp)
                loss = -F.logsigmoid(diff).mean()

                optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0)
                optimizer.step()

                epoch_loss += float(loss.item())
                n_batches += 1

            losses.append(epoch_loss / max(n_batches, 1))

        policy.save()
        return {
            "pairs": len(pairs),
            "epochs": epochs,
            "losses": losses,
            "final_loss": losses[-1] if losses else None,
        }

    # ==================== reward model ====================
    def train_reward_model(self):
        """
        يبني reward model بسيط (linear regression) يتنبأ بالمكافأة من state+action.
        يُستخدم في shaping لمكافأة الأفعال قبل تنفيذها.
        """
        import numpy as np
        c = replay.db.cursor()
        rows = c.execute("""
            SELECT state_vec, action, reward FROM transitions
            WHERE reward != 0
        """).fetchall()
        if len(rows) < 200:
            return {"error": "need >=200 samples"}

        X = []
        y = []
        for state_json, action, reward in rows:
            s = np.array(json.loads(state_json), dtype=np.float32)
            tool = action.split(":", 1)[0]
            tid = policy.tool_to_id.get(tool, 0)
            a_vec = np.zeros(32, dtype=np.float32)
            a_vec[tid % 32] = 1.0
            X.append(np.concatenate([s, a_vec]))
            y.append(reward)
        X = np.array(X)
        y = np.array(y)

        # ridge regression
        lam = 1.0
        XtX = X.T @ X + lam * np.eye(X.shape[1])
        w = np.linalg.solve(XtX, X.T @ y)

        path = os.path.expanduser("~/.albaron/reward_model.npy")
        np.save(path, w)
        pred = X @ w
        mse = float(np.mean((pred - y) ** 2))
        return {"samples": len(y), "mse": mse, "path": path}


trainer = RLTrainer()
