# language: Python, file: core/ai/rl/meta/maml.py
# MAML — meta-learn a policy that adapts in few gradient steps
import numpy as np
import os
import copy
from typing import List, Dict, Callable
from collections import defaultdict

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


STATE_DIM = 128
ACTION_DIM = 64


if HAS_TORCH:
    class MAMLPolicy(nn.Module):
        def __init__(self, state_dim=STATE_DIM, action_dim=ACTION_DIM,
                      hidden=128):
            super().__init__()
            self.trunk = nn.Sequential(
                nn.Linear(state_dim, hidden),
                nn.ReLU(),
                nn.Linear(hidden, hidden),
                nn.ReLU(),
            )
            self.actor = nn.Linear(hidden, action_dim)
            self.critic = nn.Linear(hidden, 1)

        def forward(self, s):
            h = self.trunk(s)
            return self.actor(h), self.critic(h).squeeze(-1)


class TaskSampler:
    """
    يعرّف "task" في سياقنا كـengagement جديد.
    مهمة = بيئة بعدد مختلف من الhosts، أنواع أنظمة، أدوات متاحة.
    """
    def __init__(self):
        self.tasks: List[dict] = []

    def register_task(self, task: dict):
        """
        task = {
          "name": str,
          "target_profile": {"ad": bool, "cloud": bool, "ot": bool, ...},
          "success_criteria": dict,
        }
        """
        self.tasks.append(task)

    def sample_task(self) -> dict:
        if not self.tasks:
            return {"name": "default", "target_profile": {}}
        return self.tasks[np.random.randint(len(self.tasks))]

    def register_from_engagement(self, engagement_log: List[dict]):
        """يستخرج tasks من engagement سابق"""
        profile = {
            "ad": any("ad" in str(h.get("module", "")) for h in engagement_log),
            "cloud": any("cloud" in str(h.get("module", "")) for h in engagement_log),
            "ot": any("ot" in str(h.get("module", "")) for h in engagement_log),
        }
        self.register_task({
            "name": f"engagement-{len(self.tasks)}",
            "target_profile": profile,
            "steps": len(engagement_log),
        })


class MAML:
    """
    MAML for RL:
      - Meta-policy θ يتعلم كيف يتأقلم بسرعة
      - Inner loop: K steps of gradient descent على task-specific data
      - Outer loop: تحديث θ بحيث post-adaptation loss ينخفض
    """
    def __init__(self, inner_lr: float = 0.01, outer_lr: float = 1e-3,
                  inner_steps: int = 5,
                  model_path: str = "~/.albaron/maml.pt"):
        self.inner_lr = inner_lr
        self.outer_lr = outer_lr
        self.inner_steps = inner_steps
        self.model_path = os.path.expanduser(model_path)

        if HAS_TORCH:
            self.meta_model = MAMLPolicy()
            self.meta_optimizer = torch.optim.Adam(
                self.meta_model.parameters(), lr=outer_lr)
            if os.path.exists(self.model_path):
                try:
                    self.meta_model.load_state_dict(torch.load(self.model_path))
                except Exception:
                    pass
        else:
            self.meta_model = None

    def _task_loss(self, model, task_batch: List[dict]) -> "torch.Tensor":
        """loss على task محدد"""
        states = torch.tensor([b["state"] for b in task_batch],
                                dtype=torch.float32)
        rewards = torch.tensor([b["reward"] for b in task_batch],
                                dtype=torch.float32)
        actions = torch.tensor([b.get("action_id", 0) % ACTION_DIM
                                  for b in task_batch], dtype=torch.long)
        logits, values = model(states)
        log_probs = torch.log_softmax(logits, -1)
        selected = log_probs.gather(1, actions.unsqueeze(1)).squeeze(1)
        adv = (rewards - values).detach()
        policy_loss = -(selected * adv).mean()
        value_loss = F.mse_loss(values, rewards)
        return policy_loss + 0.5 * value_loss

    def meta_train_step(self, task_batches: List[List[dict]]) -> float:
        """
        task_batches = [support_batch_1, query_batch_1, support_batch_2, ...]
        كل task له support (inner) و query (outer)
        """
        if not HAS_TORCH or not self.meta_model:
            return 0.0

        self.meta_optimizer.zero_grad()
        meta_loss = 0.0

        for task_pair in task_batches:
            support, query = task_pair["support"], task_pair["query"]

            # clone θ → θ'
            fast_weights = {
                k: v.clone() for k, v in self.meta_model.state_dict().items()
            }
            # inner loop (K steps)
            for _ in range(self.inner_steps):
                # forward with fast_weights — نستخدم functional forward
                logits, values = self._forward_with_weights(fast_weights, support)
                loss = self._loss_from_logits(logits, values, support)
                grads = torch.autograd.grad(
                    loss, fast_weights.values(), create_graph=True)
                fast_weights = {
                    k: w - self.inner_lr * g
                    for (k, w), g in zip(fast_weights.items(), grads)
                }
            # query loss with adapted weights
            q_logits, q_values = self._forward_with_weights(fast_weights, query)
            q_loss = self._loss_from_logits(q_logits, q_values, query)
            meta_loss = meta_loss + q_loss

        meta_loss = meta_loss / max(len(task_batches), 1)
        meta_loss.backward()
        self.meta_optimizer.step()
        return float(meta_loss.item())

    def _forward_with_weights(self, weights: dict, batch: List[dict]):
        """forward يدوي باستخدام weights محددة (للـMAML)"""
        states = torch.tensor([b["state"] for b in batch],
                                dtype=torch.float32)
        x = states
        # trunk
        x = F.linear(x, weights["trunk.0.weight"], weights["trunk.0.bias"])
        x = F.relu(x)
        x = F.linear(x, weights["trunk.2.weight"], weights["trunk.2.bias"])
        x = F.relu(x)
        logits = F.linear(x, weights["actor.weight"], weights["actor.bias"])
        values = F.linear(x, weights["critic.weight"],
                            weights["critic.bias"]).squeeze(-1)
        return logits, values

    def _loss_from_logits(self, logits, values, batch):
        rewards = torch.tensor([b["reward"] for b in batch],
                                dtype=torch.float32)
        actions = torch.tensor([b.get("action_id", 0) % ACTION_DIM
                                  for b in batch], dtype=torch.long)
        log_probs = torch.log_softmax(logits, -1)
        selected = log_probs.gather(1, actions.unsqueeze(1)).squeeze(1)
        adv = (rewards - values).detach()
        return -(selected * adv).mean() + 0.5 * F.mse_loss(values, rewards)

    def adapt(self, task_support: List[dict]) -> dict:
        """
        ينتج policy مُتكيّفة على task جديد بعد K خطوات.
        يرجع fast_weights — جاهزة للاستخدام في inference.
        """
        if not HAS_TORCH or not self.meta_model:
            return {}
        fast_weights = {
            k: v.clone() for k, v in self.meta_model.state_dict().items()
        }
        for _ in range(self.inner_steps):
            logits, values = self._forward_with_weights(fast_weights, task_support)
            loss = self._loss_from_logits(logits, values, task_support)
            grads = torch.autograd.grad(loss, fast_weights.values(),
                                          create_graph=False)
            fast_weights = {
                k: (w - self.inner_lr * g).detach()
                for (k, w), g in zip(fast_weights.items(), grads)
            }
        return fast_weights

    def select_action(self, state_vec: np.ndarray,
                       available_actions: List[int],
                       task_weights: dict = None,
                       epsilon: float = 0.05) -> int:
        if not available_actions:
            return 0
        if not HAS_TORCH or not self.meta_model:
            return int(np.random.choice(available_actions))
        if np.random.rand() < epsilon:
            return int(np.random.choice(available_actions))

        with torch.no_grad():
            s = torch.from_numpy(state_vec).float().unsqueeze(0)
            if task_weights:
                logits, _ = self._forward_with_weights(
                    task_weights,
                    [{"state": state_vec, "reward": 0, "action_id": 0}])
            else:
                logits, _ = self.meta_model(s)
            probs = F.softmax(logits, dim=-1).squeeze(0).cpu().numpy()
        mask = np.full_like(probs, -1e18)
        for a in available_actions:
            mask[a % len(probs)] = probs[a % len(probs)]
        return int(np.argmax(mask))

    def save(self):
        if HAS_TORCH and self.meta_model:
            try:
                torch.save(self.meta_model.state_dict(), self.model_path)
            except Exception:
                pass


maml = MAML()
