# language: Python, file: core/ai/rl/meta/task_sampler.py
# Task sampler for meta-learning — generates engagement tasks
import numpy as np
from typing import List, Dict, Optional
from datetime import datetime


class TaskSampler:
    """
    يعرّف task في سياقنا كـengagement جديد بخصائص محددة.
    يستخدمه MAML/Reptile لبناء support/query batches.
    """
    def __init__(self):
        self.tasks: List[dict] = []

    def register_task(self, task: dict):
        task.setdefault("created", datetime.utcnow().isoformat())
        self.tasks.append(task)

    def sample_task(self) -> dict:
        if not self.tasks:
            return {"name": "default", "target_profile": {}}
        return self.tasks[np.random.randint(len(self.tasks))]

    def register_from_engagement(self, engagement_log: List[dict]):
        profile = {
            "ad": any("ad" in str(h.get("module", "")) for h in engagement_log),
            "cloud": any("cloud" in str(h.get("module", "")) for h in engagement_log),
            "ot": any("ot" in str(h.get("module", "")) for h in engagement_log),
            "mobile": any("mobile" in str(h.get("module", "")) for h in engagement_log),
        }
        self.register_task({
            "name": f"engagement-{len(self.tasks)}",
            "target_profile": profile,
            "steps": len(engagement_log),
        })

    def split_support_query(self, trajectory: List[dict],
                              support_frac: float = 0.3) -> dict:
        """يقسم trajectory إلى support + query للـMAML"""
        n = len(trajectory)
        split = max(1, int(n * support_frac))
        return {
            "support": trajectory[:split],
            "query": trajectory[split:] if split < n else trajectory[-1:],
        }

    def sample_batch(self, task: dict, batch_size: int = 32) -> List[dict]:
        """يولّد batch وهمي لtask معين — للاختبار السريع"""
        state_dim, action_dim = 128, 64
        batch = []
        for _ in range(batch_size):
            batch.append({
                "state": np.random.randn(state_dim).astype(np.float32).tolist(),
                "next_state": np.random.randn(state_dim).astype(np.float32).tolist(),
                "reward": float(np.random.randn() * 10),
                "action_id": np.random.randint(action_dim),
                "done": bool(np.random.rand() < 0.1),
            })
        return batch


task_sampler = TaskSampler()
