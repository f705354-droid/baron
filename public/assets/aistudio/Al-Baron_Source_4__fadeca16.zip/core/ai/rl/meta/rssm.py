# language: Python, file: core/ai/rl/world_model/rssm.py
# RSSM — Recurrent State Space Model (Dreamer v2/v3 foundation)
# يمثل حالة العالم في latent space — يسمح بالplanning داخل الحلم
import numpy as np
import os
from typing import Tuple, Dict, List

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from torch.distributions import Normal, Categorical, kl_divergence
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


OBS_DIM = 128              # ملاحظة = manager state vector
ACTION_DIM = 64
STOCH_DIM = 32             # z (stochastic)
DETER_DIM = 256            # h (deterministic)
HIDDEN = 256


if HAS_TORCH:
    class RSSM(nn.Module):
        """
        Recurrent State Space Model:
          h_t = f(h_{t-1}, z_{t-1}, a_{t-1})     — deterministic
          z_t ~ q(z_t | h_t, o_t)                 — posterior
          ẑ_t ~ p(z_t | h_t)                      — prior
          ô_t = decoder(h_t, z_t)                 — reconstruct
        Loss = reconstruction + KL(posterior || prior)
        """
        def __init__(self, obs_dim=OBS_DIM, action_dim=ACTION_DIM,
                      stoch_dim=STOCH_DIM, deter_dim=DETER_DIM,
                      hidden=HIDDEN):
            super().__init__()
            self.obs_dim = obs_dim
            self.action_dim = action_dim
            self.stoch_dim = stoch_dim
            self.deter_dim = deter_dim
            self.hidden = hidden

            # ── recurrence ──
            self.rnn = nn.GRUCell(stoch_dim + action_dim, deter_dim)

            # ── prior: p(z | h) ──
            self.prior_net = nn.Sequential(
                nn.Linear(deter_dim, hidden),
                nn.ELU(),
                nn.Linear(hidden, 2 * stoch_dim),
            )
            # ── posterior: q(z | h, o) ──
            self.post_net = nn.Sequential(
                nn.Linear(deter_dim + obs_dim, hidden),
                nn.ELU(),
                nn.Linear(hidden, 2 * stoch_dim),
            )
            # ── observation decoder ──
            self.decoder = nn.Sequential(
                nn.Linear(deter_dim + stoch_dim, hidden),
                nn.ELU(),
                nn.Linear(hidden, obs_dim),
            )
            # ── reward predictor ──
            self.reward_head = nn.Sequential(
                nn.Linear(deter_dim + stoch_dim, hidden),
                nn.ELU(),
                nn.Linear(hidden, 1),
            )
            # ── continue predictor (done) ──
            self.continue_head = nn.Sequential(
                nn.Linear(deter_dim + stoch_dim, hidden),
                nn.ELU(),
                nn.Linear(hidden, 1),
            )

        def initial_state(self, batch_size: int = 1):
            h = torch.zeros(batch_size, self.deter_dim)
            z = torch.zeros(batch_size, self.stoch_dim)
            return h, z

        def observe_step(self, h, z, a, o):
            """
            خطوة واحدة مع observation — يعطي posterior q(z_t | h_t, o_t)
            """
            x = torch.cat([z, a], dim=-1)
            h_next = self.rnn(x, h)
            post_in = torch.cat([h_next, o], dim=-1)
            post_params = self.post_net(post_in)
            mu_q, log_sigma_q = post_params.chunk(2, dim=-1)
            sigma_q = F.softplus(log_sigma_q) + 0.1
            q = Normal(mu_q, sigma_q)
            z_next = q.rsample()
            return h_next, z_next, q

        def imagine_step(self, h, z, a):
            """
            خطوة في الحلم — بدون observation
            يستخدم prior p(z | h)
            """
            x = torch.cat([z, a], dim=-1)
            h_next = self.rnn(x, h)
            prior_params = self.prior_net(h_next)
            mu_p, log_sigma_p = prior_params.chunk(2, dim=-1)
            sigma_p = F.softplus(log_sigma_p) + 0.1
            p = Normal(mu_p, sigma_p)
            z_next = p.rsample()
            return h_next, z_next, p

        def prior(self, h):
            """يحسب prior p(z | h) من h فقط — للـKL"""
            params = self.prior_net(h)
            mu, log_sigma = params.chunk(2, dim=-1)
            sigma = F.softplus(log_sigma) + 0.1
            return Normal(mu, sigma)

        def decode(self, h, z):
            x = torch.cat([h, z], dim=-1)
            return self.decoder(x)

        def predict_reward(self, h, z):
            x = torch.cat([h, z], dim=-1)
            return self.reward_head(x).squeeze(-1)

        def predict_continue(self, h, z):
            x = torch.cat([h, z], dim=-1)
            return torch.sigmoid(self.continue_head(x)).squeeze(-1)


class WorldModelTrainer:
    """
    يدرب RSSM على engagement transitions.
    Reconstruction + KL + Reward + Continue losses.
    """
    def __init__(self, model_path: str = "~/.albaron/rssm.pt",
                  seq_len: int = 20, kl_beta: float = 1.0):
        self.model_path = os.path.expanduser(model_path)
        self.seq_len = seq_len
        self.kl_beta = kl_beta
        if HAS_TORCH:
            self.model = RSSM()
            self.optimizer = torch.optim.Adam(self.model.parameters(), lr=1e-4)
            if os.path.exists(self.model_path):
                try:
                    self.model.load_state_dict(torch.load(self.model_path))
                except Exception:
                    pass
        else:
            self.model = None

    def update(self, sequence: List[dict]) -> dict:
        """
        sequence = [{"state":..., "action_id":..., "reward":..., "done":...}]
        """
        if not HAS_TORCH or not self.model:
            return {}
        if len(sequence) < 5:
            return {}

        obs = torch.tensor([s["state"] for s in sequence], dtype=torch.float32)
        actions = torch.tensor(
            [s.get("action_id", 0) % ACTION_DIM for s in sequence],
            dtype=torch.long)
        rewards = torch.tensor([s.get("reward", 0) for s in sequence],
                                dtype=torch.float32)
        dones = torch.tensor([float(s.get("done", False)) for s in sequence],
                              dtype=torch.float32)

        # one-hot actions
        a_onehot = F.one_hot(actions, ACTION_DIM).float()

        h, z = self.model.initial_state(batch_size=1)
        recon_loss = 0.0
        kl_loss = 0.0
        reward_loss = 0.0
        continue_loss = 0.0
        T = len(sequence)

        h_seq = []
        z_seq = []
        for t in range(T):
            h, z, q = self.model.observe_step(h, z, a_onehot[t:t+1],
                                                 obs[t:t+1])
            h_seq.append(h)
            z_seq.append(z)
            # recon
            o_hat = self.model.decode(h, z)
            recon_loss = recon_loss + F.mse_loss(o_hat, obs[t:t+1])
            # KL(q || p)
            prior = self.model.prior(h)
            kl = kl_divergence(q, prior).sum(-1).mean()
            kl_loss = kl_loss + kl
            # reward
            r_hat = self.model.predict_reward(h, z)
            reward_loss = reward_loss + F.mse_loss(r_hat, rewards[t:t+1])
            # continue
            c_hat = self.model.predict_continue(h, z)
            c_target = 1.0 - dones[t:t+1]
            continue_loss = continue_loss + F.binary_cross_entropy(
                c_hat, c_target)

        # KL balancing (Dreamer v3) — free bits على الـprior
        recon_loss = recon_loss / T
        kl_loss = kl_loss / T
        reward_loss = reward_loss / T
        continue_loss = continue_loss / T
        kl_loss = torch.clamp(kl_loss, min=1.0)   # free bits

        loss = (recon_loss + self.kl_beta * kl_loss +
                reward_loss + continue_loss)

        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), 100.0)
        self.optimizer.step()

        return {
            "loss": float(loss.item()),
            "recon": float(recon_loss.item()),
            "kl": float(kl_loss.item()),
            "reward": float(reward_loss.item()),
            "continue": float(continue_loss.item()),
        }

    def save(self):
        if HAS_TORCH and self.model:
            try:
                torch.save(self.model.state_dict(), self.model_path)
            except Exception:
                pass


world_model_trainer = WorldModelTrainer()
