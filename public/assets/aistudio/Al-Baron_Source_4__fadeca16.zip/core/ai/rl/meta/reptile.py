# language: Python, file: core/ai/rl/meta/reptile.py
# Reptile — first-order meta-learning (Nichol 2018), أسرع من MAML
import numpy as np
import os
from typing import List

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


class Reptile:
    """
    Reptile:
      - K steps of SGD on task → θ'
      - Meta update: θ ← θ + ε (θ' - θ)
    لا يحتاج second-order gradients → أسرع بكثير من MAML.
    """
    def __init__(self, inner_steps: int = 10, inner_lr: float = 0.02,
                  meta_lr: float = 1.0,
                  model_path: str = "~/.albaron/reptile.pt"):
        self.inner_steps = inner_steps
        self.inner_lr = inner_lr
        self.meta_lr = meta_lr
        self.model_path = os.path.expanduser(model_path)

        if HAS_TORCH:
            from core.ai.rl.meta.maml import MAMLPolicy, ACTION_DIM
            self.model = MAMLPolicy()
            if os.path.exists(self.model_path):
                try:
                    self.model.load_state_dict(torch.load(self.model_path))
                except Exception:
                    pass
        else:
            self.model = None

    def meta_step(self, task_batch: List[dict]) -> float:
        if not HAS_TORCH or not self.model:
            return 0.0

        # احفظ θ
        old_state = {k: v.clone() for k, v in self.model.state_dict().items()}

        # inner training على task
        inner_opt = torch.optim.SGD(self.model.parameters(),
                                      lr=self.inner_lr)
        last_loss = 0.0
        for _ in range(self.inner_steps):
            inner_opt.zero_grad()
            loss = self._compute_loss(task_batch)
            loss.backward()
            inner_opt.step()
            last_loss = float(loss.item())

        # meta update: θ ← θ + ε * (θ' - θ)
        new_state = self.model.state_dict()
        with torch.no_grad():
            for k in old_state:
                interpolated = old_state[k] + self.meta_lr * (new_state[k] - old_state[k])
                new_state[k].copy_(interpolated)

        return last_loss

    def _compute_loss(self, batch: List[dict]):
        states = torch.tensor([b["state"] for b in batch],
                                dtype=torch.float32)
        rewards = torch.tensor([b["reward"] for b in batch],
                                dtype=torch.float32)
        actions = torch.tensor([b.get("action_id", 0) % 64
                                  for b in batch], dtype=torch.long)
        logits, values = self.model(states)
        log_probs = torch.log_softmax(logits, -1)
        selected = log_probs.gather(1, actions.unsqueeze(1)).squeeze(1)
        adv = (rewards - values).detach()
        return -(selected * adv).mean() + 0.5 * F.mse_loss(values, rewards)

    def save(self):
        if HAS_TORCH and self.model:
            try:
                torch.save(self.model.state_dict(), self.model_path)
            except Exception:
                pass


reptile = Reptile()
