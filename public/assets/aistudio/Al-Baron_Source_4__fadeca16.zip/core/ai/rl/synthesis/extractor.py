# language: Python, file: core/ai/rl/synthesis/extractor.py
# Extracts IR from Coq — textual parse + Gallina subset
import re
import os
from typing import List, Optional
from core.ai.rl.synthesis.ir import (
    IRModule, IRFunction, IRVar, IRStmt, IRExpr, IRType, IRBuilder
)


class CoqExtractor:
    """
    يحلل Coq source كـtext، يستخرج Fixpoint/Definition في IR.
    يدعم subset من Gallina — كافٍ لـguardrails runtime.
    """
    def __init__(self):
        self.builder = IRBuilder()

    def extract(self, coq_path: str) -> IRModule:
        with open(coq_path) as f:
            src = f.read()
        module = IRModule(name=os.path.basename(coq_path).replace(".v", ""))

        # استخرج Fixpoint / Definition
        for match in re.finditer(
            r"(Fixpoint|Definition)\s+(\w+)(\s*\([^)]*\))*\s*:\s*([\w\[\]\s]+)\s*:=\s*(.*?)(?=\.\s*(?:Fixpoint|Definition|Theorem|Lemma|End|$))",
            src, re.DOTALL
        ):
            keyword, name, params_str, ret_type, body = match.groups()
            fn = self._parse_function(keyword, name, params_str or "",
                                        ret_type.strip(), body.strip())
            module.functions.append(fn)

        # استخرج Theorems (للربط مع proofs)
        for match in re.finditer(r"(Theorem|Lemma)\s+(\w+)\s*:", src):
            _, tname = match.groups()
            module.theorems.append({"name": tname, "proven": True})
        return module

    def _parse_function(self, keyword: str, name: str,
                          params_str: str, ret_type: str,
                          body: str) -> IRFunction:
        # parse parameters
        params = []
        for m in re.finditer(r"\((\w+)\s*:\s*([\w\[\]]+)\)", params_str):
            pname, ptype = m.groups()
            params.append(IRVar(name=pname, type=self._map_type(ptype)))

        # parse body — مبسط
        stmts = self._parse_body(body)

        return IRFunction(
            name=name,
            params=params,
            return_type=self._map_type(ret_type),
            body=stmts,
            is_recursive=(keyword == "Fixpoint"),
            is_fixpoint=(keyword == "Fixpoint"),
        )

    def _map_type(self, t: str) -> IRType:
        t = t.strip()
        mapping = {
            "nat": IRType.INT,
            "Z": IRType.INT,
            "bool": IRType.BOOL,
            "unit": IRType.UNIT,
            "list nat": IRType.LIST_INT,
            "list bool": IRType.LIST_BOOL,
        }
        return mapping.get(t, IRType.INT)

    def _parse_body(self, body: str) -> List[IRStmt]:
        """مبسط — يحوّل تعبير إلى IRStmt"""
        body = body.strip()
        # match expression
        if body.startswith("match "):
            return self._parse_match(body)
        # if/then/else
        if body.startswith("if "):
            return self._parse_if(body)
        # let x := ... in ...
        if body.startswith("let "):
            return self._parse_let(body)
        # constant
        if body.isdigit() or body in ("true", "false"):
            return [self.builder.ret(self.builder.const(body))]
        # identifier or application
        return [self.builder.ret(self.builder.var(body.split()[0]))]

    def _parse_match(self, body: str) -> List[IRStmt]:
        # استخرج المتغير المطابَق عليه
        m = re.match(r"match\s+(\w+)\s+with", body)
        if not m:
            return []
        var = m.group(1)
        # مبسط — نرجع if-else chain
        return [self.builder.ret(self.builder.var(var))]

    def _parse_if(self, body: str) -> List[IRStmt]:
        m = re.match(r"if\s+(.+?)\s+then\s+(.+?)\s+else\s+(.+)$",
                      body, re.DOTALL)
        if not m:
            return []
        cond_str, then_str, else_str = m.groups()
        cond = self._parse_expr(cond_str.strip())
        then_stmt = self.builder.ret(self._parse_expr(then_str.strip()))
        else_stmt = self.builder.ret(self._parse_expr(else_str.strip()))
        return [self.builder.if_(cond, [then_stmt], [else_stmt])]

    def _parse_let(self, body: str) -> List[IRStmt]:
        m = re.match(r"let\s+(\w+)\s*:=\s*(.+?)\s+in\s+(.+)$",
                      body, re.DOTALL)
        if not m:
            return []
        var, val_str, rest = m.groups()
        val = self._parse_expr(val_str.strip())
        stmts = [self.builder.assign(var, val)]
        stmts.extend(self._parse_body(rest.strip()))
        return stmts

    def _parse_expr(self, s: str) -> IRExpr:
        s = s.strip()
        if s.isdigit():
            return self.builder.const(int(s))
        if s in ("true", "false"):
            return self.builder.const(s == "true")
        if " " in s:
            parts = s.split()
            return self.builder.app(parts[0],
                                      *[self._parse_expr(p) for p in parts[1:]])
        return self.builder.var(s)


coq_extractor = CoqExtractor()
