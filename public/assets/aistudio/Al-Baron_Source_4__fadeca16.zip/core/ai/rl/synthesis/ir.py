# language: Python, file: core/ai/rl/synthesis/ir.py
# IR — intermediate representation بين Coq و Python
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Union
from enum import Enum


class IRType(Enum):
    INT = "int"
    BOOL = "bool"
    UNIT = "unit"
    LIST_INT = "list[int]"
    LIST_BOOL = "list[bool]"
    OPTION_INT = "option[int]"
    RECORD = "record"


@dataclass
class IRVar:
    name: str
    type: IRType


@dataclass
class IRExpr:
    """IR expression — subset of Coq Gallina"""
    kind: str                       # var, const, app, if, match, ...
    args: List["IRExpr"] = field(default_factory=list)
    value: Optional[Union[int, bool]] = None
    name: Optional[str] = None


@dataclass
class IRStmt:
    """IR statement"""
    kind: str                       # assign, return, if_stmt, seq
    target: Optional[str] = None
    expr: Optional[IRExpr] = None
    body: List["IRStmt"] = field(default_factory=list)
    else_body: List["IRStmt"] = field(default_factory=list)
    condition: Optional[IRExpr] = None


@dataclass
class IRFunction:
    name: str
    params: List[IRVar]
    return_type: IRType
    body: List[IRStmt]
    is_recursive: bool = False
    is_fixpoint: bool = False       # من Coq Fixpoint
    theorems: List[str] = field(default_factory=list)  # أسماء النظريات


@dataclass
class IRModule:
    name: str
    functions: List[IRFunction] = field(default_factory=list)
    types: List[IRType] = field(default_factory=list)
    theorems: List[Dict] = field(default_factory=list)


class IRBuilder:
    """helpers لبناء IR"""
    @staticmethod
    def var(name: str) -> IRExpr:
        return IRExpr(kind="var", name=name)

    @staticmethod
    def const(value) -> IRExpr:
        return IRExpr(kind="const", value=value)

    @staticmethod
    def app(fn_name: str, *args: IRExpr) -> IRExpr:
        return IRExpr(kind="app", name=fn_name, args=list(args))

    @staticmethod
    def if_(cond: IRExpr, then_body: List[IRStmt],
             else_body: List[IRStmt]) -> IRStmt:
        return IRStmt(kind="if_stmt", condition=cond,
                       body=then_body, else_body=else_body)

    @staticmethod
    def assign(target: str, expr: IRExpr) -> IRStmt:
        return IRStmt(kind="assign", target=target, expr=expr)

    @staticmethod
    def ret(expr: IRExpr) -> IRStmt:
        return IRStmt(kind="return", expr=expr)


ir_builder = IRBuilder()
