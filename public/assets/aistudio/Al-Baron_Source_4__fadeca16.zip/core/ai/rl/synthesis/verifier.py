# language: Python, file: core/ai/rl/synthesis/verifier.py
# Proof-carrying code — كل دالة مُستخرجة تحمل بصمة proof
import os
import hashlib
import json
import subprocess
from typing import Dict, Optional
from core.ai.rl.synthesis.extractor import coq_extractor
from core.ai.rl.synthesis.python_gen import python_generator


class ProofCarryingSynthesizer:
    """
    Pipeline كامل:
      1. استخرج IR من Coq
      2. تحقق من النظريات (coqc compile)
      3. توليد Python
      4. أضف runtime assertions
      5. احسب hash للـproof
      6. ربط الـhash بالكود المُستخرج
    """
    def __init__(self, coq_dir: str = "core/ai/formal",
                  out_dir: str = "core/ai/rl/synthesis/generated"):
        self.coq_dir = coq_dir
        self.out_dir = out_dir
        os.makedirs(out_dir, exist_ok=True)

    def build(self, coq_file: str = "Guardrails.v") -> Dict:
        coq_path = os.path.join(self.coq_dir, coq_file)
        if not os.path.exists(coq_path):
            return {"error": f"{coq_path} not found"}

        # ── step 1: verify Coq compiles ──
        compile_result = self._compile_coq(coq_path)
        if not compile_result.get("ok"):
            return {"error": "coq compilation failed",
                     "details": compile_result}

        # ── step 2: extract IR ──
        module = coq_extractor.extract(coq_path)

        # ── step 3: generate Python ──
        py_code = python_generator.generate(module)

        # ── step 4: append runtime assertions ──
        py_code += self._runtime_assertions(module)

        # ── step 5: hash ──
        proof_hash = hashlib.sha256(
            (py_code + compile_result.get("hash", "")).encode()).hexdigest()[:16]

        # ── step 6: write with metadata ──
        out_py = os.path.join(self.out_dir, f"{module.name}_synth.py")
        out_meta = os.path.join(self.out_dir, f"{module.name}_proof.json")

        with open(out_py, "w") as f:
            f.write(py_code)
        with open(out_meta, "w") as f:
            json.dump({
                "coq_file": coq_file,
                "coq_hash": compile_result.get("hash", ""),
                "python_hash": proof_hash,
                "functions": [fn.name for fn in module.functions],
                "theorems": [t["name"] for t in module.theorems],
                "verified": True,
            }, f, indent=2)

        return {
            "python_path": out_py,
            "meta_path": out_meta,
            "proof_hash": proof_hash,
            "functions": len(module.functions),
            "theorems": len(module.theorems),
        }

    def _compile_coq(self, coq_path: str) -> Dict:
        try:
            r = subprocess.run(
                ["coqc", coq_path],
                capture_output=True, text=True, timeout=120)
            coq_hash = hashlib.sha256(
                open(coq_path, "rb").read()).hexdigest()[:16]
            return {
                "ok": r.returncode == 0,
                "hash": coq_hash,
                "stderr": r.stderr[-500:] if r.returncode != 0 else "",
            }
        except FileNotFoundError:
            return {"ok": False, "error": "coqc not installed"}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _runtime_assertions(self, module) -> str:
        """يضيف assertions مشتقة من الtheorems"""
        lines = ["", "", "# ─── Runtime assertions from Coq theorems ───", ""]
        for th in module.theorems:
            lines.append(f"def _assert_{th['name']}(state: dict) -> bool:")
            lines.append(f'    """Runtime check mirroring theorem {th["name"]}"""')
            lines.append(f"    # TODO: extract precondition from Coq")
            lines.append(f"    return True")
            lines.append("")
        return "\n".join(lines)

    def verify_runtime(self, meta_path: str, code_path: str) -> Dict:
        """
        يتحقق أن الكود الحالي لم يُعدّل منذ التوليد.
        """
        if not os.path.exists(meta_path) or not os.path.exists(code_path):
            return {"ok": False, "reason": "files missing"}
        with open(meta_path) as f:
            meta = json.load(f)
        with open(code_path, "rb") as f:
            current_hash = hashlib.sha256(f.read()).hexdigest()[:16]
        return {
            "ok": meta.get("python_hash") == current_hash,
            "expected": meta.get("python_hash"),
            "current": current_hash,
        }


synthesizer = ProofCarryingSynthesizer()
