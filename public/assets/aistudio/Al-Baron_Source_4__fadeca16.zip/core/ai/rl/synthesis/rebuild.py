# language: Python, file: core/ai/rl/synthesis/rebuild.py
# Rebuild synthesized Python from Coq
import os
from core.ai.rl.synthesis.verifier import synthesizer


def rebuild_all(coq_dir: str = "core/ai/formal") -> dict:
    """يبني كل ملفات Coq → Python"""
    results = {}
    for f in os.listdir(coq_dir):
        if f.endswith(".v") and not f.startswith("Extraction"):
            result = synthesizer.build(f)
            results[f] = result
    return results


if __name__ == "__main__":
    import json
    print(json.dumps(rebuild_all(), indent=2))
