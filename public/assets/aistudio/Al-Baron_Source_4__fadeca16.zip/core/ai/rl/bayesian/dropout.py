# language: Python, file: core/ai/rl/bayesian/dropout.py
# Monte Carlo Dropout (Gal & Ghahramani 2016)
import numpy as np
import os
from typing import Tuple

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


if HAS_TORCH:
    class MCDropoutNet(nn.Module):
        def __init__(self, state_dim: int, action_dim: int,
                      hidden: int = 128, dropout: float = 0.1):
            super().__init__()
            self.fc1 = nn.Linear(state_dim, hidden)
            self.drop1 = nn.Dropout(p=dropout)
            self.fc2 = nn.Linear(hidden, hidden)
            self.drop2 = nn.Dropout(p=dropout)
            self.actor = nn.Linear(hidden, action_dim)
            self.critic = nn.Linear(hidden, 1)

        def forward(self, s):
            h = F.relu(self.fc1(s))
            h = self.drop1(h)
            h = F.relu(self.fc2(h))
            h = self.drop2(h)
            return self.actor(h), self.critic(h).squeeze(-1)


class MCDropout:
    """
    MC-Dropout: uncertainty عبر تفعيل dropout في inference.
    N forward passes → mean + variance.
    """
    def __init__(self, state_dim: int = 128, action_dim: int = 64,
                  n_samples: int = 20,
                  model_path: str = "~/.albaron/mcdropout.pt"):
        self.n_samples = n_samples
        self.model_path = os.path.expanduser(model_path)
        self.net = None
        self.optimizer = None
        if HAS_TORCH:
            self.net = MCDropoutNet(state_dim, action_dim)
            self.optimizer = torch.optim.Adam(self.net.parameters(), lr=3e-4)
            if os.path.exists(self.model_path):
                try:
                    self.net.load_state_dict(torch.load(self.model_path))
                except Exception:
                    pass

    def predict(self, state_vec: np.ndarray) -> Tuple[np.ndarray, float]:
        """يرجع (mean_probs, uncertainty) عبر MC sampling"""
        if not HAS_TORCH or not self.net:
            return np.zeros(64), 0.0

        # تفعيل dropout حتى في inference
        self.net.train()
        s = torch.from_numpy(state_vec).float().unsqueeze(0)
        probs_list = []
        with torch.no_grad():
            for _ in range(self.n_samples):
                logits, _ = self.net(s)
                probs_list.append(
                    torch.softmax(logits, -1).squeeze(0).numpy())
        probs_arr = np.array(probs_list)
        mean = probs_arr.mean(axis=0)
        # predictive entropy
        eps = 1e-9
        H = -(mean * np.log(mean + eps)).sum()
        # mean of entropies
        mean_H = -(probs_arr * np.log(probs_arr + eps)).sum(axis=1).mean()
        mutual_info = H - mean_H     # epistemic
        self.net.eval()
        return mean, float(max(0.0, mutual_info))

    def update(self, batch, gamma: float = 0.99):
        if not HAS_TORCH or not self.net:
            return
        self.net.train()
        states = torch.tensor([b["state"] for b in batch],
                                dtype=torch.float32)
        rewards = torch.tensor([b["reward"] for b in batch],
                                dtype=torch.float32)
        next_states = torch.tensor([b["next_state"] for b in batch],
                                     dtype=torch.float32)
        dones = torch.tensor([b["done"] for b in batch],
                               dtype=torch.float32)
        action_ids = torch.tensor(
            [b.get("action_id", 0) % 64 for b in batch], dtype=torch.long)

        logits, values = self.net(states)
        with torch.no_grad():
            _, next_values = self.net(next_states)
            targets = rewards + gamma * (1 - dones) * next_values
        log_probs = torch.log_softmax(logits, -1)
        selected = log_probs.gather(1, action_ids.unsqueeze(1)).squeeze(1)
        adv = (targets - values).detach()
        loss = -(selected * adv).mean() + 0.5 * F.mse_loss(values, targets)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        self.net.eval()

    def save(self):
        if HAS_TORCH and self.net:
            try:
                torch.save(self.net.state_dict(), self.model_path)
            except Exception:
                pass


mc_dropout = MCDropout()
