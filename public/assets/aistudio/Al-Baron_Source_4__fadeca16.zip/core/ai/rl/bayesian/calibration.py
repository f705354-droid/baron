# language: Python, file: core/ai/rl/bayesian/calibration.py
# Calibration — temperature scaling, ECE, reliability diagram
import numpy as np
import json
import os
from typing import List, Tuple


class Calibrator:
    """
    Temperature scaling:
      - يقيس ECE (Expected Calibration Error)
      - يحسّن T لتقليل ECE
      - يستخدم calibrated probs في decision
    """
    def __init__(self, model_path: str = "~/.albaron/calibration.json"):
        self.model_path = os.path.expanduser(model_path)
        self.temperature = 1.0
        self.ece_history: List[float] = []
        if os.path.exists(self.model_path):
            try:
                with open(self.model_path) as f:
                    data = json.load(f)
                    self.temperature = data.get("temperature", 1.0)
                    self.ece_history = data.get("ece_history", [])
            except Exception:
                pass

    def ece(self, probs: np.ndarray, labels: np.ndarray,
             n_bins: int = 10) -> float:
        """Expected Calibration Error"""
        bins = np.linspace(0, 1, n_bins + 1)
        ece = 0.0
        n = len(probs)
        for i in range(n_bins):
            mask = (probs >= bins[i]) & (probs < bins[i+1])
            if mask.sum() == 0:
                continue
            avg_conf = probs[mask].mean()
            avg_acc = labels[mask].mean()
            ece += (mask.sum() / n) * abs(avg_conf - avg_acc)
        return float(ece)

    def fit_temperature(self, logits: List[np.ndarray],
                          labels: List[int],
                          lr: float = 0.01, steps: int = 100) -> float:
        """Temperature scaling — يحسّن T"""
        if not logits:
            return self.temperature
        try:
            import torch
            import torch.nn.functional as F
        except ImportError:
            return self.temperature

        T = torch.nn.Parameter(torch.tensor([self.temperature]))
        opt = torch.optim.LBFGS([T], lr=lr, max_iter=steps)
        X = torch.tensor(np.array(logits), dtype=torch.float32)
        y = torch.tensor(labels, dtype=torch.long)

        def closure():
            opt.zero_grad()
            loss = F.cross_entropy(X / T, y)
            loss.backward()
            return loss
        opt.step(closure)
        self.temperature = float(T.item())
        self.save()
        return self.temperature

    def calibrate_probs(self, logits: np.ndarray) -> np.ndarray:
        """يطبّق temperature على logits"""
        scaled = logits / max(self.temperature, 1e-3)
        ex = np.exp(scaled - scaled.max())
        return ex / ex.sum()

    def save(self):
        with open(self.model_path, "w") as f:
            json.dump({
                "temperature": self.temperature,
                "ece_history": self.ece_history[-100:],
            }, f, indent=2)


calibrator = Calibrator()
