# language: Python, file: core/ai/rl/bayesian/ensemble.py
# Deep Ensemble — uncertainty via N independently trained nets
import numpy as np
import os
import json
from typing import List, Tuple, Optional

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


if HAS_TORCH:
    class EnsembleHead(nn.Module):
        def __init__(self, state_dim: int, action_dim: int,
                      hidden: int = 128):
            super().__init__()
            self.trunk = nn.Sequential(
                nn.Linear(state_dim, hidden),
                nn.ReLU(),
                nn.Linear(hidden, hidden),
                nn.ReLU(),
            )
            self.actor = nn.Linear(hidden, action_dim)
            self.critic = nn.Linear(hidden, 1)

        def forward(self, s):
            h = self.trunk(s)
            return self.actor(h), self.critic(h).squeeze(-1)


class DeepEnsemble:
    """
    Deep Ensemble (Lakshminarayanan 2017):
      - N networks بنفس البنية، تهيئة مختلفة
      - كل واحد يتدرب على subset/bootstrap من البيانات
      - uncertainty = variance بين توقعات الـensemble
      - epistemic uncertainty عالية في حالات غير مرئية
    """
    def __init__(self, state_dim: int = 128, action_dim: int = 64,
                  n_members: int = 5, hidden: int = 128,
                  model_dir: str = "~/.albaron/ensemble"):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.n_members = n_members
        self.model_dir = os.path.expanduser(model_dir)
        os.makedirs(self.model_dir, exist_ok=True)

        self.nets: List = []
        self.optimizers: List = []
        if HAS_TORCH:
            for i in range(n_members):
                net = EnsembleHead(state_dim, action_dim, hidden)
                opt = torch.optim.Adam(net.parameters(), lr=3e-4)
                self.nets.append(net)
                self.optimizers.append(opt)
                p = os.path.join(self.model_dir, f"member_{i}.pt")
                if os.path.exists(p):
                    try:
                        net.load_state_dict(torch.load(p))
                    except Exception:
                        pass

    def predict(self, state_vec: np.ndarray) -> Tuple[np.ndarray, float, float]:
        """
        يرجع (mean_action_probs, epistemic_unc, aleatoric_unc)
        epistemic = disagreement بين الأعضاء (variance of means)
        aleatoric = متوسط الانتروبيا لكل عضو (متوسط عدم يقين كل عضو)
        """
        if not HAS_TORCH or not self.nets:
            return np.zeros(self.action_dim), 0.0, 0.0

        s = torch.from_numpy(state_vec).float().unsqueeze(0)
        probs_list = []
        values_list = []
        with torch.no_grad():
            for net in self.nets:
                logits, v = net(s)
                probs = torch.softmax(logits, -1).squeeze(0).numpy()
                probs_list.append(probs)
                values_list.append(float(v))
        probs_arr = np.array(probs_list)     # (N, A)
        # mean
        mean_probs = probs_arr.mean(axis=0)
        # epistemic = variance of per-member means → trace
        epistemic = float(probs_arr.var(axis=0).sum())
        # aleatoric = mean entropy
        eps = 1e-9
        entropies = -(probs_arr * np.log(probs_arr + eps)).sum(axis=1)
        aleatoric = float(entropies.mean())
        # value uncertainty
        value_unc = float(np.var(values_list)) if len(values_list) > 1 else 0.0
        return mean_probs, epistemic, aleatoric + value_unc

    def update(self, batch: List[dict], gamma: float = 0.99):
        """كل member يتدرب على bootstrap sample"""
        if not HAS_TORCH or not self.nets:
            return
        import random
        for i, (net, opt) in enumerate(zip(self.nets, self.optimizers)):
            # bootstrap sample
            sample = [random.choice(batch) for _ in range(len(batch))]
            states = torch.tensor([b["state"] for b in sample],
                                    dtype=torch.float32)
            rewards = torch.tensor([b["reward"] for b in sample],
                                    dtype=torch.float32)
            next_states = torch.tensor([b["next_state"] for b in sample],
                                         dtype=torch.float32)
            dones = torch.tensor([b["done"] for b in sample],
                                   dtype=torch.float32)
            action_ids = torch.tensor(
                [b.get("action_id", 0) % self.action_dim for b in sample],
                dtype=torch.long)

            logits, values = net(states)
            with torch.no_grad():
                _, next_values = net(next_states)
                targets = rewards + gamma * (1 - dones) * next_values

            # policy gradient with importance
            log_probs = torch.log_softmax(logits, -1)
            selected = log_probs.gather(1, action_ids.unsqueeze(1)).squeeze(1)
            adv = (targets - values).detach()
            policy_loss = -(selected * adv).mean()
            value_loss = F.mse_loss(values, targets)
            loss = policy_loss + 0.5 * value_loss

            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0)
            opt.step()

    def save(self):
        if not HAS_TORCH:
            return
        for i, net in enumerate(self.nets):
            try:
                torch.save(net.state_dict(),
                            os.path.join(self.model_dir, f"member_{i}.pt"))
            except Exception:
                pass

    def describe(self) -> dict:
        return {
            "n_members": self.n_members,
            "state_dim": self.state_dim,
            "action_dim": self.action_dim,
        }


ensemble = DeepEnsemble()
