# language: Python, file: core/ai/rl/bayesian/thompson.py
# Neural Thompson Sampling — sample model weights → act
import numpy as np
from typing import Tuple, List, Optional
from core.ai.rl.bayesian.ensemble import ensemble
from core.ai.rl.bayesian.dropout import mc_dropout
from core.ai.rl.bayesian.bbb import bbb


class NeuralThompsonSampling:
    """
    بدل argmax، نسحب من posterior:
      - ensemble: sample one member
      - dropout: sample one forward pass
      - bbb: sample one weight draw
    النتيجة: exploration طبيعي مع عدم يقين عالي.
    """
    def __init__(self, backend: str = "ensemble"):
        self.backend = backend

    def sample_action(self, state_vec: np.ndarray,
                       available_actions: List[int]) -> int:
        if not available_actions:
            return 0

        if self.backend == "ensemble" and ensemble.nets:
            # اختر member عشوائي
            idx = np.random.randint(len(ensemble.nets))
            import torch
            net = ensemble.nets[idx]
            with torch.no_grad():
                logits, _ = net(torch.from_numpy(state_vec).float().unsqueeze(0))
                probs = torch.softmax(logits, -1).squeeze(0).numpy()
            # mask
            mask = np.zeros_like(probs)
            for a in available_actions:
                mask[a % len(probs)] = probs[a % len(probs)]
            return int(np.argmax(mask))

        if self.backend == "dropout":
            mean, _ = mc_dropout.predict(state_vec)
            mask = np.zeros_like(mean)
            for a in available_actions:
                mask[a % len(mean)] = mean[a % len(mean)]
            return int(np.argmax(mask))

        if self.backend == "bbb":
            mean, _ = bbb.predict(state_vec)
            mask = np.zeros_like(mean)
            for a in available_actions:
                mask[a % len(mean)] = mean[a % len(mean)]
            return int(np.argmax(mask))

        # fallback random
        return int(np.random.choice(available_actions))


class UncertaintyAwareRouter:
    """
    يستخدم uncertainty لتقرير:
      - إذا epistemic عالية → exploration
      - إذا aleatoric عالية → تفادي القرار أو استشارة LLM
      - إذا منخفضة → exploitation مباشر
    """
    def __init__(self, high_epistemic_threshold: float = 0.5,
                  high_aleatoric_threshold: float = 2.0):
        self.ep_th = high_epistemic_threshold
        self.al_th = high_aleatoric_threshold
        self.ts = NeuralThompsonSampling("ensemble")

    def decide(self, state_vec: np.ndarray,
                available_actions: List[int]) -> dict:
        mean, ep, al = ensemble.predict(state_vec)

        if ep > self.ep_th:
            # حالة جديدة → explore
            return {
                "mode": "explore",
                "action": self.ts.sample_action(state_vec, available_actions),
                "epistemic": ep, "aleatoric": al,
                "reason": "high epistemic — novel state",
            }
        if al > self.al_th:
            # حالة غامضة → conservative
            return {
                "mode": "conservative",
                "action": int(np.argmax(mean)),
                "epistemic": ep, "aleatoric": al,
                "reason": "high aleatoric — noisy environment",
            }
        return {
            "mode": "exploit",
            "action": int(np.argmax(mean)),
            "epistemic": ep, "aleatoric": al,
            "reason": "confident",
        }


neural_ts = NeuralThompsonSampling()
ua_router = UncertaintyAwareRouter()
