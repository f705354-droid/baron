# language: Python, file: core/ai/rl/bayesian/bbb.py
# Bayes-by-Backprop (Blundell 2015) — Bayesian neural network
import numpy as np
import os
import math
from typing import Tuple, List

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


if HAS_TORCH:
    class BayesianLinear(nn.Module):
        """
        طبقة بايزية:
          - weights ~ N(mu_w, sigma_w^2)
          - sigma = softplus(rho)
          - sampling via reparameterization
        """
        def __init__(self, in_features: int, out_features: int,
                      prior_sigma: float = 1.0):
            super().__init__()
            self.in_features = in_features
            self.out_features = out_features
            self.prior_sigma = prior_sigma

            # posterior parameters
            self.mu_w = nn.Parameter(torch.zeros(out_features, in_features))
            self.rho_w = nn.Parameter(torch.full((out_features, in_features),
                                                   -3.0))
            self.mu_b = nn.Parameter(torch.zeros(out_features))
            self.rho_b = nn.Parameter(torch.full((out_features,), -3.0))

            # init
            nn.init.kaiming_normal_(self.mu_w, nonlinearity="relu")

        def forward(self, x):
            sigma_w = torch.log1p(torch.exp(self.rho_w))
            sigma_b = torch.log1p(torch.exp(self.rho_b))

            eps_w = torch.randn_like(self.mu_w)
            eps_b = torch.randn_like(self.mu_b)

            w = self.mu_w + sigma_w * eps_w
            b = self.mu_b + sigma_b * eps_b

            return F.linear(x, w, b)

        def kl_divergence(self) -> torch.Tensor:
            sigma_w = torch.log1p(torch.exp(self.rho_w))
            sigma_b = torch.log1p(torch.exp(self.rho_b))
            prior_var = self.prior_sigma ** 2
            # KL(q || p) for each weight
            kl_w = (torch.log(self.prior_sigma / (sigma_w + 1e-8)) +
                     (sigma_w ** 2 + self.mu_w ** 2) / (2 * prior_var) - 0.5)
            kl_b = (torch.log(self.prior_sigma / (sigma_b + 1e-8)) +
                     (sigma_b ** 2 + self.mu_b ** 2) / (2 * prior_var) - 0.5)
            return kl_w.sum() + kl_b.sum()


    class BayesianNet(nn.Module):
        def __init__(self, state_dim: int, action_dim: int,
                      hidden: int = 128, prior_sigma: float = 1.0):
            super().__init__()
            self.b1 = BayesianLinear(state_dim, hidden, prior_sigma)
            self.b2 = BayesianLinear(hidden, hidden, prior_sigma)
            self.b_actor = BayesianLinear(hidden, action_dim, prior_sigma)
            self.b_critic = BayesianLinear(hidden, 1, prior_sigma)

        def forward(self, s):
            h = F.relu(self.b1(s))
            h = F.relu(self.b2(h))
            return self.b_actor(h), self.b_critic(h).squeeze(-1)

        def kl(self):
            return (self.b1.kl_divergence() + self.b2.kl_divergence() +
                    self.b_actor.kl_divergence() +
                    self.b_critic.kl_divergence())


class BayesByBackprop:
    """
    BBB — تعلّم توزيع posterior على الأوزان.
    uncertainty = variance من sampling.
    """
    def __init__(self, state_dim: int = 128, action_dim: int = 64,
                  n_samples: int = 10,
                  model_path: str = "~/.albaron/bbb.pt"):
        self.n_samples = n_samples
        self.model_path = os.path.expanduser(model_path)
        self.net = None
        self.optimizer = None
        if HAS_TORCH:
            self.net = BayesianNet(state_dim, action_dim)
            self.optimizer = torch.optim.Adam(self.net.parameters(), lr=1e-3)
            if os.path.exists(self.model_path):
                try:
                    self.net.load_state_dict(torch.load(self.model_path))
                except Exception:
                    pass

    def predict(self, state_vec: np.ndarray) -> Tuple[np.ndarray, float]:
        if not HAS_TORCH or not self.net:
            return np.zeros(64), 0.0
        self.net.train()   # sampling in forward
        s = torch.from_numpy(state_vec).float().unsqueeze(0)
        probs_list = []
        with torch.no_grad():
            for _ in range(self.n_samples):
                logits, _ = self.net(s)
                probs_list.append(
                    torch.softmax(logits, -1).squeeze(0).numpy())
        arr = np.array(probs_list)
        mean = arr.mean(axis=0)
        # epistemic = total variance
        unc = float(arr.var(axis=0).sum())
        self.net.eval()
        return mean, unc

    def update(self, batch: List[dict], gamma: float = 0.99,
                kl_weight: float = 1e-3):
        if not HAS_TORCH or not self.net:
            return
        self.net.train()
        states = torch.tensor([b["state"] for b in batch],
                                dtype=torch.float32)
        rewards = torch.tensor([b["reward"] for b in batch],
                                dtype=torch.float32)
        next_states = torch.tensor([b["next_state"] for b in batch],
                                     dtype=torch.float32)
        dones = torch.tensor([b["done"] for b in batch],
                               dtype=torch.float32)
        action_ids = torch.tensor(
            [b.get("action_id", 0) % 64 for b in batch], dtype=torch.long)

        # multi-sample ELBO
        total_loss = 0.0
        for _ in range(3):
            logits, values = self.net(states)
            with torch.no_grad():
                _, next_values = self.net(next_states)
                targets = rewards + gamma * (1 - dones) * next_values
            log_probs = torch.log_softmax(logits, -1)
            selected = log_probs.gather(
                1, action_ids.unsqueeze(1)).squeeze(1)
            adv = (targets - values).detach()
            pg_loss = -(selected * adv).mean()
            v_loss = F.mse_loss(values, targets)
            total_loss = total_loss + pg_loss + 0.5 * v_loss

        kl = self.net.kl()
        loss = total_loss / 3 + kl_weight * kl

        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.net.parameters(), 1.0)
        self.optimizer.step()

    def save(self):
        if HAS_TORCH and self.net:
            try:
                torch.save(self.net.state_dict(), self.model_path)
            except Exception:
                pass


bbb = BayesByBackprop()
