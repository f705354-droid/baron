# language: Python, file: core/ai/rl/hrl/manager.py
# Manager policy — selects options (temporal abstraction)
import numpy as np
import os
import json
from typing import Tuple, Optional, List
from core.ai.rl.hrl.options import options_lib, Option

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


MANAGER_STATE_DIM = 96
N_OPTIONS = 32


def featurize_manager_state(ctx: dict) -> np.ndarray:
    """حالة عالية المستوى — تركز على الأهداف طويلة المدى"""
    v = np.zeros(MANAGER_STATE_DIM, dtype=np.float32)
    # ── progress على الهدف (16 خانات) ──
    v[0] = min(ctx.get("cumulative_reward", 0) / 1000, 1.0)
    v[1] = min(ctx.get("total_steps", 0) / 200, 1.0)
    v[2] = min(ctx.get("sessions_count", 0) / 10, 1.0)
    v[3] = min(ctx.get("hosts_count", 0) / 50, 1.0)
    v[4] = min(ctx.get("creds_count", 0) / 20, 1.0)
    v[5] = 1.0 if ctx.get("has_domain_admin") else 0.0
    v[6] = 1.0 if ctx.get("has_cloud_admin") else 0.0
    v[7] = 1.0 if ctx.get("persistence_set") else 0.0
    v[8] = 1.0 if ctx.get("exfil_done") else 0.0
    v[9] = 1.0 if ctx.get("ad_enumerated") else 0.0
    v[10] = 1.0 if ctx.get("subnet_scanned") else 0.0
    v[11] = 1.0 if ctx.get("detected") else 0.0
    v[12] = min(ctx.get("failure_streak", 0) / 5, 1.0)
    v[13] = min(ctx.get("time_elapsed_min", 0) / 60, 1.0)
    v[14] = min(ctx.get("tokens_used", 0) / 100_000, 1.0)
    v[15] = min(len(ctx.get("recent_options", [])) / 5, 1.0)

    # ── context flags (16 خانات) ──
    v[16] = 1.0 if ctx.get("ad_environment") else 0.0
    v[17] = 1.0 if ctx.get("cloud") else 0.0
    v[18] = 1.0 if ctx.get("ot_iot") else 0.0
    v[19] = 1.0 if ctx.get("stealth_mode") else 0.0
    v[20] = 1.0 if ctx.get("time_pressure") else 0.0
    v[21] = 1.0 if ctx.get("has_session") else 0.0

    # ── option availability (32 خانة) ──
    applicable = options_lib.applicable(ctx)
    for i, opt in enumerate(options_lib.options.values()):
        if i < 32:
            v[32 + i] = 1.0 if opt in applicable else 0.0

    # ── option histories (32 خانة) — نجاح/فشل كل option ──
    opt_stats = ctx.get("option_stats", {})
    for i, name in enumerate(options_lib.options.keys()):
        if i < 32:
            stats = opt_stats.get(name, {"success": 0, "fail": 0})
            total = stats["success"] + stats["fail"]
            if total > 0:
                v[64 + i] = stats["success"] / total
    return v


if HAS_TORCH:
    class ManagerNet(nn.Module):
        """
        Manager: π_Ω(o | s) + V(s) — يختار option كل K steps
        Uses option-critic architecture.
        """
        def __init__(self, state_dim=MANAGER_STATE_DIM, n_options=N_OPTIONS,
                      hidden=256):
            super().__init__()
            self.trunk = nn.Sequential(
                nn.Linear(state_dim, hidden),
                nn.LayerNorm(hidden),
                nn.ReLU(),
                nn.Linear(hidden, hidden),
                nn.LayerNorm(hidden),
                nn.ReLU(),
            )
            self.option_actor = nn.Linear(hidden, n_options)
            self.value = nn.Linear(hidden, 1)

        def forward(self, s):
            h = self.trunk(s)
            logits = self.option_actor(h)
            v = self.value(h).squeeze(-1)
            return logits, v


class Manager:
    """
    Manager policy — يختار option كل K steps.
    K = option's max_steps أو termination.
    """
    def __init__(self, K: int = 20, model_path: str = "~/.albaron/manager.pt"):
        self.K = K
        self.model_path = os.path.expanduser(model_path)
        self.net = None
        self.optimizer = None
        if HAS_TORCH:
            self.net = ManagerNet()
            self.optimizer = torch.optim.Adam(self.net.parameters(), lr=3e-4)
            if os.path.exists(self.model_path):
                try:
                    self.net.load_state_dict(torch.load(self.model_path))
                except Exception:
                    pass

        # option name ↔ id
        self.option_list = list(options_lib.options.keys())
        self.name_to_id = {n: i for i, n in enumerate(self.option_list)}
        self.id_to_name = {i: n for n, i in self.name_to_id.items()}

        # option-critic stats
        self.option_stats = {n: {"success": 0, "fail": 0, "avg_return": 0.0}
                              for n in self.option_list}
        self.action_counter = {n: 0 for n in self.option_list}

        # termination head — learns β(s) per option
        if HAS_TORCH:
            self.termination_head = nn.Sequential(
                nn.Linear(MANAGER_STATE_DIM, 64),
                nn.ReLU(),
                nn.Linear(64, N_OPTIONS),
                nn.Sigmoid(),
            )
            self.term_optimizer = torch.optim.Adam(
                self.termination_head.parameters(), lr=3e-4)

    def select_option(self, state_vec: np.ndarray, ctx: dict,
                        epsilon: float = 0.1) -> Optional[Option]:
        """يختار option من الapplicable set"""
        applicable = options_lib.applicable(ctx)
        if not applicable:
            return None

        # epsilon-greedy على الoption space
        if np.random.rand() < epsilon:
            return applicable[np.random.randint(len(applicable))]

        if not HAS_TORCH or not self.net:
            # fallback: أعلى avg_return
            best = max(applicable,
                       key=lambda o: self.option_stats[o.name]["avg_return"])
            return best

        with torch.no_grad():
            s = torch.from_numpy(state_vec).float().unsqueeze(0)
            logits, _ = self.net(s)
            probs = torch.softmax(logits, dim=-1).squeeze(0).numpy()

        # mask غير المتاح
        mask = np.zeros_like(probs)
        for opt in applicable:
            oid = self.name_to_id.get(opt.name)
            if oid is not None:
                mask[oid] = probs[oid]
        if mask.sum() == 0:
            return applicable[0]
        chosen_id = int(np.argmax(mask))
        chosen_name = self.id_to_name.get(chosen_id)
        return options_lib.get(chosen_name) or applicable[0]

    def should_terminate(self, state_vec: np.ndarray, option: Option,
                          ctx: dict) -> bool:
        """β(s) — يقرر إنهاء الoption قبل max_steps"""
        # hand-coded condition
        if option.termination(ctx):
            return True
        if option.steps_taken >= option.max_steps:
            return True
        # learned termination
        if HAS_TORCH and self.termination_head:
            with torch.no_grad():
                s = torch.from_numpy(state_vec).float().unsqueeze(0)
                probs = self.termination_head(s).squeeze(0).numpy()
            oid = self.name_to_id.get(option.name, 0)
            if probs[oid] > 0.7:
                return True
        return False

    def update_option_stats(self, option_name: str, success: bool,
                              ret: float):
        s = self.option_stats[option_name]
        if success:
            s["success"] += 1
        else:
            s["fail"] += 1
        # running avg
        n = s["success"] + s["fail"]
        s["avg_return"] = (s["avg_return"] * (n - 1) + ret) / n

    def update_neural(self, batch: List[dict], gamma: float = 0.99):
        """
        Option-critic update:
          - policy loss على الoptions المختارة
          - value loss على returns
          - termination loss (regularization)
        """
        if not HAS_TORCH or not self.net:
            return
        states = torch.tensor([b["manager_state"] for b in batch],
                                dtype=torch.float32)
        returns = torch.tensor([b["option_return"] for b in batch],
                                dtype=torch.float32)
        option_ids = torch.tensor([self.name_to_id.get(b["option_name"], 0)
                                     for b in batch], dtype=torch.long)

        logits, values = self.net(states)
        log_probs = torch.log_softmax(logits, -1)
        selected = log_probs.gather(1, option_ids.unsqueeze(1)).squeeze(1)
        advantages = (returns - values).detach()

        policy_loss = -(selected * advantages).mean()
        value_loss = F.mse_loss(values, returns)
        entropy = -(torch.softmax(logits, -1) * log_probs).sum(-1).mean()

        loss = policy_loss + 0.5 * value_loss - 0.01 * entropy
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.net.parameters(), 1.0)
        self.optimizer.step()

    def save(self):
        if HAS_TORCH and self.net:
            try:
                torch.save(self.net.state_dict(), self.model_path)
            except Exception:
                pass
        # stats
        with open(self.model_path + ".stats", "w") as f:
            json.dump(self.option_stats, f, indent=2)


manager = Manager()
