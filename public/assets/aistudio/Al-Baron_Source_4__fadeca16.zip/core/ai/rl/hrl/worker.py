# language: Python, file: core/ai/rl/hrl/worker.py
# Worker policy — primitive actions داخل option
import numpy as np
import json
import os
from typing import Tuple, Optional, Dict
from core.ai.rl.hrl.options import Option

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


WORKER_STATE_DIM = 128
PRIMITIVE_ACTIONS = 64   # discretized actions


def featurize_worker_state(ctx: dict, option: Option) -> np.ndarray:
    """حالة منخفضة — تركز على التنفيذ الحالي"""
    v = np.zeros(WORKER_STATE_DIM, dtype=np.float32)
    # steps داخل option
    v[0] = min(option.steps_taken / option.max_steps, 1.0)
    v[1] = np.tanh(option.reward_accum / 50)
    # sub_goal progress
    for i, sg in enumerate(option.sub_goals[:16]):
        v[2 + i] = 1.0 if ctx.get(f"sg_{sg}_done") else 0.0
    # recent action histogram (32 خانات)
    hist = ctx.get("recent_actions_hist", {})
    for i, (k, c) in enumerate(list(hist.items())[:32]):
        v[32 + i] = min(c / 10, 1.0)
    # opsec signals (16 خانات)
    v[64] = 1.0 if ctx.get("detected") else 0.0
    v[65] = min(ctx.get("alert_count", 0) / 5, 1.0)
    v[66] = 1.0 if ctx.get("honeypot_suspected") else 0.0
    v[67] = min(ctx.get("repeat_count", 0) / 5, 1.0)
    # resource
    v[68] = min(ctx.get("tokens_used_step", 0) / 5000, 1.0)
    v[69] = min(ctx.get("step_latency_ms", 0) / 10000, 1.0)
    # intra-option features
    v[70] = 1.0 if ctx.get("last_action_success") else 0.0
    v[71] = 1.0 if ctx.get("last_action_detected") else 0.0
    v[72] = min(ctx.get("option_step_goal_reached", 0), 1.0)
    # intrinsic reward signal
    v[73] = np.tanh(ctx.get("intrinsic_bonus", 0) / 5)
    # uncertainty (Bayesian)
    v[74] = min(ctx.get("policy_uncertainty", 0), 1.0)
    v[75] = min(ctx.get("value_uncertainty", 0), 1.0)
    # padding
    return v


if HAS_TORCH:
    class WorkerNet(nn.Module):
        """
        Worker: π_a(a | s, o) + V(s, o)
        Input = state + one-hot(option)
        Output = action distribution
        """
        def __init__(self, state_dim=WORKER_STATE_DIM,
                      n_options=32, n_actions=PRIMITIVE_ACTIONS,
                      hidden=256):
            super().__init__()
            self.trunk = nn.Sequential(
                nn.Linear(state_dim + n_options, hidden),
                nn.LayerNorm(hidden),
                nn.ReLU(),
                nn.Linear(hidden, hidden),
                nn.LayerNorm(hidden),
                nn.ReLU(),
            )
            self.actor = nn.Linear(hidden, n_actions)
            self.critic = nn.Linear(hidden, 1)

        def forward(self, s, option_onehot):
            x = torch.cat([s, option_onehot], dim=-1)
            h = self.trunk(x)
            return self.actor(h), self.critic(h).squeeze(-1)


class Worker:
    """
    Worker policy — ينفذ primitive actions داخل option.
    """
    def __init__(self, model_path: str = "~/.albaron/worker.pt"):
        self.model_path = os.path.expanduser(model_path)
        self.net = None
        self.optimizer = None
        if HAS_TORCH:
            self.net = WorkerNet()
            self.optimizer = torch.optim.Adam(self.net.parameters(), lr=3e-4)
            if os.path.exists(self.model_path):
                try:
                    self.net.load_state_dict(torch.load(self.model_path))
                except Exception:
                    pass

        self.option_list = list(__import__("core.ai.rl.hrl.options",
                                              fromlist=["options_lib"])
                                 .options_lib.options.keys())
        self.n_options = len(self.option_list)

    def _option_onehot(self, option_name: str) -> np.ndarray:
        v = np.zeros(self.n_options, dtype=np.float32)
        if option_name in self.option_list:
            v[self.option_list.index(option_name)] = 1.0
        return v

    def select_action(self, state_vec: np.ndarray, option: Option,
                       ctx: dict, epsilon: float = 0.1) -> Tuple[str, dict]:
        """
        يستدعي option.policy() كـprior، ثم يعدّله بـneural policy.
        Args placeholder — LLM سيملأها لاحقاً.
        """
        # option policy gives semantic action
        tool, args = option.policy(ctx)

        # neural policy can override (epsilon-greedy)
        if HAS_TORCH and self.net and np.random.rand() > epsilon:
            with torch.no_grad():
                s = torch.from_numpy(state_vec).float().unsqueeze(0)
                oh = torch.from_numpy(
                    self._option_onehot(option.name)).float().unsqueeze(0)
                logits, _ = self.net(s, oh)
                probs = torch.softmax(logits, dim=-1).squeeze(0).numpy()
            # sample action_id — يُستَخدم كـprior لـLLM فقط
            action_id = int(np.random.choice(len(probs), p=probs))
            ctx["worker_action_hint"] = action_id

        return tool, args

    def update(self, batch: List[dict], gamma: float = 0.99):
        if not HAS_TORCH or not self.net:
            return
        states = torch.tensor([b["worker_state"] for b in batch],
                                dtype=torch.float32)
        oh = torch.tensor([self._option_onehot(b["option_name"])
                            for b in batch], dtype=torch.float32)
        rewards = torch.tensor([b["reward"] for b in batch],
                                dtype=torch.float32)
        next_states = torch.tensor([b["next_worker_state"] for b in batch],
                                     dtype=torch.float32)
        next_oh = torch.tensor([self._option_onehot(b["next_option_name"])
                                 for b in batch], dtype=torch.float32)
        dones = torch.tensor([b["done"] for b in batch],
                              dtype=torch.float32)

        logits, values = self.net(states, oh)
        with torch.no_grad():
            _, next_values = self.net(next_states, next_oh)
            targets = rewards + gamma * (1 - dones) * next_values

        advantages = (targets - values).detach()
        log_probs = torch.log_softmax(logits, -1)
        # action id pseudo
        action_ids = torch.tensor(
            [b.get("action_id", 0) % PRIMITIVE_ACTIONS for b in batch],
            dtype=torch.long)
        selected = log_probs.gather(1, action_ids.unsqueeze(1)).squeeze(1)

        policy_loss = -(selected * advantages).mean()
        value_loss = F.mse_loss(values, targets)
        loss = policy_loss + 0.5 * value_loss

        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.net.parameters(), 1.0)
        self.optimizer.step()

    def save(self):
        if HAS_TORCH and self.net:
            try:
                torch.save(self.net.state_dict(), self.model_path)
            except Exception:
                pass


worker = Worker()
