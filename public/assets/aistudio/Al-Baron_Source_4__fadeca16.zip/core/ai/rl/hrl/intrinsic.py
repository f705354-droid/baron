# language: Python, file: core/ai/rl/hrl/intrinsic.py
# Intrinsic motivation — RND + ICM + count-based + empowerment
import numpy as np
import os
import hashlib
from collections import deque
from typing import List, Optional

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


class CountBasedBonus:
    """
    Count-based exploration (Bellemare et al).
    مكافأة = 1/sqrt(N(s)) — states نادرة تُكافأ أكثر.
    يستخدم SimHash لتجميع الحالات.
    """
    def __init__(self, hash_dim: int = 32, decay: float = 0.99):
        self.counts = {}
        self.hash_dim = hash_dim
        self.total = 0

    def _hash_state(self, state_vec: np.ndarray) -> int:
        # SimHash — vector → int
        import hashlib
        # quantize
        q = (state_vec * 10).astype(int)
        s = ",".join(str(x) for x in q[:self.hash_dim])
        return int(hashlib.md5(s.encode()).hexdigest()[:16], 16)

    def bonus(self, state_vec: np.ndarray) -> float:
        h = self._hash_state(state_vec)
        self.total += 1
        count = self.counts.get(h, 0) + 1
        self.counts[h] = count
        return 1.0 / np.sqrt(count)


if HAS_TORCH:
    class RNDNetwork(nn.Module):
        """Random Network Distillation — target + predictor"""
        def __init__(self, state_dim: int, hidden: int = 128,
                      out_dim: int = 64):
            super().__init__()
            self.target = nn.Sequential(
                nn.Linear(state_dim, hidden),
                nn.ReLU(),
                nn.Linear(hidden, out_dim),
            )
            self.predictor = nn.Sequential(
                nn.Linear(state_dim, hidden),
                nn.ReLU(),
                nn.Linear(hidden, hidden),
                nn.ReLU(),
                nn.Linear(hidden, out_dim),
            )
            # fix target
            for p in self.target.parameters():
                p.requires_grad = False

        def forward(self, s):
            with torch.no_grad():
                t = self.target(s)
            p = self.predictor(s)
            return t, p


    class ICMModule(nn.Module):
        """
        Intrinsic Curiosity Module (Pathak et al 2017).
        forward model + inverse model.
        reward = prediction error of forward model في feature space.
        """
        def __init__(self, state_dim: int, action_dim: int = 64,
                      hidden: int = 128, feature_dim: int = 64):
            super().__init__()
            # encoder
            self.encoder = nn.Sequential(
                nn.Linear(state_dim, hidden),
                nn.ReLU(),
                nn.Linear(hidden, feature_dim),
            )
            # inverse model: (φ(s), φ(s')) → action
            self.inverse = nn.Sequential(
                nn.Linear(feature_dim * 2, hidden),
                nn.ReLU(),
                nn.Linear(hidden, action_dim),
            )
            # forward model: (φ(s), a) → φ(s')
            self.forward = nn.Sequential(
                nn.Linear(feature_dim + action_dim, hidden),
                nn.ReLU(),
                nn.Linear(hidden, feature_dim),
            )

        def forward(self, s, s_next, action_onehot):
            phi_s = self.encoder(s)
            phi_next = self.encoder(s_next)
            # inverse
            inv_in = torch.cat([phi_s, phi_next], dim=-1)
            pred_action = self.inverse(inv_in)
            # forward
            fwd_in = torch.cat([phi_s, action_onehot], dim=-1)
            pred_next = self.forward(fwd_in)
            return phi_s, phi_next, pred_action, pred_next


class IntrinsicMotivation:
    """
    يجمع ثلاث إشارات داخلية:
      1. RND — randomness prediction error
      2. ICM — forward dynamics error
      3. Count — novelty
      4. Empowerment (mutual information)
    """
    def __init__(self, state_dim: int = 128, action_dim: int = 64,
                  rnd_weight: float = 0.5, icm_weight: float = 0.3,
                  count_weight: float = 0.2, decay: float = 0.999):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.rnd_weight = rnd_weight
        self.icm_weight = icm_weight
        self.count_weight = count_weight
        self.decay = decay

        if HAS_TORCH:
            self.rnd = RNDNetwork(state_dim)
            self.rnd_opt = torch.optim.Adam(
                self.rnd.predictor.parameters(), lr=1e-3)
            self.icm = ICMModule(state_dim, action_dim)
            self.icm_opt = torch.optim.Adam(self.icm.parameters(), lr=1e-3)

        self.counts = CountBasedBonus()
        self.recent_bonuses = deque(maxlen=100)
        self.total_bonus = 0.0

    def compute(self, state_vec: np.ndarray, action_id: int,
                 next_state_vec: np.ndarray) -> float:
        """يرجع intrinsic reward للtransition"""
        bonuses = {}

        # RND
        if HAS_TORCH and self.rnd:
            s = torch.from_numpy(state_vec).float().unsqueeze(0)
            t, p = self.rnd(s)
            rnd_loss = float(F.mse_loss(p, t.detach()))
            # update predictor
            self.rnd_opt.zero_grad()
            loss = F.mse_loss(p, t.detach())
            loss.backward()
            self.rnd_opt.step()
            bonuses["rnd"] = rnd_loss
        else:
            bonuses["rnd"] = 0.0

        # Count
        bonuses["count"] = self.counts.bonus(next_state_vec)

        # ICM
        if HAS_TORCH and self.icm:
            s = torch.from_numpy(state_vec).float().unsqueeze(0)
            ns = torch.from_numpy(next_state_vec).float().unsqueeze(0)
            a_oh = torch.zeros(1, self.action_dim)
            a_oh[0, action_id % self.action_dim] = 1.0
            phi_s, phi_next, pred_a, pred_next = self.icm(s, ns, a_oh)
            fwd_err = float(F.mse_loss(pred_next, phi_next.detach()))
            inv_loss = F.cross_entropy(pred_a, a_oh.argmax(-1))
            icm_loss = fwd_err + 0.1 * inv_loss
            self.icm_opt.zero_grad()
            loss = F.mse_loss(pred_next, phi_next.detach()) + 0.1 * inv_loss
            loss.backward()
            self.icm_opt.step()
            bonuses["icm"] = fwd_err
        else:
            bonuses["icm"] = 0.0

        total = (self.rnd_weight * bonuses["rnd"] +
                  self.icm_weight * bonuses["icm"] +
                  self.count_weight * bonuses["count"])
        self.recent_bonuses.append(total)
        self.total_bonus += total
        return total

    def describe(self) -> dict:
        return {
            "total_bonus": self.total_bonus,
            "recent_avg": float(np.mean(self.recent_bonuses)
                                 if self.recent_bonuses else 0),
            "count_states": len(self.counts.counts),
        }


intrinsic = IntrinsicMotivation()
