# language: Python, file: core/ai/rl/replay.py
# Experience replay buffer — SQLite-backed, prioritized sampling
import os
import json
import sqlite3
import random
import math
from datetime import datetime
from typing import List, Dict, Optional, Tuple
import numpy as np


class ReplayBuffer:
    """
    Experience replay:
      state  = سياق engagement (module, target, findings count, step)
      action = (tool, args) تم اختياره
      reward = reward signal
      next_state = السياق بعد التنفيذ
      done   = هل انتهى الtrajectory
    Prioritized sampling — أعلى TD-error أولاً.
    """
    def __init__(self, path: str = "~/.albaron/rl_replay.db",
                  capacity: int = 200_000):
        self.path = os.path.expanduser(path)
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self.capacity = capacity
        self.db = sqlite3.connect(self.path, check_same_thread=False)
        self._init()

    def _init(self):
        c = self.db.cursor()
        c.executescript("""
        CREATE TABLE IF NOT EXISTS transitions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_id TEXT,
            session_id TEXT,
            state_vec TEXT,
            action TEXT,
            action_vec TEXT,
            reward REAL,
            next_state_vec TEXT,
            done INTEGER,
            priority REAL DEFAULT 1.0,
            ts TEXT,
            meta TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_trans_priority
            ON transitions(priority DESC);
        CREATE INDEX IF NOT EXISTS idx_trans_run
            ON transitions(run_id);
        """)
        self.db.commit()

    def store(self, state_vec: List[float], action: Tuple[str, dict],
               reward: float, next_state_vec: List[float],
               done: bool = False, run_id: str = None,
               session_id: str = None, meta: dict = None):
        c = self.db.cursor()
        c.execute("""
            INSERT INTO transitions(run_id, session_id, state_vec, action,
                action_vec, reward, next_state_vec, done, priority, ts, meta)
            VALUES(?,?,?,?,?,?,?,?,?,?,?)
        """, (
            run_id, session_id,
            json.dumps(state_vec),
            action[0] + ":" + json.dumps(action[1]),
            json.dumps([hash(action[0]) % 1000, hash(json.dumps(action[1], sort_keys=True)) % 1000]),
            reward,
            json.dumps(next_state_vec),
            1 if done else 0,
            abs(reward) + 1e-3,   # initial priority
            datetime.utcnow().isoformat(),
            json.dumps(meta or {}),
        ))
        self.db.commit()

        # prune إذا تجاوزنا السعة
        count = c.execute("SELECT COUNT(*) FROM transitions").fetchone()[0]
        if count > self.capacity:
            overflow = count - self.capacity
            c.execute("""DELETE FROM transitions WHERE id IN
                (SELECT id FROM transitions ORDER BY priority ASC LIMIT ?)""",
                (overflow,))
            self.db.commit()

    def sample(self, batch_size: int = 64, alpha: float = 0.6,
                beta: float = 0.4) -> List[dict]:
        """prioritized experience replay (PER)"""
        c = self.db.cursor()
        rows = c.execute("""
            SELECT id, state_vec, action, reward, next_state_vec,
                   done, priority, run_id, session_id, meta
            FROM transitions
        """).fetchall()
        if not rows:
            return []

        priorities = np.array([r[6] ** alpha for r in rows], dtype=np.float64)
        probs = priorities / priorities.sum()
        idxs = np.random.choice(len(rows), size=min(batch_size, len(rows)),
                                  replace=False, p=probs)

        # importance sampling weights
        n = len(rows)
        weights = (n * probs[idxs]) ** (-beta)
        weights = weights / weights.max()

        out = []
        for i, idx in zip(idxs, range(len(idxs))):
            r = rows[i]
            out.append({
                "id": r[0],
                "state": json.loads(r[1]),
                "action": r[2],
                "reward": r[3],
                "next_state": json.loads(r[4]),
                "done": bool(r[5]),
                "priority": r[6],
                "run_id": r[7],
                "session_id": r[8],
                "meta": json.loads(r[9] or "{}"),
                "is_weight": float(weights[idx]),
            })
        return out

    def update_priorities(self, ids: List[int], td_errors: List[float],
                            epsilon: float = 1e-3):
        c = self.db.cursor()
        for i, err in zip(ids, td_errors):
            c.execute("UPDATE transitions SET priority=? WHERE id=?",
                       (abs(err) + epsilon, i))
        self.db.commit()

    def trajectories(self, run_id: str) -> List[dict]:
        c = self.db.cursor()
        rows = c.execute("""
            SELECT state_vec, action, reward, next_state_vec, done, meta, ts
            FROM transitions WHERE run_id=? ORDER BY id ASC
        """, (run_id,)).fetchall()
        return [{
            "state": json.loads(r[0]),
            "action": r[1],
            "reward": r[2],
            "next_state": json.loads(r[3]),
            "done": bool(r[4]),
            "meta": json.loads(r[5] or "{}"),
            "ts": r[6],
        } for r in rows]

    def stats(self) -> dict:
        c = self.db.cursor()
        total = c.execute("SELECT COUNT(*) FROM transitions").fetchone()[0]
        avg_r = c.execute("SELECT AVG(reward) FROM transitions").fetchone()[0] or 0
        pos = c.execute("SELECT COUNT(*) FROM transitions WHERE reward > 0").fetchone()[0]
        neg = c.execute("SELECT COUNT(*) FROM transitions WHERE reward < 0").fetchone()[0]
        return {
            "total": total,
            "avg_reward": round(avg_r, 3),
            "positive": pos,
            "negative": neg,
            "runs": c.execute(
                "SELECT COUNT(DISTINCT run_id) FROM transitions").fetchone()[0],
        }


replay = ReplayBuffer()
