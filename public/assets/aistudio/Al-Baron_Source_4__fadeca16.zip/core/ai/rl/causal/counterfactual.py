# language: Python, file: core/ai/rl/causal/counterfactual.py
# Counterfactual inference — "ماذا لو اتخذنا قراراً مختلفاً؟"
import numpy as np
from typing import Dict, List, Optional
from core.ai.rl.causal.scm import albaron_scm


class CounterfactualEngine:
    """
    Three-step counterfactual (Pearl):
      1. Abduction: P(U | evidence)
      2. Action: do(X=x')
      3. Prediction: forward with new X
    """
    def __init__(self, scm=None):
        self.scm = scm or albaron_scm

    def abduction(self, observed: Dict[str, float]) -> Dict[str, float]:
        """
        يقدر الضجيج U لكل variable بناءً على الملاحظات.
        U_v = v - f_v(parents(v))
        """
        noise = {}
        order = list(np.array(list(self.scm.graph.nodes)))
        try:
            import networkx as nx
            order = list(nx.topological_sort(self.scm.graph))
        except Exception:
            pass
        for v in order:
            if v not in self.scm.structural_eqs:
                continue
            parents = self.scm.parents(v)
            parent_vals = {p: observed.get(p, 0.0) for p in parents}
            predicted = self.scm.structural_eqs[v](parent_vals, 0.0)
            noise[v] = observed.get(v, 0.0) - predicted
        return noise

    def counterfactual(self, observed: Dict[str, float],
                        intervention: Dict[str, float]) -> Dict[str, float]:
        """
        P(Y_x' | evidence, do(X=x'))
        """
        # 1. abduction
        noise = self.abduction(observed)
        # 2. intervention + 3. forward
        try:
            import networkx as nx
            order = list(nx.topological_sort(self.scm.graph))
        except Exception:
            order = list(self.scm.graph.nodes)
        cf_values = {}
        for v in order:
            if v in intervention:
                cf_values[v] = intervention[v]
                continue
            if v not in self.scm.structural_eqs:
                cf_values[v] = observed.get(v, 0.0)
                continue
            parents = self.scm.parents(v)
            parent_vals = {p: cf_values.get(p, observed.get(p, 0.0))
                            for p in parents}
            cf_values[v] = self.scm.structural_eqs[v](
                parent_vals, noise.get(v, 0.0))
        return cf_values

    def batch_counterfactual(self, observed_batch: List[Dict[str, float]],
                              intervention: Dict[str, float]) -> List[Dict]:
        return [self.counterfactual(obs, intervention)
                for obs in observed_batch]

    def regret(self, observed: Dict[str, float],
                taken_action: Dict[str, float],
                alternative_action: Dict[str, float],
                outcome_var: str = "exfil") -> Dict:
        """
        يحسب regret = outcome(alternative) - outcome(taken)
        """
        cf_taken = self.counterfactual(observed, taken_action)
        cf_alt = self.counterfactual(observed, alternative_action)
        return {
            "outcome_var": outcome_var,
            "outcome_taken": cf_taken.get(outcome_var, 0.0),
            "outcome_alt": cf_alt.get(outcome_var, 0.0),
            "regret": cf_alt.get(outcome_var, 0.0) -
                        cf_taken.get(outcome_var, 0.0),
            "better_action": ("alternative"
                              if cf_alt.get(outcome_var, 0.0) >
                                 cf_taken.get(outcome_var, 0.0)
                              else "taken"),
        }

    def explain_decision(self, observed: Dict[str, float],
                          decision: Dict[str, float],
                          outcome_var: str = "exfil") -> Dict:
        """
        يشرح القرار بثلاث سيناريوهات:
          - ما حدث (factual)
          - ماذا لو عكسنا القرار (counterfactual)
          - ماذا لو لم نفعل شيئاً
        """
        factual = self.counterfactual(observed, decision)
        opposite = {k: 1.0 - v if isinstance(v, (int, float)) else v
                     for k, v in decision.items()}
        cf_opposite = self.counterfactual(observed, opposite)
        no_action = self.counterfactual(observed, {k: 0.0 for k in decision})
        return {
            "factual": {outcome_var: factual.get(outcome_var, 0.0)},
            "if_opposite": {outcome_var: cf_opposite.get(outcome_var, 0.0)},
            "if_no_action": {outcome_var: no_action.get(outcome_var, 0.0)},
            "delta_from_opposite": (factual.get(outcome_var, 0.0) -
                                     cf_opposite.get(outcome_var, 0.0)),
            "delta_from_inaction": (factual.get(outcome_var, 0.0) -
                                     no_action.get(outcome_var, 0.0)),
        }


counterfactual_engine = CounterfactualEngine()
