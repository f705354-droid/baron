# language: Python, file: core/ai/rl/causal/do_calculus.py
# do-calculus — ثلاث قواعد Pearl + backdoor/frontdoor identification
import numpy as np
import networkx as nx
from typing import List, Set, Dict, Optional
from core.ai.rl.causal.scm import StructuralCausalModel, albaron_scm


class DoCalculus:
    """
    ثلاث قواعد Pearl:
      Rule 1: P(Y | do(X), Z, W) = P(Y | do(X), W)  إذا (Y ⊥ Z | X, W) في G_X̄
      Rule 2: P(Y | do(X), do(Z), W) = P(Y | X, do(Z), W)  إذا (Y ⊥ Z | X, W) في G_X̲Z̄
      Rule 3: P(Y | do(X), do(Z), W) = P(Y | do(X), W)  إذا (Y ⊥ Z | X, W) في G_X̄Z̲(W)

    نستخدمها لتحويل الاستعلامات الـcausal إلى observable.
    """
    def __init__(self, scm: StructuralCausalModel):
        self.scm = scm

    def backdoor_adjustment_set(self, x: str, y: str) -> Optional[List[str]]:
        """
        يبحث عن مجموعة Z تحقق backdoor criterion:
          1. لا Z descendant of X
          2. Z تحجب كل backdoor paths من X إلى Y
        نستخدم heuristic: parents(X) \ {Y}
        """
        x_ancestors = self.scm.ancestors(x)
        x_descendants = self.scm.descendants(x)
        parents = set(self.scm.parents(x))

        candidates = [n for n in self.scm.graph.nodes
                        if n != x and n != y and
                           n not in x_descendants]
        # simple heuristic: parents of X
        if parents:
            return list(parents - x_descendants)
        # fallback: all non-descendants
        return list(set(candidates))

    def is_valid_backdoor(self, x: str, y: str,
                            adjustment_set: Set[str]) -> bool:
        """تحقق من صحة مجموعة التعديل"""
        # الشرط 1: لا descendant of X
        x_descendants = self.scm.descendants(x)
        if adjustment_set & x_descendants:
            return False
        # الشرط 2: d-separation
        g = self.scm.graph.copy()
        # احذف edges الداخلة لـX
        for pred in list(g.predecessors(x)):
            g.remove_edge(pred, x)
        return nx.d_separated(g, {x}, {y}, adjustment_set)

    def causal_effect(self, x: str, y: str,
                        n_samples: int = 5000) -> Dict:
        """
        يحسب ACE = E[Y | do(X=x1)] - E[Y | do(X=x0)]
        باستخدام backdoor adjustment.
        """
        adj_set = self.backdoor_adjustment_set(x, y)
        # نجرب عدة مستويات لـX
        samples_x0 = self.scm.do(x, 0.0, n_samples)
        samples_x1 = self.scm.do(x, 1.0, n_samples)
        y0 = np.mean([s[y] for s in samples_x0])
        y1 = np.mean([s[y] for s in samples_x1])
        ace = y1 - y0
        # اكتب أيضاً observational correlation
        obs = self.scm.sample(n_samples=n_samples)
        x_vals = np.array([s[x] for s in obs])
        y_vals = np.array([s[y] for s in obs])
        if x_vals.std() > 1e-6:
            corr = np.corrcoef(x_vals, y_vals)[0, 1]
        else:
            corr = 0.0
        return {
            "treatment": x,
            "outcome": y,
            "adjustment_set": adj_set,
            "E_Y_do_X_0": float(y0),
            "E_Y_do_X_1": float(y1),
            "ACE": float(ace),
            "observational_corr": float(corr),
            "confounding_bias": float(corr - ace),
        }

    def rule1_apply(self, y: str, x: str, z: str,
                     w: Set[str]) -> bool:
        """Rule 1 — insertion/deletion of observation"""
        g = self.scm.graph.copy()
        # G_X̄ — احذف edges خارجة من X
        for succ in list(g.successors(x)):
            g.remove_edge(x, succ)
        return nx.d_separated(g, {y}, {z}, w | {x})

    def rule2_apply(self, y: str, x: str, z: str,
                     w: Set[str]) -> bool:
        """Rule 2 — action/observation exchange"""
        g = self.scm.graph.copy()
        for pred in list(g.predecessors(x)):
            g.remove_edge(pred, x)
        for succ in list(g.successors(z)):
            g.remove_edge(z, succ)
        return nx.d_separated(g, {y}, {z}, w | {x, z})

    def rule3_apply(self, y: str, x: str, z: str,
                     w: Set[str]) -> bool:
        """Rule 3 — action/action exchange"""
        g = self.scm.graph.copy()
        for pred in list(g.predecessors(x)):
            g.remove_edge(pred, x)
        for pred in list(g.predecessors(z)):
            g.remove_edge(pred, z)
        return nx.d_separated(g, {y}, {z}, w | {x})

    def probability_of_necessity(self, x: str, y: str,
                                   threshold: float = 0.5,
                                   n_samples: int = 3000) -> float:
        """
        P(Y_{x=0} < threshold | X=1, Y > threshold)
        احتمال أن Y كان سيحدث بدون X.
        """
        # observational: events where X=1 and Y > threshold
        obs = self.scm.sample(n_samples=n_samples)
        events = [s for s in obs if s.get(x, 0) > 0.5 and
                    s.get(y, 0) > threshold]
        if not events:
            return 0.0
        # counterfactual: do(X=0) لكل حالة
        counterfactuals_hit = 0
        for e in events[:500]:
            # نستخدم abduction-action-prediction
            # abduction: noise = observed - structural_eq(parents)
            parent_vals = {p: e[p] for p in self.scm.parents(y)}
            # simplified: نقدر الضجيج
            obs_y = e[y]
            predicted_y = self.scm.structural_eqs[y](parent_vals, 0.0)
            noise_y = obs_y - predicted_y
            # action: do(X=0) — نغير X ونعيد الحساب
            # note: هذا مبسط — abduction كامل يحتاج noise per variable
            parent_vals_new = dict(parent_vals)
            if x in parent_vals_new:
                parent_vals_new[x] = 0.0
            y_cf = self.scm.structural_eqs[y](parent_vals_new, noise_y)
            if y_cf < threshold:
                counterfactuals_hit += 1
        return counterfactuals_hit / min(len(events), 500)

    def probability_of_sufficiency(self, x: str, y: str,
                                     threshold: float = 0.5,
                                     n_samples: int = 3000) -> float:
        """
        P(Y_{x=1} > threshold | X=0, Y < threshold)
        """
        obs = self.scm.sample(n_samples=n_samples)
        events = [s for s in obs if s.get(x, 0) < 0.5 and
                    s.get(y, 0) < threshold]
        if not events:
            return 0.0
        hit = 0
        for e in events[:500]:
            parent_vals = {p: e[p] for p in self.scm.parents(y)}
            obs_y = e[y]
            predicted_y = self.scm.structural_eqs[y](parent_vals, 0.0)
            noise_y = obs_y - predicted_y
            parent_vals_new = dict(parent_vals)
            if x in parent_vals_new:
                parent_vals_new[x] = 1.0
            y_cf = self.scm.structural_eqs[y](parent_vals_new, noise_y)
            if y_cf > threshold:
                hit += 1
        return hit / min(len(events), 500)


do_calculus = DoCalculus(albaron_scm)
