# language: Python, file: core/ai/rl/causal/scm.py
# Structural Causal Model — DAG + structural equations
import numpy as np
import networkx as nx
from typing import Dict, List, Optional, Callable, Set
import itertools


class StructuralCausalModel:
    """
    SCM: (U, V, F)
      U = exogenous (خارجية)
      V = endogenous (داخلية، مرتبطة بالـDAG)
      F = دوال بنيوية — v_i = f_i(parents(v_i), u_i)
    سياقنا: V = {session, creds, DA, detection, exfil}
    """
    def __init__(self):
        self.graph = nx.DiGraph()
        self.structural_eqs: Dict[str, Callable] = {}
        self.exogenous_dist: Dict[str, Callable] = {}
        self.values: Dict[str, float] = {}

    def add_variable(self, name: str,
                       parents: List[str],
                       equation: Callable,
                       exogenous: Optional[Callable] = None):
        self.graph.add_node(name)
        for p in parents:
            self.graph.add_edge(p, name)
        self.structural_eqs[name] = equation
        if exogenous:
            self.exogenous_dist[name] = exogenous

    def sample(self, interventions: Optional[Dict[str, float]] = None,
                n_samples: int = 1) -> List[Dict]:
        """
        يسحب من SCM مع interventions (do-operator).
        interventions = {"variable": value} — يقطع ويربط بالقيمة.
        """
        interventions = interventions or {}
        results = []
        for _ in range(n_samples):
            order = list(nx.topological_sort(self.graph))
            values: Dict[str, float] = {}
            for v in order:
                if v in interventions:
                    values[v] = interventions[v]
                    continue
                parents = list(self.graph.predecessors(v))
                parent_vals = {p: values[p] for p in parents}
                u = (self.exogenous_dist[v]()
                       if v in self.exogenous_dist else 0.0)
                values[v] = self.structural_eqs[v](parent_vals, u)
            results.append(values)
        return results

    def do(self, variable: str, value: float,
            n_samples: int = 1000) -> List[Dict]:
        """
        P(Y | do(X=x)) — يحسب بتدخل جراحي على SCM.
        يقطع كل edges داخلة للـvariable.
        """
        return self.sample(interventions={variable: value},
                            n_samples=n_samples)

    def observe(self, variable: str, value: float,
                 n_samples: int = 1000) -> List[Dict]:
        """
        P(Y | X=x) — conditional observation (ليس تدخل).
        يستخدم rejection sampling.
        """
        results = []
        tries = 0
        while len(results) < n_samples and tries < n_samples * 50:
            s = self.sample(n_samples=1)[0]
            if abs(s.get(variable, 0) - value) < 1e-3:
                results.append(s)
            tries += 1
        return results

    def parents(self, v: str) -> List[str]:
        return list(self.graph.predecessors(v))

    def children(self, v: str) -> List[str]:
        return list(self.graph.successors(v))

    def descendants(self, v: str) -> Set[str]:
        return nx.descendants(self.graph, v)

    def ancestors(self, v: str) -> Set[str]:
        return nx.ancestors(self.graph, v)

    def backdoor_paths(self, x: str, y: str) -> List[List[str]]:
        """
        backdoor paths بين X و Y — الطرق التي تبدأ بـX→parent(X).
        نحتاجها لمعرفة ما يجب تعديله.
        """
        g_undirected = self.graph.to_undirected()
        paths = []
        for path in nx.all_simple_paths(g_undirected, x, y, cutoff=5):
            # تحقق أنه يبدأ بـX→parent(X) (وليس X→child)
            if len(path) >= 2 and self.graph.has_edge(x, path[1]):
                continue    # هذه forward path، ليست backdoor
            paths.append(path)
        return paths


def build_albaron_scm() -> StructuralCausalModel:
    """
    SCM لعمليات Al-Baron:
      sessions → creds → DA → exfil → detection
      stealth → detection
      exploitation → detection
    """
    scm = StructuralCausalModel()

    # exogenous noise
    noise = lambda scale: (lambda: np.random.randn() * scale)

    # ── variables ──
    scm.add_variable("stealth_mode", [], lambda p, u: u,
                       exogenous=noise(0.5))
    scm.add_variable("recon_quality", [], lambda p, u: u,
                       exogenous=noise(1.0))
    scm.add_variable("sessions",
                       ["recon_quality", "stealth_mode"],
                       lambda p, u: 0.8 * p["recon_quality"] -
                                     0.3 * p["stealth_mode"] + u,
                       exogenous=noise(0.5))
    scm.add_variable("creds",
                       ["sessions", "stealth_mode"],
                       lambda p, u: 0.7 * p["sessions"] +
                                      0.2 * p["stealth_mode"] + u,
                       exogenous=noise(0.5))
    scm.add_variable("domain_admin",
                       ["creds", "sessions"],
                       lambda p, u: 0.6 * p["creds"] +
                                      0.3 * p["sessions"] + u,
                       exogenous=noise(0.3))
    scm.add_variable("detection",
                       ["stealth_mode", "sessions", "exploitation_noise"],
                       lambda p, u: (-0.7 * p["stealth_mode"] +
                                      0.5 * p["sessions"] +
                                      0.6 * p.get("exploitation_noise", 0) + u),
                       exogenous=noise(0.4))
    scm.add_variable("exploitation_noise", [], lambda p, u: u,
                       exogenous=noise(1.0))
    scm.add_variable("exfil",
                       ["domain_admin", "sessions", "detection"],
                       lambda p, u: (0.5 * p["domain_admin"] +
                                      0.4 * p["sessions"] -
                                      0.3 * p["detection"] + u),
                       exogenous=noise(0.4))
    return scm


albaron_scm = build_albaron_scm()
