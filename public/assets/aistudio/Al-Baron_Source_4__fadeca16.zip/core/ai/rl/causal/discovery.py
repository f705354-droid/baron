# language: Python, file: core/ai/rl/causal/discovery.py
# Causal discovery — يستخرج DAG من engagement data
import numpy as np
import networkx as nx
from itertools import combinations
from typing import List, Set, Dict, Optional, Tuple


class PCAlgorithm:
    """
    PC algorithm (Spirtes 2000):
      1. Start with complete graph
      2. Remove edges based on conditional independence
      3. Orient v-structures
      4. Apply Meek rules
    """
    def __init__(self, alpha: float = 0.05):
        self.alpha = alpha
        self.graph: Optional[nx.Graph] = None
        self.sepsets: Dict[Tuple[str, str], Set[str]] = {}

    def fit(self, data: np.ndarray,
             var_names: List[str]) -> nx.DiGraph:
        """
        data: (N, D) — N samples, D variables
        """
        D = data.shape[1]
        self.graph = nx.complete_graph(D)
        self.graph = nx.relabel_nodes(self.graph,
            {i: var_names[i] for i in range(D)})

        # ── Step 1: skeleton discovery ──
        for level in range(D):
            for x, y in list(self.graph.edges):
                if x not in self.graph or y not in self.graph:
                    continue
                neighbors_x = [n for n in self.graph.neighbors(x) if n != y]
                if len(neighbors_x) < level:
                    continue
                for subset in combinations(neighbors_x, level):
                    if self._cond_indep(x, y, list(subset), data, var_names):
                        self.graph.remove_edge(x, y)
                        self.sepsets[(x, y)] = set(subset)
                        self.sepsets[(y, x)] = set(subset)
                        break

        # ── Step 2: orient v-structures ──
        directed = nx.DiGraph()
        directed.add_nodes_from(self.graph.nodes)
        for x, y in self.graph.edges:
            directed.add_edge(x, y)
            directed.add_edge(y, x)

        # remove bidirected where not v-structure
        for x, z in list(self.graph.edges):
            neighbors_x = set(self.graph.neighbors(x))
            neighbors_z = set(self.graph.neighbors(z))
            common = neighbors_x & neighbors_z
            for y in common:
                if not self.graph.has_edge(x, y) and not self.graph.has_edge(y, z):
                    continue
                sep = self.sepsets.get((x, z), set())
                if y not in sep:
                    # v-structure: x → y ← z
                    if directed.has_edge(y, x):
                        directed.remove_edge(y, x)
                    if directed.has_edge(y, z):
                        directed.remove_edge(y, z)

        # ── Step 3: Meek rules (simplified) ──
        directed = self._meek_rules(directed)
        return directed

    def _cond_indep(self, x: str, y: str, z: List[str],
                     data: np.ndarray, var_names: List[str]) -> bool:
        """partial correlation test — Fisher's z"""
        ix = var_names.index(x)
        iy = var_names.index(y)
        iz = [var_names.index(v) for v in z]
        # احسب correlation matrix
        if not z:
            r = np.corrcoef(data[:, ix], data[:, iy])[0, 1]
        else:
            # partial correlation via residualization
            from sklearn.linear_model import LinearRegression
            Xz = data[:, iz]
            rx = data[:, ix] - LinearRegression().fit(Xz, data[:, ix]).predict(Xz)
            ry = data[:, iy] - LinearRegression().fit(Xz, data[:, iy]).predict(Xz)
            r = np.corrcoef(rx, ry)[0, 1]
        r = np.clip(r, -0.999, 0.999)
        n = data.shape[0]
        z_stat = 0.5 * np.log((1 + r) / (1 - r)) * np.sqrt(n - len(z) - 3)
        from scipy.stats import norm
        p = 2 * (1 - norm.cdf(abs(z_stat)))
        return p > self.alpha

    def _meek_rules(self, g: nx.DiGraph) -> nx.DiGraph:
        """Meek rules R1-R4 للتوجيه الإضافي"""
        changed = True
        while changed:
            changed = False
            for a in g.nodes:
                for b in g.successors(a):
                    if not g.has_edge(b, a):
                        continue
                    # R1: a→b, b—c, a not adjacent c ⇒ b→c
                    for c in g.successors(b) + list(g.predecessors(b)):
                        if c == a:
                            continue
                        if not g.has_edge(a, c) and not g.has_edge(c, a):
                            # b—c is undirected
                            if g.has_edge(b, c) and g.has_edge(c, b):
                                if not g.has_edge(b, c) or g.has_edge(c, b):
                                    if g.has_edge(c, b) and not g.has_edge(b, c):
                                        continue
                                    # orient b→c
                                    if g.has_edge(c, b):
                                        g.remove_edge(c, b)
                                        changed = True
        return g


class GESAlgorithm:
    """
    Greedy Equivalence Search (Chickering 2002).
    يعمل على space of CPDAGs.
    أسرع من PC على بيانات كبيرة.
    """
    def __init__(self, score_fn: str = "bic"):
        self.score_fn = score_fn

    def fit(self, data: np.ndarray, var_names: List[str]) -> nx.DiGraph:
        # simplified: forward greedy
        n, D = data.shape
        g = nx.DiGraph()
        g.add_nodes_from(var_names)
        # start empty, add edges greedily by score
        all_edges = list(combinations(var_names, 2))
        improved = True
        while improved:
            improved = False
            best_gain = 0.0
            best_edge = None
            for a, b in all_edges:
                for edge in [(a, b), (b, a)]:
                    if g.has_edge(*edge):
                        continue
                    g.add_edge(*edge)
                    if nx.is_directed_acyclic_graph(g):
                        s = self._bic(g, data, var_names)
                        if s > best_gain:
                            best_gain = s
                            best_edge = edge
                    g.remove_edge(*edge)
            if best_edge:
                g.add_edge(*best_edge)
                improved = True
        return g

    def _bic(self, g: nx.DiGraph, data: np.ndarray,
              var_names: List[str]) -> float:
        """BIC score (higher is better)"""
        from sklearn.linear_model import LinearRegression
        n, D = data.shape
        total_ll = 0.0
        n_params = 0
        for v in var_names:
            iv = var_names.index(v)
            parents = list(g.predecessors(v))
            if parents:
                ip = [var_names.index(p) for p in parents]
                Xp = data[:, ip]
                model = LinearRegression().fit(Xp, data[:, iv])
                resid = data[:, iv] - model.predict(Xp)
                n_params += len(parents) + 1
            else:
                resid = data[:, iv] - data[:, iv].mean()
                n_params += 1
            sigma2 = (resid ** 2).mean() + 1e-9
            ll = -0.5 * n * (np.log(2 * np.pi * sigma2) + 1)
            total_ll += ll
        bic = total_ll - 0.5 * n_params * np.log(n)
        return float(bic)


pc_algorithm = PCAlgorithm()
ges_algorithm = GESAlgorithm()
