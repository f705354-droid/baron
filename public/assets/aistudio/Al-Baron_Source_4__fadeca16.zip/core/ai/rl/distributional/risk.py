# language: Python, file: core/ai/rl/distributional/risk.py
# Risk measures — CVaR, VaR, distorted expectations, spectral risk
import numpy as np
from typing import Optional


class RiskMeasures:
    """
    مجموعة مقاييس المخاطر المستخدمة لتقييم توزيعات العوائد.

    سياق Al-Baron:
      - VaR يخبرنا: ما أسوأ نتيجة محتملة في α من الحالات؟
      - CVaR يخبرنا: إذا دخلنا في أسوأ α، كم متوسط الخسارة؟
      - Distorted: يسمح بتحكم أدق (Wang, proportional hazards)
    """

    @staticmethod
    def var(samples: np.ndarray, alpha: float = 0.05) -> float:
        """VaR_α — α-quantile (lower tail)"""
        return float(np.quantile(samples, alpha))

    @staticmethod
    def cvar(samples: np.ndarray, alpha: float = 0.05) -> float:
        """CVaR_α — متوسط أسوأ α من الحالات"""
        var = np.quantile(samples, alpha)
        tail = samples[samples <= var]
        if len(tail) == 0:
            return float(var)
        return float(tail.mean())

    @staticmethod
    def mean(samples: np.ndarray) -> float:
        return float(samples.mean())

    @staticmethod
    def std(samples: np.ndarray) -> float:
        return float(samples.std())

    @staticmethod
    def distorted_expectation(samples: np.ndarray,
                                distortion: str = "wang") -> float:
        """
        Distorted expectation تحت دالة تشويه g:
          ρ(X) = ∫ g(F(x)) dx
        Wang distortion: g(u) = Φ(Φ^{-1}(u) + λ)
        """
        sorted_samples = np.sort(samples)
        n = len(sorted_samples)
        if distortion == "wang":
            from scipy.stats import norm
            lam = 0.5
            u = np.linspace(0, 1, n)
            g_u = norm.cdf(norm.ppf(u) + lam)
        elif distortion == "ph":     # proportional hazards
            beta = 2.0
            u = np.linspace(0, 1, n)
            g_u = u ** beta
        elif distortion == "dual":   # dual power
            beta = 3.0
            u = np.linspace(0, 1, n)
            g_u = 1 - (1 - u) ** beta
        else:
            g_u = np.linspace(0, 1, n)
        # integral via summation
        diffs = np.diff(np.concatenate([[0], g_u]))
        return float((sorted_samples * diffs).sum())

    @staticmethod
    def entropy(samples: np.ndarray, bins: int = 30) -> float:
        hist, _ = np.histogram(samples, bins=bins, density=True)
        hist = hist + 1e-9
        hist = hist / hist.sum()
        return float(-(hist * np.log(hist)).sum())

    @staticmethod
    def downside_deviation(samples: np.ndarray, target: float = 0.0) -> float:
        """Downside deviation — انحراف الأسوأ من target"""
        diff = np.minimum(samples - target, 0)
        return float(np.sqrt((diff ** 2).mean()))

    @staticmethod
    def omega_ratio(samples: np.ndarray, threshold: float = 0.0) -> float:
        """Omega ratio — احتمالات الربح مقابل الخسارة فوق threshold"""
        gains = samples[samples > threshold] - threshold
        losses = threshold - samples[samples <= threshold]
        if losses.sum() == 0:
            return float("inf")
        return float(gains.sum() / losses.sum())


class RiskAwareSelector:
    """
    يستخدم Distributional RL outputs لاتخاذ قرار واعي بالمخاطر.
    يبدّل بين risk measures بناءً على:
      - ظروف engagement (stealth_mode، time_pressure، detected)
      - مرحلة kill chain
    """
    def __init__(self):
        self.rm = RiskMeasures()

    def select_measure(self, context: dict) -> str:
        if context.get("detected"):
            return "cvar"          # نحن مكتشفون — تجنب المخاطر
        if context.get("stealth_mode"):
            return "cvar"          # وضع التخفي
        if context.get("time_pressure"):
            return "mean"          # الوقت ضيق — انتهازي
        if context.get("has_domain_admin"):
            return "mean"          # لدينا DA — لا وقت للمخاوف
        if context.get("ot_iot"):
            return "cvar"          # OT — أي خطأ مكلف
        return "mean_cvar"         # الافتراضي — متوازن

    def rank_actions(self, action_samples: dict, context: dict) -> list:
        """
        action_samples = {action_id: np.array([samples...]), ...}
        يرجع قائمة مرتبة بالأفضل (أعلى أولاً)
        """
        measure = self.select_measure(context)
        scored = []
        for action_id, samples in action_samples.items():
            if measure == "mean":
                score = self.rm.mean(samples)
            elif measure == "cvar":
                score = self.rm.cvar(samples, 0.05)
            elif measure == "var":
                score = self.rm.var(samples, 0.05)
            elif measure == "mean_cvar":
                score = 0.6 * self.rm.mean(samples) + 0.4 * self.rm.cvar(samples, 0.05)
            elif measure == "wang":
                score = self.rm.distorted_expectation(samples, "wang")
            else:
                score = self.rm.mean(samples)
            scored.append((action_id, score))
        scored.sort(key=lambda x: -x[1])
        return scored


risk_selector = RiskAwareSelector()
