# language: Python, file: core/ai/rl/distributional/c51.py
# C51 — Categorical DQN (Bellemare, Dabney, Munos 2017)
# يتعلم توزيع العوائد بدل المتوسط — للقرارات الواعية بالمخاطر
import numpy as np
import os
import json
from typing import Tuple, List, Optional

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


STATE_DIM = 128
ACTION_DIM = 64
N_ATOMS = 51               # عدد الذرات (51 من الورقة الأصلية)
V_MIN = -150.0             # أدنى قيمة عائد (نطاق Engagement)
V_MAX = 300.0              # أعلى قيمة (عند تحقيق DA مثلاً)


class C51Net(nn.Module):
    """
    يخرج توزيع احتمالي على N_ATOMS لكل action.
    كل action له توزيع كامل للعائد — يسمح بـrisk-aware decision.
    """
    def __init__(self, state_dim=STATE_DIM, action_dim=ACTION_DIM,
                  n_atoms=N_ATOMS, hidden=256):
        super().__init__()
        self.n_atoms = n_atoms
        self.action_dim = action_dim
        self.trunk = nn.Sequential(
            nn.Linear(state_dim, hidden),
            nn.ReLU(),
            nn.Linear(hidden, hidden),
            nn.ReLU(),
        )
        self.head = nn.Linear(hidden, action_dim * n_atoms)

    def forward(self, s):
        h = self.trunk(s)
        logits = self.head(h).view(-1, self.action_dim, self.n_atoms)
        return logits                       # (B, A, N_ATOMS)


class C51Agent:
    """
    Categorical DQN:
      - projection step (Bellman → categorical distribution)
      - cross-entropy loss بين التوزيع المتوقع والهدف المسقط
      - يختار action بأعلى قيمة متوقعة
    """
    def __init__(self, model_path: str = "~/.albaron/c51.pt"):
        self.model_path = os.path.expanduser(model_path)
        self.n_atoms = N_ATOMS
        self.v_min = V_MIN
        self.v_max = V_MAX
        self.delta_z = (V_MAX - V_MIN) / (N_ATOMS - 1)
        self.support = torch.linspace(V_MIN, V_MAX, N_ATOMS) if HAS_TORCH else None

        self.net = None
        self.target_net = None
        self.optimizer = None
        if HAS_TORCH:
            self.net = C51Net()
            self.target_net = C51Net()
            self.target_net.load_state_dict(self.net.state_dict())
            self.optimizer = torch.optim.Adam(self.net.parameters(), lr=1e-4)
            if os.path.exists(self.model_path):
                try:
                    self.net.load_state_dict(torch.load(self.model_path))
                    self.target_net.load_state_dict(self.net.state_dict())
                except Exception:
                    pass
        self.step_count = 0

    def _projection(self, next_dist, rewards, dones, gamma=0.99):
        """
        يسقط التوزيع الهدف على شبكة الدعم.
        Tz = r + γ * z (مع tiling ومقاطعة على [v_min, v_max]).
        """
        B = next_dist.size(0)
        support = self.support.to(next_dist.device)
        Tz = rewards.unsqueeze(1) + (1 - dones.unsqueeze(1)) * gamma * support.unsqueeze(0)
        Tz = Tz.clamp(self.v_min, self.v_max)

        b = (Tz - self.v_min) / self.delta_z
        l = b.floor().long()
        u = b.ceil().long()

        # تعامل مع الحواف
        l[(u > 0) * (l == u)] -= 1
        u[(l < (self.n_atoms - 1)) * (l == u)] += 1

        proj = torch.zeros_like(next_dist)
        offset = torch.linspace(0, (B - 1) * self.n_atoms, B).long() \
                    .unsqueeze(1).to(next_dist.device)
        proj.view(-1).index_add_(0, (l + offset).view(-1),
                                  (next_dist * (u.float() - b)).view(-1))
        proj.view(-1).index_add_(0, (u + offset).view(-1),
                                  (next_dist * (b - l.float())).view(-1))
        return proj

    def select_action(self, state_vec: np.ndarray, available_actions: List[int],
                       epsilon: float = 0.05,
                       risk_measure: str = "mean") -> int:
        """
        risk_measure:
          mean     — القيمة المتوقعة (محايد للمخاطر)
          cvar     — Conditional VaR (يتجنب المخاطر)
          var      — VaR (يتجنب الأسوأ)
          mean_cvar — مزيج
        """
        if not available_actions:
            return 0
        if not HAS_TORCH or not self.net:
            return int(np.random.choice(available_actions))
        if np.random.rand() < epsilon:
            return int(np.random.choice(available_actions))

        with torch.no_grad():
            s = torch.from_numpy(state_vec).float().unsqueeze(0)
            logits = self.net(s)                    # (1, A, N)
            probs = F.softmax(logits, dim=-1).squeeze(0).cpu().numpy()  # (A, N)
        support = np.linspace(V_MIN, V_MAX, N_ATOMS)

        # احسب value حسب risk measure
        values = np.zeros(probs.shape[0])
        for a in range(probs.shape[0]):
            values[a] = self._compute_risk(probs[a], support, risk_measure)

        mask = np.full_like(values, -1e18)
        for a in available_actions:
            mask[a % len(values)] = values[a % len(values)]
        return int(np.argmax(mask))

    def _compute_risk(self, probs: np.ndarray, support: np.ndarray,
                       measure: str) -> float:
        if measure == "mean":
            return float((probs * support).sum())
        if measure == "var":
            # VaR 5% — أسوأ حالة
            cdf = np.cumsum(probs)
            idx = np.searchsorted(cdf, 0.05)
            return float(support[min(idx, len(support) - 1)])
        if measure == "cvar":
            # CVaR 5% — متوسط أسوأ 5%
            cdf = np.cumsum(probs)
            idx = np.searchsorted(cdf, 0.05)
            tail = probs[:idx + 1]
            if tail.sum() == 0:
                return float(support[0])
            tail_norm = tail / tail.sum()
            return float((tail_norm * support[:idx + 1]).sum())
        if measure == "mean_cvar":
            m = float((probs * support).sum())
            cdf = np.cumsum(probs)
            idx = np.searchsorted(cdf, 0.05)
            tail = probs[:idx + 1]
            if tail.sum() > 0:
                cvar = float(((tail / tail.sum()) * support[:idx + 1]).sum())
            else:
                cvar = m
            return 0.6 * m + 0.4 * cvar
        return float((probs * support).sum())

    def update(self, batch: List[dict], gamma: float = 0.99):
        if not HAS_TORCH or not self.net:
            return 0.0
        states = torch.tensor([b["state"] for b in batch], dtype=torch.float32)
        next_states = torch.tensor([b["next_state"] for b in batch],
                                     dtype=torch.float32)
        rewards = torch.tensor([b["reward"] for b in batch], dtype=torch.float32)
        dones = torch.tensor([b["done"] for b in batch], dtype=torch.float32)
        action_ids = torch.tensor(
            [b.get("action_id", 0) % ACTION_DIM for b in batch],
            dtype=torch.long)

        # احسب التوزيع الهدف
        with torch.no_grad():
            next_logits = self.target_net(next_states)         # (B, A, N)
            next_probs = F.softmax(next_logits, dim=-1)
            # argmax على mean للـaction
            next_values = (next_probs * self.support).sum(-1)  # (B, A)
            best_next = next_values.argmax(dim=1)              # (B,)
            next_dist = next_probs[range(len(batch)), best_next]  # (B, N)
            target_dist = self._projection(next_dist, rewards, dones, gamma)

        logits = self.net(states)                              # (B, A, N)
        log_probs = F.log_softmax(logits, dim=-1)
        chosen_log_probs = log_probs[range(len(batch)), action_ids]  # (B, N)
        loss = -(target_dist * chosen_log_probs).sum(dim=1).mean()

        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.net.parameters(), 10.0)
        self.optimizer.step()

        self.step_count += 1
        if self.step_count % 100 == 0:
            self.target_net.load_state_dict(self.net.state_dict())

        return float(loss.item())

    def get_distribution(self, state_vec: np.ndarray,
                          action_id: int) -> Tuple[np.ndarray, np.ndarray]:
        """يرجع (support, probabilities) للـaction — للعرض في UI"""
        if not HAS_TORCH or not self.net:
            return np.linspace(V_MIN, V_MAX, N_ATOMS), np.ones(N_ATOMS) / N_ATOMS
        with torch.no_grad():
            s = torch.from_numpy(state_vec).float().unsqueeze(0)
            logits = self.net(s).squeeze(0)
            probs = F.softmax(logits, dim=-1).cpu().numpy()
        return np.linspace(V_MIN, V_MAX, N_ATOMS), probs[action_id % ACTION_DIM]

    def save(self):
        if HAS_TORCH and self.net:
            try:
                torch.save(self.net.state_dict(), self.model_path)
            except Exception:
                pass


c51 = C51Agent()
