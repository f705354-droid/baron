# language: Python, file: core/ai/rl/distributional/iqn.py
# IQN — Implicit Quantile Networks (Dabney 2018)
# يستمر التعلم على quantiles تعسفية (sample من τ ~ U(0,1))
import numpy as np
import os
from typing import List

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


STATE_DIM = 128
ACTION_DIM = 64
COS_DIM = 64               # عدد cos features لترميز τ


class IQNNet(nn.Module):
    """
    IQN: 
      ψ(s) = state embedding
      φ(τ) = cos embedding of τ
      Z(s, a, τ) = f(ψ(s) ⊙ φ(τ))
    """
    def __init__(self, state_dim=STATE_DIM, action_dim=ACTION_DIM,
                  cos_dim=COS_DIM, hidden=256):
        super().__init__()
        self.state_net = nn.Sequential(
            nn.Linear(state_dim, hidden),
            nn.ReLU(),
        )
        # π_i = i * π (constant)
        self.register_buffer("pi_embed",
            torch.arange(1, cos_dim + 1).float() * np.pi)
        self.cos_net = nn.Sequential(
            nn.Linear(cos_dim, hidden),
            nn.ReLU(),
        )
        self.head = nn.Sequential(
            nn.Linear(hidden, hidden),
            nn.ReLU(),
            nn.Linear(hidden, action_dim),
        )

    def forward(self, s, taus):
        """
        s: (B, state_dim)
        taus: (B, N) — N sampled quantiles
        returns: (B, N, A)
        """
        B, N = taus.shape
        psi = self.state_net(s)                            # (B, H)
        # cos embedding: (B, N, H)
        cos_emb = torch.cos(taus.unsqueeze(-1) * self.pi_embed)  # (B, N, cos_dim)
        phi = self.cos_net(cos_emb)                        # (B, N, H)
        # element-wise product broadcast
        combined = psi.unsqueeze(1) * phi                  # (B, N, H)
        out = self.head(combined)                          # (B, N, A)
        return out


class IQNAgent:
    """
    IQN: أخف من C51 مع قوة تمثيلية أعلى.
    نستخدمه في الظروف التي تتغير فيها scale العوائد.
    """
    def __init__(self, model_path: str = "~/.albaron/iqn.pt",
                  n_samples: int = 32, kappa: float = 1.0):
        self.model_path = os.path.expanduser(model_path)
        self.n_samples = n_samples
        self.kappa = kappa
        self.net = None
        self.target_net = None
        self.optimizer = None
        if HAS_TORCH:
            self.net = IQNNet()
            self.target_net = IQNNet()
            self.target_net.load_state_dict(self.net.state_dict())
            self.optimizer = torch.optim.Adam(self.net.parameters(), lr=5e-5)
            if os.path.exists(self.model_path):
                try:
                    self.net.load_state_dict(torch.load(self.model_path))
                    self.target_net.load_state_dict(self.net.state_dict())
                except Exception:
                    pass
        self.step_count = 0

    def _quantile_huber_loss(self, pred, target, taus, kappa=None):
        """pred: (B, N), target: (B, N), taus: (B, N)"""
        k = kappa or self.kappa
        u = target.unsqueeze(1) - pred.unsqueeze(2)
        huber = torch.where(u.abs() <= k,
                             0.5 * u.pow(2),
                             k * (u.abs() - 0.5 * k))
        tau = taus.unsqueeze(2)                                # (B, N, 1)
        weight = (tau - (u < 0).float()).abs()
        return (weight * huber).mean(dim=2).sum(dim=1).mean()

    def select_action(self, state_vec: np.ndarray,
                       available_actions: List[int],
                       epsilon: float = 0.05,
                       risk_tau: float = 0.5) -> int:
        """
        risk_tau يتحكم في الأداء:
          0.5 → median (محايد)
          0.1 → CVaR-like (يتجنب المخاطر)
          0.9 → optimistic
        """
        if not available_actions:
            return 0
        if not HAS_TORCH or not self.net:
            return int(np.random.choice(available_actions))
        if np.random.rand() < epsilon:
            return int(np.random.choice(available_actions))

        with torch.no_grad():
            s = torch.from_numpy(state_vec).float().unsqueeze(0)
            tau = torch.full((1, 64), risk_tau)                # ثابت للاختيار
            q = self.net(s, tau).squeeze(0).mean(dim=0).cpu().numpy()
        mask = np.full_like(q, -1e18)
        for a in available_actions:
            mask[a % len(q)] = q[a % len(q)]
        return int(np.argmax(mask))

    def update(self, batch: List[dict], gamma: float = 0.99):
        if not HAS_TORCH or not self.net:
            return 0.0
        B = len(batch)
        states = torch.tensor([b["state"] for b in batch], dtype=torch.float32)
        next_states = torch.tensor([b["next_state"] for b in batch],
                                     dtype=torch.float32)
        rewards = torch.tensor([b["reward"] for b in batch], dtype=torch.float32)
        dones = torch.tensor([b["done"] for b in batch], dtype=torch.float32)
        actions = torch.tensor(
            [b.get("action_id", 0) % ACTION_DIM for b in batch],
            dtype=torch.long)

        N = self.n_samples
        # sample taus
        taus = torch.rand(B, N)
        taus_prime = torch.rand(B, N)

        with torch.no_grad():
            # target distribution
            next_q = self.target_net(next_states, taus_prime)   # (B, N, A)
            next_mean = next_q.mean(dim=1)                      # (B, A)
            best_next = next_mean.argmax(dim=1)                 # (B,)
            next_q_best = next_q[range(B), :, best_next]        # (B, N)
            target = rewards.unsqueeze(1) + \
                       (1 - dones.unsqueeze(1)) * gamma * next_q_best  # (B, N)

        # predictions
        pred_all = self.net(states, taus)                       # (B, N, A)
        pred = pred_all[range(B), :, actions]                   # (B, N)

        loss = self._quantile_huber_loss(pred, target, taus)

        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.net.parameters(), 10.0)
        self.optimizer.step()

        self.step_count += 1
        if self.step_count % 100 == 0:
            self.target_net.load_state_dict(self.net.state_dict())
        return float(loss.item())

    def get_quantiles(self, state_vec: np.ndarray, action_id: int,
                        n: int = 100):
        if not HAS_TORCH or not self.net:
            return np.array([0]), np.array([0])
        with torch.no_grad():
            s = torch.from_numpy(state_vec).float().unsqueeze(0)
            taus = torch.linspace(0.001, 0.999, n).unsqueeze(0)
            q = self.net(s, taus).squeeze(0)[:, action_id % ACTION_DIM]
        return taus.squeeze(0).cpu().numpy(), q.cpu().numpy()

    def save(self):
        if HAS_TORCH and self.net:
            try:
                torch.save(self.net.state_dict(), self.model_path)
            except Exception:
                pass


iqn = IQNAgent()
