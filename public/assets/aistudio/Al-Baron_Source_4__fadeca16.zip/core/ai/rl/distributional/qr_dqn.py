# language: Python, file: core/ai/rl/distributional/qr_dqn.py
# QR-DQN — Quantile Regression DQN (Dabney 2017)
# يمثل التوزيع عبر N quantiles بدل atoms ثابتة
import numpy as np
import os
from typing import Tuple, List

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


STATE_DIM = 128
ACTION_DIM = 64
N_QUANTILES = 200


class QRDQNNet(nn.Module):
    """يخرج N_QUANTILES قيمة لكل action"""
    def __init__(self, state_dim=STATE_DIM, action_dim=ACTION_DIM,
                  n_quantiles=N_QUANTILES, hidden=256):
        super().__init__()
        self.n_quantiles = n_quantiles
        self.action_dim = action_dim
        self.trunk = nn.Sequential(
            nn.Linear(state_dim, hidden),
            nn.ReLU(),
            nn.Linear(hidden, hidden),
            nn.ReLU(),
        )
        self.head = nn.Linear(hidden, action_dim * n_quantiles)

    def forward(self, s):
        h = self.trunk(s)
        return self.head(h).view(-1, self.action_dim, self.n_quantiles)


class QRDQNAgent:
    """
    QR-DQN:
      - يمثل Q(s,a) بN quantiles
      - Huber quantile loss (asymmetric)
      - risk-sensitive: يمكن اختيار quantile معين
    """
    def __init__(self, model_path: str = "~/.albaron/qrdqn.pt",
                  n_quantiles: int = N_QUANTILES):
        self.model_path = os.path.expanduser(model_path)
        self.n_quantiles = n_quantiles
        if HAS_TORCH:
            self.quantile_taus = torch.linspace(0.5 / n_quantiles,
                                                  1 - 0.5 / n_quantiles,
                                                  n_quantiles)
        self.net = None
        self.target_net = None
        self.optimizer = None
        if HAS_TORCH:
            self.net = QRDQNNet(n_quantiles=n_quantiles)
            self.target_net = QRDQNNet(n_quantiles=n_quantiles)
            self.target_net.load_state_dict(self.net.state_dict())
            self.optimizer = torch.optim.Adam(self.net.parameters(), lr=1e-4)
            if os.path.exists(self.model_path):
                try:
                    self.net.load_state_dict(torch.load(self.model_path))
                    self.target_net.load_state_dict(self.net.state_dict())
                except Exception:
                    pass
        self.step_count = 0

    def _quantile_huber_loss(self, pred, target, taus, kappa=1.0):
        """
        Quantile Huber loss (Dabney 2017 eq. 10)
        pred, target: (B, N)
        """
        u = target.unsqueeze(1) - pred.unsqueeze(2)             # (B, N, N)
        huber = torch.where(u.abs() <= kappa,
                             0.5 * u.pow(2),
                             kappa * (u.abs() - 0.5 * kappa))
        # asymmetric weighting
        tau = taus.view(1, -1, 1)                                # (1, N, 1)
        weight = (tau - (u < 0).float()).abs()
        return (weight * huber).mean(dim=2).sum(dim=1).mean()

    def select_action(self, state_vec: np.ndarray,
                       available_actions: List[int],
                       epsilon: float = 0.05,
                       quantile: float = 0.5) -> int:
        """
        quantile: 0.5 = median (محايد)
                  0.1 = pessimistic (يتجنب المخاطر)
                  0.9 = optimistic (يستكشف)
        """
        if not available_actions:
            return 0
        if not HAS_TORCH or not self.net:
            return int(np.random.choice(available_actions))
        if np.random.rand() < epsilon:
            return int(np.random.choice(available_actions))

        with torch.no_grad():
            s = torch.from_numpy(state_vec).float().unsqueeze(0)
            quantiles = self.net(s).squeeze(0).cpu().numpy()      # (A, N)
        # اختيار quantile حسب risk preference
        idx = int(quantile * (self.n_quantiles - 1))
        values = quantiles[:, idx]                                # (A,)
        mask = np.full_like(values, -1e18)
        for a in available_actions:
            mask[a % len(values)] = values[a % len(values)]
        return int(np.argmax(mask))

    def update(self, batch: List[dict], gamma: float = 0.99):
        if not HAS_TORCH or not self.net:
            return 0.0
        states = torch.tensor([b["state"] for b in batch], dtype=torch.float32)
        next_states = torch.tensor([b["next_state"] for b in batch],
                                     dtype=torch.float32)
        rewards = torch.tensor([b["reward"] for b in batch], dtype=torch.float32)
        dones = torch.tensor([b["done"] for b in batch], dtype=torch.float32)
        action_ids = torch.tensor(
            [b.get("action_id", 0) % ACTION_DIM for b in batch],
            dtype=torch.long)

        with torch.no_grad():
            next_q = self.target_net(next_states)                 # (B, A, N)
            next_mean = next_q.mean(dim=-1)                       # (B, A)
            best_next = next_mean.argmax(dim=1)                   # (B,)
            next_q_best = next_q[range(len(batch)), best_next]    # (B, N)
            target = rewards.unsqueeze(1) + \
                       (1 - dones.unsqueeze(1)) * gamma * next_q_best

        pred = self.net(states)[range(len(batch)), action_ids]    # (B, N)
        loss = self._quantile_huber_loss(pred, target, self.quantile_taus)

        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.net.parameters(), 10.0)
        self.optimizer.step()

        self.step_count += 1
        if self.step_count % 100 == 0:
            self.target_net.load_state_dict(self.net.state_dict())
        return float(loss.item())

    def get_quantiles(self, state_vec: np.ndarray, action_id: int
                        ) -> Tuple[np.ndarray, np.ndarray]:
        if not HAS_TORCH or not self.net:
            return np.array([0]), np.array([0])
        with torch.no_grad():
            s = torch.from_numpy(state_vec).float().unsqueeze(0)
            q = self.net(s).squeeze(0).cpu().numpy()
        taus = self.quantile_taus.cpu().numpy()
        return taus, q[action_id % ACTION_DIM]

    def save(self):
        if HAS_TORCH and self.net:
            try:
                torch.save(self.net.state_dict(), self.model_path)
            except Exception:
                pass


qrdqn = QRDQNAgent()
