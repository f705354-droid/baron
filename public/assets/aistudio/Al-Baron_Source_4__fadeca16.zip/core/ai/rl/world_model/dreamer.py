# language: Python, file: core/ai/rl/world_model/dreamer.py
# Dreamer — full agent wrapper combining RSSM + actor + critic + imagination
import os
from core.ai.rl.world_model.rssm import RSSM, world_model_trainer
from core.ai.rl.world_model.imagination import (
    ActorNet, CriticNet, DreamerPolicy, ImaginedRollout
)

try:
    import torch
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


class DreamerAgent:
    """
    يجمع كل مكونات Dreamer v3 في واجهة واحدة.
    - wm: RSSM (world model)
    - actor/critic: يعملان على latent
    - policy: تنسيق التدريب + planning
    """
    def __init__(self, model_dir: str = "~/.albaron/dreamer"):
        self.model_dir = os.path.expanduser(model_dir)
        os.makedirs(self.model_dir, exist_ok=True)
        if HAS_TORCH:
            self.wm = RSSM()
            self.actor = ActorNet()
            self.critic = CriticNet()
            self.policy = DreamerPolicy(self.wm, self.actor, self.critic,
                                          model_dir=self.model_dir)
            self.rollout = ImaginedRollout(self.wm, self.actor, self.critic)
        else:
            self.wm = self.actor = self.critic = self.policy = None
            self.rollout = None

    def observe(self, state_vector, prev_action: int = 0):
        """يعطي latent state محدث"""
        if not HAS_TORCH or not self.wm:
            return None, None
        h, z = self.wm.initial_state(batch_size=1)
        a_oh = torch.zeros(1, 64)
        a_oh[0, prev_action % 64] = 1.0
        o = torch.from_numpy(state_vector).float().unsqueeze(0)
        h, z, _ = self.wm.observe_step(h, z, a_oh, o)
        return h, z

    def act(self, h, z, epsilon: float = 0.05) -> int:
        if not self.policy:
            return 0
        return self.policy.act(h, z, epsilon=epsilon)

    def plan(self, h, z, n_candidates: int = 10, horizon: int = 15):
        if not self.policy:
            return 0, []
        return self.policy.plan(h, z, n_candidates=n_candidates,
                                  horizon=horizon)

    def train_imagination(self, h, z) -> dict:
        if not self.policy:
            return {}
        return self.policy.train_step(h, z)

    def save(self):
        if self.policy:
            self.policy.save()

    def load(self):
        if self.policy:
            self.policy.load()


dreamer_agent = DreamerAgent()
