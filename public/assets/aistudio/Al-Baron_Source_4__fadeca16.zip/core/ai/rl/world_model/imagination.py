# language: Python, file: core/ai/rl/world_model/imagination.py
# Imagination — planning داخل latent space بدل البيئة الحقيقية
# هذا قلب Dreamer: policy تتدرب على rollouts مُتخيَّلة
import numpy as np
from typing import Tuple, List, Optional

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


ACTION_DIM = 64
HORIZON = 15


if HAS_TORCH:
    class ActorNet(nn.Module):
        """
        Actor يعمل على latent state (h, z).
        يتدرب بالكامل داخل imagination.
        """
        def __init__(self, deter_dim=256, stoch_dim=32,
                      action_dim=ACTION_DIM, hidden=256):
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(deter_dim + stoch_dim, hidden),
                nn.ELU(),
                nn.Linear(hidden, hidden),
                nn.ELU(),
                nn.Linear(hidden, action_dim),
            )

        def forward(self, h, z):
            x = torch.cat([h, z], dim=-1)
            logits = self.net(x)
            return logits

    class CriticNet(nn.Module):
        """Critic على latent state"""
        def __init__(self, deter_dim=256, stoch_dim=32, hidden=256):
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(deter_dim + stoch_dim, hidden),
                nn.ELU(),
                nn.Linear(hidden, hidden),
                nn.ELU(),
                nn.Linear(hidden, 1),
            )

        def forward(self, h, z):
            x = torch.cat([h, z], dim=-1)
            return self.net(x).squeeze(-1)


class ImaginedRollout:
    """
    ينفذ rollout داخل RSSM latent space.
    يرجع: rewards، values، log_probs، states — لتدريب actor-critic.
    """
    def __init__(self, world_model, actor, critic, horizon: int = HORIZON,
                  gamma: float = 0.99, lambda_: float = 0.95):
        self.wm = world_model
        self.actor = actor
        self.critic = critic
        self.horizon = horizon
        self.gamma = gamma
        self.lambda_ = lambda_

    def run(self, h: "torch.Tensor", z: "torch.Tensor") -> dict:
        """
        h, z: latent state ابتدائي (بعد observe).
        يرجع مسار متخيل كامل.
        """
        if not HAS_TORCH:
            return {}

        rewards = []
        values = []
        log_probs = []
        continues = []
        hs = [h]
        zs = [z]

        for t in range(self.horizon):
            # actor يختار action
            logits = self.actor(h, z)
            dist = torch.distributions.Categorical(logits=logits)
            a = dist.sample()
            lp = dist.log_prob(a)
            a_onehot = F.one_hot(a, ACTION_DIM).float()

            # world model يتخيل الخطوة التالية
            h_next, z_next, _ = self.wm.imagine_step(h, z, a_onehot)

            # توقعات
            r_hat = self.wm.predict_reward(h_next, z_next)
            c_hat = self.wm.predict_continue(h_next, z_next)
            v_hat = self.critic(h_next, z_next)

            rewards.append(r_hat)
            continues.append(c_hat)
            values.append(v_hat)
            log_probs.append(lp)
            hs.append(h_next)
            zs.append(z_next)

            h, z = h_next, z_next

        return {
            "rewards": torch.stack(rewards),
            "values": torch.stack(values),
            "log_probs": torch.stack(log_probs),
            "continues": torch.stack(continues),
            "hs": torch.stack(hs),
            "zs": torch.stack(zs),
        }

    def compute_lambda_returns(self, rollout: dict) -> "torch.Tensor":
        """
        Lambda returns (Schulman GAE):
          R_t = r_t + γ * c_t * [(1-λ) V_{t+1} + λ R_{t+1}]
        """
        rewards = rollout["rewards"]
        values = rollout["values"]
        continues = rollout["continues"]
        T = rewards.size(0)

        # bootstrap بأخر قيمة
        with torch.no_grad():
            R = values[-1]
        returns = []
        for t in reversed(range(T)):
            v_next = values[t] if t == T - 1 else values[t + 1]
            R = rewards[t] + self.gamma * continues[t] * (
                (1 - self.lambda_) * v_next + self.lambda_ * R)
            returns.append(R)
        returns.reverse()
        return torch.stack(returns)


class DreamerPolicy:
    """
    يجمع RSSM + Actor + Critic.
    يدربهم على imagination rollouts.
    """
    def __init__(self, wm, actor, critic,
                  model_dir: str = "~/.albaron/dreamer"):
        import os
        self.model_dir = os.path.expanduser(model_dir)
        os.makedirs(self.model_dir, exist_ok=True)
        self.wm = wm
        self.actor = actor
        self.critic = critic

        if HAS_TORCH:
            self.actor_opt = torch.optim.Adam(actor.parameters(), lr=8e-5)
            self.critic_opt = torch.optim.Adam(critic.parameters(), lr=8e-5)
            self.rollout = ImaginedRollout(wm, actor, critic)
            self.entropy_coef = 3e-4
            self.load()

    def train_step(self, h, z) -> dict:
        """خطوة تدريب داخل الحلم"""
        if not HAS_TORCH:
            return {}
        rollout = self.rollout.run(h, z)
        returns = self.rollout.compute_lambda_returns(rollout)
        values = rollout["values"]
        log_probs = rollout["log_probs"]

        # advantage
        adv = (returns - values).detach()

        # actor loss (REINFORCE + entropy)
        actor_loss = -(log_probs * adv).mean()

        # critic loss
        critic_loss = F.mse_loss(values, returns.detach())

        # update
        self.actor_opt.zero_grad()
        actor_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(), 100.0)
        self.actor_opt.step()

        self.critic_opt.zero_grad()
        critic_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic.parameters(), 100.0)
        self.critic_opt.step()

        return {
            "actor_loss": float(actor_loss.item()),
            "critic_loss": float(critic_loss.item()),
            "return_mean": float(returns.mean().item()),
        }

    def act(self, h, z, epsilon: float = 0.05) -> int:
        """action selection من latent state"""
        if not HAS_TORCH:
            return np.random.randint(ACTION_DIM)
        if np.random.rand() < epsilon:
            return np.random.randint(ACTION_DIM)
        with torch.no_grad():
            logits = self.actor(h, z)
            probs = F.softmax(logits, dim=-1).squeeze(0).cpu().numpy()
        return int(np.argmax(probs))

    def plan(self, h, z, n_candidates: int = 10,
              horizon: int = 15) -> Tuple[int, List[dict]]:
        """
        Planning: sample N action sequences، sim في imagination،
        اختر الأفضل.
        """
        if not HAS_TORCH:
            return np.random.randint(ACTION_DIM), []

        trajectories = []
        for _ in range(n_candidates):
            # sample action sequence من actor
            h_cur, z_cur = h.clone(), z.clone()
            total_return = 0.0
            actions = []
            for t in range(horizon):
                with torch.no_grad():
                    logits = self.actor(h_cur, z_cur)
                    dist = torch.distributions.Categorical(logits=logits)
                    a = dist.sample()
                a_onehot = F.one_hot(a, ACTION_DIM).float()
                h_cur, z_cur, _ = self.wm.imagine_step(h_cur, z_cur, a_onehot)
                with torch.no_grad():
                    r = self.wm.predict_reward(h_cur, z_cur).item()
                total_return += r
                actions.append(int(a.item()))
            trajectories.append({
                "actions": actions,
                "return": total_return,
            })
        trajectories.sort(key=lambda x: -x["return"])
        return trajectories[0]["actions"][0], trajectories

    def save(self):
        if not HAS_TORCH:
            return
        import os
        try:
            torch.save(self.wm.state_dict(),
                        os.path.join(self.model_dir, "rssm.pt"))
            torch.save(self.actor.state_dict(),
                        os.path.join(self.model_dir, "actor.pt"))
            torch.save(self.critic.state_dict(),
                        os.path.join(self.model_dir, "critic.pt"))
        except Exception:
            pass

    def load(self):
        if not HAS_TORCH:
            return
        import os
        for name, module in [("rssm.pt", self.wm),
                                ("actor.pt", self.actor),
                                ("critic.pt", self.critic)]:
            p = os.path.join(self.model_dir, name)
            if os.path.exists(p):
                try:
                    module.load_state_dict(torch.load(p))
                except Exception:
                    pass


def build_dreamer():
    """factory — ينشئ كامل الـDreamer stack"""
    if not HAS_TORCH:
        return None, None, None, None
    from core.ai.rl.world_model.rssm import RSSM
    wm = RSSM()
    actor = ActorNet()
    critic = CriticNet()
    policy = DreamerPolicy(wm, actor, critic)
    return wm, actor, critic, policy


dreamer_wm, dreamer_actor, dreamer_critic, dreamer_policy = build_dreamer()
