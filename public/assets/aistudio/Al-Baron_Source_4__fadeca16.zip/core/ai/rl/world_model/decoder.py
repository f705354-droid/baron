# language: Python, file: core/ai/rl/world_model/decoder.py
# Decoder utilities — latent → observable interpretation
import numpy as np
from typing import Tuple, Optional

try:
    import torch
    import torch.nn as nn
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


class FeatureDecoder:
    """
    يفك تشفير latent state إلى معنى مفهوم للمشغل البشري.
    يحوّل (h, z) إلى:
      - predicted reward
      - predicted continue
      - top features (interpretable)
    """
    def __init__(self, wm=None):
        self.wm = wm

    def decode(self, h, z) -> dict:
        if not HAS_TORCH or self.wm is None:
            return {}
        with torch.no_grad():
            o_hat = self.wm.decode(h, z)
            r_hat = self.wm.predict_reward(h, z)
            c_hat = self.wm.predict_continue(h, z)
        return {
            "reconstructed_state": o_hat.squeeze(0).cpu().numpy().tolist(),
            "predicted_reward": float(r_hat.item()),
            "predicted_continue": float(c_hat.item()),
        }

    def describe_latent(self, h, z) -> str:
        """نص وصفي مختصر عن الحالة الحالية"""
        d = self.decode(h, z)
        if not d:
            return "(no latent)"
        return (f"reward≈{d['predicted_reward']:.2f}  "
                f"continue≈{d['predicted_continue']:.2f}")


def describe_trajectory(hs, zs, decoder: Optional[FeatureDecoder] = None
                          ) -> list:
    """يصف trajectory كامل من latents"""
    decoder = decoder or FeatureDecoder()
    out = []
    for i, (h, z) in enumerate(zip(hs, zs)):
        h_t = h.unsqueeze(0) if h.dim() == 1 else h
        z_t = z.unsqueeze(0) if z.dim() == 1 else z
        out.append({
            "step": i,
            "reward": decoder.decode(h_t, z_t).get("predicted_reward", 0.0),
            "h_norm": float(h.norm().item()),
            "z_norm": float(z.norm().item()),
        })
    return out


feature_decoder = FeatureDecoder()
