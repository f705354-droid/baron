# language: Python, file: core/ai/collab.py
# Shared AI session — multiple operators see the same chat in real-time
import json
import os
import asyncio
from typing import Optional


class CollabChat:
    """
    يشترك في جلسة AI مع operators آخرين.
    يستخدم teamserver WebSocket لبث الرسائل.
    """
    def __init__(self, teamserver_url: str = None):
        self.url = teamserver_url or os.getenv(
            "AL-BARON_TEAMSERVER", "ws://localhost:8000/ws/operator")
        self.ws = None
        self.room_id = None
        self.on_message = None

    async def connect(self, token: str, room_id: str):
        try:
            import websockets
            self.ws = await websockets.connect(
                f"{self.url}?token={token}")
            self.room_id = room_id
            await self.ws.send(json.dumps({
                "type": "join_room", "room_id": room_id,
                "kind": "ai_chat",
            }))
            asyncio.create_task(self._listen())
        except Exception:
            pass

    async def _listen(self):
        try:
            async for msg in self.ws:
                data = json.loads(msg)
                if data.get("type") == "ai_message" and self.on_message:
                    self.on_message(data)
        except Exception:
            pass

    async def send(self, role: str, content: str):
        if self.ws:
            await self.ws.send(json.dumps({
                "type": "ai_message",
                "room_id": self.room_id,
                "role": role, "content": content,
            }))


collab_chat = CollabChat()
