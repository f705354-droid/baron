# language: Python, file: core/ai/embeddings.py
# Real neural embeddings — sentence-transformers + FAISS + hybrid search
import os
import json
import sqlite3
import threading
import numpy as np
from typing import List, Dict, Optional, Tuple
from datetime import datetime


class NeuralEmbeddings:
    """
    Sentence-transformers embeddings + FAISS index + BM25 hybrid search.
    Fallback إلى TF-IDF hashing إذا المكتبات غائبة.
    """
    def __init__(self, db_path: str = "~/.albaron/ai_memory.db",
                  model_name: str = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"):
        self.db_path = os.path.expanduser(db_path)
        self.model_name = os.getenv("AL-BARON_EMBED_MODEL", model_name)
        self.model = None
        self.dim = 384
        self.index = None
        self.id_map = []     # FAISS index → msg_id
        self._lock = threading.Lock()
        self.available = False
        self._try_load()

    def _try_load(self):
        try:
            from sentence_transformers import SentenceTransformer
            self.model = SentenceTransformer(self.model_name)
            self.dim = self.model.get_embedding_dimension()
            self.available = True
            self._init_faiss()
        except Exception as e:
            print(f"[embeddings] neural not available: {e} — falling back to hashing")
            self.available = False

    def _init_faiss(self):
        try:
            import faiss
            # Inner product on normalized vectors = cosine
            self.index = faiss.IndexFlatIP(self.dim)
            # load existing vectors from DB
            self._load_existing()
        except Exception as e:
            print(f"[embeddings] faiss missing: {e}")
            self.index = None

    def _load_existing(self):
        if not self.index:
            return
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        c = conn.cursor()
        try:
            rows = c.execute("""
                SELECT m.id, e.vec FROM messages m
                JOIN embeddings e ON e.msg_id=m.id
                WHERE e.vec IS NOT NULL
                ORDER BY m.id ASC
            """).fetchall()
            vecs = []
            ids = []
            for mid, vec_json in rows:
                try:
                    v = json.loads(vec_json)
                    if len(v) == self.dim:
                        vecs.append(v)
                        ids.append(mid)
                except Exception:
                    continue
            if vecs:
                arr = np.array(vecs, dtype=np.float32)
                # normalize
                norms = np.linalg.norm(arr, axis=1, keepdims=True)
                norms[norms == 0] = 1
                arr = arr / norms
                self.index.add(arr)
                self.id_map = ids
        finally:
            conn.close()

    # ==================== encode ====================
    def encode(self, text: str) -> List[float]:
        if self.available and self.model:
            try:
                v = self.model.encode([text], normalize_embeddings=True)[0]
                return v.tolist()
            except Exception:
                pass
        return self._hash_fallback(text)

    def encode_batch(self, texts: List[str]) -> List[List[float]]:
        if self.available and self.model:
            try:
                arr = self.model.encode(texts, normalize_embeddings=True,
                                          batch_size=32, show_progress_bar=False)
                return arr.tolist()
            except Exception:
                pass
        return [self._hash_fallback(t) for t in texts]

    def _hash_fallback(self, text: str, dim: int = 256) -> List[float]:
        import hashlib, re, math
        tokens = re.findall(r"[a-z0-9_]+", text.lower())
        vec = [0.0] * dim
        for t in tokens:
            h = int(hashlib.md5(t.encode()).hexdigest()[:8], 16)
            vec[h % dim] += 1.0 if (h >> 31) & 1 == 0 else -1.0
        n = math.sqrt(sum(x * x for x in vec)) or 1.0
        return [x / n for x in vec]

    # ==================== add ====================
    def add(self, msg_id: int, text: str):
        vec = self.encode(text)
        with self._lock:
            if self.index:
                try:
                    import faiss
                    arr = np.array([vec], dtype=np.float32)
                    norms = np.linalg.norm(arr, axis=1, keepdims=True)
                    norms[norms == 0] = 1
                    arr = arr / norms
                    self.index.add(arr)
                    self.id_map.append(msg_id)
                except Exception:
                    pass
            # also persist in DB
            conn = sqlite3.connect(self.db_path, check_same_thread=False)
            try:
                conn.execute("INSERT INTO embeddings(msg_id, vec) VALUES(?,?)",
                              (msg_id, json.dumps(vec)))
                conn.commit()
            finally:
                conn.close()

    # ==================== search ====================
    def search(self, query: str, k: int = 10,
                session_id: Optional[str] = None,
                min_score: float = 0.2) -> List[Dict]:
        if not self.available:
            # fallback لـhashing search
            return self._hash_search(query, k, session_id)
        qv = self.encode(query)
        with self._lock:
            if not self.index:
                return self._hash_search(query, k, session_id)
            try:
                arr = np.array([qv], dtype=np.float32)
                norms = np.linalg.norm(arr, axis=1, keepdims=True)
                norms[norms == 0] = 1
                arr = arr / norms
                scores, idxs = self.index.search(arr, min(k * 3, len(self.id_map)))
            except Exception:
                return self._hash_search(query, k, session_id)

        # جمع نتائج
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        try:
            out = []
            for score, idx in zip(scores[0], idxs[0]):
                if idx < 0 or idx >= len(self.id_map):
                    continue
                if score < min_score:
                    continue
                mid = self.id_map[idx]
                row = conn.execute("""
                    SELECT role, content, ts, session_id FROM messages
                    WHERE id=?
                """, (mid,)).fetchone()
                if not row:
                    continue
                role, content, ts, sid = row
                if session_id and sid != session_id:
                    continue
                out.append({
                    "id": mid, "role": role, "content": content,
                    "ts": ts, "session_id": sid, "score": float(score),
                })
                if len(out) >= k:
                    break
            return out
        finally:
            conn.close()

    def _hash_search(self, query: str, k: int,
                      session_id: Optional[str]) -> List[Dict]:
        qv = np.array(self._hash_fallback(query), dtype=np.float32)
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        try:
            rows = conn.execute("""
                SELECT m.id, m.role, m.content, m.ts, m.session_id, e.vec
                FROM messages m LEFT JOIN embeddings e ON e.msg_id=m.id
                WHERE (? IS NULL OR m.session_id=?)
                ORDER BY m.id DESC LIMIT 3000
            """, (session_id, session_id)).fetchall()
        finally:
            conn.close()
        scored = []
        for mid, role, content, ts, sid, vj in rows:
            try:
                if vj:
                    v = np.array(json.loads(vj), dtype=np.float32)
                    if len(v) != len(qv):
                        v = np.array(self._hash_fallback(content), dtype=np.float32)
                else:
                    v = np.array(self._hash_fallback(content), dtype=np.float32)
                score = float(np.dot(qv, v))
                if score > 0.05:
                    scored.append({
                        "id": mid, "role": role, "content": content,
                        "ts": ts, "session_id": sid, "score": score,
                    })
            except Exception:
                continue
        scored.sort(key=lambda x: -x["score"])
        return scored[:k]

    # ==================== hybrid search ====================
    def hybrid_search(self, query: str, k: int = 10,
                       session_id: Optional[str] = None) -> List[Dict]:
        """يجمع semantic + BM25 keyword للدقة"""
        sem = self.search(query, k=k * 2, session_id=session_id)
        kw = self._keyword_search(query, k=k * 2, session_id=session_id)

        # RRF (Reciprocal Rank Fusion)
        scores = {}
        for i, r in enumerate(sem):
            scores[r["id"]] = scores.get(r["id"], 0) + 1.0 / (60 + i)
        for i, r in enumerate(kw):
            scores[r["id"]] = scores.get(r["id"], 0) + 1.0 / (60 + i)

        by_id = {r["id"]: r for r in sem + kw}
        ranked = sorted(scores.items(), key=lambda x: -x[1])
        out = []
        for mid, _ in ranked[:k]:
            if mid in by_id:
                out.append(by_id[mid])
        return out

    def _keyword_search(self, query: str, k: int,
                         session_id: Optional[str]) -> List[Dict]:
        terms = [t for t in query.lower().split() if len(t) > 2]
        if not terms:
            return []
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        try:
            where = " AND ".join(["(LOWER(content) LIKE ?)"] * len(terms))
            params = [f"%{t}%" for t in terms]
            if session_id:
                where += " AND session_id=?"
                params.append(session_id)
            rows = conn.execute(f"""
                SELECT id, role, content, ts, session_id FROM messages
                WHERE {where}
                ORDER BY id DESC LIMIT ?
            """, params + [k]).fetchall()
            return [{"id": r[0], "role": r[1], "content": r[2],
                      "ts": r[3], "session_id": r[4],
                      "score": 1.0 - i * 0.05}
                    for i, r in enumerate(rows)]
        finally:
            conn.close()

    # ==================== reindex ====================
    def reindex_all(self, progress_cb=None):
        """يعيد فهرسة كل الرسائل — يستخدمه عند تغيير النموذج"""
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        try:
            rows = conn.execute("SELECT id, content FROM messages ORDER BY id").fetchall()
            total = len(rows)
            # reset
            self.index = None
            self.id_map = []
            self._init_faiss()
            if progress_cb:
                progress_cb(0, total)
            batch = []
            for i, (mid, content) in enumerate(rows):
                batch.append((mid, content))
                if len(batch) >= 64:
                    self._index_batch(batch)
                    batch = []
                    if progress_cb:
                        progress_cb(i + 1, total)
            if batch:
                self._index_batch(batch)
            if progress_cb:
                progress_cb(total, total)
        finally:
            conn.close()

    def _index_batch(self, batch):
        if not self.index:
            return
        try:
            import faiss
            texts = [c for _, c in batch]
            arr = np.array(self.encode_batch(texts), dtype=np.float32)
            norms = np.linalg.norm(arr, axis=1, keepdims=True)
            norms[norms == 0] = 1
            arr = arr / norms
            self.index.add(arr)
            for mid, _ in batch:
                self.id_map.append(mid)
        except Exception:
            pass


neural_embeddings = NeuralEmbeddings()
