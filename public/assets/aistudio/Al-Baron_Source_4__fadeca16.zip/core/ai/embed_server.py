# language: Python, file: core/ai/embed_server.py
# FastAPI embedding server — for distributed RAG
from fastapi import FastAPI
from pydantic import BaseModel
from typing import List
from sentence_transformers import SentenceTransformer
import os

app = FastAPI()
model = SentenceTransformer(os.getenv("MODEL",
    "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"))

class Batch(BaseModel):
    texts: List[str]

@app.post("/embed")
def embed(batch: Batch):
    vecs = model.encode(batch.texts, normalize_embeddings=True,
                          batch_size=32).tolist()
    return {"vectors": vecs, "dim": len(vecs[0]) if vecs else 0}

@app.get("/health")
def health():
    return {"ok": True, "model": model._model_card_vars.get("model_name", "")}
