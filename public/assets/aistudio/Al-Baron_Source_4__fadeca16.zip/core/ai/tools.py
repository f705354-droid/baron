# language: Python, file: core/ai/tools.py
# Agentic tools — AI can call real functions (function calling / tool use)
import json
import os
import subprocess
from typing import Dict, Callable, Any


class ToolRegistry:
    """سجل أدوات يستدعيها AI خلال المحادثة"""

    def __init__(self, app=None):
        self.app = app
        self._tools: Dict[str, dict] = {}
        self._register_builtins()

    def _register_builtins(self):
        self.register("get_sessions",
            "يعيد كل الجلسات النشطة",
            {}, self._get_sessions)
        self.register("get_facts",
            "يعيد حقائق مستخلصة من الجلسة (creds, CVEs, hosts)",
            {"session_id": "str"}, self._get_facts)
        self.register("dispatch_task",
            "يرسل أمر إلى beacon معين",
            {"sid": "str", "task": "str"}, self._dispatch_task)
        self.register("read_log",
            "يقرأ آخر N سطر من سجل المنصة",
            {"lines": "int"}, self._read_log)
        self.register("search_memory",
            "بحث دلالي في ذاكرة المحادثات",
            {"query": "str"}, self._search_memory)
        self.register("query_cve",
            "يبحث عن CVE في قاعدة بيانات محلية",
            {"cve_id": "str"}, self._query_cve)
        self.register("write_file",
            "يكتب ملف على القرص",
            {"path": "str", "content": "str"}, self._write_file)
        self.register("read_file",
            "يقرأ ملف من القرص",
            {"path": "str"}, self._read_file)
        self.register("run_shell",
            "يشغّل أمر shell ويرجع output",
            {"cmd": "str"}, self._run_shell)
        self.register("compile_check",
            "يتحقق من صحة بناء كود C/C++ بدون تشغيل",
            {"path": "str", "lang": "str"}, self._compile_check)

    def register(self, name: str, description: str,
                  params: dict, fn: Callable):
        self._tools[name] = {
            "name": name, "description": description,
            "params": params, "fn": fn,
        }

    def schemas(self) -> list:
        """يرجع schemas جاهزة لـAnthropic/OpenAI tool use API"""
        return [{
            "name": t["name"],
            "description": t["description"],
            "input_schema": {
                "type": "object",
                "properties": {
                    k: {"type": "string" if v == "str" else
                        "integer" if v == "int" else "number"}
                    for k, v in t["params"].items()
                },
            },
        } for t in self._tools.values()]

    def call(self, name: str, args: dict) -> Any:
        t = self._tools.get(name)
        if not t:
            return {"error": f"unknown tool: {name}"}
        try:
            return t["fn"](**args)
        except Exception as e:
            return {"error": str(e)}

    # ==================== implementations ====================
    def _get_sessions(self):
        if not self.app:
            return {}
        out = {}
        for key in ("c2_ui", "c2", "lan", "ad"):
            mod = self.app.modules.get(key)
            if mod and hasattr(mod, "sessions"):
                out.update(mod.sessions)
        return out

    def _get_facts(self, session_id: str):
        from core.ai.memory import memory
        return memory.get_facts(session_id)

    def _dispatch_task(self, sid: str, task: str):
        if not self.app:
            return {"error": "app not attached"}
        ui = self.app.modules.get("c2_ui")
        if ui and hasattr(ui, "on_dispatch"):
            ui.on_dispatch(sid, task)
            return {"ok": True, "sid": sid, "task": task}
        return {"error": "c2_ui not available"}

    def _read_log(self, lines: int = 100):
        if not self.app:
            return ""
        log = self.app.log.get("1.0", "end")
        return "\n".join(log.splitlines()[-lines:])

    def _search_memory(self, query: str):
        from core.ai.memory import memory
        return memory.search(query, limit=10)

    def _query_cve(self, cve_id: str):
        # بحث محلي في DB — نستخدم index.json بسيط
        path = os.path.expanduser("~/.albaron/cve_index.json")
        if not os.path.exists(path):
            return {"error": "no CVE index — run: download-cve-index"}
        with open(path) as f:
            db = json.load(f)
        return db.get(cve_id.upper(), {"error": "not found"})

    def _write_file(self, path: str, content: str):
        path = os.path.expanduser(path)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as f:
            f.write(content)
        return {"ok": True, "path": path,
                 "bytes": len(content)}

    def _read_file(self, path: str):
        path = os.path.expanduser(path)
        try:
            with open(path) as f:
                return f.read()
        except Exception as e:
            return {"error": str(e)}

    def _run_shell(self, cmd: str):
        # sandbox بسيط — يمنع أوامر مدمرة
        blocked = ["rm -rf /", "mkfs", "dd if=/dev/zero",
                    ":(){ :|:& };:"]
        for b in blocked:
            if b in cmd:
                return {"error": "blocked"}
        try:
            p = subprocess.run(cmd, shell=True, capture_output=True,
                                text=True, timeout=30)
            return {"stdout": p.stdout[-4000:],
                     "stderr": p.stderr[-2000:],
                     "returncode": p.returncode}
        except subprocess.TimeoutExpired:
            return {"error": "timeout 30s"}
        except Exception as e:
            return {"error": str(e)}

    def _compile_check(self, path: str, lang: str = "c"):
        path = os.path.expanduser(path)
        if lang in ("c", "cpp"):
            cc = "gcc" if lang == "c" else "g++"
            cmd = f"{cc} -fsyntax-only {path}"
        elif lang == "python":
            cmd = f"python3 -m py_compile {path}"
        else:
            return {"error": "unsupported lang"}
        return self._run_shell(cmd)


registry = ToolRegistry()
