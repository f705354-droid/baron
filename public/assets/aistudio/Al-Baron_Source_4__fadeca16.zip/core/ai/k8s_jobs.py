# language: Python, file: core/ai/k8s_jobs.py
# Distributed AI — dispatch heavy inference/analysis to K8s GPU pool
import os
import uuid
import json
import subprocess
import time
import yaml
from typing import List, Dict, Optional


class K8sAIJobs:
    """
    يشغّل مهام AI ثقيلة على K8s:
      - batch analysis لآلاف النتائج
      - parallel scan enrichment
      - continuous RAG indexing
      - fine-tune jobs (مدمج مع finetune.py)
    """
    def __init__(self, namespace: str = "albaron"):
        self.ns = namespace
        self.jobs: Dict[str, dict] = {}

    # ==================== batch AI analyze ====================
    def submit_batch_analysis(self, items: List[dict],
                                prompt_template: str,
                                model: str = "claude-sonnet-4-20250514",
                                parallel: int = 8) -> str:
        """
        يقسّم items إلى shards، يشغل container لكل shard.
        الاستخدام: تحليل 10,000 host من مسح واحد.
        """
        job_id = f"batch-{uuid.uuid4().hex[:8]}"
        shards = self._shard(items, parallel)

        manifest = {
            "apiVersion": "batch/v1",
            "kind": "Job",
            "metadata": {
                "name": job_id,
                "namespace": self.ns,
                "labels": {"app": "albaron-batch-ai", "job-id": job_id},
            },
            "spec": {
                "parallelism": parallel,
                "completions": len(shards),
                "backoffLimit": 2,
                "template": {
                    "spec": {
                        "restartPolicy": "Never",
                        "containers": [{
                            "name": "analyzer",
                            "image": "albaron/ai-worker:latest",
                            "command": ["python", "-m", "core.ai.batch_worker"],
                            "env": [
                                {"name": "JOB_ID", "value": job_id},
                                {"name": "MODEL", "value": model},
                                {"name": "PROMPT_TEMPLATE",
                                 "value": prompt_template},
                                {"name": "SHARDS", "value":
                                 json.dumps([s for s in shards])},
                                {"name": "ANTHROPIC_API_KEY",
                                 "valueFrom": {"secretKeyRef": {
                                     "name": "albaron-secrets",
                                     "key": "anthropic-key"}}},
                                {"name": "REDIS_URL", "value":
                                 "redis://redis:6379/1"},
                            ],
                            "resources": {
                                "requests": {"memory": "1Gi", "cpu": "500m"},
                                "limits": {"memory": "4Gi", "cpu": "2000m"},
                            },
                        }],
                    },
                },
            },
        }
        self._apply(job_id, manifest)
        return job_id

    # ==================== streaming AI ====================
    def submit_parallel_reasoning(self, questions: List[str],
                                    model: str = "claude-sonnet-4-20250514") -> str:
        """
        يشغّل N containers، كل واحد يجاوب على مجموعة أسئلة.
        للـagentic loop: 100 سؤال بالتوازي بدل التسلسل.
        """
        job_id = f"reason-{uuid.uuid4().hex[:8]}"
        shards = self._shard(questions, min(16, len(questions)))

        manifest = {
            "apiVersion": "batch/v1",
            "kind": "Job",
            "metadata": {"name": job_id, "namespace": self.ns,
                          "labels": {"app": "albaron-reasoning"}},
            "spec": {
                "parallelism": len(shards),
                "completions": len(shards),
                "backoffLimit": 1,
                "template": {
                    "spec": {
                        "restartPolicy": "Never",
                        "containers": [{
                            "name": "reasoner",
                            "image": "albaron/ai-worker:latest",
                            "command": ["python", "-m", "core.ai.reason_worker"],
                            "env": [
                                {"name": "MODEL", "value": model},
                                {"name": "QUESTIONS",
                                 "value": json.dumps(shards)},
                                {"name": "RESULT_KEY", "value": job_id},
                                {"name": "REDIS_URL",
                                 "value": "redis://redis:6379/1"},
                            ],
                        }],
                    },
                },
            },
        }
        self._apply(job_id, manifest)
        return job_id

    # ==================== continuous indexing ====================
    def submit_indexing_daemon(self, db_dsn: str, embed_model: str) -> str:
        """Deployment مستمر يعيد فهرسة الرسائل الجديدة"""
        name = "ai-indexer"
        manifest = {
            "apiVersion": "apps/v1",
            "kind": "Deployment",
            "metadata": {"name": name, "namespace": self.ns},
            "spec": {
                "replicas": 1,
                "selector": {"matchLabels": {"app": name}},
                "template": {
                    "metadata": {"labels": {"app": name}},
                    "spec": {
                        "containers": [{
                            "name": "indexer",
                            "image": "albaron/ai-worker:latest",
                            "command": ["python", "-m",
                                         "core.ai.indexer_daemon"],
                            "env": [
                                {"name": "AL-BARON_DSN", "value": db_dsn},
                                {"name": "EMBED_MODEL", "value": embed_model},
                                {"name": "INTERVAL_SEC", "value": "60"},
                            ],
                            "resources": {
                                "requests": {"memory": "1Gi", "cpu": "500m"},
                                "limits": {"memory": "4Gi", "cpu": "2000m"},
                            },
                        }],
                    },
                },
            },
        }
        self._apply(name, manifest, kind="deployment")
        return name

    # ==================== GPU model server ====================
    def submit_model_server(self, model_name: str,
                              replicas: int = 1,
                              gpu: str = "a100-40gb") -> str:
        """
        ينشر vLLM server لنموذج مفتوح على GPU pool.
        الاستخدام: بديل محلي لـClaude/GPT.
        """
        name = f"vllm-{model_name.split('/')[-1][:20]}"
        name = name.replace(".", "-").lower()
        manifest = {
            "apiVersion": "apps/v1",
            "kind": "Deployment",
            "metadata": {"name": name, "namespace": self.ns,
                          "labels": {"app": "vllm", "model": model_name}},
            "spec": {
                "replicas": replicas,
                "selector": {"matchLabels": {"app": "vllm",
                                              "model": model_name}},
                "template": {
                    "metadata": {"labels": {"app": "vllm",
                                             "model": model_name}},
                    "spec": {
                        "nodeSelector": {"gpu": gpu},
                        "tolerations": [{
                            "key": "nvidia.com/gpu", "operator": "Exists",
                            "effect": "NoSchedule",
                        }],
                        "containers": [{
                            "name": "vllm",
                            "image": "vllm/vllm-openai:latest",
                            "args": [
                                "--model", model_name,
                                "--max-model-len", "8192",
                                "--gpu-memory-utilization", "0.9",
                                "--dtype", "auto",
                            ],
                            "ports": [{"containerPort": 8000}],
                            "resources": {
                                "limits": {"nvidia.com/gpu": 1,
                                            "memory": "80Gi"},
                                "requests": {"nvidia.com/gpu": 1,
                                              "memory": "40Gi"},
                            },
                        }],
                    },
                },
            },
        }
        service = {
            "apiVersion": "v1",
            "kind": "Service",
            "metadata": {"name": name, "namespace": self.ns},
            "spec": {
                "selector": {"app": "vllm", "model": model_name},
                "ports": [{"port": 8000, "targetPort": 8000}],
            },
        }
        self._apply(name, manifest, kind="deployment")
        self._apply(name, service, kind="service")
        url = f"http://{name}.{self.ns}.svc.cluster.local:8000"
        return url

    # ==================== helpers ====================
    def _shard(self, items: list, n: int) -> List[list]:
        if n <= 0:
            n = 1
        size = max(1, len(items) // n + (1 if len(items) % n else 0))
        return [items[i:i+size] for i in range(0, len(items), size)]

    def _apply(self, name: str, manifest: dict, kind: str = "job"):
        path = f"/tmp/{name}.yaml"
        with open(path, "w") as f:
            yaml.safe_dump(manifest, f)
        try:
            subprocess.run(["kubectl", "apply", "-f", path], check=True,
                            capture_output=True)
            self.jobs[name] = {"kind": kind, "manifest": manifest,
                                "created": time.time()}
        except Exception as e:
            print(f"[k8s-jobs] apply failed: {e}")

    def job_status(self, name: str) -> dict:
        try:
            out = subprocess.run(
                ["kubectl", "-n", self.ns, "get", "job", name, "-o", "json"],
                capture_output=True, text=True, check=True)
            return json.loads(out.stdout)
        except Exception:
            return {}

    def tail_logs(self, name: str, follow: bool = False,
                   tail: int = 200):
        args = ["kubectl", "-n", self.ns, "logs",
                 f"job/{name}", f"--tail={tail}"]
        if follow:
            args.append("-f")
        subprocess.run(args)

    def wait_completion(self, name: str, timeout: int = 3600) -> bool:
        start = time.time()
        while time.time() - start < timeout:
            st = self.job_status(name)
            status = st.get("status", {})
            if status.get("succeeded"):
                return True
            if status.get("failed"):
                return False
            time.sleep(5)
        return False

    def cleanup(self, name: str):
        subprocess.run(["kubectl", "-n", self.ns, "delete", "job", name,
                         "--ignore-not-found"], capture_output=True)


ai_jobs = K8sAIJobs()
