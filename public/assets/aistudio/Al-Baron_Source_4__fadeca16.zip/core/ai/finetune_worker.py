# language: Python, file: core/ai/finetune_worker.py
# Container entrypoint for K8s finetune job
import os
import sys
from core.ai.finetune import FinetunePipeline


def main():
    base = os.getenv("BASE_MODEL", "unsloth/llama-3.1-8b-instruct")
    epochs = int(os.getenv("EPOCHS", "3"))
    train_path = os.getenv("TRAIN_PATH", "/data/train.jsonl")
    out_dir = os.getenv("OUTPUT_DIR", "/out")

    pipe = FinetunePipeline(output_dir=out_dir)
    if not os.path.exists(train_path):
        print(f"[worker] no training data at {train_path}")
        sys.exit(1)

    # copy data into output_dir for pipeline
    import shutil
    os.makedirs(out_dir, exist_ok=True)
    shutil.copy(train_path, os.path.join(out_dir, "train.jsonl"))

    adapter = pipe.train_lora_local(base_model=base, epochs=epochs)
    if adapter:
        print(f"[worker] done: {adapter}")
    else:
        print("[worker] training failed")
        sys.exit(2)


if __name__ == "__main__":
    main()
