# language: Python, file: core/ai/autonomous.py
# Autonomous agent — goal-driven operation with guardrails (HRL + Bayesian + Coq)
import os
import json
import time
import threading
import uuid
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Callable
from core.ai.memory import memory
from core.ai.agents import AGENTS
from core.ai.tools import registry
from core.ai.guardrails import Guardrails, Budget, StopCondition

# استيراد وحدات HRL و Bayesian والتحقق الرسمي
from core.ai.rl.hrl.manager import manager, featurize_manager_state
from core.ai.rl.hrl.worker import worker, featurize_worker_state
from core.ai.rl.hrl.intrinsic import intrinsic
from core.ai.rl.bayesian.ensemble import ensemble
from core.ai.rl.bayesian.thompson import ua_router
from core.ai.formal.invariants_runtime import combined_checker


AUTONOMOUS_SYSTEM = """أنت وكيل مستقل داخل Al-Baron يعمل بنظام التعلم الهرمي المعزز (HRL) والاستدلال البايزي. تعمل بدون تدخل بشري.

الهدف الحالي: {goal}
معايير النجاح: {success_criteria}
القيود: {constraints}
الميزانية: {budget}

السياق حتى الآن:
{context}

الأدوات المتاحة لك:
{tools}
"""


class AutonomousAgent:
    """
    وكيل مستقل يخطط وينفذ نحو هدف باستخدام HRL, Bayesian, والتحقق الرسمي.
    """
    def __init__(self, app, guardrails: Guardrails = None):
        self.app = app
        self.guardrails = guardrails or Guardrails()
        self.registry = registry
        self.registry.app = app

        # state
        self.running = False
        self.paused = False
        self.thread: Optional[threading.Thread] = None
        self.run_id = None
        self.goal = ""
        self.history: List[dict] = []
        self.results: List[dict] = []
        self.on_event: Optional[Callable] = None

    # ==================== control ====================
    def start(self, goal: str, success_criteria: str = "",
               constraints: str = "", max_iterations: int = 50,
               max_minutes: int = 60, max_usd: float = 5.0,
               on_event: Callable = None) -> str:
        if self.running:
            return self.run_id or ""

        self.run_id = uuid.uuid4().hex[:8]
        self.goal = goal
        self.history = []
        self.results = []
        self.on_event = on_event
        self.running = True
        self.paused = False

        self.guardrails = Guardrails(
            budget=Budget(max_usd=max_usd, max_tokens=500000),
            stop=StopCondition(
                max_iterations=max_iterations,
                max_minutes=max_minutes,
                max_consecutive_failures=3,
            )
        )

        memory.record_episode("global", "autonomous_start", {
            "run_id": self.run_id, "goal": goal,
            "criteria": success_criteria,
        })

        self.thread = threading.Thread(
            target=self._loop_v2,
            args=(goal, success_criteria, constraints),
            daemon=True)
        self.thread.start()
        self._emit("start", {"run_id": self.run_id, "goal": goal})
        return self.run_id

    def pause(self):
        self.paused = True
        self._emit("paused", {})

    def resume(self):
        self.paused = False
        self._emit("resumed", {})

    def stop(self, reason: str = "user_abort"):
        self.running = False
        self._emit("stopped", {"reason": reason})
        memory.record_episode("global", "autonomous_stop", {
            "run_id": self.run_id, "reason": reason,
            "iterations": len(self.history),
        })

    # ==================== hierarchical loop (HRL + Bayesian + Coq) ====================
    def _loop_v2(self, goal: str, success_criteria: str, constraints: str):
        """
        Hierarchical loop:
          Outer: Manager يختار option كل K steps
          Inner: Worker ينفذ primitive actions داخل option
          Verification: combined_checker على كل action
          Curiosity: intrinsic bonus يُضاف للـreward
        """
        iteration = 0
        consecutive_fails = 0
        start_time = time.time()
        current_option = None
        option_return = 0.0

        while self.running:
            if self.paused:
                time.sleep(2)
                continue

            # ── budget/time checks ──
            if iteration >= self.guardrails.stop.max_iterations:
                self.stop("max_iterations")
                break
            if (time.time() - start_time) / 60 > self.guardrails.stop.max_minutes:
                self.stop("timeout")
                break
            if self.guardrails.budget.exceeded():
                self.stop("budget_exceeded")
                break

            iteration += 1
            self._emit("iteration", {"n": iteration})

            # ── high-level: Manager يختار option ──
            ctx = self._gather_context()
            manager_state = featurize_manager_state(ctx)
            if current_option is None or manager.should_terminate(
                    manager_state, current_option, ctx):
                # أنهِ الـ option السابق
                if current_option:
                    success = current_option.termination(ctx)
                    manager.update_option_stats(
                        current_option.name, success, option_return)
                    self._emit("option_done", {
                        "name": current_option.name,
                        "success": success,
                        "return": option_return,
                        "steps": current_option.steps_taken,
                    })
                # اختر option جديد
                current_option = manager.select_option(manager_state, ctx)
                if current_option is None:
                    self.stop("no_applicable_options")
                    break
                current_option.steps_taken = 0
                current_option.reward_accum = 0.0
                current_option.entry_state = dict(ctx)
                option_return = 0.0
                self._emit("option_start", {"name": current_option.name})

            # ── low-level: Worker يختار action ──
            worker_state = featurize_worker_state(ctx, current_option)
            tool, args = worker.select_action(
                worker_state, current_option, ctx)

            # ── uncertainty-aware routing ──
            routing = ua_router.decide(worker_state,
                available_actions=list(range(64)))

            # ── verify via Coq + TLA+ ──
            verify_state = {
                "iteration": iteration,
                "tokens_used": self.guardrails.budget.tokens,
                "minutes_elapsed": (time.time() - start_time) / 60,
                "auto_approve": self.guardrails.auto_approve,
                "goal_reached": False,
                "approvals": set(),
                "max_iterations": self.guardrails.stop.max_iterations,
                "max_tokens": self.guardrails.budget.max_tokens,
                "max_minutes": self.guardrails.stop.max_minutes,
            }
            verification = combined_checker.check(verify_state,
                {"tool": tool, "args": args})
            if not verification["allowed"]:
                self._emit("verification_denied", {
                    "tool": tool, "args": args,
                    "reasons": verification["reasons"],
                    "tiers": {k: v for k, v in verification["tiers"].items()},
                })
                consecutive_fails += 1
                continue

            # ── dangerous tool confirmation ──
            if self.guardrails.requires_confirmation(tool, args):
                self._emit("awaiting_confirmation",
                    {"tool": tool, "args": args})
                if not self.guardrails.auto_approve:
                    wait_start = time.time()
                    while self.running and not self.guardrails.is_approved(
                            self.run_id, tool, args):
                        if time.time() - wait_start > 300:
                            self.stop("approval_timeout")
                            return
                        time.sleep(1)
                    if not self.running:
                        return

            # ── execute ──
            self._emit("executing", {"tool": tool, "args": args,
                                       "option": current_option.name,
                                       "routing_mode": routing["mode"]})
            try:
                result = self.registry.call(tool, args)
                success = not (isinstance(result, dict) and "error" in result)
            except Exception as e:
                result = {"error": str(e)}
                success = False

            # ── intrinsic curiosity bonus ──
            action_id = routing["action"]
            next_ctx = self._gather_context()
            next_worker_state = featurize_worker_state(next_ctx, current_option)
            intrinsic_bonus = intrinsic.compute(
                worker_state, action_id, next_worker_state)

            # ── extrinsic reward ──
            from core.ai.rl.reward import reward_shaper
            reward_sig = reward_shaper.compute({
                "kind": self._classify_result(result, tool),
                "tokens_used": self.guardrails.budget.tokens,
            })

            # ── combined reward ──
            total_reward = reward_sig.value + 0.3 * intrinsic_bonus
            option_return += total_reward
            current_option.reward_accum += total_reward
            current_option.steps_taken += 1

            # ── store transition ──
            from core.ai.rl.trainer import trainer
            trainer.step(
                manager_state, (tool, args), total_reward,
                featurize_manager_state(next_ctx),
                done=False, run_id=self.run_id,
                meta={"option": current_option.name,
                       "intrinsic": intrinsic_bonus,
                       "uncertainty": routing})

            # ── update worker + ensemble + mcdropout + bbb ──
            sample = [{
                "state": manager_state,
                "reward": total_reward,
                "next_state": featurize_manager_state(next_ctx),
                "done": False,
                "action_id": action_id,
            }]
            
            if iteration % 16 == 0:
                ensemble.update(sample * 16)
                from core.ai.rl.bayesian.dropout import mc_dropout
                from core.ai.rl.bayesian.bbb import bbb
                mc_dropout.update(sample * 16)
                bbb.update(sample * 16)
                worker.update(sample * 16)

            # ── record ──
            step = {
                "iteration": iteration,
                "option": current_option.name,
                "tool": tool,
                "args": args,
                "result": result,
                "success": success,
                "reward": total_reward,
                "intrinsic": intrinsic_bonus,
                "routing": routing,
                "ts": datetime.utcnow().isoformat(),
            }
            self.history.append(step)
            self.results.append(result)

            memory.store_message("global", "assistant",
                f"[autonomous:{self.run_id}] iter={iteration} option={current_option.name} tool={tool} "
                f"result={str(result)[:500]}",
                meta={"agent": "autonomous", "run_id": self.run_id})
            memory.record_episode("global", "autonomous_step", {
                "run_id": self.run_id, "iteration": iteration,
                "tool": tool, "success": success,
            })

            self._emit("result", step)

            if success:
                consecutive_fails = 0
            else:
                consecutive_fails += 1
                if consecutive_fails >= self.guardrails.stop.max_consecutive_failures:
                    self.stop("too_many_failures")
                    break

            time.sleep(self.guardrails.throttle_sec)

        # ── cleanup ──
        if current_option:
            ctx = self._gather_context()
            success = current_option.termination(ctx)
            manager.update_option_stats(current_option.name, success, option_return)
        manager.save()
        worker.save()
        ensemble.save()
        self._emit("finished", {"run_id": self.run_id})

    # ==================== gather context ====================
    def _gather_context(self) -> dict:
        """يجمع كل إشارات السياق لـ HRL + Bayesian"""
        ctx = {
            "sessions_count": 0,
            "hosts_count": 0,
            "creds_count": 0,
            "has_session": False,
            "has_domain_admin": False,
            "ad_environment": False,
            "cloud": False,
            "ot_iot": False,
            "stealth_mode": True,
            "cumulative_reward": sum(
                r.value for r in __import__("core.ai.rl.reward",
                    fromlist=["reward_shaper"]).reward_shaper.history),
            "total_steps": len(self.history),
            "failure_streak": 0,
            "tokens_used": self.guardrails.budget.tokens,
            "time_elapsed_min": 0,
            "recent_options": [h.get("option") for h in self.history[-5:]],
            "detected": any(h.get("reward", 0) < -30 for h in self.history[-10:]),
            "policy_uncertainty": 0.0,
            "value_uncertainty": 0.0,
            "intrinsic_bonus": 0.0,
            "recent_actions_hist": {},
        }

        if self.app:
            for k in ("c2_ui", "c2", "lan"):
                mod = self.app.modules.get(k)
                if mod and hasattr(mod, "sessions"):
                    ctx["sessions_count"] += len(mod.sessions)
                    if mod.sessions:
                        ctx["has_session"] = True
            ad = self.app.modules.get("ad")
            if ad and getattr(ad, "domain", ""):
                ctx["ad_environment"] = True
            cloud = self.app.modules.get("cloud")
            if cloud:
                ctx["cloud"] = True

        # ensemble uncertainty للمرحلة الحالية
        try:
            manager_state = featurize_manager_state(ctx)
            _, ep, al = ensemble.predict(manager_state)
            ctx["policy_uncertainty"] = ep
            ctx["value_uncertainty"] = al
        except Exception:
            pass

        return ctx

    # ==================== helper classification ====================
    def _classify_result(self, result, tool: str) -> str:
        if isinstance(result, dict) and "error" in result:
            return "error"
        return "success"

    # ==================== emit ====================
    def _emit(self, event_type: str, payload: dict):
        ev = {"type": event_type, "ts": datetime.utcnow().isoformat(),
               "run_id": self.run_id, **payload}
        if self.on_event:
            try:
                self.on_event(ev)
            except Exception:
                pass

    # ==================== report ====================
    def report(self) -> dict:
        return {
            "run_id": self.run_id,
            "goal": self.goal,
            "iterations": len(self.history),
            "results": self.results,
            "history": self.history,
            "budget": self.guardrails.budget.describe(),
        }


_agent: Optional[AutonomousAgent] = None

def get_autonomous_agent(app) -> AutonomousAgent:
    global _agent
    if _agent is None:
        _agent = AutonomousAgent(app)
    return _agent
