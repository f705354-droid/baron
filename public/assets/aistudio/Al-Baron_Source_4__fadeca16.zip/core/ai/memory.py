# language: Python, file: core/ai/memory.py
# Layered memory — short-term buffer, working memory, long-term vector, episodic
import sqlite3
import json
import os
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from core.ai.embeddings import neural_embeddings


class MemoryStore:
    """
    ثلاث طبقات:
      - short_term: آخر N رسالة (in-memory)
      - working: ملخص كل جلسة في SQLite
      - long_term: كل شيء مع neural embeddings
      - episodic: أحداث مرتبطة بأهداف (session_new, finding, cred_hit)
    """

    def __init__(self, path: str = "~/.albaron/ai_memory.db"):
        path = os.path.expanduser(path)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.db = sqlite3.connect(path, check_same_thread=False)
        self._init_schema()
        self.short_term: List[dict] = []      # آخر 50 رسالة
        self.short_cap = 50

    def _init_schema(self):
        c = self.db.cursor()
        c.executescript("""
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            ts TEXT NOT NULL,
            meta TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_msg_session ON messages(session_id, ts);

        CREATE TABLE IF NOT EXISTS summaries (
            session_id TEXT PRIMARY KEY,
            summary TEXT NOT NULL,
            tokens INTEGER,
            updated TEXT
        );

        CREATE TABLE IF NOT EXISTS facts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            kind TEXT,           -- cred, host, cve, finding, note
            key TEXT,
            value TEXT,
            ts TEXT,
            weight REAL DEFAULT 1.0
        );
        CREATE INDEX IF NOT EXISTS idx_fact_kind ON facts(kind, session_id);

        CREATE TABLE IF NOT EXISTS episodes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            kind TEXT,           -- session_new, cred_hit, finding, task_done
            payload TEXT,
            ts TEXT
        );
        """)
        self.db.commit()

    # ==================== short term ====================
    def push_short(self, role: str, content: str, meta: dict = None):
        entry = {
            "role": role, "content": content,
            "ts": datetime.utcnow().isoformat(),
            "meta": meta or {},
        }
        self.short_term.append(entry)
        if len(self.short_term) > self.short_cap:
            self.short_term = self.short_term[-self.short_cap:]
        return entry

    def get_short(self, n: int = 10) -> List[dict]:
        return self.short_term[-n:]

    # ==================== long term ====================
    def store_message(self, session_id: str, role: str, content: str,
                       meta: dict = None) -> int:
        c = self.db.cursor()
        c.execute("""INSERT INTO messages(session_id, role, content, ts, meta)
                     VALUES(?,?,?,?,?)""",
                  (session_id, role, content,
                   datetime.utcnow().isoformat(),
                   json.dumps(meta or {})))
        msg_id = c.lastrowid
        self.db.commit()
        # neural embedding
        neural_embeddings.add(msg_id, content)
        return msg_id

    def search(self, query: str, session_id: str = None,
                limit: int = 10) -> List[dict]:
        return neural_embeddings.hybrid_search(
            query, k=limit, session_id=session_id)

    # ==================== summaries ====================
    def upsert_summary(self, session_id: str, summary: str, tokens: int = 0):
        c = self.db.cursor()
        c.execute("""
        INSERT INTO summaries(session_id, summary, tokens, updated)
        VALUES(?,?,?,?)
        ON CONFLICT(session_id) DO UPDATE SET
            summary=excluded.summary, tokens=excluded.tokens,
            updated=excluded.updated
        """, (session_id, summary, tokens, datetime.utcnow().isoformat()))
        self.db.commit()

    def get_summary(self, session_id: str) -> Optional[str]:
        c = self.db.cursor()
        row = c.execute("SELECT summary FROM summaries WHERE session_id=?",
                         (session_id,)).fetchone()
        return row[0] if row else None

    # ==================== facts ====================
    def add_fact(self, session_id: str, kind: str, key: str,
                  value: str, weight: float = 1.0):
        c = self.db.cursor()
        c.execute("""
        INSERT INTO facts(session_id, kind, key, value, ts, weight)
        VALUES(?,?,?,?,?,?)
        """, (session_id, kind, key, value,
              datetime.utcnow().isoformat(), weight))
        self.db.commit()

    def get_facts(self, session_id: str, kind: str = None) -> List[dict]:
        c = self.db.cursor()
        if kind:
            rows = c.execute("""
                SELECT kind, key, value, weight FROM facts
                WHERE session_id=? AND kind=?
                ORDER BY weight DESC, ts DESC LIMIT 100
            """, (session_id, kind)).fetchall()
        else:
            rows = c.execute("""
                SELECT kind, key, value, weight FROM facts
                WHERE session_id=?
                ORDER BY weight DESC, ts DESC LIMIT 200
            """, (session_id,)).fetchall()
        return [{"kind": r[0], "key": r[1], "value": r[2],
                  "weight": r[3]} for r in rows]

    def extract_facts(self, session_id: str, text: str):
        """يستخرج حقائق من رسالة — IPs, creds, CVEs, hosts"""
        import re
        # IPs
        for ip in set(re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text)):
            self.add_fact(session_id, "host", ip, ip, weight=0.6)
        # CVEs
        for cve in set(re.findall(r"CVE-\d{4}-\d{4,7}", text)):
            self.add_fact(session_id, "cve", cve, cve, weight=0.9)
        # creds (user:pass)
        for m in re.findall(r"([\w.@-]+):([^\s:]{3,})", text):
            self.add_fact(session_id, "cred", m[0], m[1], weight=1.0)
        # domains
        for d in set(re.findall(r"\b[\w-]+\.(?:com|net|org|io|local|lan)\b",
                                 text, re.I)):
            self.add_fact(session_id, "domain", d, d, weight=0.4)

    # ==================== episodes ====================
    def record_episode(self, session_id: str, kind: str, payload: dict):
        c = self.db.cursor()
        c.execute("""INSERT INTO episodes(session_id, kind, payload, ts)
                     VALUES(?,?,?,?)""",
                  (session_id, kind, json.dumps(payload),
                   datetime.utcnow().isoformat()))
        self.db.commit()

    def episodes_since(self, session_id: str, minutes: int = 60) -> List[dict]:
        cutoff = (datetime.utcnow() - timedelta(minutes=minutes)).isoformat()
        c = self.db.cursor()
        rows = c.execute("""
            SELECT kind, payload, ts FROM episodes
            WHERE session_id=? AND ts>?
            ORDER BY ts DESC LIMIT 200
        """, (session_id, cutoff)).fetchall()
        return [{"kind": r[0], "payload": json.loads(r[1]), "ts": r[2]}
                for r in rows]

    # ==================== context builder ====================
    def build_context(self, session_id: str, query: str,
                       max_chars: int = 4000) -> str:
        """يبني سياق مركب من كل الطبقات — للاستخدام في prompt"""
        parts = []

        # 1. summary
        s = self.get_summary(session_id)
        if s:
            parts.append(f"[ملخص الجلسة]\n{s}")

        # 2. facts
        facts = self.get_facts(session_id)
        if facts:
            by_kind = {}
            for f in facts:
                by_kind.setdefault(f["kind"], []).append(f["key"])
            lines = []
            for kind, keys in by_kind.items():
                unique = list(dict.fromkeys(keys))[:10]
                lines.append(f"  {kind}: {', '.join(unique)}")
            parts.append("[حقائق مستخلصة]\n" + "\n".join(lines))

        # 3. recent episodes
        eps = self.episodes_since(session_id, minutes=120)[:10]
        if eps:
            ep_lines = [f"  {e['ts'][11:19]} {e['kind']}: "
                        f"{str(e['payload'])[:80]}" for e in eps]
            parts.append("[أحداث حديثة]\n" + "\n".join(ep_lines))

        # 4. semantic search hits
        hits = self.search(query, session_id=session_id, limit=5)
        if hits:
            hit_lines = [f"  [{h.get('score', 0):.2f}] {h.get('role', '')}: "
                         f"{h.get('content', '')[:200]}" for h in hits]
            parts.append("[رسائل ذات صلة]\n" + "\n".join(hit_lines))

        # 5. short term
        if self.short_term:
            recent = self.short_term[-6:]
            r_lines = [f"  {e['role']}: {e['content'][:150]}"
                        for e in recent]
            parts.append("[آخر المحادثة]\n" + "\n".join(r_lines))

        ctx = "\n\n".join(parts)
        if len(ctx) > max_chars:
            ctx = ctx[:max_chars] + "\n...(truncated)"
        return ctx

    def prune(self, days: int = 90):
        """ينظف الرسائل القديمة"""
        cutoff = (datetime.utcnow() - timedelta(days=days)).isoformat()
        c = self.db.cursor()
        c.execute("DELETE FROM messages WHERE ts < ?", (cutoff,))
        # إذا كانت جدول embeddings القديم موجوداً أو تم حذفه
        try:
            c.execute("DELETE FROM embeddings WHERE msg_id NOT IN (SELECT id FROM messages)")
        except sqlite3.OperationalError:
            pass
        self.db.commit()


# singleton
memory = MemoryStore()
