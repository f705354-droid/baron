# language: Python, file: core/ai/guardrails.py
# Autonomous guardrails — budget, rate, dangerous tool confirmation
import os
import time
import threading
from datetime import datetime, timedelta
from typing import Dict, Set, Optional


# أدوات تُعد عالية المخاطر — تحتاج تأكيد بشري
DANGEROUS_TOOLS = {
    "run_shell",           # shell execution
    "dispatch_task",       # push to beacon
    "write_file",          # disk write
}


class Budget:
    """budget بالمليمترات والدولارات"""
    # أسعار تقديرية لكل 1M tokens
    PRICE = {
        "claude": {"in": 3.0, "out": 15.0},
        "gpt4o":  {"in": 2.5, "out": 10.0},
        "local":  {"in": 0.0, "out": 0.0},
    }

    def __init__(self, max_usd: float = 5.0, max_tokens: int = 500_000):
        self.max_usd = max_usd
        self.max_tokens = max_tokens
        self.tokens = 0
        self.usd = 0.0
        self.started = time.time()
        self._lock = threading.Lock()

    def add_usage(self, tokens: int, model: str = "claude"):
        with self._lock:
            self.tokens += tokens
            p = self.PRICE.get(model, self.PRICE["claude"])
            self.usd += (tokens / 1_000_000) * (p["in"] + p["out"]) / 2

    def exceeded(self) -> bool:
        return self.tokens > self.max_tokens or self.usd > self.max_usd

    def describe(self) -> str:
        return (f"tokens={self.tokens}/{self.max_tokens}, "
                f"usd=${self.usd:.3f}/${self.max_usd}")


class StopCondition:
    def __init__(self, max_iterations: int = 50, max_minutes: int = 60,
                  max_consecutive_failures: int = 3):
        self.max_iterations = max_iterations
        self.max_minutes = max_minutes
        self.max_consecutive_failures = max_consecutive_failures


class Guardrails:
    def __init__(self, budget: Budget = None, stop: StopCondition = None):
        self.budget = budget or Budget()
        self.stop = stop or StopCondition()
        self.throttle_sec = float(os.getenv("AL-BARON_AUTONOMOUS_THROTTLE", "3"))
        self.auto_approve = os.getenv("AL-BARON_AUTO_APPROVE", "0") == "1"
        self._approvals: Set[str] = set()  # keys موافق عليها

    def requires_confirmation(self, tool: str, args: dict) -> bool:
        return tool in DANGEROUS_TOOLS

    def _key(self, run_id: str, tool: str, args: dict) -> str:
        import json, hashlib
        h = hashlib.md5(json.dumps(args, sort_keys=True).encode()).hexdigest()[:8]
        return f"{run_id}:{tool}:{h}"

    def approve(self, run_id: str, tool: str, args: dict):
        self._approvals.add(self._key(run_id, tool, args))

    def is_approved(self, run_id: str, tool: str, args: dict) -> bool:
        return self._key(run_id, tool, args) in self._approvals
