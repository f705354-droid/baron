# language: Python, file: core/ai/batch_worker.py
# Worker for K8s batch analysis job
import os
import json
import sys
import redis
from anthropic import Anthropic


def main():
    job_id = os.getenv("JOB_ID")
    model = os.getenv("MODEL")
    template = os.getenv("PROMPT_TEMPLATE")
    shards = json.loads(os.getenv("SHARDS", "[]"))
    redis_url = os.getenv("REDIS_URL", "redis://redis:6379/1")

    # في K8s، كل pod يأخذ shard واحد بـindex job-completion-index
    # لكن للتبسيط: كل pod يعالج كل الshards المتاحة له
    idx = int(os.getenv("JOB_COMPLETION_INDEX", "0"))
    if idx >= len(shards):
        print(f"[batch] no shard for index {idx}")
        return
    items = shards[idx]

    client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
    r = redis.from_url(redis_url)

    results = []
    for i, item in enumerate(items):
        prompt = template.format(item=json.dumps(item, ensure_ascii=False))
        try:
            resp = client.messages.create(
                model=model, max_tokens=1024,
                messages=[{"role": "user", "content": prompt}])
            results.append({
                "input": item,
                "output": resp.content[0].text,
            })
        except Exception as e:
            results.append({"input": item, "error": str(e)})
        if (i + 1) % 10 == 0:
            print(f"[batch] {idx}: {i+1}/{len(items)}")

    # publish to redis
    key = f"batch:{job_id}:{idx}"
    r.set(key, json.dumps(results))
    print(f"[batch] done shard {idx}: {len(results)} results → {key}")


if __name__ == "__main__":
    main()
