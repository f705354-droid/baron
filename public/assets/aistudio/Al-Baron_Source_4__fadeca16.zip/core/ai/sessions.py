# language: Python, file: core/ai/sessions.py
# Multiple chat sessions — switch between them, name them, archive
import sqlite3
import os
import uuid
import json
from datetime import datetime


class ChatSessions:
    def __init__(self, path: str = "~/.albaron/chat_sessions.db"):
        path = os.path.expanduser(path)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.db = sqlite3.connect(path, check_same_thread=False)
        self._init()

    def _init(self):
        c = self.db.cursor()
        c.executescript("""
        CREATE TABLE IF NOT EXISTS chat_sessions (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            created TEXT,
            updated TEXT,
            archived INTEGER DEFAULT 0,
            meta TEXT
        );
        """)
        self.db.commit()

    def create(self, name: str = None) -> str:
        sid = str(uuid.uuid4())[:8]
        name = name or f"chat-{sid}"
        c = self.db.cursor()
        c.execute("""
            INSERT INTO chat_sessions(id, name, created, updated)
            VALUES(?,?,?,?)
        """, (sid, name, datetime.utcnow().isoformat(),
              datetime.utcnow().isoformat()))
        self.db.commit()
        return sid

    def rename(self, sid: str, name: str):
        c = self.db.cursor()
        c.execute("UPDATE chat_sessions SET name=?, updated=? WHERE id=?",
                  (name, datetime.utcnow().isoformat(), sid))
        self.db.commit()

    def touch(self, sid: str):
        c = self.db.cursor()
        c.execute("UPDATE chat_sessions SET updated=? WHERE id=?",
                  (datetime.utcnow().isoformat(), sid))
        self.db.commit()

    def archive(self, sid: str):
        c = self.db.cursor()
        c.execute("UPDATE chat_sessions SET archived=1 WHERE id=?", (sid,))
        self.db.commit()

    def list(self, include_archived: bool = False) -> list:
        c = self.db.cursor()
        q = ("SELECT id, name, created, updated, archived FROM chat_sessions"
              + ("" if include_archived else " WHERE archived=0")
              + " ORDER BY updated DESC")
        return [{"id": r[0], "name": r[1], "created": r[2],
                  "updated": r[3], "archived": bool(r[4])}
                for r in c.execute(q).fetchall()]

    def delete(self, sid: str):
        c = self.db.cursor()
        c.execute("DELETE FROM chat_sessions WHERE id=?", (sid,))
        self.db.commit()


chat_sessions = ChatSessions()
