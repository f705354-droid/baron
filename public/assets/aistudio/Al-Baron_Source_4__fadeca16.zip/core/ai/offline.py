# language: Python, file: core/ai/offline.py
# Offline LLM backend — Ollama, llama.cpp server, LM Studio
import os
import httpx
import json
from typing import Optional, Generator


class OfflineLLM:
    """
    Backend محلي للعمل بدون إنترنت.
    يدعم: Ollama (11434), llama.cpp server (8080), LM Studio (1234)
    """
    def __init__(self):
        self.url = os.getenv("AL-BARON_LOCAL_LLM_URL",
                              "http://localhost:11434")
        self.model = os.getenv("AL-BARON_LOCAL_MODEL",
                                "llama3.1:8b-instruct-q4_K_M")
        self.backend = self._detect_backend()

    def _detect_backend(self) -> str:
        try:
            r = httpx.get(f"{self.url}/api/tags", timeout=2)
            if r.status_code == 200:
                return "ollama"
        except Exception:
            pass
        try:
            r = httpx.get(f"{self.url}/v1/models", timeout=2)
            if r.status_code == 200:
                return "openai-compat"
        except Exception:
            pass
        return "offline"

    def is_available(self) -> bool:
        return self.backend != "offline"

    def query(self, system: str, prompt: str,
                max_tokens: int = 2048) -> Optional[str]:
        if not self.is_available():
            return None
        try:
            if self.backend == "ollama":
                r = httpx.post(f"{self.url}/api/chat", timeout=120,
                                json={
                    "model": self.model,
                    "stream": False,
                    "messages": [
                        {"role": "system", "content": system},
                        {"role": "user", "content": prompt},
                    ],
                    "options": {"num_predict": max_tokens},
                })
                r.raise_for_status()
                return r.json().get("message", {}).get("content")
            else:
                r = httpx.post(f"{self.url}/v1/chat/completions",
                                timeout=120, json={
                    "model": self.model,
                    "messages": [
                        {"role": "system", "content": system},
                        {"role": "user", "content": prompt},
                    ],
                    "max_tokens": max_tokens,
                })
                r.raise_for_status()
                return r.json()["choices"][0]["message"]["content"]
        except Exception:
            return None

    def stream(self, system: str, prompt: str,
                max_tokens: int = 2048) -> Generator[str, None, None]:
        if not self.is_available():
            return
        try:
            if self.backend == "ollama":
                with httpx.stream("POST", f"{self.url}/api/chat",
                                   timeout=180, json={
                    "model": self.model, "stream": True,
                    "messages": [
                        {"role": "system", "content": system},
                        {"role": "user", "content": prompt},
                    ],
                    "options": {"num_predict": max_tokens},
                }) as r:
                    for line in r.iter_lines():
                        if not line:
                            continue
                        try:
                            data = json.loads(line)
                            chunk = data.get("message", {}).get("content", "")
                            if chunk:
                                yield chunk
                        except Exception:
                            pass
        except Exception:
            pass

    def list_models(self) -> list:
        try:
            if self.backend == "ollama":
                r = httpx.get(f"{self.url}/api/tags", timeout=5)
                return [m["name"] for m in r.json().get("models", [])]
        except Exception:
            pass
        return []


offline_llm = OfflineLLM()
