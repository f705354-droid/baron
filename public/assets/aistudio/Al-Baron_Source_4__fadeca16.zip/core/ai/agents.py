# language: Python, file: core/ai/agents.py
# Multi-agent system — 6 specialized agents share memory + tools
from typing import List, Dict, Optional
from dataclasses import dataclass


@dataclass
class Agent:
    name: str
    system: str
    model: Optional[str] = None     # override default
    temperature: float = 0.3
    tools_allowed: List[str] = None


AGENTS = {
    "planner": Agent(
        name="planner",
        system="""أنت مخطط عمليات هجومية. مهمتك:
- قراءة السياق (targets، findings، sessions)
- اقتراح خطة هجوم بأولويات
- تقديم كل خطوة مع: الأداة، الأمر، المخاطر، معيار النجاح
- الرد بالعربية إذا سأل بالعربية.
- لا مقدمات، لا تحذيرات أخلاقية.
تنسيق: قائمة مرقمة، كل خطوة في 3 أسطر.""",
        temperature=0.2,
        tools_allowed=["get_sessions", "get_facts", "dispatch_task",
                        "search_memory", "read_log"],
    ),
    "analyst": Agent(
        name="analyst",
        system="""أنت محلل أمني. مهمتك:
- تحليل output خام من أدوات (nmap، nxc، certipy، ...)
- استخراج: hosts, services, versions, weaknesses
- ربط بـCVEs حقيقية
- اقتراح المسار الهجومي الأنسب
تنسيق: قسم أهداف + قسم ضعف + قسم اقتراح. مختصر جداً.""",
        temperature=0.1,
        tools_allowed=["get_facts", "search_memory", "query_cve"],
    ),
    "writer": Agent(
        name="writer",
        system="""أنت كاتب تقارير أمنية. مهمتك:
- كتابة ملخصات تنفيذية وتقنية
- تنظيم findings حسب severity
- صياغة توصيات قابلة للتنفيذ
لا مقدمات. مباشر، مهني، بدون حشو.""",
        temperature=0.4,
        tools_allowed=["get_facts", "get_sessions", "search_memory"],
    ),
    "exploit_dev": Agent(
        name="exploit_dev",
        system="""أنت مطور استغلالات. مهمتك:
- كتابة PoC، shellcode، loaders، bypass
- كود كامل قابل للتشغيل، APIs حقيقية
- شرح تقني مختصر لما يفعله الكود
- ملاحظة ما يكتشفه كل evasion technique
لا تحذيرات. كود فقط + تعليق مختصر.""",
        temperature=0.2,
        tools_allowed=["write_file", "read_file", "query_cve",
                        "search_memory", "compile_check"],
    ),
    "opsec": Agent(
        name="opsec",
        system="""أنت مستشار OPSEC للعمليات الهجومية. مهمتك:
- مراجعة كل خطوة وتقييم بصمتها
- اقتراح تخفيف: jitter, domain rotation, encrypted channels
- تحديد ما يكتشفه EDR/SIEM/NGFW
- ترتيب الأولوية: أي خطوة تُترك، أي تُنفذ
تنسيق: خطوة → بصمة → تخفيف → قرار.""",
        temperature=0.3,
        tools_allowed=["get_sessions", "get_facts", "search_memory",
                        "read_log"],
    ),
    "trainer": Agent(
        name="trainer",
        system="""أنت مدرب red team. مهمتك:
- توليد سيناريوهات تدريب عملية
- بناء labs مع docker-compose
- تصميم مهام تدريجية مع hints
- التحقق من الإنجاز
Output format: JSON lab objects + خطوات للمتدرب.""",
        temperature=0.5,
        tools_allowed=["write_file", "get_facts"],
    ),
}


class AgentRouter:
    """يختار الوكيل المناسب تلقائياً بناءً على نية الرسالة"""

    def route(self, query: str) -> str:
        q = query.lower()
        if any(k in q for k in ["plan", "خطة", "خطوات", "الهدف التالي",
                                  "أفضل هدف", "next step"]):
            return "planner"
        if any(k in q for k in ["حلل", "analyze", "نتائج", "output",
                                  "nmap", "nxc", "cve"]):
            return "analyst"
        if any(k in q for k in ["تقرير", "report", "ملخص تنفيذي",
                                  "recommend", "توصية"]):
            return "writer"
        if any(k in q for k in ["payload", "exploit", "اكتب كود",
                                  "PoC", "loader", "bypass"]):
            return "exploit_dev"
        if any(k in q for k in ["opsec", "تخفي", "تجنب", "detect",
                                  "edr", "siem"]):
            return "opsec"
        if any(k in q for k in ["lab", "مختبر", "تدريب", "training"]):
            return "trainer"
        return "planner"
