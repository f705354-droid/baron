# language: Python, file: core/ai/reflect.py
# Self-reflection — AI critiques its own answer, improves if needed
from typing import Optional


REFLECT_PROMPT = """راجع إجابتك السابقة على هذا السؤال:

السؤال: {question}

الإجابة: {answer}

قيّم الإجابة داخلياً على:
1. الدقة التقنية (هل المعلومات صحيحة؟)
2. الاكتمال (هل أجبت على كل جزء؟)
3. العملية (هل الأوامر/الكود قابل للتنفيذ؟)
4. الإيجاز (هل هناك حشو؟)

إذا كانت الإجابة ممتازة، أرجع فقط: "OK"
إذا كان هناك تحسين مهم، أرجع الإجابة المحسّنة الكاملة بدون شرح."""


class ReflectionEngine:
    def __init__(self, ai_call_fn):
        self.ai_call = ai_call_fn

    def reflect(self, question: str, answer: str,
                 min_len_for_reflection: int = 400) -> str:
        """يرجع إجابة محسّنة (أو الأصل إذا كان جيداً)"""
        if len(answer) < min_len_for_reflection:
            return answer
        try:
            critique = self.ai_call(
                "أنت مراجع دقيق. لا تجامل. صحّح أو أكّد.",
                REFLECT_PROMPT.format(question=question, answer=answer)
            )
            if not critique or critique.strip().upper().startswith("OK"):
                return answer
            if len(critique) > len(answer) * 0.5:
                return critique
        except Exception:
            pass
        return answer
