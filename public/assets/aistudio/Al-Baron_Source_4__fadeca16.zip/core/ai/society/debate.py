# language: Python, file: core/ai/society/debate.py
# Multi-agent debate — advocate, skeptic, judge, historian
import os
import json
import time
import uuid
from datetime import datetime
from typing import List, Dict, Optional
from core.ai.agents import AGENTS


DEBATE_ROLES = {
    "advocate": {
        "system": """أنت المدافع عن القرار المطروح.
مهمتك: قدّم أفضل حجة لصالح هذا القرار.
- اذكر الأدلة التقنية
- توقع النتائج الإيجابية
- اقترح خطة تنفيذ
كن مباشراً، 3-5 نقاط فقط.""",
        "temp": 0.4,
    },
    "skeptic": {
        "system": """أنت المتشكك. مهمتك: هاجم القرار.
- اذكر المخاطر التقنية
- اذكر سيناريوهات الفشل
- اذكر ما قد يكتشفه المدافع
- اقترح بدائل
3-5 نقاط. لا مجاملة.""",
        "temp": 0.5,
    },
    "historian": {
        "system": """أنت مؤرخ العمليات. مهمتك:
- استرجع engagements سابقة مشابهة
- اذكر ما نجح وما فشل
- استخرج أنماط
- قارن بالوضع الحالي
مختصر، قائم على الحقائق.""",
        "temp": 0.3,
    },
    "opsec": {
        "system": """أنت مسؤول OPSEC. مهمتك:
- قيّم البصمة (footprint)
- ما يكتشفه EDR/SIEM/NGFW
- احسب احتمال الكشف
- اقترح تخفيف
تنسيق: خطوة → بصمة → تخفيف.""",
        "temp": 0.3,
    },
    "judge": {
        "system": """أنت القاضي. مهمتك:
- اقرأ كل الحجج
- وزن الأدلة
- أصدر قراراً نهائياً
- حدد شرط abort
أخرج JSON:
{
  "verdict": "proceed|reject|modify",
  "confidence": 0.0-1.0,
  "reasoning": "...",
  "action": {...},
  "abort_if": "..."
}""",
        "temp": 0.1,
    },
    "red_team": {
        "system": """أنت الخصم الأحمر. مهمتك:
- حاول كسر الخطة المقترحة
- ابحث عن ثغرة في التفكير
- اقترح هجوماً مضاداً على الخطة نفسها
مختصر.""",
        "temp": 0.6,
    },
}


class DebateSociety:
    """
    مجتمع وكلاء يتناقشون قبل القرار.
    Rounds:
      1. Advocate + Skeptic + Historian + Opsec → 4 آراء متوازية
      2. Red_team يحاول كسر كل رأي
      3. Advocate + Skeptic يعيدان بصياغة موجزة
      4. Judge يصدر القرار النهائي
    """
    def __init__(self, ai_call_fn, max_rounds: int = 2):
        self.ai_call = ai_call_fn
        self.max_rounds = max_rounds
        self.transcripts: List[dict] = []

    def debate(self, question: str, context: str,
                roles: Optional[List[str]] = None,
                parallel: bool = True) -> dict:
        debate_id = uuid.uuid4().hex[:8]
        roles = roles or ["advocate", "skeptic", "historian", "opsec"]

        transcript = {
            "id": debate_id,
            "question": question,
            "context": context[:2000],
            "started": datetime.utcnow().isoformat(),
            "rounds": [],
        }

        current_round = 0
        propositions = {}

        while current_round < self.max_rounds:
            current_round += 1
            round_data = {"n": current_round, "positions": {}}

            # ── الجولة الأولى: كل دور يعطي رأيه ──
            if parallel:
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(
                        max_workers=len(roles)) as ex:
                    futures = {
                        r: ex.submit(self._ask_role, r, question,
                                       context, propositions)
                        for r in roles
                    }
                    for r, fut in futures.items():
                        try:
                            round_data["positions"][r] = fut.result(timeout=120)
                        except Exception as e:
                            round_data["positions"][r] = f"[error] {e}"
            else:
                for r in roles:
                    round_data["positions"][r] = self._ask_role(
                        r, question, context, propositions)

            # ── red team critique ──
            critique = self._red_team_critique(question, round_data["positions"])
            round_data["red_team"] = critique

            # ── reassessment ──
            for r in ["advocate", "skeptic"]:
                if r in round_data["positions"]:
                    round_data["positions"][r + "_v2"] = self._reassess(
                        r, question, round_data["positions"][r], critique,
                        round_data["positions"])

            propositions = round_data["positions"]
            transcript["rounds"].append(round_data)

            # ── convergence check ──
            if self._converged(round_data):
                transcript["converged_round"] = current_round
                break

        # ── final verdict ──
        verdict = self._judge(question, context, propositions)
        transcript["verdict"] = verdict
        transcript["ended"] = datetime.utcnow().isoformat()
        self.transcripts.append(transcript)
        return transcript

    def _ask_role(self, role: str, question: str, context: str,
                    previous: dict) -> str:
        spec = DEBATE_ROLES[role]
        sys = spec["system"]
        # أضف سياق الجولات السابقة
        prev_txt = ""
        if previous:
            prev_txt = "\n\nآراء سابقة:\n" + "\n".join(
                f"[{k}] {v[:300]}" for k, v in previous.items())

        prompt = f"""السؤال/القرار:
{question}

السياق:
{context[:1500]}
{prev_txt}

قدّم موقفك."""

        return self.ai_call(sys, prompt, temperature=spec["temp"])

    def _red_team_critique(self, question: str, positions: dict) -> str:
        sys = DEBATE_ROLES["red_team"]["system"]
        positions_txt = "\n\n".join(
            f"[{r}]\n{p[:500]}" for r, p in positions.items())
        prompt = f"""القرار: {question}

الآراء المطروحة:
{positions_txt}

اكسر كل رأي بثغرة أو افتراض خاطئ."""
        return self.ai_call(sys, prompt, temperature=0.6)

    def _reassess(self, role: str, question: str, original: str,
                    critique: str, all_positions: dict) -> str:
        sys = f"""أنت [{role}]. راجع موقفك بعد النقد.
احتفظ بما صمد. عدّل ما كُسر. 3 نقاط فقط."""
        prompt = f"""موقفك السابق:
{original}

النقد:
{critique}

موقفك المعدّل:"""
        return self.ai_call(sys, prompt, temperature=0.4)

    def _converged(self, round_data: dict) -> bool:
        """يتحقق من تقارب الآراء"""
        positions = list(round_data["positions"].values())
        if len(positions) < 2:
            return False
        # heuristic: كلمات مشتركة عالية
        import re
        word_sets = []
        for p in positions:
            words = set(re.findall(r"\w+", p.lower()))
            word_sets.append(words)
        if len(word_sets) < 2:
            return False
        common = word_sets[0]
        for ws in word_sets[1:]:
            common &= ws
        union = set()
        for ws in word_sets:
            union |= ws
        if not union:
            return False
        jaccard = len(common) / len(union)
        return jaccard > 0.3

    def _judge(self, question: str, context: str, positions: dict) -> dict:
        sys = DEBATE_ROLES["judge"]["system"]
        positions_txt = "\n\n".join(
            f"[{r}]\n{p[:600]}" for r, p in positions.items())
        prompt = f"""القرار: {question}

السياق: {context[:1000]}

الآراء:
{positions_txt}

أصدر الحكم JSON."""
        raw = self.ai_call(sys, prompt, temperature=0.1)
        # استخرج JSON
        try:
            if "```" in raw:
                raw = raw.split("```")[1]
                if raw.startswith("json"):
                    raw = raw[4:]
            return json.loads(raw.strip())
        except Exception:
            import re
            m = re.search(r"\{.*\}", raw, re.DOTALL)
            if m:
                try:
                    return json.loads(m.group(0))
                except Exception:
                    pass
        return {
            "verdict": "modify",
            "confidence": 0.5,
            "reasoning": raw[:500],
            "action": {},
            "abort_if": "",
        }


def make_ai_call(ai_chat_drawer):
    """adapter — يستخدم نفس backend الـdrawer"""
    def call(system: str, prompt: str, temperature: float = 0.3) -> str:
        import os
        if os.getenv("ANTHROPIC_API_KEY"):
            try:
                from anthropic import Anthropic
                c = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
                r = c.messages.create(
                    model="claude-sonnet-4-20250514",
                    max_tokens=1500, temperature=temperature,
                    system=system,
                    messages=[{"role": "user", "content": prompt}])
                return r.content[0].text
            except Exception as e:
                return f"[error] {e}"
        if os.getenv("OPENAI_API_KEY"):
            try:
                from openai import OpenAI
                c = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
                r = c.chat.completions.create(
                    model="gpt-4o", max_tokens=1500,
                    temperature=temperature,
                    messages=[{"role": "system", "content": system},
                              {"role": "user", "content": prompt}])
                return r.choices[0].message.content
            except Exception as e:
                return f"[error] {e}"
        from core.ai.offline import offline_llm
        if offline_llm.is_available():
            return offline_llm.query(system, prompt) or ""
        return ""
    return call
