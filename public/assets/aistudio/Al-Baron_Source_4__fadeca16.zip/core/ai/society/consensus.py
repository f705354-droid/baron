# language: Python, file: core/ai/society/consensus.py
# Consensus — vote aggregation, quorum, Byzantine tolerance
import json
from typing import List, Dict
from collections import Counter


def majority_vote(votes: List[str]) -> Dict:
    c = Counter(votes)
    winner, count = c.most_common(1)[0]
    return {"winner": winner, "count": count, "total": len(votes),
             "confidence": count / len(votes)}


def weighted_vote(votes: List[tuple]) -> Dict:
    """votes = [(choice, weight), ...]"""
    scores = {}
    for choice, w in votes:
        scores[choice] = scores.get(choice, 0) + w
    total = sum(scores.values())
    winner = max(scores, key=scores.get)
    return {"winner": winner, "score": scores[winner], "total": total,
             "confidence": scores[winner] / total if total else 0.0}


def byzantine_consensus(votes: List[tuple], f: int = 1) -> Dict:
    """
    BFT: مع f أخطاء محتملة، نحتاج 3f+1 عقدة على الأقل.
    votes = [(choice, node_id), ...]
    """
    n = len(votes)
    required = 3 * f + 1
    if n < required:
        return {"error": f"need >= {required} votes, have {n}",
                 "f": f}
    # عدّ + تحقق من الإجماع
    c = Counter(v[0] for v in votes)
    for choice, count in c.most_common():
        if count >= 2 * f + 1:
            return {"winner": choice, "count": count,
                     "n": n, "f": f, "confidence": count / n}
    return {"error": "no consensus", "votes": dict(c)}


class DebateConsensus:
    """مبني فوق DebateSociety لإنتاج قرار نهائي"""
    def __init__(self, society):
        self.society = society

    def decide(self, question: str, context: str,
                use_bft: bool = False, f: int = 1) -> dict:
        transcript = self.society.debate(question, context)
        verdict = transcript.get("verdict", {})

        if use_bft:
            votes = []
            for round_data in transcript["rounds"]:
                for role, pos in round_data["positions"].items():
                    # استخرج موقف كل دور: proceed/reject/modify
                    stance = self._extract_stance(pos)
                    votes.append((stance, role))
            bft = byzantine_consensus(votes, f=f)
            return {"transcript": transcript, "verdict": verdict,
                     "consensus": bft}

        return {"transcript": transcript, "verdict": verdict}

    def _extract_stance(self, position: str) -> str:
        p = position.lower()
        if "reject" in p or "لا أنصح" in p or "خطر" in p:
            return "reject"
        if "modify" in p or "أعدّل" in p or "بشرط" in p:
            return "modify"
        if "proceed" in p or "أنصح" in p or "نفّذ" in p:
            return "proceed"
        return "modify"
