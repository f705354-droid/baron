# language: Python, file: core/saas/tenant_manager.py
# Multi-tenant SaaS — tenant isolation + billing
import sqlite3
import os
import uuid
import json
import hashlib
from datetime import datetime, timedelta
from typing import Optional


class TenantManager:
    """
    إدارة tenants:
    - each tenant has own graph DB + users + billing
    - APIs return data scoped to tenant
    """
    PLAN_LIMITS = {
        "starter": {
            "max_hosts": 100,
            "max_users": 3,
            "max_sessions": 10,
            "features": ["recon", "lan", "c2"],
        },
        "pro": {
            "max_hosts": 1000,
            "max_users": 20,
            "max_sessions": 100,
            "features": ["*"],
        },
        "enterprise": {
            "max_hosts": 100000,
            "max_users": 200,
            "max_sessions": 10000,
            "features": ["*"],
        },
    }

    def __init__(self, db_path: str = "~/.albaron/saas.db"):
        self.db_path = os.path.expanduser(db_path)
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self.db = sqlite3.connect(self.db_path, check_same_thread=False)
        self._init_schema()

    def _init_schema(self):
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS tenants (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT UNIQUE,
            plan TEXT DEFAULT 'starter',
            subscription_status TEXT DEFAULT 'trial',
            trial_ends_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            api_key TEXT UNIQUE,
            graph_db_path TEXT
        );

        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            tenant_id TEXT,
            email TEXT,
            password_hash TEXT,
            role TEXT DEFAULT 'operator',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(tenant_id) REFERENCES tenants(id)
        );

        CREATE TABLE IF NOT EXISTS usage (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tenant_id TEXT,
            metric TEXT,
            quantity REAL,
            recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(tenant_id) REFERENCES tenants(id)
        );
        """)
        self.db.commit()

    # ==================== tenant CRUD ====================
    def create_tenant(self, name: str, email: str,
                       plan: str = "starter") -> dict:
        tenant_id = str(uuid.uuid4())
        api_key = hashlib.sha256(
            f"{tenant_id}{datetime.now().timestamp()}".encode()
        ).hexdigest()[:32]

        trial_end = (datetime.now() + timedelta(days=14)).isoformat()
        graph_path = f"~/.albaron/tenants/{tenant_id}/graph.db"

        self.db.execute("""
            INSERT INTO tenants
            (id, name, email, plan, subscription_status,
             trial_ends_at, api_key, graph_db_path)
            VALUES (?, ?, ?, ?, 'trial', ?, ?, ?)
        """, (tenant_id, name, email, plan, trial_end,
                api_key, graph_path))
        self.db.commit()

        return {
            "tenant_id": tenant_id,
            "api_key": api_key,
            "plan": plan,
            "trial_ends_at": trial_end,
        }

    def get_tenant(self, tenant_id: str) -> Optional[dict]:
        row = self.db.execute(
            "SELECT * FROM tenants WHERE id=?",
            (tenant_id,)).fetchone()
        if not row:
            return None
        cols = ["id", "name", "email", "plan", "subscription_status",
                 "trial_ends_at", "created_at", "api_key", "graph_db_path"]
        return dict(zip(cols, row))

    def get_tenant_by_api_key(self, api_key: str) -> Optional[dict]:
        row = self.db.execute(
            "SELECT id FROM tenants WHERE api_key=?",
            (api_key,)).fetchone()
        if not row:
            return None
        return self.get_tenant(row[0])

    def list_tenants(self) -> list:
        rows = self.db.execute(
            "SELECT id, name, email, plan, subscription_status, created_at "
            "FROM tenants ORDER BY created_at DESC").fetchall()
        return [
            {"id": r[0], "name": r[1], "email": r[2], "plan": r[3],
              "subscription_status": r[4], "created_at": r[5]}
            for r in rows
        ]

    def delete_tenant(self, tenant_id: str):
        self.db.execute("DELETE FROM tenants WHERE id=?", (tenant_id,))
        self.db.execute("DELETE FROM users WHERE tenant_id=?", (tenant_id,))
        self.db.execute("DELETE FROM usage WHERE tenant_id=?", (tenant_id,))
        self.db.commit()

    # ==================== users ====================
    def add_user(self, tenant_id: str, email: str,
                  password: str, role: str = "operator") -> str:
        user_id = str(uuid.uuid4())
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        self.db.execute("""
            INSERT INTO users (id, tenant_id, email, password_hash, role)
            VALUES (?, ?, ?, ?, ?)
        """, (user_id, tenant_id, email, password_hash, role))
        self.db.commit()
        return user_id

    def authenticate(self, email: str, password: str) -> Optional[dict]:
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        row = self.db.execute("""
            SELECT id, tenant_id, role FROM users
            WHERE email=? AND password_hash=?
        """, (email, password_hash)).fetchone()
        if not row:
            return None
        return {
            "user_id": row[0],
            "tenant_id": row[1],
            "role": row[2],
        }

    # ==================== usage / billing ====================
    def record_usage(self, tenant_id: str, metric: str,
                       quantity: float = 1.0):
        self.db.execute("""
            INSERT INTO usage (tenant_id, metric, quantity)
            VALUES (?, ?, ?)
        """, (tenant_id, metric, quantity))
        self.db.commit()

    def get_usage(self, tenant_id: str, days: int = 30) -> dict:
        cutoff = (datetime.now() - timedelta(days=days)).isoformat()
        rows = self.db.execute("""
            SELECT metric, SUM(quantity) FROM usage
            WHERE tenant_id=? AND recorded_at >= ?
            GROUP BY metric
        """, (tenant_id, cutoff)).fetchall()
        return {r[0]: r[1] for r in rows}

    def check_limits(self, tenant_id: str) -> dict:
        """يتحقق إن كان الـtenant تحت الحد"""
        tenant = self.get_tenant(tenant_id)
        if not tenant:
            return {"error": "tenant not found"}
        plan = self.PLAN_LIMITS.get(tenant["plan"], {})
        usage = self.get_usage(tenant_id)

        return {
            "plan": tenant["plan"],
            "limits": plan,
            "usage": usage,
            "within_limits": {
                "hosts": usage.get("hosts", 0) <= plan.get("max_hosts", 999999),
                "users": usage.get("users", 0) <= plan.get("max_users", 999999),
                "sessions": usage.get("sessions", 0) <= plan.get("max_sessions", 999999),
            },
        }

    # ==================== plans ====================
    def list_plans(self) -> list:
        return [
            {"name": k, **v}
            for k, v in self.PLAN_LIMITS.items()
        ]


# singleton
tenant_manager = TenantManager()
