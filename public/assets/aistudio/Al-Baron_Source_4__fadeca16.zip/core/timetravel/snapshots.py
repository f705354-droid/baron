# language: Python, file: core/timetravel/snapshots.py
# Snapshot manager — save graph state every N minutes
import os
import json
import sqlite3
import time
import shutil
import threading
from datetime import datetime
from core.graph.graph_db import graph


class SnapshotManager:
    """
    يأخذ snapshot للـgraph كل 5 دقائق.
    يحتفظ بـ 50 snapshot (4 ساعات من التاريخ).
    """
    def __init__(self, snapshot_dir: str = "~/.albaron/snapshots",
                  interval_min: int = 5, keep: int = 50):
        self.dir = os.path.expanduser(snapshot_dir)
        os.makedirs(self.dir, exist_ok=True)
        self.interval = interval_min * 60
        self.keep = keep
        self.running = False
        self.thread = None

    def start(self):
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False

    def _loop(self):
        while self.running:
            try:
                self.snapshot()
            except Exception as e:
                print(f"[snapshot] {e}")
            time.sleep(self.interval)

    def snapshot(self, tag: str = None) -> str:
        """ينشئ snapshot. يعيد المسار."""
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        tag = tag or "auto"
        filename = f"graph_{tag}_{ts}.db"
        path = os.path.join(self.dir, filename)

        # نسخ مباشر (SQLite)
        if os.path.exists(graph.path):
            shutil.copy2(graph.path, path)
            # metadata
            meta = {
                "snapshot": filename,
                "created": datetime.now().isoformat(),
                "tag": tag,
                "graph_stats": graph.get_attack_surface(),
                "size": os.path.getsize(path),
            }
            meta_path = path.replace(".db", ".json")
            with open(meta_path, "w") as f:
                json.dump(meta, f, indent=2)

        self._cleanup()
        return path

    def _cleanup(self):
        """يحذف snapshots قديمة إذا تجاوزنا keep"""
        files = sorted([
            f for f in os.listdir(self.dir)
            if f.startswith("graph_") and f.endswith(".db")
        ])
        while len(files) > self.keep:
            old = files.pop(0)
            os.remove(os.path.join(self.dir, old))
            meta = os.path.join(self.dir, old.replace(".db", ".json"))
            if os.path.exists(meta):
                os.remove(meta)

    def list_snapshots(self) -> list:
        snaps = []
        for f in sorted(os.listdir(self.dir), reverse=True):
            if f.startswith("graph_") and f.endswith(".db"):
                path = os.path.join(self.dir, f)
                meta_path = path.replace(".db", ".json")
                meta = {}
                if os.path.exists(meta_path):
                    with open(meta_path) as mf:
                        meta = json.load(mf)
                snaps.append({
                    "file": f,
                    "path": path,
                    "size": os.path.getsize(path),
                    "meta": meta,
                })
        return snaps


class Rewind:
    """
    يستعيد graph لحظة معينة (للقراءة فقط).
    يفتح snapshot في اتصال منفصل.
    """
    def __init__(self, snapshot_manager: SnapshotManager):
        self.sm = snapshot_manager

    def open_snapshot(self, filename: str) -> sqlite3.Connection:
        """يفتح snapshot للاستعلام"""
        path = os.path.join(self.sm.dir, filename)
        if not os.path.exists(path):
            raise FileNotFoundError(path)
        return sqlite3.connect(path, check_same_thread=False)

    def diff(self, snapshot_a: str, snapshot_b: str) -> dict:
        """يقارن بين snapshotين"""
        conn_a = self.open_snapshot(snapshot_a)
        conn_b = self.open_snapshot(snapshot_b)

        def nodes(conn):
            return {r[0] for r in conn.execute(
                "SELECT key FROM nodes").fetchall()}

        def edges(conn):
            return {(r[0], r[1], r[2]) for r in conn.execute(
                "SELECT n1.key, n2.key, e.edge_type FROM edges e "
                "JOIN nodes n1 ON e.src_id=n1.id "
                "JOIN nodes n2 ON e.dst_id=n2.id"
            ).fetchall()}

        nodes_a = nodes(conn_a)
        nodes_b = nodes(conn_b)
        edges_a = edges(conn_a)
        edges_b = edges(conn_b)

        conn_a.close()
        conn_b.close()

        return {
            "nodes_added": sorted(nodes_b - nodes_a),
            "nodes_removed": sorted(nodes_a - nodes_b),
            "edges_added": sorted(edges_b - edges_a),
            "edges_removed": sorted(edges_a - edges_b),
        }

    def query_at_time(self, filename: str, cypher_like: str) -> list:
        """
        استعلام على snapshot معين.
        simplified: نستخدم SQL مباشرة
        """
        conn = self.open_snapshot(filename)
        try:
            rows = conn.execute(cypher_like).fetchall()
            return rows
        finally:
            conn.close()


snapshot_manager = SnapshotManager()
rewind = Rewind(snapshot_manager)
