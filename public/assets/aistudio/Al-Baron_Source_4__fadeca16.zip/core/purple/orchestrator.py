# language: Python, file: core/purple/orchestrator.py
# Purple Team — runs APT emulation, measures detection
import threading
import time
from datetime import datetime
from core.adversary.emulator import get_emulator
from core.blue.detection_engine import engine


class PurpleOrchestrator:
    """
    يشغل APT emulation تلقائياً، يقيس detection.
    """
    def __init__(self, app, log_queue):
        self.app = app
        self.log = log_queue
        self.emulator = get_emulator(app, log_queue)
        self.engine = engine
        self.results = []
        self.on_result = None

    def run_exercise(self, profile_name: str, target: str) -> dict:
        """
        1. clear alerts
        2. run emulation
        3. wait
        4. measure
        """
        self.engine.clear()
        start = datetime.now()

        self.log.put(f"[purple] starting {profile_name} → {target}")
        result = self.emulator.start(profile_name, target, "fast")
        if result != "started":
            return {"error": result}

        # wait for completion
        while self.emulator.running:
            time.sleep(1)

        # measure
        time.sleep(3)
        alerts = self.engine.get_alerts()

        # compute per-step detection
        timeline = self.emulator.get_timeline()
        step_results = []
        for step in timeline:
            # match alert by technique
            technique = step.get("technique", "")
            matched_alert = any(
                technique.lower() in (a.get("log", {}).get(
                    "process", {}).get("command_line", "") or "").lower()
                or technique in str(a.get("log", ""))
                for a in alerts
            )
            step_results.append({
                "step": step.get("step"),
                "phase": step.get("phase"),
                "technique": technique,
                "action": step.get("action"),
                "detected": step.get("detected", False) or matched_alert,
                "alerts_matched": matched_alert,
            })

        total = len(step_results)
        detected = sum(1 for s in step_results if s["detected"])
        detection_rate = (detected / total * 100) if total > 0 else 0

        exercise = {
            "profile": profile_name,
            "target": target,
            "started": start.isoformat(),
            "finished": datetime.now().isoformat(),
            "total_steps": total,
            "detected": detected,
            "undetected": total - detected,
            "detection_rate": round(detection_rate, 1),
            "step_results": step_results,
            "alerts_generated": len(alerts),
            "blue_team_score": self._compute_score(detected, total),
        }

        self.results.append(exercise)
        self.log.put(f"[purple] {detection_rate:.0f}% detected")

        if self.on_result:
            try:
                self.on_result(exercise)
            except Exception:
                pass

        return exercise

    def _compute_score(self, detected: int, total: int) -> str:
        if total == 0:
            return "N/A"
        rate = detected / total
        if rate >= 0.9:
            return "A+"
        elif rate >= 0.7:
            return "A"
        elif rate >= 0.5:
            return "B"
        elif rate >= 0.3:
            return "C"
        else:
            return "F"

    def get_all_results(self) -> list:
        return self.results

    def trend(self) -> list:
        """trend over time"""
        return [
            {
                "date": r["started"][:10],
                "profile": r["profile"],
                "detection_rate": r["detection_rate"],
                "score": r["blue_team_score"],
            }
            for r in self.results
        ]


_orchestrator = None
def get_orchestrator(app, log_queue):
    global _orchestrator
    if _orchestrator is None:
        _orchestrator = PurpleOrchestrator(app, log_queue)
    return _orchestrator
