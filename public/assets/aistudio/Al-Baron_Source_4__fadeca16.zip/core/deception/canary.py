# language: Python, file: core/deception/canary.py
# Canary tokens — URL/file tokens that alert on access
import os
import uuid
import json
import threading
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs


class CanaryTokens:
    """
    Canary URLs يتم تسجيلها. إذا وصولها أي شخص → alert.
    """
    def __init__(self, port: int = 8888, log_queue=None):
        self.port = port
        self.log = log_queue
        self.tokens = {}          # token → metadata
        self.hits = []            # access events
        self.server = None
        self.on_hit = None

    def create_token(self, name: str, kind: str = "url") -> str:
        """ينشئ token جديد"""
        token = str(uuid.uuid4())[:12]
        self.tokens[token] = {
            "name": name,
            "kind": kind,
            "created": datetime.now().isoformat(),
            "hits": 0,
        }
        return token

    def start(self):
        """يشغل HTTP server يستقبل hits"""
        manager = self

        class CanaryHandler(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_GET(self):
                path = urlparse(self.path).path
                token = path.strip("/")
                ip = self.client_address[0]
                ua = self.headers.get("User-Agent", "?")
                ref = self.headers.get("Referer", "")

                if token in manager.tokens:
                    hit = {
                        "time": datetime.now().isoformat(),
                        "token": token,
                        "name": manager.tokens[token]["name"],
                        "source_ip": ip,
                        "user_agent": ua,
                        "referer": ref,
                    }
                    manager.tokens[token]["hits"] += 1
                    manager.hits.append(hit)
                    if manager.on_hit:
                        try:
                            manager.on_hit(hit)
                        except Exception:
                            pass
                    if manager.log:
                        manager.log.put(
                            f"[canary] HIT: {manager.tokens[token]['name']} "
                            f"from {ip}")

                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(b"<html><body>It works!</body></html>")

        self.server = HTTPServer(("0.0.0.0", self.port), CanaryHandler)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def stop(self):
        if self.server:
            self.server.shutdown()

    def generate_tracking_url(self, token: str) -> str:
        """يعيد URL جاهز للاستخدام"""
        return f"http://<your-ip>:{self.port}/{token}"

    def list_tokens(self) -> list:
        return [
            {"token": t, **meta}
            for t, meta in self.tokens.items()
        ]


class FileCanary:
    """
    ملفات canary — إذا فُتحت/نُسخت في مكان آخر → alert.
    نستخدم ملفات Excel/Word/PDF تحتوي على URL داخلي.
    """
    def __init__(self):
        self.canaries = []

    def create_office_canary(self, name: str,
                                canary_url: str) -> str:
        """ينشئ ملف Word/Excel يحتوي على canary URL"""
        # في الواقع: نستخدم مكتبة مثل python-docx
        path = f"canary_{name}.txt"
        with open(path, "w") as f:
            f.write(f"This document belongs to {name}.\n")
            f.write(f"If found, please visit: {canary_url}\n")
        self.canaries.append({
            "name": name,
            "path": path,
            "url": canary_url,
            "created": datetime.now().isoformat(),
        })
        return path


canary_tokens = CanaryTokens()
