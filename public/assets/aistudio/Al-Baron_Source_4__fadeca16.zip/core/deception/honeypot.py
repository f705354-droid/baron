# language: Python, file: core/deception/honeypot.py
# Honeypot — SSH + HTTP + FTP decoy servers that log attacks
import socket
import threading
import json
import os
import time
from datetime import datetime
from typing import List, Dict, Callable


class HoneypotBase:
    def __init__(self, port: int, service: str, log_queue=None):
        self.port = port
        self.service = service
        self.log = log_queue
        self.socket = None
        self.running = False
        self.thread = None
        self.events = []
        self.on_event = None

    def start(self):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            self.socket.bind(("0.0.0.0", self.port))
            self.socket.listen(10)
        except PermissionError:
            raise PermissionError(
                f"Need sudo for port {self.port}")
        self.running = True
        self.thread = threading.Thread(target=self._serve, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False
        if self.socket:
            try:
                self.socket.close()
            except Exception:
                pass

    def _serve(self):
        while self.running:
            try:
                client, addr = self.socket.accept()
                threading.Thread(
                    target=self._handle,
                    args=(client, addr), daemon=True).start()
            except OSError:
                break
            except Exception:
                pass

    def _handle(self, client, addr):
        ip = addr[0]
        banner = self._get_banner()
        event = {
            "time": datetime.now().isoformat(),
            "service": self.service,
            "port": self.port,
            "source_ip": ip,
            "source_port": addr[1],
            "banner_sent": banner[:100],
            "interactions": [],
        }

        try:
            # send banner
            client.sendall(banner.encode())
            client.settimeout(10)

            # read up to 5 lines
            for _ in range(5):
                try:
                    data = client.recv(1024)
                    if not data:
                        break
                    interaction = data.decode(errors="ignore").strip()
                    event["interactions"].append(interaction[:200])
                    # respond with fake data
                    response = self._respond(interaction)
                    if response:
                        client.sendall(response.encode())
                except socket.timeout:
                    break
        except Exception as e:
            event["error"] = str(e)
        finally:
            try:
                client.close()
            except Exception:
                pass

        self.events.append(event)
        if self.on_event:
            try:
                self.on_event(event)
            except Exception:
                pass
        if self.log:
            self.log.put(f"[honeypot:{self.service}] {ip} → "
                          f"{len(event['interactions'])} interactions")

    def _get_banner(self) -> str:
        return "220 Welcome\r\n"

    def _respond(self, data: str) -> str:
        return ""


class SSHHoneypot(HoneypotBase):
    def __init__(self, log_queue=None, port: int = 2222):
        super().__init__(port, "ssh", log_queue)

    def _get_banner(self) -> str:
        return "SSH-2.0-OpenSSH_7.4\r\n"

    def _respond(self, data: str) -> str:
        if "password" in data.lower():
            return "Permission denied, please try again.\r\n"
        return ""


class FTPHoneypot(HoneypotBase):
    def __init__(self, log_queue=None, port: int = 2121):
        super().__init__(port, "ftp", log_queue)

    def _get_banner(self) -> str:
        return "220 (vsFTPd 2.3.4)\r\n"

    def _respond(self, data: str) -> str:
        cmd = data.upper()[:4]
        responses = {
            "USER": "331 Please specify the password.\r\n",
            "PASS": "530 Login incorrect.\r\n",
            "SYST": "215 UNIX Type: L8\r\n",
            "PWD ": "257 \"/\"\r\n",
        }
        return responses.get(cmd, "500 Unknown command.\r\n")


class HTTPHoneypot(HoneypotBase):
    def __init__(self, log_queue=None, port: int = 8080):
        super().__init__(port, "http", log_queue)

    def _get_banner(self) -> str:
        return ""

    def _handle(self, client, addr):
        ip = addr[0]
        try:
            client.settimeout(5)
            data = client.recv(4096)
            request = data.decode(errors="ignore")
            event = {
                "time": datetime.now().isoformat(),
                "service": "http",
                "port": self.port,
                "source_ip": ip,
                "request": request[:500],
                "path": self._extract_path(request),
                "user_agent": self._extract_ua(request),
            }
            # respond with fake admin panel
            response = """HTTP/1.1 200 OK\r
Server: Apache/2.4.49\r
Content-Type: text/html\r
Content-Length: 134\r
\r
<html><head><title>Admin Panel</title></head>
<body><h1>Admin Login</h1>
<form><input name=user><input name=pass type=password></form></body></html>"""
            client.sendall(response.encode())

            self.events.append(event)
            if self.on_event:
                try:
                    self.on_event(event)
                except Exception:
                    pass
            if self.log:
                self.log.put(f"[honeypot:http] {ip} → "
                              f"{event.get('path', '?')}")
        except Exception:
            pass
        finally:
            try:
                client.close()
            except Exception:
                pass

    def _extract_path(self, request: str) -> str:
        try:
            first_line = request.split("\r\n")[0]
            return first_line.split(" ")[1]
        except Exception:
            return "?"

    def _extract_ua(self, request: str) -> str:
        for line in request.split("\r\n"):
            if line.lower().startswith("user-agent:"):
                return line[11:].strip()
        return ""


class HoneypotManager:
    """يدير عدة honeypots"""
    def __init__(self, log_queue=None):
        self.log = log_queue
        self.pots: List[HoneypotBase] = []
        self.events: List[dict] = []

    def add_pot(self, pot: HoneypotBase):
        pot.on_event = self._on_event
        self.pots.append(pot)

    def start_all(self):
        started = []
        for pot in self.pots:
            try:
                pot.start()
                started.append(f"{pot.service}:{pot.port}")
            except Exception as e:
                if self.log:
                    self.log.put(f"[honeypot] {pot.service}: {e}")
        return started

    def stop_all(self):
        for pot in self.pots:
            pot.stop()

    def _on_event(self, event: dict):
        self.events.append(event)

    def get_events(self) -> List[dict]:
        return self.events


honeypot_manager = HoneypotManager()
