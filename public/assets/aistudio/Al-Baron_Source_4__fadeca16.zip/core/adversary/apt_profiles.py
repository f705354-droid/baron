# language: Python, file: core/adversary/apt_profiles.py
# APT profiles — MITRE ATT&CK-mapped adversary groups
import json
from datetime import datetime


class APTProfile:
    """
    يمثل APT group معروف.
    كل خطوة لها:
      - tactic + technique (MITRE)
      - tool used (real or equivalent)
      - detection likelihood (high/med/low)
    """
    def __init__(self, name: str, alias: str, origin: str,
                  description: str, techniques: list, ttps: list):
        self.name = name
        self.alias = alias
        self.origin = origin
        self.description = description
        self.techniques = techniques     # MITRE tactics
        self.ttps = ttps                 # list of steps

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "alias": self.alias,
            "origin": self.origin,
            "description": self.description,
            "techniques": self.techniques,
            "ttps": self.ttps,
        }


# ═══════════════════════════════════════════════════════════════════
# APT28 — Fancy Bear (Russia/GRU)
# ═══════════════════════════════════════════════════════════════════
APT28 = APTProfile(
    name="APT28",
    alias="Fancy Bear",
    origin="Russia (GRU 26165)",
    description="State-sponsored cyber espionage group, active since 2004. "
                "Targets government, military, and defense contractors. "
                "Known for credential phishing, zero-days, and strategic web compromises.",
    techniques=[
        "T1566.001 Spearphishing Attachment",
        "T1566.002 Spearphishing Link",
        "T1078 Valid Accounts",
        "T1059.005 Visual Basic",
        "T1059.001 PowerShell",
        "T1555.003 Credentials from Web Browsers",
        "T1003.001 LSASS Memory",
        "T1071.001 Web Protocols",
    ],
    ttps=[
        {
            "step": 1,
            "phase": "Initial Access",
            "technique": "T1566.002",
            "action": "Send spearphishing link (simulated)",
            "tool": "phishing_module",
            "target": "email_gateway",
            "detectability": "high",
            "detection_hint": "Unusual sender, link to newly-registered domain",
        },
        {
            "step": 2,
            "phase": "Execution",
            "technique": "T1059.001",
            "action": "Run obfuscated PowerShell dropper",
            "tool": "payload",
            "target": "endpoint",
            "detectability": "medium",
            "detection_hint": "PowerShell -EncodedCommand, AMSI bypass",
        },
        {
            "step": 3,
            "phase": "Persistence",
            "technique": "T1547.001",
            "action": "Create Run key persistence",
            "tool": "post_pipeline",
            "target": "endpoint",
            "detectability": "low",
            "detection_hint": "Reg add HKCU\\...\\Run",
        },
        {
            "step": 4,
            "phase": "Credential Access",
            "technique": "T1003.001",
            "action": "Dump LSASS memory",
            "tool": "post_pipeline",
            "target": "endpoint",
            "detectability": "high",
            "detection_hint": "procdump.exe, mimikatz sekurlsa, non-Microsoft debugger",
        },
        {
            "step": 5,
            "phase": "Lateral Movement",
            "technique": "T1021.002",
            "action": "SMB/WMI lateral movement",
            "tool": "lan",
            "target": "internal_host",
            "detectability": "medium",
            "detection_hint": "5140, 5145, WMI remote process execution",
        },
        {
            "step": 6,
            "phase": "Command and Control",
            "technique": "T1071.001",
            "action": "HTTPS C2 to attacker infrastructure",
            "tool": "c2",
            "target": "internet",
            "detectability": "high",
            "detection_hint": "Beaconing, self-signed cert, unusual UA",
        },
        {
            "step": 7,
            "phase": "Exfiltration",
            "technique": "T1041",
            "action": "Exfiltrate over C2 channel",
            "tool": "exfil",
            "target": "internet",
            "detectability": "medium",
            "detection_hint": "Large outbound to unusual destination",
        },
    ],
)


# ═══════════════════════════════════════════════════════════════════
# APT29 — Cozy Bear (Russia/SVR)
# ═══════════════════════════════════════════════════════════════════
APT29 = APTProfile(
    name="APT29",
    alias="Cozy Bear",
    origin="Russia (SVR)",
    description="Sophisticated state-sponsored actor attributed to SVR. "
                "Known for supply chain attacks (SolarWinds), "
                "cloud infrastructure abuse, and stealthy operations.",
    techniques=[
        "T1195.002 Supply Chain Compromise",
        "T1078.004 Cloud Accounts",
        "T1071.001 Web Protocols",
        "T1071.004 DNS",
        "T1550.001 Application Access Token",
        "T1550.002 Pass the Hash",
        "T1021.001 RDP",
        "T1552.001 Credentials In Files",
    ],
    ttps=[
        {
            "step": 1,
            "phase": "Initial Access",
            "technique": "T1195.002",
            "action": "Compromise software supply chain",
            "tool": "payload",
            "target": "build_server",
            "detectability": "very_low",
            "detection_hint": "Unusual build artifact, code signing anomalies",
        },
        {
            "step": 2,
            "phase": "Execution",
            "technique": "T1059.003",
            "action": "Execute via trusted binary (LOLbin)",
            "tool": "post_pipeline",
            "target": "endpoint",
            "detectability": "low",
            "detection_hint": "certutil -urlcache, rundll32, mshta",
        },
        {
            "step": 3,
            "phase": "Defense Evasion",
            "technique": "T1562.001",
            "action": "Disable AV/EDR",
            "tool": "post_pipeline",
            "target": "endpoint",
            "detectability": "high",
            "detection_hint": "Windows Defender service stops, AMSI patching",
        },
        {
            "step": 4,
            "phase": "Credential Access",
            "technique": "T1550.001",
            "action": "Use stolen OAuth token",
            "tool": "cloud",
            "target": "o365",
            "detectability": "medium",
            "detection_hint": "Anomalous API calls from unusual IP/UA",
        },
        {
            "step": 5,
            "phase": "Lateral Movement",
            "technique": "T1021.001",
            "action": "RDP lateral movement",
            "tool": "lan",
            "target": "internal_host",
            "detectability": "medium",
            "detection_hint": "4624 logon type 10 from unusual host",
        },
        {
            "step": 6,
            "phase": "Command and Control",
            "technique": "T1071.004",
            "action": "DNS tunneling C2",
            "tool": "covert_c2",
            "target": "internet",
            "detectability": "low",
            "detection_hint": "High-volume TXT queries, long subdomains",
        },
        {
            "step": 7,
            "phase": "Collection",
            "technique": "T1114.002",
            "action": "Harvest emails via Graph API",
            "tool": "cloud",
            "target": "o365",
            "detectability": "medium",
            "detection_hint": "Bulk mail access via EWS/Graph from unusual client",
        },
    ],
)


# ═══════════════════════════════════════════════════════════════════
# Lazarus Group (North Korea)
# ═══════════════════════════════════════════════════════════════════
LAZARUS = APTProfile(
    name="Lazarus Group",
    alias="Hidden Cobra",
    origin="North Korea (RGB)",
    description="Financially and politically motivated. Known for SWIFT banking attacks, "
                "cryptocurrency theft, and destructive malware.",
    techniques=[
        "T1566.001 Spearphishing Attachment",
        "T1204.002 Malicious File",
        "T1486 Data Encrypted for Impact",
        "T1490 Inhibit System Recovery",
        "T1657 Financial Theft",
    ],
    ttps=[
        {
            "step": 1,
            "phase": "Initial Access",
            "technique": "T1566.001",
            "action": "Malicious macro document",
            "tool": "phishing",
            "target": "employee",
            "detectability": "high",
            "detection_hint": "Macro execution, child process from Office",
        },
        {
            "step": 2,
            "phase": "Execution",
            "technique": "T1204.002",
            "action": "Execute dropper",
            "tool": "payload",
            "target": "endpoint",
            "detectability": "medium",
        },
        {
            "step": 3,
            "phase": "Impact",
            "technique": "T1486",
            "action": "Deploy ransomware",
            "tool": "post_pipeline",
            "target": "fileserver",
            "detectability": "high",
            "detection_hint": "Mass file encryption, extension change",
        },
    ],
)


ALL_APT_GROUPS = {
    "APT28": APT28,
    "APT29": APT29,
    "Lazarus": LAZARUS,
}
