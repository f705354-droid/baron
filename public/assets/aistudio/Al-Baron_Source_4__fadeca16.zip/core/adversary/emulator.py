# language: Python, file: core/adversary/emulator.py
# Adversary emulator — runs APT simulations
import threading
import time
import json
from datetime import datetime
from core.adversary.apt_profiles import ALL_APT_GROUPS, APTProfile
from core.graph.graph_db import graph


class EmulationEvent:
    def __init__(self, step: dict, status: str = "pending"):
        self.step = step
        self.status = status
        self.started_at = None
        self.completed_at = None
        self.detected = False
        self.detection_source = None
        self.notes = []

    def to_dict(self):
        return {
            "step": self.step.get("step"),
            "phase": self.step.get("phase"),
            "technique": self.step.get("technique"),
            "action": self.step.get("action"),
            "tool": self.step.get("tool"),
            "status": self.status,
            "detected": self.detected,
            "detection_source": self.detection_source,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "notes": self.notes,
        }


class AdversaryEmulator:
    """
    يشغل APT profile مقابل المختبر.
    لكل خطوة:
      - يستدعي module المناسب
      - يوثق النتيجة في graph
      - يرسل حدثاً لفريق Blue
    """
    def __init__(self, app, log_queue):
        self.app = app
        self.log = log_queue
        self.running = False
        self.current_profile = None
        self.events = []
        self.on_event = None

    def list_profiles(self) -> list:
        return [
            {"name": p.name, "alias": p.alias, "origin": p.origin,
              "description": p.description,
              "techniques": len(p.techniques),
              "steps": len(p.ttps)}
            for p in ALL_APT_GROUPS.values()
        ]

    def start(self, profile_name: str, target: str,
               speed: str = "normal") -> str:
        if self.running:
            return "already running"
        if profile_name not in ALL_APT_GROUPS:
            return f"unknown profile: {profile_name}"

        self.current_profile = ALL_APT_GROUPS[profile_name]
        self.target = target
        self.speed = speed
        self.running = True
        self.events = []

        thread = threading.Thread(target=self._run, daemon=True)
        thread.start()
        return "started"

    def stop(self):
        self.running = False
        self._emit("stopped", {})

    def _run(self):
        profile = self.current_profile
        self._emit("start", {
            "profile": profile.name,
            "alias": profile.alias,
            "target": self.target,
            "steps": len(profile.ttps),
        })

        delay_map = {"fast": 0.5, "normal": 3, "slow": 10}
        delay = delay_map.get(self.speed, 3)

        for step in profile.ttps:
            if not self.running:
                break

            event = EmulationEvent(step, status="running")
            event.started_at = datetime.now().isoformat()
            self.events.append(event)

            self._emit("step_start", {
                "step": step["step"],
                "phase": step["phase"],
                "technique": step["technique"],
                "action": step["action"],
            })

            try:
                self._execute_step(step)
                event.status = "completed"
                event.completed_at = datetime.now().isoformat()

                # register in graph
                graph.register_technique(
                    step["technique"],
                    step["action"],
                    step["phase"])

                # simulate detection probability
                import random
                detect_prob = {
                    "very_low": 0.05,
                    "low": 0.15,
                    "medium": 0.4,
                    "high": 0.7,
                }.get(step.get("detectability", "medium"), 0.4)

                if random.random() < detect_prob:
                    event.detected = True
                    event.detection_source = "simulated_blue_team"
                    self._emit("detected", {
                        "step": step["step"],
                        "technique": step["technique"],
                        "hint": step.get("detection_hint", ""),
                    })

                self._emit("step_complete", {
                    "step": step["step"],
                    "status": event.status,
                    "detected": event.detected,
                })

            except Exception as e:
                event.status = "failed"
                event.notes.append(str(e))
                self._emit("step_error", {
                    "step": step["step"],
                    "error": str(e),
                })

            time.sleep(delay)

        self.running = False
        detected = sum(1 for e in self.events if e.detected)
        self._emit("complete", {
            "profile": profile.name,
            "total_steps": len(profile.ttps),
            "detected": detected,
            "undetected": len(self.events) - detected,
        })

    def _execute_step(self, step: dict):
        """ينفذ خطوة من الـprofile"""
        tool_name = step.get("tool")
        if not tool_name:
            return

        module = self.app.modules.get(tool_name) if self.app else None
        if not module:
            raise Exception(f"module '{tool_name}' not loaded")

        # محاكاة: نسجل في graph فقط
        # في الواقع، تستدعي method حقيقية
        action = step.get("action", "")
        self.log.put(f"[emulator] {step['phase']}: {action}")

        # register in graph
        graph.register_host(
            self.target,
            simulated=True,
            apT_step=step["step"])

    def get_timeline(self) -> list:
        """يعيد timeline كامل"""
        return [e.to_dict() for e in self.events]

    def _emit(self, event_type: str, payload: dict):
        ev = {
            "type": event_type,
            "ts": datetime.now().isoformat(),
            **payload,
        }
        if self.on_event:
            try:
                self.on_event(ev)
            except Exception:
                pass
        self.log.put(f"[emulator] {event_type}")


# instance
_emulator = None

def get_emulator(app, log_queue):
    global _emulator
    if _emulator is None:
        _emulator = AdversaryEmulator(app, log_queue)
    return _emulator
