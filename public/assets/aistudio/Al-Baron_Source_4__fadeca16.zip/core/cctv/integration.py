# language: Python, file: core/cctv/integration.py
# CCTV integration with platform — graph + reports + MITRE
import json
from datetime import datetime
from core.graph.graph_db import graph


class CCTVIntegration:
    """
    يربط كل نتائج CCTV بالمنصة:
      - graph nodes
      - MITRE ATT&CK techniques
      - findings
    """

    # MITRE techniques المستخدمة
    TECHNIQUES = {
        "discovery": "T1046",           # Network Service Discovery
        "rtsp_probe": "T1046",          # Network Service Discovery
        "ws_discovery": "T1018",        # Remote System Discovery
        "ssdp": "T1018",                # Remote System Discovery
        "default_creds": "T1078.001",   # Default Accounts
        "brute_force": "T1110",         # Brute Force
        "exploit_rce": "T1190",         # Exploit Public-Facing App
        "auth_bypass": "T1190",         # Exploit Public-Facing App
        "path_traversal": "T1083",      # File and Directory Discovery
        "ptz_control": "T1565",         # Data Manipulation
        "snapshot_theft": "T1530",      # Data from Cloud Storage (adapt)
        "stream_intercept": "T1113",    # Screen Capture (adapt)
        "motion_hijack": "T1113",       # Screen Capture (adapt)
        "firmware_backdoor": "T1542.001",  # Pre-OS Boot: System Firmware
        "playback_download": "T1005",   # Data from Local System (adapt)
        "nvr_dump": "T1005",            # Data from Local System
    }

    def __init__(self):
        self.findings = []

    # ==================== graph integration ====================
    def register_camera_to_graph(self, cam: dict,
                                   creds: dict = None) -> int:
        """
        يضيف كاميرا كـnode في graph.
        """
        ip = cam.get("ip")
        if not ip:
            return -1

        # host node
        graph.register_host(
            ip,
            is_camera=True,
            camera_vendor=cam.get("vendor", ""),
            camera_ports=cam.get("open_ports", []),
            camera_model=cam.get("model", ""),
            camera_serial=cam.get("serial", ""),
            camera_firmware=cam.get("firmware", ""),
            is_dc=False,
            is_admin=False,
            public=True,
        )

        # subnets edges
        graph.add_edge("host", ip, "host", "network",
                        "is_on_network", {})

        # credentials
        if creds:
            key = f"{creds.get('user','admin')}@camera-{ip}"
            graph.register_credential(
                creds.get("user", "admin"),
                creds.get("password", ""),
                source=f"camera-{ip}",
                service="rtsp" if "rtsp" in creds.get("protocol", "")
                         else "http")
            graph.add_edge("credential", key, "host", ip,
                            "has_cred")

        return graph.get_node("host", ip)["id"] if graph.get_node(
            "host", ip) else -1

    def register_vulnerability(self, cam_ip: str, cve: str,
                                 severity: str, description: str):
        """يضيف vulnerability"""
        graph.register_vuln(
            cve, cam_ip,
            cvss=9.8 if severity == "critical" else 7.5 if severity == "high" else 5.0,
            severity=severity,
            description=description,
            source="cctv_scan",
        )

    def register_technique(self, technique_key: str,
                             context: str = ""):
        """يسجل MITRE technique"""
        tid = self.TECHNIQUES.get(technique_key)
        if not tid:
            return
        name = self._technique_name(tid)
        tactic = self._technique_tactic(tid)
        graph.register_technique(tid, name, tactic)
        graph.add_edge("technique", tid, "task", "cctv_scan",
                        "used_in", {"context": context})

    def _technique_name(self, tid: str) -> str:
        names = {
            "T1046": "Network Service Discovery",
            "T1018": "Remote System Discovery",
            "T1078.001": "Default Accounts",
            "T1110": "Brute Force",
            "T1190": "Exploit Public-Facing Application",
            "T1083": "File and Directory Discovery",
            "T1565": "Data Manipulation",
            "T1530": "Data from Cloud Storage",
            "T1113": "Screen Capture",
            "T1542.001": "System Firmware",
            "T1005": "Data from Local System",
        }
        return names.get(tid, "Unknown Technique")

    def _technique_tactic(self, tid: str) -> str:
        tactics = {
            "T1046": "Discovery",
            "T1018": "Discovery",
            "T1078.001": "Initial Access",
            "T1110": "Credential Access",
            "T1190": "Initial Access",
            "T1083": "Discovery",
            "T1565": "Impact",
            "T1530": "Collection",
            "T1113": "Collection",
            "T1542.001": "Persistence",
            "T1005": "Collection",
        }
        return tactics.get(tid, "Unknown")

    # ==================== findings generation ====================
    def create_findings(self, scan_results: list,
                          working_creds: dict,
                          exploitation_results: list = None) -> list:
        """
        يحوّل نتائج CCTV إلى findings قياسية.
        """
        findings = []

        for cam in scan_results:
            ip = cam.get("ip")
            if not ip:
                continue

            # 1. default creds finding
            if ip in working_creds:
                creds = working_creds[ip]
                finding = {
                    "severity": "high",
                    "title": f"Camera uses weak credentials: {ip}",
                    "host": ip,
                    "description": f"Camera accessible with default creds "
                                   f"({creds['user']}:{creds['password']}) via "
                                   f"{creds.get('protocol', 'unknown')}",
                    "evidence": f"Successful authentication: "
                                f"{creds.get('protocol')} on port {creds.get('port')}",
                    "mitre": self.TECHNIQUES["default_creds"],
                    "category": "authentication",
                }
                findings.append(finding)
                self.register_vulnerability(
                    ip, "CWE-1392",
                    "high",
                    "Use of Default Credentials")

            # 2. unauthenticated RTSP finding
            if cam.get("rtsp", {}).get("paths_found"):
                unauth_paths = [p for p in cam["rtsp"]["paths_found"]
                                  if not p.get("auth")]
                if unauth_paths:
                    finding = {
                        "severity": "high",
                        "title": f"Unauthenticated RTSP stream on {ip}",
                        "host": ip,
                        "description": f"RTSP streams accessible without "
                                        f"authentication: {len(unauth_paths)} paths",
                        "evidence": f"Paths: {[p['path'] for p in unauth_paths][:3]}",
                        "mitre": self.TECHNIQUES["rtsp_probe"],
                        "category": "authentication",
                    }
                    findings.append(finding)

            # 3. ONVIF accessible
            if cam.get("onvif", {}).get("reachable"):
                finding = {
                    "severity": "medium",
                    "title": f"ONVIF service exposed: {ip}",
                    "host": ip,
                    "description": f"ONVIF device service accessible",
                    "mitre": self.TECHNIQUES["ws_discovery"],
                    "category": "exposure",
                }
                findings.append(finding)

            # 4. CVE findings
            for expl in (exploitation_results or []):
                if expl.get("ip") == ip and expl.get("vulnerable"):
                    finding = {
                        "severity": "critical",
                        "title": f"{expl['cve']} on camera {ip}",
                        "host": ip,
                        "cve": expl["cve"],
                        "description": expl.get("description", ""),
                        "mitre": self.TECHNIQUES["exploit_rce"],
                        "category": "exploitation",
                    }
                    findings.append(finding)
                    self.register_vulnerability(
                        ip, expl["cve"], "critical",
                        expl.get("description", ""))

        self.findings = findings
        return findings

    # ==================== events ====================
    def log_technique_use(self, technique_key: str,
                            target_ip: str, success: bool,
                            details: str = ""):
        """يسجل استخدام technique"""
        graph.add_edge(
            "technique", self.TECHNIQUES.get(technique_key, "unknown"),
            "host", target_ip,
            "attempted_on",
            {"success": success, "details": details,
              "at": datetime.now().isoformat()})

    # ==================== attack surface ====================
    def update_attack_surface(self):
        """يحدّث graph attack surface"""
        # hosted cameras
        cameras = graph.list_nodes("host")
        camera_count = sum(1 for c in cameras
                            if c["properties"].get("is_camera"))
        return {
            "total_hosts": len(cameras),
            "cameras": camera_count,
            "vulnerabilities": len(graph.list_nodes("vulnerability")),
            "credentials": len(graph.list_nodes("credential")),
            "techniques": len(graph.list_nodes("technique")),
        }
