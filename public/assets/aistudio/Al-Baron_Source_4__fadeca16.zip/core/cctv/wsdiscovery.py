# language: Python, file: core/cctv/wsdiscovery.py
# ONVIF discovery — broadcast + collect responses
import socket
import struct
import time
import threading
import xml.etree.ElementTree as ET
from datetime import datetime
from typing import List, Callable


class WSDiscoveryBroadcast:
    """
    ONVIF WS-Discovery broadcast:
      - يرسل Probe لكل IP في subnet
      - يجمع الردود
      - يستخرج XAddrs (device endpoints)
    """
    MULTICAST_GROUP = "239.255.255.250"
    PORT = 3702

    PROBE = '''<?xml version="1.0" encoding="UTF-8"?>
<e:Envelope xmlns:e="http://www.w3.org/2003/05/soap-envelope"
            xmlns:w="http://schemas.xmlsoap.org/ws/2004/08/addressing"
            xmlns:d="http://schemas.xmlsoap.org/ws/2005/04/discovery"
            xmlns:dn="http://www.onvif.org/ver10/network/wsdl">
  <e:Header>
    <w:MessageID>uuid:{message_id}</w:MessageID>
    <w:To>urn:schemas-xmlsoap-org:ws:2005:04:discovery</w:To>
    <w:Action>http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</w:Action>
  </e:Header>
  <e:Body>
    <d:Probe>
      <d:Types>dn:NetworkVideoTransmitter</d:Types>
    </d:Probe>
  </e:Body>
</e:Envelope>'''

    def __init__(self, log_queue=None):
        self.log = log_queue
        self.devices = []
        self.on_device = None

    def _out(self, text):
        if self.log:
            self.log.put(f"[ws-d] {text}")

    def send_probe(self, ip: str, timeout: float = 2.0) -> List[dict]:
        """
        يرسل Probe لـIP محدد وينتظر الرد.
        """
        import uuid
        message_id = str(uuid.uuid4())
        probe = self.PROBE.format(message_id=message_id)

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.settimeout(timeout)
            sock.sendto(probe.encode(), (ip, self.PORT))

            responses = []
            start = time.time()
            while time.time() - start < timeout:
                try:
                    data, addr = sock.recvfrom(65535)
                    if addr[0] != ip:
                        continue
                    device = self._parse_response(data, addr[0])
                    if device:
                        responses.append(device)
                except socket.timeout:
                    break

            sock.close()
            return responses
        except Exception as e:
            self._out(f"probe {ip}: {e}")
            return []

    def _parse_response(self, data: bytes, ip: str) -> dict:
        """يفك WS-Discovery response"""
        try:
            root = ET.fromstring(data)
            device = {
                "ip": ip,
                "endpoints": [],
                "types": [],
                "scopes": [],
                "xaddrs": [],
                "discovered_at": datetime.now().isoformat(),
            }

            for elem in root.iter():
                tag = elem.tag.split("}")[-1]
                if tag == "XAddrs" and elem.text:
                    device["xaddrs"] = elem.text.split()
                elif tag == "Types" and elem.text:
                    device["types"] = elem.text.split()
                elif tag == "Scopes" and elem.text:
                    device["scopes"] = elem.text.split()
                elif tag == "Address" and elem.text:
                    device["endpoints"].append(elem.text)

            if device["xaddrs"] or device["endpoints"]:
                return device
        except Exception as e:
            self._out(f"parse: {e}")
        return None

    def scan_range(self, base_ip: str, prefix: int = 24,
                    timeout: float = 1.5,
                    max_workers: int = 50) -> List[dict]:
        """
        scan subnet — يرسل Probe لكل IP.
        base_ip: "192.168.1.0" أو "192.168.1.1"
        prefix: 24 for /24
        """
        from concurrent.futures import ThreadPoolExecutor
        import ipaddress

        try:
            net = ipaddress.ip_network(f"{base_ip}/{prefix}", strict=False)
        except ValueError:
            return []

        hosts = [str(ip) for ip in net.hosts()]
        self._out(f"scanning {len(hosts)} hosts for ONVIF")

        found = []
        lock = threading.Lock()

        def probe_one(ip):
            devs = self.send_probe(ip, timeout)
            if devs:
                with lock:
                    found.extend(devs)
                    for d in devs:
                        self._out(f"✓ {d['ip']} ({len(d['xaddrs'])} addrs)")
                        if self.on_device:
                            try:
                                self.on_device(d)
                            except Exception:
                                pass

        with ThreadPoolExecutor(max_workers=max_workers) as ex:
            ex.map(probe_one, hosts)

        self.devices = found
        return found

    def scan_multicast(self, timeout: int = 10) -> List[dict]:
        """
        يرسل Probe لـmulticast ويستمع للردود.
        """
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM,
                                   socket.IPPROTO_UDP)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(("", self.PORT))

            mreq = struct.pack(
                "4s4s",
                socket.inet_aton(self.MULTICAST_GROUP),
                socket.inet_aton("0.0.0.0"))
            sock.setsockopt(socket.IPPROTO_IP,
                              socket.IP_ADD_MEMBERSHIP, mreq)
            sock.settimeout(1.0)

            # send probe
            import uuid
            probe = self.PROBE.format(message_id=str(uuid.uuid4()))
            sock.sendto(probe.encode(),
                          (self.MULTICAST_GROUP, self.PORT))
            self._out("multicast probe sent")

            # collect responses
            devices = []
            start = time.time()
            while time.time() - start < timeout:
                try:
                    data, addr = sock.recvfrom(65535)
                    device = self._parse_response(data, addr[0])
                    if device and device["ip"] not in [d["ip"] for d in devices]:
                        devices.append(device)
                        self._out(f"✓ {device['ip']}")
                        if self.on_device:
                            try:
                                self.on_device(device)
                            except Exception:
                                pass
                except socket.timeout:
                    continue

            sock.close()
            return devices
        except Exception as e:
            self._out(f"multicast error: {e}")
            return []
