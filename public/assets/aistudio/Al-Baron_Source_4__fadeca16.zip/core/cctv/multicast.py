# language: Python, file: core/cctv/multicast.py
# Multicast sniffing — passive discovery of cameras
import socket
import struct
import threading
import time
from datetime import datetime
from typing import Callable


class MulticastSniffer:
    """
    يصطاد multicast packets التي ترسلها الكاميرات:
      - ONVIF WS-Discovery (239.255.255.250:3702)
      - mDNS (224.0.0.251:5353)
      - SSDP/UPnP (239.255.255.250:1900)
    """
    WS_DISCOVERY_GROUP = "239.255.255.250"
    WS_DISCOVERY_PORT = 3702
    SSDP_GROUP = "239.255.255.250"
    SSDP_PORT = 1900
    MDNS_GROUP = "224.0.0.251"
    MDNS_PORT = 5353

    def __init__(self, log_queue=None):
        self.log = log_queue
        self.running = False
        self.devices = {}
        self.handlers = []

    def on_device(self, callback: Callable):
        self.handlers.append(callback)

    def start(self, iface: str = None, duration: int = 60):
        """يبدأ الاستماع لـONVIF + SSDP"""
        self.running = True
        threads = [
            threading.Thread(
                target=self._sniff_ws_discovery,
                args=(iface, duration), daemon=True),
            threading.Thread(
                target=self._sniff_ssdp,
                args=(iface, duration), daemon=True),
        ]
        for t in threads:
            t.start()

    def stop(self):
        self.running = False

    def _sniff_ws_discovery(self, iface: str, duration: int):
        """ONVIF WS-Discovery"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM,
                                   socket.IPPROTO_UDP)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(("", self.WS_DISCOVERY_PORT))

            mreq = struct.pack(
                "4s4s",
                socket.inet_aton(self.WS_DISCOVERY_GROUP),
                socket.inet_aton("0.0.0.0"))
            sock.setsockopt(socket.IPPROTO_IP,
                              socket.IP_ADD_MEMBERSHIP, mreq)
            sock.settimeout(1)

            start = time.time()
            while self.running and (time.time() - start) < duration:
                try:
                    data, addr = sock.recvfrom(65535)
                    ip = addr[0]
                    if b"onvif" in data.lower() or b"NetworkVideoTransmitter" in data:
                        self._register_device(ip, "onvif", data[:200])
                except socket.timeout:
                    continue
        except Exception as e:
            if self.log:
                self.log.put(f"[multicast] ws-discovery: {e}")

    def _sniff_ssdp(self, iface: str, duration: int):
        """SSDP / UPnP"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM,
                                   socket.IPPROTO_UDP)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(("", self.SSDP_PORT))

            mreq = struct.pack(
                "4s4s",
                socket.inet_aton(self.SSDP_GROUP),
                socket.inet_aton("0.0.0.0"))
            sock.setsockopt(socket.IPPROTO_IP,
                              socket.IP_ADD_MEMBERSHIP, mreq)
            sock.settimeout(1)

            start = time.time()
            while self.running and (time.time() - start) < duration:
                try:
                    data, addr = sock.recvfrom(65535)
                    ip = addr[0]
                    text = data.decode(errors="ignore").lower()

                    if any(kw in text for kw in [
                        "camera", "nvr", "dvr", "ipc",
                        "hikvision", "dahua", "axis",
                        "onvif", "network video", "webcam",
                    ]):
                        self._register_device(ip, "ssdp", data[:200])
                except socket.timeout:
                    continue
        except Exception as e:
            if self.log:
                self.log.put(f"[multicast] ssdp: {e}")

    def _register_device(self, ip: str, protocol: str, raw: bytes):
        if ip in self.devices:
            return

        device = {
            "ip": ip,
            "protocol": protocol,
            "discovered_at": datetime.now().isoformat(),
            "raw": raw.decode(errors="ignore")[:300],
        }
        self.devices[ip] = device

        if self.log:
            self.log.put(f"[multicast] {protocol}: {ip}")

        for h in self.handlers:
            try:
                h(device)
            except Exception:
                pass

    def send_ws_discovery_probe(self, iface: str = None):
        """
        يرسل WS-Discovery Probe — يجبر الكاميرات على الرد.
        """
        probe = b'''<?xml version="1.0" encoding="UTF-8"?>
<e:Envelope xmlns:e="http://www.w3.org/2003/05/soap-envelope"
            xmlns:w="http://schemas.xmlsoap.org/ws/2004/08/addressing"
            xmlns:d="http://schemas.xmlsoap.org/ws/2005/04/discovery"
            xmlns:dn="http://www.onvif.org/ver10/network/wsdl">
  <e:Header>
    <w:MessageID>uuid:albaron-probe</w:MessageID>
    <w:To>urn:schemas-xmlsoap-org:ws:2005:04:discovery</w:To>
    <w:Action>http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</w:Action>
  </e:Header>
  <e:Body>
    <d:Probe>
      <d:Types>dn:NetworkVideoTransmitter</d:Types>
    </d:Probe>
  </e:Body>
</e:Envelope>'''

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM,
                                   socket.IPPROTO_UDP)
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
            sock.sendto(probe, (self.WS_DISCOVERY_GROUP,
                                  self.WS_DISCOVERY_PORT))
            sock.close()
            if self.log:
                self.log.put("[multicast] WS-Discovery probe sent")
        except Exception as e:
            if self.log:
                self.log.put(f"[multicast] probe: {e}")
