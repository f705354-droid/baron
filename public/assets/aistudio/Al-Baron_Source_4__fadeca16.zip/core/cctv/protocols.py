# language: Python, file: core/cctv/protocols.py
# Protocol implementations — RTSP, ONVIF, HTTP
import socket
import base64
import re
import xml.etree.ElementTree as ET


# ═══════════════════════════════════════════════════════════════════
# RTSP
# ═══════════════════════════════════════════════════════════════════
class RTSPClient:
    """RTSP protocol client — يستخدم للـstream enumeration"""
    PATHS = [
        "/",
        "/Streaming/Channels/101",          # Hikvision main
        "/Streaming/Channels/102",          # Hikvision sub
        "/cam/realmonitor?channel=1&subtype=0",  # Dahua
        "/axis-media/media.amp",            # Axis
        "/live/ch0",                        # Vivotek
        "/mpeg4",                           # Panasonic
        "/h264",                            # Generic
        "/videoMain",                       # Generic
        "/live",                            # Generic
        "/stream1",                         # Generic
    ]

    @staticmethod
    def probe(ip: str, port: int = 554, timeout: float = 3.0) -> dict:
        """
        يفحص RTSP server ويعيد معلومات.
        """
        result = {
            "ip": ip,
            "port": port,
            "server": "",
            "paths_found": [],
            "auth_required": False,
            "reachable": False,
        }

        # OPTIONS request
        try:
            sock = socket.create_connection((ip, port), timeout=timeout)
            sock.settimeout(timeout)

            options_req = (
                f"OPTIONS rtsp://{ip}:{port}/ RTSP/1.0\r\n"
                f"CSeq: 1\r\n"
                f"User-Agent: Al-Baron\r\n"
                f"\r\n"
            )
            sock.send(options_req.encode())
            response = sock.recv(4096).decode(errors="ignore")

            if "RTSP/1.0 200" in response:
                result["reachable"] = True
            if "Server:" in response:
                server_line = [l for l in response.split("\r\n")
                                if l.startswith("Server:")]
                if server_line:
                    result["server"] = server_line[0][8:].strip()

            # try paths
            for path in RTSPClient.PATHS:
                try:
                    describe_req = (
                        f"DESCRIBE rtsp://{ip}:{port}{path} RTSP/1.0\r\n"
                        f"CSeq: 2\r\n"
                        f"Accept: application/sdp\r\n"
                        f"User-Agent: Al-Baron\r\n"
                        f"\r\n"
                    )
                    sock.send(describe_req.encode())
                    resp = sock.recv(8192).decode(errors="ignore")

                    if "RTSP/1.0 200" in resp:
                        result["paths_found"].append({
                            "path": path,
                            "auth": False,
                        })
                    elif "RTSP/1.0 401" in resp:
                        result["paths_found"].append({
                            "path": path,
                            "auth": True,
                        })
                        result["auth_required"] = True
                except socket.timeout:
                    continue

            sock.close()
        except Exception as e:
            result["error"] = str(e)

        return result


# ═══════════════════════════════════════════════════════════════════
# ONVIF
# ═══════════════════════════════════════════════════════════════════
class ONVIFClient:
    """
    ONVIF protocol — يعرض معلومات الجهاز.
    الـSOAP requests.
    """

    GET_DEVICE_INFO = """<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope">
  <s:Body xmlns:tds="http://www.onvif.org/ver10/device/wsdl">
    <tds:GetDeviceInformation/>
  </s:Body>
</s:Envelope>"""

    GET_CAPABILITIES = """<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope">
  <s:Body xmlns:tds="http://www.onvif.org/ver10/device/wsdl">
    <tds:GetCapabilities><tds:Category>All</tds:Category></tds:GetCapabilities>
  </s:Body>
</s:Envelope>"""

    @staticmethod
    def probe(ip: str, port: int = 80, timeout: float = 5.0) -> dict:
        """يتصل بـONVIF endpoint ويسأل عن معلومات الجهاز"""
        import httpx
        result = {
            "ip": ip,
            "port": port,
            "manufacturer": "",
            "model": "",
            "firmware": "",
            "serial": "",
            "reachable": False,
        }

        endpoints = [
            f"http://{ip}/onvif/device_service",
            f"http://{ip}:{port}/onvif/device_service",
            f"http://{ip}/onvif/services",
        ]

        for url in endpoints:
            try:
                r = httpx.post(url, data=ONVIFClient.GET_DEVICE_INFO,
                                timeout=timeout,
                                headers={"Content-Type": "application/soap+xml"})
                if r.status_code == 200:
                    result["reachable"] = True
                    # parse XML
                    try:
                        root = ET.fromstring(r.text)
                        # find fields
                        for field in ["Manufacturer", "Model",
                                       "FirmwareVersion", "SerialNumber"]:
                            for elem in root.iter():
                                if field in elem.tag and elem.text:
                                    key = field.lower()
                                    result[{
                                        "manufacturer": "manufacturer",
                                        "model": "model",
                                        "firmwareversion": "firmware",
                                        "serialnumber": "serial",
                                    }.get(key, key)] = elem.text
                                    break
                    except Exception:
                        pass
                    break
            except Exception:
                continue

        return result


# ═══════════════════════════════════════════════════════════════════
# HTTP Detection
# ═══════════════════════════════════════════════════════════════════
class HTTPDetector:
    """يكشف الكاميرا من HTTP response"""
    @staticmethod
    def probe(ip: str, port: int = 80, timeout: float = 3.0) -> dict:
        import httpx
        result = {
            "ip": ip,
            "port": port,
            "status": 0,
            "title": "",
            "server": "",
            "authenticated": False,
            "vendor": "",
        }

        try:
            r = httpx.get(f"http://{ip}:{port}/", timeout=timeout,
                            verify=False, follow_redirects=True)
            result["status"] = r.status_code
            result["server"] = r.headers.get("Server", "")

            # extract title
            m = re.search(r"<title>(.*?)</title>", r.text,
                            re.IGNORECASE | re.DOTALL)
            if m:
                result["title"] = m.group(1).strip()[:100]

            # detect vendor from title/server
            from core.cctv.defaults import detect_vendor
            result["vendor"] = detect_vendor(
                result["server"], result["title"])

            if r.status_code == 401:
                result["authenticated"] = True
        except Exception as e:
            result["error"] = str(e)

        return result


# ═══════════════════════════════════════════════════════════════════
# Auth test
# ═══════════════════════════════════════════════════════════════════
class AuthTester:
    """يختبر credentials مختلفة"""
    @staticmethod
    def test_http_basic(ip: str, port: int, user: str, password: str,
                          path: str = "/", timeout: float = 3.0) -> bool:
        """يختبر HTTP Basic Auth"""
        import httpx
        try:
            auth = base64.b64encode(f"{user}:{password}".encode()).decode()
            r = httpx.get(f"http://{ip}:{port}{path}",
                            headers={"Authorization": f"Basic {auth}"},
                            timeout=timeout, verify=False)
            return r.status_code == 200
        except Exception:
            return False

    @staticmethod
    def test_rtsp_digest(ip: str, port: int, user: str, password: str,
                          timeout: float = 3.0) -> bool:
        """يختبر RTSP Digest Auth"""
        try:
            sock = socket.create_connection((ip, port), timeout=timeout)
            sock.settimeout(timeout)

            # first DESCRIBE — get nonce
            describe = (
                f"DESCRIBE rtsp://{ip}:{port}/ RTSP/1.0\r\n"
                f"CSeq: 1\r\n"
                f"User-Agent: Al-Baron\r\n"
                f"\r\n"
            )
            sock.send(describe.encode())
            response = sock.recv(4096).decode(errors="ignore")

            if "RTSP/1.0 200" in response:
                # no auth required
                sock.close()
                return True

            if "WWW-Authenticate:" not in response:
                sock.close()
                return False

            # extract realm, nonce
            m = re.search(r'realm="([^"]+)"', response)
            n = re.search(r'nonce="([^"]+)"', response)
            if not m or not n:
                sock.close()
                return False
            realm, nonce = m.group(1), n.group(1)

            # build digest
            import hashlib
            ha1 = hashlib.md5(f"{user}:{realm}:{password}".encode()).hexdigest()
            ha2 = hashlib.md5(f"DESCRIBE:rtsp://{ip}:{port}/".encode()).hexdigest()
            response_digest = hashlib.md5(
                f"{ha1}:{nonce}:{ha2}".encode()).hexdigest()

            digest_header = (
                f'Digest username="{user}", realm="{realm}", '
                f'nonce="{nonce}", uri="rtsp://{ip}:{port}/", '
                f'response="{response_digest}"'
            )

            describe_auth = (
                f"DESCRIBE rtsp://{ip}:{port}/ RTSP/1.0\r\n"
                f"CSeq: 2\r\n"
                f"Authorization: {digest_header}\r\n"
                f"User-Agent: Al-Baron\r\n"
                f"\r\n"
            )
            sock.send(describe_auth.encode())
            response2 = sock.recv(8192).decode(errors="ignore")
            sock.close()

            return "RTSP/1.0 200" in response2
        except Exception:
            return False
