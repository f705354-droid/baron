# language: Python, file: core/cctv/report.py
# CCTV PDF report generator
import os
import json
from datetime import datetime
from typing import Dict, List

try:
    from fpdf import FPDF
    HAS_FPDF = True
except ImportError:
    HAS_FPDF = False


class CCTVReporter:
    """
    يبني PDF تقرير كامل لكل ما تم في CCTV.
    """

    def __init__(self, output_dir: str = "reports"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def generate(self, scan_results: List[dict],
                  working_creds: Dict[str, dict],
                  exploitation_results: List[dict] = None,
                  snapshots: List[str] = None,
                  metadata: dict = None,
                  output_path: str = None) -> dict:
        """
        يبني تقرير PDF كامل.
        """
        if not HAS_FPDF:
            return {"error": "fpdf2 not installed"}

        metadata = metadata or {}
        output = output_path or os.path.join(
            self.output_dir,
            f"cctv_report_{int(datetime.now().timestamp())}.pdf")

        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=15)

        # ── cover page ──
        pdf.add_page()
        pdf.set_fill_color(15, 20, 30)
        pdf.rect(0, 0, 210, 297, "F")

        pdf.set_text_color(0, 255, 156)
        pdf.set_font("Helvetica", "B", 32)
        pdf.ln(80)
        pdf.cell(0, 15, "CCTV SECURITY ASSESSMENT",
                  align="C", new_x="LMARGIN", new_y="NEXT")
        pdf.ln(10)
        pdf.cell(0, 15, "REPORT", align="C",
                  new_x="LMARGIN", new_y="NEXT")

        pdf.set_text_color(200, 214, 229)
        pdf.set_font("Helvetica", "", 12)
        pdf.ln(30)

        for line in [
            metadata.get("client", "N/A"),
            f"Engagement: {metadata.get('engagement', 'N/A')}",
            f"Tester: {metadata.get('tester', 'N/A')}",
            f"Scope: {metadata.get('scope', 'N/A')}",
            f"Generated: {datetime.now().isoformat()[:19]}",
        ]:
            pdf.cell(0, 8, line, align="C",
                      new_x="LMARGIN", new_y="NEXT")

        pdf.ln(30)
        pdf.set_text_color(255, 107, 107)
        pdf.set_font("Helvetica", "B", 11)
        pdf.cell(0, 10, "CONFIDENTIAL", align="C",
                  new_x="LMARGIN", new_y="NEXT")

        # ── Executive Summary ──
        pdf.add_page()
        pdf.set_text_color(0, 0, 0)
        pdf.set_font("Helvetica", "B", 20)
        pdf.cell(0, 12, "Executive Summary",
                  new_x="LMARGIN", new_y="NEXT")
        pdf.ln(4)
        pdf.set_font("Helvetica", "", 11)

        total_cameras = len(scan_results)
        with_creds = len(working_creds)
        vulnerable = sum(1 for c in scan_results
                          if c.get("is_camera") and
                          (c.get("http", {}).get("status") == 401 or
                            c.get("rtsp", {}).get("auth_required")))
        snapshots_count = len(snapshots) if snapshots else 0

        summary = f"""This report documents the CCTV security assessment
conducted on {metadata.get('scope', 'the authorized scope')}.

Summary of Findings:
  • Total cameras discovered: {total_cameras}
  • Cameras with weak credentials: {with_creds}
  • Cameras requiring authentication (unauthenticated access): {vulnerable}
  • Snapshots captured: {snapshots_count}

The assessment identified {total_cameras} IP cameras on the network,
of which {with_creds} were accessible using default/weak credentials.

All testing was conducted within the authorized scope and timeframe.
"""
        pdf.multi_cell(0, 6, summary)

        # ── Discovered Cameras ──
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 18)
        pdf.cell(0, 12, "Discovered Cameras",
                  new_x="LMARGIN", new_y="NEXT")
        pdf.ln(4)

        pdf.set_font("Helvetica", "B", 9)
        headers = ["IP", "Vendor", "Ports", "RTSP", "ONVIF", "Status"]
        widths = [35, 30, 40, 20, 25, 30]
        for h, w in zip(headers, widths):
            pdf.cell(w, 7, h, border=1)
        pdf.ln()

        pdf.set_font("Helvetica", "", 8)
        for cam in scan_results[:100]:
            ip = cam.get("ip", "?")
            vendor = cam.get("vendor", "?")
            ports = ",".join(str(p) for p in cam.get("open_ports", [])[:5])
            rtsp = "✓" if cam.get("rtsp") else "✗"
            onvif = "✓" if cam.get("onvif") else "✗"
            status = "AUTH" if ip in working_creds else "open"

            for val, w in zip(
                [ip, vendor[:15], ports[:20], rtsp, onvif, status],
                widths):
                pdf.cell(w, 6, str(val)[:25], border=1)
            pdf.ln()

        # ── Credentials Found ──
        if working_creds:
            pdf.add_page()
            pdf.set_font("Helvetica", "B", 18)
            pdf.cell(0, 12, "Compromised Credentials",
                      new_x="LMARGIN", new_y="NEXT")
            pdf.ln(4)

            pdf.set_font("Helvetica", "B", 10)
            pdf.cell(40, 7, "Camera IP", border=1)
            pdf.cell(50, 7, "Username", border=1)
            pdf.cell(40, 7, "Password", border=1)
            pdf.cell(40, 7, "Protocol", border=1)
            pdf.ln()

            pdf.set_font("Courier", "", 9)
            for ip, creds in working_creds.items():
                pdf.cell(40, 6, ip[:20], border=1)
                pdf.cell(50, 6, creds.get("user", "?")[:20], border=1)
                pdf.cell(40, 6, creds.get("password", "?")[:20], border=1)
                pdf.cell(40, 6, creds.get("protocol", "?")[:20], border=1)
                pdf.ln()

        # ── Exploitation Results ──
        if exploitation_results:
            pdf.add_page()
            pdf.set_font("Helvetica", "B", 18)
            pdf.cell(0, 12, "Exploitation Results",
                      new_x="LMARGIN", new_y="NEXT")
            pdf.ln(4)
            pdf.set_font("Helvetica", "", 10)

            for expl in exploitation_results:
                pdf.set_font("Helvetica", "B", 10)
                pdf.cell(0, 7, f"• {expl.get('cve', '?')}",
                          new_x="LMARGIN", new_y="NEXT")
                pdf.set_font("Helvetica", "", 9)
                pdf.multi_cell(0, 5,
                    f"  Target: {expl.get('ip', '?')}\n"
                    f"  Status: {'VULNERABLE' if expl.get('vulnerable') else 'not vulnerable'}\n"
                    f"  Description: {expl.get('description', '?')}")
                pdf.ln(2)

        # ── Snapshots ──
        if snapshots:
            pdf.add_page()
            pdf.set_font("Helvetica", "B", 18)
            pdf.cell(0, 12, "Captured Snapshots",
                      new_x="LMARGIN", new_y="NEXT")
            pdf.ln(4)
            pdf.set_font("Helvetica", "", 10)

            for snap in snapshots[:6]:  # max 6 images
                if os.path.exists(snap):
                    try:
                        pdf.image(snap, x=10, w=170)
                        pdf.ln(4)
                        pdf.cell(0, 5, os.path.basename(snap),
                                  align="C", new_x="LMARGIN",
                                  new_y="NEXT")
                        pdf.ln(4)
                    except Exception:
                        pass

        # ── Recommendations ──
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 18)
        pdf.cell(0, 12, "Recommendations",
                  new_x="LMARGIN", new_y="NEXT")
        pdf.ln(4)
        pdf.set_font("Helvetica", "", 10)

        recommendations = [
            "IMMEDIATE (0-30 days):",
            "  1. Change all default credentials immediately.",
            "  2. Update firmware to latest version.",
            "  3. Isolate cameras on separate VLAN from production.",
            "  4. Disable unused services (UPnP, ONVIF if not needed).",
            "  5. Enable strong authentication (MFA if supported).",
            "",
            "SHORT-TERM (30-90 days):",
            "  1. Implement network access control for cameras.",
            "  2. Enable encrypted protocols (HTTPS, SRTP).",
            "  3. Configure logging and monitoring.",
            "  4. Regular firmware audits (monthly).",
            "  5. Restrict management access to specific IPs.",
            "",
            "LONG-TERM (90+ days):",
            "  1. Deploy a dedicated VMS with centralized auth.",
            "  2. Implement zero-trust for camera network.",
            "  3. Continuous security assessment (quarterly).",
        ]
        for rec in recommendations:
            pdf.multi_cell(0, 5, rec)

        # ── Appendix: raw data ──
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 16)
        pdf.cell(0, 10, "Appendix: Raw Findings",
                  new_x="LMARGIN", new_y="NEXT")
        pdf.ln(4)
        pdf.set_font("Courier", "", 7)

        for cam in scan_results[:30]:
            raw = json.dumps(cam, indent=2, default=str)[:800]
            pdf.multi_cell(0, 3, raw)
            pdf.ln(3)

        pdf.output(output)
        return {
            "path": output,
            "size": os.path.getsize(output),
            "pages": pdf.pages_count,
            "cameras": total_cameras,
            "credentials": with_creds,
        }
