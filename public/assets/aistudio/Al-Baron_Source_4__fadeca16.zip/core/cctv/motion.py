# language: Python, file: core/cctv/motion.py
# Motion detection — intercept motion events from cameras
import httpx
import base64
import xml.etree.ElementTree as ET
import threading
import time
import os
from datetime import datetime
from typing import Callable


class MotionDetector:
    """
    يستقبل أحداث الحركة من الكاميرات (Hikvision ISAPI event stream).
    """
    def __init__(self, log_queue=None):
        self.log = log_queue
        self.handlers = []
        self.running = False
        self.events = []

    def on_motion(self, callback: Callable):
        """يسجل callback لكل حركة"""
        self.handlers.append(callback)

    def stream_motion(self, ip: str, user: str, password: str,
                        port: int = 80, channel: int = 1):
        """
        يفتح event stream من Hikvision.
        كل حركة = event.
        """
        url = f"http://{ip}:{port}/ISAPI/Event/notification/alertStream"

        def run():
            self.running = True
            try:
                with httpx.stream(
                    "GET", url,
                    auth=(user, password) if user else None,
                    timeout=None, verify=False) as response:
                    buffer = ""
                    for line in response.iter_lines():
                        if not self.running:
                            break
                        line = line.strip()
                        if not line:
                            continue
                        buffer += line
                        if "</EventNotification>" in buffer:
                            self._parse_event(buffer, ip)
                            buffer = ""
            except Exception as e:
                if self.log:
                    self.log.put(f"[motion] {ip}: {e}")
            finally:
                self.running = False

        threading.Thread(target=run, daemon=True).start()

    def _parse_event(self, xml_text: str, ip: str):
        """يستخرج الحركة من XML"""
        try:
            root = ET.fromstring(xml_text)
            # Hikvision event structure:
            # <EventNotificationAlert>
            #   <eventType>VMD</eventType>  (Video Motion Detection)
            #   <channelID>1</channelID>
            #   <dateTime>...</dateTime>
            # </EventNotificationAlert>
            event_type = root.findtext(".//{*}eventType") or "?"
            channel = root.findtext(".//{*}channelID") or "?"

            if event_type.upper() in ("VMD", "MOTION", "VIDEOLOSS"):
                event = {
                    "time": datetime.now().isoformat(),
                    "ip": ip,
                    "type": event_type,
                    "channel": channel,
                }
                self.events.append(event)

                if self.log:
                    self.log.put(f"[motion] {ip} ch{channel} — {event_type}")

                for handler in self.handlers:
                    try:
                        handler(event)
                    except Exception:
                        pass
        except Exception as e:
            if self.log:
                self.log.put(f"[motion] parse error: {e}")

    def stop(self):
        self.running = False


class MotionSnapshotter:
    """
    يلتقط صورة فوراً عند اكتشاف حركة.
    """
    def __init__(self, output_dir: str = "loot/cctv_motion"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        self.last_snapshot = {}

    def on_event(self, event: dict, capture_fn: Callable):
        """
        يحفظ snapshot عند الحركة.
        capture_fn: function() → snapshot path.
        """
        ip = event["ip"]
        # throttle: max 1 snapshot per 5 seconds per IP
        last = self.last_snapshot.get(ip, 0)
        if time.time() - last < 5:
            return
        self.last_snapshot[ip] = time.time()

        try:
            result = capture_fn()
            if result.get("success"):
                # rename with motion timestamp
                new_path = os.path.join(
                    self.output_dir,
                    f"motion_{ip.replace('.', '_')}_"
                    f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg")
                os.rename(result["path"], new_path)
                if self.log:
                    self.log.put(f"[motion] snapshot → {new_path}")
        except Exception as e:
            if self.log:
                self.log.put(f"[motion] capture failed: {e}")
