# language: Python, file: core/cctv/scanner.py
# CCTV Scanner — discovers cameras on network
import socket
import threading
import ipaddress
from concurrent.futures import ThreadPoolExecutor
from typing import List, Dict


class CCTVScanner:
    """
    يكتشف كاميرات على الشبكة:
      - فحص المنافذ
      - تحليل HTTP/RTSP/ONVIF
      - كشف المصنع
    """
    CAMERA_PORTS = [80, 443, 554, 8080, 8000, 8443, 88, 8888, 34567]
    RTSP_PORTS = [554, 8554, 10554]

    def __init__(self, log_queue=None, max_workers: int = 50):
        self.log = log_queue
        self.max_workers = max_workers
        self.results = []

    def scan_network(self, cidr: str, timeout: float = 2.0) -> List[dict]:
        """يفحص كل hosts في CIDR"""
        try:
            net = ipaddress.ip_network(cidr, strict=False)
        except ValueError:
            return []

        hosts = list(net.hosts())
        results = []
        lock = threading.Lock()

        def check_host(ip: str):
            host_result = self.scan_host(str(ip), timeout)
            if host_result and host_result.get("is_camera"):
                with lock:
                    results.append(host_result)
                    if self.log:
                        self.log.put(
                            f"[cctv] found camera: {ip} "
                            f"({host_result.get('vendor', 'unknown')})")

        with ThreadPoolExecutor(max_workers=self.max_workers) as ex:
            ex.map(check_host, hosts)

        self.results = results
        return results

    def scan_host(self, ip: str, timeout: float = 2.0) -> dict:
        """يفحص host واحد"""
        from core.cctv.protocols import (
            HTTPDetector, RTSPClient, ONVIFClient)

        result = {
            "ip": ip,
            "open_ports": [],
            "is_camera": False,
            "vendor": "",
            "http": None,
            "rtsp": None,
            "onvif": None,
        }

        # 1. scan ports
        for port in self.CAMERA_PORTS:
            if self._port_open(ip, port, timeout):
                result["open_ports"].append(port)

        if not result["open_ports"]:
            return result

        # 2. detect via HTTP
        for port in [80, 8080, 8000]:
            if port in result["open_ports"]:
                http = HTTPDetector.probe(ip, port, timeout)
                if http.get("status", 0) > 0:
                    result["http"] = http
                    result["vendor"] = http.get("vendor", "")

                    # heuristic: title contains camera keywords
                    title = http.get("title", "").lower()
                    server = http.get("server", "").lower()
                    keywords = [
                        "camera", "cctv", "ipc", "nvr", "dvr",
                        "webcam", "network camera", "ip camera",
                        "hikvision", "dahua", "axis", "vivotek",
                        "reolink", "foscam", "amcrest", "uniview",
                        "web service", "streaming",
                    ]
                    if any(k in title or k in server for k in keywords):
                        result["is_camera"] = True
                    if http.get("status") == 401:
                        result["is_camera"] = True
                    break

        # 3. detect via RTSP
        for port in self.RTSP_PORTS:
            if port in result["open_ports"]:
                rtsp = RTSPClient.probe(ip, port, timeout)
                if rtsp.get("reachable"):
                    result["rtsp"] = rtsp
                    result["is_camera"] = True
                    break

        # 4. ONVIF (only if HTTP open)
        if 80 in result["open_ports"]:
            onvif = ONVIFClient.probe(ip, 80, timeout)
            if onvif.get("reachable"):
                result["onvif"] = onvif
                result["is_camera"] = True
                if onvif.get("manufacturer"):
                    result["vendor"] = onvif["manufacturer"].lower()

        return result

    def _port_open(self, ip: str, port: int, timeout: float) -> bool:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            result = sock.connect_ex((ip, port))
            sock.close()
            return result == 0
        except Exception:
            return False
