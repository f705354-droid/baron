# language: Python, file: core/cctv/hunting.py
# CCTV threat hunting — Blue Team passive detection
import socket
import struct
import threading
import time
import json
import os
from datetime import datetime
from typing import List, Dict, Set


class CCTVHunter:
    """
    يكشف كاميرات غير مصرّح بها على الشبكة:
      - passive multicast sniffing
      - active probes (WS-Discovery، SSDP)
      - MAC OUI check (camera vendors)
      - HTTP signature matching
      - behavioral analysis (RTSP keepalive)
    """

    # MAC OUIs الخاصة بكاميرات (Samsung، Hikvision، Dahua، Axis، إلخ)
    CAMERA_OUIS = {
        "C0:56:E3": "Hikvision",
        "44:19:B6": "Hikvision",
        "4C:BD:8F": "Hikvision",
        "BC:76:70": "Hikvision",
        "28:57:BE": "Hangzhou Hikvision",
        "B4:A3:82": "Dahua",
        "3C:EF:8C": "Dahua",
        "90:02:A9": "Dahua",
        "E0:50:8B": "Dahua",
        "00:40:8C": "Axis Communications",
        "AC:CC:8E": "Axis",
        "B8:A4:4F": "Axis",
        "00:0D:C5": "Vivotek",
        "00:02:D1": "Vivotek",
        "E8:AB:FA": "Shenzhen Reecam",
        "3C:A3:08": "TP-Link Tapo",
        "A4:DA:22": "TP-Link Tapo",
        "84:0D:8E": "Espressif (IoT camera)",
        "24:6F:28": "Espressif (ESP32)",
        "5C:CF:7F": "Espressif",
        "C4:2F:90": "Xiaomi",
        "78:11:DC": "Xiaomi",
        "F0:B4:29": "Xiaomi",
        "7C:DD:90": "Shenzhen Ogemray",
        "EC:FA:5C": "Shenzhen Bilian",
    }

    # HTTP signatures للكاميرات
    CAMERA_SIGNATURES = [
        ("Server", "Hikvision"),
        ("Server", "Dahua"),
        ("Server", "Boa"),  # Linux HTTP server used in many cameras
        ("Server", "goahead"),
        ("Server", "App-webs"),
        ("Server", "nginx"),  # common in NVRs
        ("WWW-Authenticate", "Hikvision"),
        ("WWW-Authenticate", "Dahua"),
        ("WWW-Authenticate", "AXIS"),
        ("X-Frame-Options", "SAMEORIGIN"),  # cameras use this
        ("Content-Type", "image/jpeg"),  # snapshots
        ("Content-Type", "video/H264"),
        ("Content-Type", "video/mjpeg"),
    ]

    # Title keywords
    TITLE_KEYWORDS = [
        "camera", "ipc", "nvr", "dvr", "cctv",
        "network video", "surveillance", "webcam",
        "hikvision", "dahua", "axis", "vivotek",
        "reolink", "amcrest", "uniview", "foscam",
        "tapo", "xiaomi camera",
    ]

    def __init__(self, log_queue=None):
        self.log = log_queue
        self.findings = []
        self.on_finding = None

    def _out(self, text):
        if self.log:
            self.log.put(f"[hunt] {text}")

    def _emit(self, finding: dict):
        self.findings.append(finding)
        self._out(f"{finding['severity'].upper()}: {finding['title']}")
        if self.on_finding:
            try:
                self.on_finding(finding)
            except Exception:
                pass

    # ==================== passive ====================
    def sniff_multicast(self, duration: int = 60) -> List[dict]:
        """
        يستمع لـmulticast traffic للكاميرات:
          - SSDP (UPnP)
          - mDNS (Bonjour)
          - WS-Discovery
        """
        self._out(f"passive sniffing for {duration}s...")
        found = []

        # SSDP listener
        def ssdp():
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM,
                                       socket.IPPROTO_UDP)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(("", 1900))
                mreq = struct.pack("4s4s",
                                     socket.inet_aton("239.255.255.250"),
                                     socket.inet_aton("0.0.0.0"))
                sock.setsockopt(socket.IPPROTO_IP,
                                  socket.IP_ADD_MEMBERSHIP, mreq)
                sock.settimeout(1)

                start = time.time()
                seen = set()
                while time.time() - start < duration:
                    try:
                        data, addr = sock.recvfrom(65535)
                        ip = addr[0]
                        if ip in seen:
                            continue
                        text = data.decode(errors="ignore")
                        # check for camera keywords
                        lower = text.lower()
                        if any(kw in lower for kw in self.TITLE_KEYWORDS):
                            seen.add(ip)
                            finding = {
                                "severity": "medium",
                                "title": f"Unauthorized camera (SSDP): {ip}",
                                "ip": ip,
                                "source": "ssdp",
                                "evidence": text[:500],
                                "detected_at": datetime.now().isoformat(),
                            }
                            found.append(finding)
                            self._emit(finding)
                    except socket.timeout:
                        continue
                sock.close()
            except Exception as e:
                self._out(f"ssdp error: {e}")

        threads = [
            threading.Thread(target=ssdp, daemon=True),
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        return found

    def sniff_arp(self, iface: str = "eth0",
                  duration: int = 60) -> List[dict]:
        """
        يصطاد ARP requests لكشف أجهزة جديدة.
        + فحص MAC OUI.
        """
        try:
            from scapy.all import sniff, ARP
        except ImportError:
            self._out("scapy not installed")
            return []

        self._out(f"ARP sniffing for {duration}s...")
        found = []
        seen_macs = set()

        def handle(pkt):
            if not pkt.haslayer(ARP):
                return
            ip = pkt[ARP].psrc
            mac = pkt[ARP].hwsrc.upper()

            if mac in seen_macs:
                return
            seen_macs.add(mac)

            # check MAC OUI
            oui = mac[:8]
            if oui in self.CAMERA_OUIS:
                vendor = self.CAMERA_OUIS[oui]
                finding = {
                    "severity": "medium",
                    "title": f"Camera detected (MAC OUI): {ip}",
                    "ip": ip,
                    "mac": mac,
                    "vendor": vendor,
                    "source": "arp_oui",
                    "detected_at": datetime.now().isoformat(),
                }
                found.append(finding)
                self._emit(finding)

        try:
            sniff(iface=iface, filter="arp", prn=handle,
                  timeout=duration, store=False)
        except Exception as e:
            self._out(f"arp error: {e}")

        return found

    # ==================== active ====================
    def probe_host(self, ip: str, timeout: float = 2.0) -> dict:
        """
        يفحص host واحد لاكتشاف كاميرا.
        """
        finding = {
            "severity": "low",
            "title": f"Camera probe: {ip}",
            "ip": ip,
            "source": "probe",
            "detected_at": datetime.now().isoformat(),
        }

        # check ports
        camera_ports = [80, 554, 8080, 8000, 88, 443]
        open_ports = []

        for port in camera_ports:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(timeout)
                if sock.connect_ex((ip, port)) == 0:
                    open_ports.append(port)
                sock.close()
            except Exception:
                pass

        if not open_ports:
            return {}

        # RTSP probe
        rtsp_port = None
        if 554 in open_ports:
            rtsp_port = 554

        if rtsp_port:
            rtsp_banner = self._probe_rtsp(ip, rtsp_port, timeout)
            if rtsp_banner:
                finding["severity"] = "medium"
                finding["title"] = f"Unauthorized RTSP camera: {ip}"
                finding["rtsp_banner"] = rtsp_banner
                finding["open_ports"] = open_ports
                self._emit(finding)
                return finding

        # HTTP signature
        for port in [80, 8080, 8000, 88]:
            if port in open_ports:
                signature = self._probe_http_signature(ip, port, timeout)
                if signature:
                    finding["severity"] = "medium"
                    finding["title"] = f"Camera signature: {ip}"
                    finding["signature"] = signature
                    finding["open_ports"] = open_ports
                    self._emit(finding)
                    return finding

        return {}

    def _probe_rtsp(self, ip: str, port: int,
                      timeout: float) -> dict:
        """RTSP OPTIONS probe"""
        try:
            sock = socket.create_connection((ip, port), timeout=timeout)
            sock.settimeout(timeout)
            req = (f"OPTIONS rtsp://{ip}:{port}/ RTSP/1.0\r\n"
                   f"CSeq: 1\r\n\r\n")
            sock.send(req.encode())
            response = sock.recv(4096).decode(errors="ignore")
            sock.close()

            if "RTSP/1.0" in response:
                server = ""
                for line in response.split("\r\n"):
                    if line.startswith("Server:"):
                        server = line[7:].strip()
                        break
                return {"server": server, "response": response[:300]}
        except Exception:
            pass
        return None

    def _probe_http_signature(self, ip: str, port: int,
                                timeout: float) -> dict:
        """HTTP signature check"""
        import httpx
        try:
            r = httpx.get(f"http://{ip}:{port}/", timeout=timeout,
                           verify=False, follow_redirects=True)

            # check signature
            for header, expected in self.CAMERA_SIGNATURES:
                value = r.headers.get(header, "")
                if expected.lower() in value.lower():
                    return {
                        "header": header,
                        "value": value,
                        "vendor": expected,
                    }

            # check title
            import re
            m = re.search(r"<title>(.*?)</title>", r.text,
                            re.I | re.DOTALL)
            if m:
                title = m.group(1).lower()
                if any(kw in title for kw in self.TITLE_KEYWORDS):
                    return {"title": m.group(1)}

            # check WWW-Authenticate
            if r.status_code == 401:
                www = r.headers.get("WWW-Authenticate", "")
                return {"status": 401, "www_authenticate": www}
        except Exception:
            pass
        return None

    # ==================== full hunt ====================
    def hunt_network(self, cidr: str,
                      active_probes: bool = True,
                      passive_duration: int = 60) -> dict:
        """
        حرب شاملة — passive + active.
        """
        self._out(f"starting hunt on {cidr}")
        findings = []

        # passive
        findings.extend(self.sniff_multicast(duration=passive_duration))

        # active probes
        if active_probes:
            import ipaddress
            from concurrent.futures import ThreadPoolExecutor

            try:
                net = ipaddress.ip_network(cidr, strict=False)
            except ValueError:
                return {"error": "invalid CIDR"}

            hosts = [str(ip) for ip in net.hosts()]
            self._out(f"active probing {len(hosts)} hosts...")

            with ThreadPoolExecutor(max_workers=50) as ex:
                results = list(ex.map(self.probe_host, hosts))

            for r in results:
                if r and r.get("title"):
                    findings.append(r)

        # summary
        by_severity = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        for f in findings:
            by_severity[f.get("severity", "low")] += 1

        return {
            "cidr": cidr,
            "total_findings": len(findings),
            "by_severity": by_severity,
            "findings": findings,
            "completed_at": datetime.now().isoformat(),
        }

    def export_findings(self, path: str) -> str:
        """exports findings to JSON"""
        with open(path, "w") as f:
            json.dump({
                "generated": datetime.now().isoformat(),
                "total": len(self.findings),
                "findings": self.findings,
            }, f, indent=2, default=str)
        return path
