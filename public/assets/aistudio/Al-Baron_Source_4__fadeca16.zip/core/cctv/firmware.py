# language: Python, file: core/cctv/firmware.py
# Firmware analysis — extract, analyze, find backdoors
import os
import re
import subprocess
import hashlib
import json
from datetime import datetime
from typing import List, Dict


class FirmwareAnalyzer:
    """
    يحلل firmware صورة:
      - strings — يبحث عن URLs، كلمات مرور، مفاتيح
      - binwalk — يستخرج الملفات
      - CVE check
      - known backdoor patterns
    """

    # regex patterns للبحث
    PATTERNS = {
        "ips": r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
        "urls": r"https?://[^\s\"'<>]+",
        "emails": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b",
        "btc_addresses": r"\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b",
        "hashes": r"\b[a-fA-F0-9]{32,64}\b",
        "passwords": r"(?i)(password|passwd|pwd|secret)\s*[:=]\s*['\"]?([^\s'\"]{4,})",
        "api_keys": r"(?i)(api[_-]?key|token)\s*[:=]\s*['\"]?([a-z0-9]{20,})",
        "private_keys": r"-----BEGIN (?:RSA |EC )?PRIVATE KEY-----",
        "ssh_keys": r"ssh-rsa [A-Za-z0-9+/]{100,}",
    }

    # Backdoor usernames معروفة في firmware
    KNOWN_BACKDOORS = {
        "hikvision": ["support", "debug", "admin12345", "hik12345"],
        "dahua": ["default", "888888", "666666", "admin123"],
        "xiaomi": ["root", "support"],
    }

    def __init__(self, output_dir: str = "loot/cctv_firmware"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def analyze(self, firmware_path: str) -> dict:
        """يحلل firmware file"""
        if not os.path.exists(firmware_path):
            return {"error": "file not found"}

        result = {
            "file": firmware_path,
            "size": os.path.getsize(firmware_path),
            "sha256": self._hash(firmware_path),
            "analyzed_at": datetime.now().isoformat(),
            "strings_analysis": {},
            "binwalk_output": "",
            "known_backdoors": [],
            "credentials_found": [],
            "urls_found": [],
            "cves_matched": [],
        }

        # 1. strings
        strings = self._extract_strings(firmware_path)
        for kind, pattern in self.PATTERNS.items():
            matches = list(set(re.findall(pattern, strings)))
            if matches:
                result["strings_analysis"][kind] = matches[:50]

        # 2. credentials
        for match in re.findall(
                r"(?i)(password|passwd|pwd)\s*[:=]\s*['\"]?([^\s'\"]{4,})",
                strings):
            result["credentials_found"].append({
                "key": match[0],
                "value": match[1][:50],
            })

        # 3. URLs
        for url in set(re.findall(r"https?://[^\s\"'<>]+", strings)):
            result["urls_found"].append(url[:200])

        # 4. binwalk (extract filesystem)
        try:
            r = subprocess.run(
                ["binwalk", firmware_path],
                capture_output=True, text=True, timeout=60)
            result["binwalk_output"] = r.stdout[:5000]
        except FileNotFoundError:
            result["binwalk_output"] = "binwalk not installed — apt install binwalk"
        except Exception as e:
            result["binwalk_output"] = f"error: {e}"

        # 5. known backdoors
        for vendor, backdoors in self.KNOWN_BACKDOORS.items():
            for bd in backdoors:
                if bd.lower() in strings.lower():
                    result["known_backdoors"].append({
                        "vendor": vendor,
                        "pattern": bd,
                    })

        # 6. CVE patterns
        cve_patterns = {
            "CVE-2021-36260": r"webLanguage.*xml",
            "CVE-2013-4977": r"admin.*12345",
            "CVE-2021-33044": r"global.login",
        }
        for cve, pattern in cve_patterns.items():
            if re.search(pattern, strings, re.I):
                result["cves_matched"].append(cve)

        return result

    def _extract_strings(self, path: str,
                          min_len: int = 6) -> str:
        """يستخرج strings من firmware"""
        try:
            r = subprocess.run(
                ["strings", "-n", str(min_len), path],
                capture_output=True, text=True, timeout=120)
            return r.stdout
        except Exception:
            return ""

    def _hash(self, path: str) -> str:
        try:
            h = hashlib.sha256()
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)
            return h.hexdigest()
        except Exception:
            return ""

    def extract_firmware(self, firmware_path: str) -> dict:
        """يستخرج محتوى firmware بـbinwalk"""
        output_dir = os.path.join(
            self.output_dir,
            os.path.basename(firmware_path) + "_extracted")
        os.makedirs(output_dir, exist_ok=True)

        try:
            r = subprocess.run(
                ["binwalk", "-e", "-C", output_dir, firmware_path],
                capture_output=True, text=True, timeout=300)
            return {
                "success": r.returncode == 0,
                "output": r.stdout[:2000],
                "extracted_to": output_dir,
            }
        except FileNotFoundError:
            return {"error": "binwalk not installed"}
        except Exception as e:
            return {"error": str(e)}

    def scan_squashfs(self, squashfs_path: str) -> dict:
        """
        يفك squashfs ويفحص:
          - /etc/passwd
          - /etc/shadow
          - hidden backdoor files
        """
        try:
            out_dir = squashfs_path + "_root"
            subprocess.run(
                ["unsquashfs", "-d", out_dir, squashfs_path],
                capture_output=True, timeout=120)

            # check /etc/shadow
            shadow = os.path.join(out_dir, "etc/shadow")
            passwd = os.path.join(out_dir, "etc/passwd")

            return {
                "root_dir": out_dir,
                "passwd": self._read_file(passwd),
                "shadow": self._read_file(shadow),
                "suspicious_files": self._find_suspicious(out_dir),
            }
        except FileNotFoundError:
            return {"error": "unsquashfs not installed"}
        except Exception as e:
            return {"error": str(e)}

    def _read_file(self, path: str) -> str:
        if not os.path.exists(path):
            return ""
        try:
            with open(path) as f:
                return f.read()[:2000]
        except Exception:
            return ""

    def _find_suspicious(self, root_dir: str) -> list:
        """يبحث عن ملفات مشبوهة"""
        suspicious = []
        for root, dirs, files in os.walk(root_dir):
            for f in files:
                if f in [".backdoor", "backdoor", "debug", ".hidden"]:
                    suspicious.append(os.path.join(root, f))
                if f.startswith(".") and f not in (".htaccess",):
                    suspicious.append(os.path.join(root, f))
        return suspicious[:20]
