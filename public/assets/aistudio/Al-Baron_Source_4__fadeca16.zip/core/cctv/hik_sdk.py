# language: Python, file: core/cctv/hik_sdk.py
# Hikvision SDK wrapper — via HCNetSDK.so (Linux) or HTTP ISAPI fallback
import ctypes
import os
import base64
import json
from datetime import datetime


class HikvisionSDK:
    """
    Hikvision SDK (HCNetSDK).
    - preview streams (native)
    - playback (seamless)
    - PTZ (all speeds)
    - alarms (real-time)
    - download via SDK

    Fallback to ISAPI إذا SDK غير متوفر.
    """

    def __init__(self, ip: str, port: int = 8000,
                  user: str = "", password: str = ""):
        self.ip = ip
        self.port = port
        self.user = user
        self.password = password
        self.user_id = -1
        self.sdk = None
        self._try_load_sdk()

    def _try_load_sdk(self) -> bool:
        """يحاول تحميل HCNetSDK.so"""
        sdk_paths = [
            "/opt/hikvision/libhcnetsdk.so",
            "/usr/local/hikvision/libhcnetsdk.so",
            "./libhcnetsdk.so",
        ]
        for path in sdk_paths:
            if os.path.exists(path):
                try:
                    self.sdk = ctypes.CDLL(path)
                    self._init_sdk()
                    return True
                except Exception:
                    pass
        # no SDK — will use ISAPI fallback
        return False

    def _init_sdk(self):
        """HCNetSDK init"""
        try:
            self.sdk.NET_DVR_Init()
            # set log path
            self.sdk.NET_DVR_SetLogToFile(3, b"/tmp/hik_sdk_log", False)
        except Exception:
            pass

    def login(self) -> dict:
        """يسجل الدخول"""
        if self.sdk:
            return self._sdk_login()
        return self._isapi_login()

    def _sdk_login(self) -> dict:
        """SDK login"""
        try:
            # NET_DVR_USER_LOGIN_INFO
            class UserLoginInfo(ctypes.Structure):
                _fields_ = [
                    ("sDeviceAddress", ctypes.c_char * 129),
                    ("byUseTransport", ctypes.c_ubyte),
                    ("wPort", ctypes.c_ushort),
                    ("sUserName", ctypes.c_char * 64),
                    ("sPassword", ctypes.c_char * 64),
                    ("cbLoginResult", ctypes.c_void_p),
                    ("pUser", ctypes.c_void_p),
                    ("bUseAsynLogin", ctypes.c_int),
                    ("byProxyType", ctypes.c_ubyte),
                    ("byUseUTCTime", ctypes.c_ubyte),
                    ("byLoginMode", ctypes.c_ubyte),
                ]

            class DeviceInfo(ctypes.Structure):
                _fields_ = [
                    ("sSerialNumber", ctypes.c_char * 48),
                    ("byAlarmInPortNum", ctypes.c_ubyte),
                    ("byAlarmOutPortNum", ctypes.c_ubyte),
                    ("byDiskNum", ctypes.c_ubyte),
                    ("byDVRType", ctypes.c_ubyte),
                    ("byChanNum", ctypes.c_ubyte),
                ]

            login_info = UserLoginInfo()
            login_info.sDeviceAddress = self.ip.encode()[:128]
            login_info.wPort = self.port
            login_info.sUserName = self.user.encode()[:63]
            login_info.sPassword = self.password.encode()[:63]

            device_info = DeviceInfo()
            self.user_id = self.sdk.NET_DVR_Login_V40(
                ctypes.byref(login_info),
                ctypes.byref(device_info))

            if self.user_id >= 0:
                return {
                    "status": "ok",
                    "method": "sdk",
                    "user_id": self.user_id,
                    "channels": device_info.byChanNum,
                    "serial": device_info.sSerialNumber.decode(
                        errors="ignore"),
                }
            else:
                err = self.sdk.NET_DVR_GetLastError()
                return {"error": f"SDK login failed: {err}"}
        except Exception as e:
            return {"error": str(e)}

    def _isapi_login(self) -> dict:
        """ISAPI fallback — يختبر auth"""
        import httpx
        try:
            r = httpx.get(
                f"http://{self.ip}/ISAPI/System/deviceInfo",
                auth=(self.user, self.password),
                timeout=10, verify=False)
            if r.status_code == 200:
                return {"status": "ok", "method": "isapi"}
            return {"error": f"HTTP {r.status_code}"}
        except Exception as e:
            return {"error": str(e)}

    # ==================== preview ====================
    def start_preview(self, channel: int = 1,
                       output_file: str = None) -> dict:
        """بدء stream preview"""
        if not self.sdk or self.user_id < 0:
            # use ISAPI + ffmpeg
            return self._preview_isapi(channel, output_file)

        try:
            # NET_DVR_PREVIEWINFO
            class PreviewInfo(ctypes.Structure):
                _fields_ = [
                    ("lChannel", ctypes.c_long),
                    ("dwStreamType", ctypes.c_ulong),
                    ("dwLinkMode", ctypes.c_ulong),
                    ("hPlayWnd", ctypes.c_void_p),
                    ("bBlocked", ctypes.c_int),
                    ("bPassbackRecord", ctypes.c_int),
                    ("byPreviewMode", ctypes.c_ubyte),
                    ("byStreamID", ctypes.c_ubyte * 32),
                    ("byProtoType", ctypes.c_ubyte),
                    ("byRes1", ctypes.c_ubyte),
                    ("byVideoCodingType", ctypes.c_ubyte),
                    ("dwDisplayBufNum", ctypes.c_ulong),
                    ("byRes", ctypes.c_ubyte * 216),
                ]

            preview = PreviewInfo()
            preview.lChannel = channel
            preview.dwStreamType = 0  # main stream
            preview.dwLinkMode = 0    # TCP
            preview.bBlocked = 0

            handle = self.sdk.NET_DVR_RealPlay_V40(
                self.user_id, ctypes.byref(preview), None, None)

            if handle >= 0:
                return {"status": "ok", "handle": handle,
                          "method": "sdk", "channel": channel}
            return {"error": f"preview failed: {self.sdk.NET_DVR_GetLastError()}"}
        except Exception as e:
            return {"error": str(e)}

    def _preview_isapi(self, channel: int,
                        output_file: str) -> dict:
        """ISAPI + ffmpeg fallback"""
        import subprocess
        rtsp_url = (f"rtsp://{self.user}:{self.password}@{self.ip}:554/"
                     f"Streaming/Channels/{channel}01")
        if not output_file:
            output_file = f"loot/cctv_snapshots/preview_{channel}_{int(datetime.now().timestamp())}.jpg"
            os.makedirs(os.path.dirname(output_file), exist_ok=True)

        try:
            subprocess.run([
                "ffmpeg", "-rtsp_transport", "tcp",
                "-i", rtsp_url, "-frames:v", "1", "-y", output_file
            ], capture_output=True, timeout=30)
            return {
                "status": "ok",
                "method": "isapi+ffmpeg",
                "output": output_file,
                "size": os.path.getsize(output_file) if os.path.exists(output_file) else 0,
            }
        except Exception as e:
            return {"error": str(e)}

    # ==================== PTZ ====================
    def ptz_control(self, command: int, speed: int = 4,
                     channel: int = 1) -> dict:
        """
        تحكم PTZ عبر SDK.
        command: 1=up, 2=down, 3=left, 4=right, 5=zoomin, 6=zoomout, 7=focus+, 8=focus-
        """
        if not self.sdk or self.user_id < 0:
            return {"error": "SDK not available"}

        try:
            result = self.sdk.NET_DVR_PTZControl_Other(
                self.user_id, channel, command, 0)
            return {"status": "ok" if result else "failed",
                      "command": command, "speed": speed}
        except Exception as e:
            return {"error": str(e)}

    def ptz_stop(self, channel: int = 1) -> dict:
        """إيقاف PTZ"""
        if not self.sdk or self.user_id < 0:
            return {"error": "SDK not available"}

        try:
            for command in [1, 2, 3, 4, 5, 6]:
                self.sdk.NET_DVR_PTZControl_Other(
                    self.user_id, channel, command, 1)  # 1=stop
            return {"status": "stopped"}
        except Exception as e:
            return {"error": str(e)}

    def ptz_preset(self, preset: int, channel: int = 1,
                    action: str = "goto") -> dict:
        """
        Preset operations.
        action: goto, set, clear
        """
        if not self.sdk or self.user_id < 0:
            return {"error": "SDK not available"}

        try:
            cmd = 39 if action == "goto" else 8 if action == "set" else 9
            result = self.sdk.NET_DVR_PTZPreset_Other(
                self.user_id, channel, cmd, preset)
            return {"status": "ok" if result else "failed",
                      "preset": preset, "action": action}
        except Exception as e:
            return {"error": str(e)}

    # ==================== download ====================
    def download_recording(self, start: str, end: str,
                             channel: int = 1,
                             output_file: str = None) -> dict:
        """
        تنزيل تسجيل عبر SDK.
        start/end: "2024-01-01 00:00:00"
        """
        if not self.sdk or self.user_id < 0:
            return self._download_isapi(start, end, channel, output_file)

        try:
            # NET_DVR_PLAYCOND
            class PlayCond(ctypes.Structure):
                _fields_ = [
                    ("dwChannel", ctypes.c_ulong),
                    ("struStartTime", ctypes.c_ubyte * 16),
                    ("struStopTime", ctypes.c_ubyte * 16),
                    ("byDownload", ctypes.c_ubyte),
                ]

            # parse datetime to SDK format
            def sdk_time(dt_str):
                dt = datetime.strptime(dt_str, "%Y-%m-%d %H:%M:%S")
                # SDK time structure: year, month, day, hour, minute, second
                buf = ctypes.c_ubyte * 16
                t = buf()
                # simplified — actual SDK uses NET_DVR_TIME struct
                return t

            play_cond = PlayCond()
            play_cond.dwChannel = channel
            play_cond.byDownload = 1

            if not output_file:
                output_file = f"loot/cctv_recordings/sdk_download_{int(datetime.now().timestamp())}.mp4"

            # call SDK download — requires callback setup
            # (simplified — actual SDK download is complex)
            return {
                "error": "SDK download requires callback — using ISAPI fallback",
                "hint": "use PlaybackDownloader.auto_download_hikvision()"
            }
        except Exception as e:
            return {"error": str(e)}

    def _download_isapi(self, start: str, end: str,
                          channel: int, output_file: str) -> dict:
        """ISAPI download fallback"""
        from core.cctv.playback import PlaybackDownloader
        dl = PlaybackDownloader()
        tracks = dl.hikvision_list_tracks(self.ip, 80,
                                            self.user, self.password)
        if not tracks:
            return {"error": "no tracks"}

        # format time for ISAPI
        start_iso = start.replace(" ", "T")
        end_iso = end.replace(" ", "T")

        recordings = dl.hikvision_search(
            self.ip, 80, self.user, self.password,
            int(tracks[0]["id"]), start_iso, end_iso)

        if not recordings:
            return {"error": "no recordings"}

        if not output_file:
            output_file = f"loot/cctv_recordings/dl_{int(datetime.now().timestamp())}.mp4"
            os.makedirs(os.path.dirname(output_file), exist_ok=True)

        return dl.hikvision_download(
            self.ip, 80, self.user, self.password,
            recordings[0]["playback_uri"], output_file)

    # ==================== alarm stream ====================
    def listen_alarms(self, callback=None) -> dict:
        """يستمع للإنذارات (motion، line crossing، إلخ)"""
        if not self.sdk or self.user_id < 0:
            return {"error": "SDK not available — use ISAPI event stream"}

        try:
            # NET_DVR_SetDVRMessageCallBack_V50
            # + NET_DVR_SetupAlarmChan_V41
            class SetupAlarmParam(ctypes.Structure):
                _fields_ = [
                    ("byActive", ctypes.c_ubyte),
                    ("byRes", ctypes.c_ubyte * 3),
                ]

            param = SetupAlarmParam()
            param.byActive = 1  # active upload

            handle = self.sdk.NET_DVR_SetupAlarmChan_V41(
                self.user_id, ctypes.byref(param))

            return {
                "status": "listening" if handle >= 0 else "failed",
                "handle": handle,
            }
        except Exception as e:
            return {"error": str(e)}

    # ==================== logout ====================
    def logout(self):
        if self.sdk and self.user_id >= 0:
            try:
                self.sdk.NET_DVR_Logout(self.user_id)
                self.user_id = -1
            except Exception:
                pass

    def cleanup(self):
        """SDK cleanup"""
        if self.sdk:
            try:
                self.sdk.NET_DVR_Cleanup()
            except Exception:
                pass
