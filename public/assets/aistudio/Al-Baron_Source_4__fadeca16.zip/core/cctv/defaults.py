# language: Python, file: core/cctv/defaults.py
# Default credentials for common CCTV vendors
# Source: public CVE disclosures + manufacturer docs

DEFAULT_CREDS = {
    "hikvision": [
        ("admin", "12345"),           # CVE-2013-4977 (older)
        ("admin", "admin"),
        ("admin", "Hik12345"),
        ("admin", "password"),
        ("admin", "Admin12345"),
        ("root", "admin"),
        ("admin", "12345678"),
    ],
    "dahua": [
        ("admin", "admin"),           # Many older units
        ("admin", "password"),
        ("admin", "123456"),
        ("888888", "888888"),         # Very common
        ("666666", "666666"),
        ("admin", "Admin123"),
    ],
    "axis": [
        ("root", "pass"),             # Factory default
        ("admin", "admin"),
        ("root", "root"),
        ("admin", "password"),
    ],
    "vivotek": [
        ("root", "root"),
        ("admin", "admin"),
    ],
    "panasonic": [
        ("admin", "12345"),
        ("admin", ""),
    ],
    "sony": [
        ("admin", "admin"),
        ("admin", "password"),
    ],
    "samsung": [
        ("admin", "4321"),
        ("admin", "1111111"),
        ("root", "root"),
    ],
    "bosch": [
        ("service", "service"),
        ("user", "user"),
    ],
    "geovision": [
        ("admin", "admin"),
    ],
    "foscam": [
        ("admin", ""),                # Foscam defaults
        ("admin", "admin"),
    ],
    "reolink": [
        ("admin", ""),
        ("admin", "admin"),
    ],
    "amcrest": [
        ("admin", "admin"),
    ],
    "swann": [
        ("admin", "12345"),
    ],
    "uniview": [
        ("admin", "admin"),
    ],
    "h_264": [
        ("admin", "admin"),
    ],
    "generic": [
        ("admin", "admin"),
        ("admin", "password"),
        ("admin", "12345"),
        ("admin", "1234"),
        ("admin", "123456"),
        ("admin", "111111"),
        ("admin", "000000"),
        ("root", "root"),
        ("root", "admin"),
        ("root", "password"),
        ("user", "user"),
        ("test", "test"),
        ("guest", "guest"),
        ("admin", "888888"),
    ],
}


def get_creds_for_vendor(vendor: str) -> list:
    """يرجع credentials للمصنع"""
    vendor = vendor.lower()
    creds = list(DEFAULT_CREDS.get(vendor, []))
    creds.extend(DEFAULT_CREDS["generic"])
    return creds


def detect_vendor(banner: str, http_title: str = "") -> str:
    """يحاول كشف المصنع من banner أو title"""
    text = (banner + " " + http_title).lower()
    vendors = [
        "hikvision", "dahua", "axis", "vivotek", "panasonic",
        "sony", "samsung", "bosch", "geovision", "foscam",
        "reolink", "amcrest", "swann", "uniview",
    ]
    for v in vendors:
        if v in text:
            return v
    return "generic"
