# language: Python, file: core/cctv/forensics.py
# Video forensics — frame analysis, motion, objects
import os
import subprocess
import json
import hashlib
from datetime import datetime, timedelta
from typing import List, Dict


class VideoForensics:
    """
    تحليل التسجيلات:
      - extract frames
      - motion detection
      - person detection (باستخدام OpenCV + YOLO اختياري)
      - scene change
      - hash verification
    """

    def __init__(self, output_dir: str = "loot/cctv_forensics",
                  log_queue=None):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        self.log = log_queue

    def _out(self, text):
        if self.log:
            self.log.put(f"[forensics] {text}")

    # ==================== metadata ====================
    def get_video_info(self, video_path: str) -> dict:
        """ffprobe info"""
        try:
            r = subprocess.run(
                ["ffprobe", "-v", "quiet", "-print_format", "json",
                 "-show_format", "-show_streams", video_path],
                capture_output=True, text=True, timeout=30)
            if r.returncode == 0:
                data = json.loads(r.stdout)
                fmt = data.get("format", {})
                streams = data.get("streams", [])

                video_stream = next(
                    (s for s in streams if s.get("codec_type") == "video"),
                    {})

                return {
                    "path": video_path,
                    "duration": float(fmt.get("duration", 0)),
                    "size": int(fmt.get("size", 0)),
                    "bit_rate": int(fmt.get("bit_rate", 0)),
                    "format": fmt.get("format_name", ""),
                    "width": video_stream.get("width", 0),
                    "height": video_stream.get("height", 0),
                    "fps": video_stream.get("r_frame_rate", "0/1"),
                    "codec": video_stream.get("codec_name", ""),
                    "sha256": self._hash(video_path),
                }
        except Exception as e:
            return {"error": str(e)}
        return {"error": "ffprobe failed"}

    def _hash(self, path: str) -> str:
        h = hashlib.sha256()
        try:
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)
            return h.hexdigest()
        except Exception:
            return ""

    # ==================== frame extraction ====================
    def extract_frames(self, video_path: str,
                        fps: float = 1.0,
                        max_frames: int = 100) -> list:
        """
        يستخرج frames من الفيديو.
        fps: frames per second (1.0 = frame each second)
        """
        safe_name = os.path.basename(video_path).replace(".", "_")
        out_dir = os.path.join(self.output_dir, safe_name + "_frames")
        os.makedirs(out_dir, exist_ok=True)

        try:
            r = subprocess.run([
                "ffmpeg", "-i", video_path,
                "-vf", f"fps={fps}",
                "-frames:v", str(max_frames),
                os.path.join(out_dir, "frame_%04d.jpg"),
                "-y"
            ], capture_output=True, text=True, timeout=600)

            if r.returncode != 0:
                return {"error": r.stderr[-500:]}

            frames = sorted([
                os.path.join(out_dir, f)
                for f in os.listdir(out_dir)
                if f.endswith(".jpg")
            ])

            self._out(f"extracted {len(frames)} frames")
            return {"frames": frames, "dir": out_dir, "count": len(frames)}
        except Exception as e:
            return {"error": str(e)}

    # ==================== motion analysis ====================
    def analyze_motion(self, video_path: str,
                        threshold: float = 0.02) -> dict:
        """
        يكشف الحركة في الفيديو.
        يستخدم ffmpeg scene detection.
        """
        try:
            # ffmpeg scene detection
            r = subprocess.run([
                "ffmpeg", "-i", video_path,
                "-vf", f"select='gt(scene,{threshold})',showinfo",
                "-f", "null", "-"
            ], capture_output=True, text=True, timeout=600)

            # parse showinfo output
            import re
            motion_times = []
            for line in r.stderr.splitlines():
                m = re.search(r"pts_time:([\d.]+).*scene:([\d.]+)", line)
                if m:
                    motion_times.append({
                        "time": float(m.group(1)),
                        "score": float(m.group(2)),
                    })

            return {
                "video": video_path,
                "motion_events": len(motion_times),
                "events": motion_times[:200],
                "threshold": threshold,
            }
        except Exception as e:
            return {"error": str(e)}

    # ==================== person detection ====================
    def detect_persons(self, video_path: str,
                        sample_fps: float = 0.5) -> dict:
        """
        كشف الأشخاص باستخدام OpenCV + HOG.
        (بديل: YOLO إذا opencv+yolo متاحين)
        """
        try:
            import cv2
        except ImportError:
            return {"error": "opencv not installed — pip install opencv-python"}

        detections = []

        try:
            cap = cv2.VideoCapture(video_path)
            if not cap.isOpened():
                return {"error": "cannot open video"}

            fps = cap.get(cv2.CAP_PROP_FPS)
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            frame_interval = max(1, int(fps / sample_fps))

            # HOG descriptor
            hog = cv2.HOGDescriptor()
            hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

            frame_num = 0
            while True:
                ret, frame = cap.read()
                if not ret:
                    break

                if frame_num % frame_interval == 0:
                    # detect people
                    boxes, weights = hog.detectMultiScale(
                        frame, winStride=(8, 8), padding=(4, 4),
                        scale=1.05)

                    for (x, y, w, h), weight in zip(boxes, weights):
                        if weight > 0.5:
                            detections.append({
                                "frame": frame_num,
                                "time": round(frame_num / fps, 2),
                                "bbox": [int(x), int(y), int(w), int(h)],
                                "confidence": float(weight),
                            })

                frame_num += 1

            cap.release()

            return {
                "video": video_path,
                "total_frames": total_frames,
                "duration": round(total_frames / fps, 2) if fps > 0 else 0,
                "person_detections": len(detections),
                "detections": detections[:500],
            }
        except Exception as e:
            return {"error": str(e)}

    # ==================== scene change ====================
    def detect_scene_changes(self, video_path: str,
                              threshold: float = 0.3) -> dict:
        """كشف تغيّرات المشهد (scene transitions)"""
        try:
            r = subprocess.run([
                "ffmpeg", "-i", video_path,
                "-vf", f"select='gt(scene,{threshold})',showinfo",
                "-f", "null", "-"
            ], capture_output=True, text=True, timeout=600)

            import re
            changes = []
            for line in r.stderr.splitlines():
                m = re.search(r"pts_time:([\d.]+).*scene:([\d.]+)", line)
                if m:
                    changes.append({
                        "time": float(m.group(1)),
                        "confidence": float(m.group(2)),
                    })

            return {
                "video": video_path,
                "scene_changes": len(changes),
                "changes": changes[:100],
            }
        except Exception as e:
            return {"error": str(e)}

    # ==================== full forensic analysis ====================
    def full_analysis(self, video_path: str) -> dict:
        """
        تحليل كامل:
          - metadata
          - frames
          - motion
          - scene changes
          - persons (if opencv)
        """
        self._out(f"analyzing {video_path}...")

        result = {
            "path": video_path,
            "analyzed_at": datetime.now().isoformat(),
            "metadata": self.get_video_info(video_path),
            "motion": self.analyze_motion(video_path),
            "scene_changes": self.detect_scene_changes(video_path),
        }

        # only extract frames if useful
        if result["metadata"].get("duration", 0) > 10:
            result["frames"] = self.extract_frames(
                video_path, fps=0.5, max_frames=50)

        # person detection if opencv available
        try:
            import cv2
            result["persons"] = self.detect_persons(video_path)
        except ImportError:
            result["persons"] = {"skipped": "opencv not installed"}

        return result

    # ==================== report ====================
    def export_report(self, analyses: list, path: str) -> str:
        """تصدير تقرير JSON"""
        with open(path, "w") as f:
            json.dump({
                "generated": datetime.now().isoformat(),
                "analyses": analyses,
            }, f, indent=2, default=str)
        return path
