# language: Python, file: core/cctv/stream.py
# RTSP stream capture — snapshot from camera
import subprocess
import os
import threading
from datetime import datetime


class StreamCapture:
    """
    يسحب snapshot من RTSP stream.
    يستخدم ffmpeg (يحتاج: apt install ffmpeg).
    """
    def __init__(self, output_dir: str = "loot/cctv_snapshots"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def capture_snapshot(self, ip: str, port: int = 554,
                          path: str = "/Streaming/Channels/101",
                          user: str = None, password: str = None,
                          timeout: int = 15) -> dict:
        """
        يلتقط صورة واحدة من stream.
        """
        # build RTSP url
        if user and password:
            url = f"rtsp://{user}:{password}@{ip}:{port}{path}"
        else:
            url = f"rtsp://{ip}:{port}{path}"

        # output filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_ip = ip.replace(".", "_")
        output = os.path.join(self.output_dir,
                                f"snapshot_{safe_ip}_{timestamp}.jpg")

        # ffmpeg — capture 1 frame
        cmd = [
            "ffmpeg",
            "-rtsp_transport", "tcp",
            "-i", url,
            "-frames:v", "1",
            "-y",
            output,
        ]

        result = {
            "ip": ip,
            "path": path,
            "output": output,
            "success": False,
        }

        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True,
                timeout=timeout)
            if os.path.exists(output) and os.path.getsize(output) > 1000:
                result["success"] = True
                result["size"] = os.path.getsize(output)
            else:
                result["error"] = proc.stderr[-500:]
        except subprocess.TimeoutExpired:
            result["error"] = "timeout"
        except FileNotFoundError:
            result["error"] = "ffmpeg not installed — apt install ffmpeg"
        except Exception as e:
            result["error"] = str(e)

        return result

    def capture_video(self, ip: str, port: int = 554,
                       path: str = "/Streaming/Channels/101",
                       user: str = None, password: str = None,
                       duration: int = 10) -> dict:
        """يلتقط فيديو قصير"""
        if user and password:
            url = f"rtsp://{user}:{password}@{ip}:{port}{path}"
        else:
            url = f"rtsp://{ip}:{port}{path}"

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_ip = ip.replace(".", "_")
        output = os.path.join(self.output_dir,
                                f"video_{safe_ip}_{timestamp}.mp4")

        cmd = [
            "ffmpeg",
            "-rtsp_transport", "tcp",
            "-i", url,
            "-t", str(duration),
            "-c", "copy",
            "-y",
            output,
        ]

        result = {"ip": ip, "path": path, "output": output,
                    "success": False}

        try:
            proc = subprocess.run(cmd, capture_output=True, text=True,
                                   timeout=duration + 30)
            if os.path.exists(output) and os.path.getsize(output) > 10000:
                result["success"] = True
                result["size"] = os.path.getsize(output)
        except Exception as e:
            result["error"] = str(e)

        return result
