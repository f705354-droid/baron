# language: Python, file: core/cctv/hikvision.py
# Hikvision ISAPI — full camera control
import httpx
import base64
import hashlib
import os
import xml.etree.ElementTree as ET
from datetime import datetime
from typing import Optional


class HikvisionISAPI:
    """
    Hikvision ISAPI — واجهة كاملة للتحكم.
    Endpoints الأساسية:
      GET  /ISAPI/System/deviceInfo
      GET  /ISAPI/System/status
      GET  /ISAPI/Streaming/channels
      GET  /ISAPI/ContentMgmt/record/tracks
      PUT  /ISAPI/PTZCtrl/channels/1/continuous
      POST /ISAPI/Security/users
      GET  /ISAPI/Security/users
      DELETE /ISAPI/Security/users/{id}
      GET  /ISAPI/System/IO/outputs
    """

    def __init__(self, ip: str, port: int = 80, user: str = "",
                  password: str = "", use_digest: bool = True):
        self.ip = ip
        self.port = port
        self.user = user
        self.password = password
        self.base_url = f"http://{ip}:{port}"
        self.client = httpx.Client(
            auth=(user, password) if user else None,
            timeout=10, verify=False)
        self.session_id = None

    # ==================== authentication ====================
    def test_auth(self) -> dict:
        """يختبر المصادقة"""
        try:
            r = self.client.get(
                f"{self.base_url}/ISAPI/System/deviceInfo")
            if r.status_code == 200:
                return {"status": "ok", "authenticated": True}
            if r.status_code == 401:
                return {"status": "unauthorized"}
        except Exception as e:
            return {"error": str(e)}
        return {"error": "unknown"}

    # ==================== device info ====================
    def get_device_info(self) -> dict:
        """device info — model، serial، firmware"""
        try:
            r = self.client.get(
                f"{self.base_url}/ISAPI/System/deviceInfo")
            if r.status_code != 200:
                return {"error": f"HTTP {r.status_code}"}

            root = ET.fromstring(r.text)
            info = {}
            for tag in ["deviceName", "deviceID", "deviceDescription",
                        "deviceLocation", "systemContact", "model",
                        "serialNumber", "macAddress", "firmwareVersion",
                        "firmwareReleasedDate", "encoderVersion",
                        "encoderReleasedDate", "deviceType"]:
                for elem in root.iter():
                    if elem.tag.endswith(tag) and elem.text:
                        info[tag] = elem.text
                        break
            return info
        except Exception as e:
            return {"error": str(e)}

    def get_system_status(self) -> dict:
        """حالة النظام"""
        try:
            r = self.client.get(
                f"{self.base_url}/ISAPI/System/status")
            if r.status_code != 200:
                return {"error": f"HTTP {r.status_code}"}
            return {"xml": r.text[:5000]}
        except Exception as e:
            return {"error": str(e)}

    # ==================== streaming ====================
    def list_streams(self) -> list:
        """كل قنوات البث"""
        try:
            r = self.client.get(
                f"{self.base_url}/ISAPI/Streaming/channels")
            if r.status_code != 200:
                return []
            root = ET.fromstring(r.text)
            channels = []
            for ch in root.iter():
                if ch.tag.endswith("StreamingChannel"):
                    channels.append({
                        "id": ch.findtext(".//{*}id") or "?",
                        "name": ch.findtext(".//{*}channelName") or "?",
                        "enabled": ch.findtext(".//{*}enabled") or "?",
                    })
            return channels
        except Exception as e:
            return [{"error": str(e)}]

    def get_stream_url(self, channel_id: int = 101) -> str:
        """RTSP URL للقناة"""
        if self.user:
            auth = base64.b64encode(
                f"{self.user}:{self.password}".encode()).decode()
            return (f"rtsp://{self.user}:{self.password}@{self.ip}:554/"
                    f"Streaming/Channels/{channel_id}")
        return f"rtsp://{self.ip}:554/Streaming/Channels/{channel_id}"

    # ==================== PTZ control ====================
    def ptz_continuous(self, pan: int = 0, tilt: int = 0,
                        zoom: int = 0, channel: int = 1) -> dict:
        """
        تحريك PTZ. pan/tilt/zoom بين -100 و100.
        """
        payload = f'''<?xml version="1.0" encoding="UTF-8"?>
<PTZData>
  <pan>{pan}</pan>
  <tilt>{tilt}</tilt>
  <zoom>{zoom}</zoom>
</PTZData>'''
        try:
            r = self.client.put(
                f"{self.base_url}/ISAPI/PTZCtrl/channels/{channel}/continuous",
                content=payload.encode(),
                headers={"Content-Type": "application/xml"})
            return {"status": r.status_code, "success": r.status_code == 200}
        except Exception as e:
            return {"error": str(e)}

    def ptz_stop(self, channel: int = 1) -> dict:
        return self.ptz_continuous(0, 0, 0, channel)

    def ptz_preset_goto(self, preset_id: int, channel: int = 1) -> dict:
        payload = f'''<?xml version="1.0" encoding="UTF-8"?>
<PTZPreset>
  <id>{preset_id}</id>
</PTZPreset>'''
        try:
            r = self.client.put(
                f"{self.base_url}/ISAPI/PTZCtrl/channels/{channel}/presets/{preset_id}/goto",
                content=payload.encode(),
                headers={"Content-Type": "application/xml"})
            return {"status": r.status_code, "success": r.status_code == 200}
        except Exception as e:
            return {"error": str(e)}

    def ptz_presets(self, channel: int = 1) -> list:
        """قائمة presets"""
        try:
            r = self.client.get(
                f"{self.base_url}/ISAPI/PTZCtrl/channels/{channel}/presets")
            if r.status_code != 200:
                return []
            root = ET.fromstring(r.text)
            presets = []
            for p in root.iter():
                if p.tag.endswith("PTZPreset"):
                    presets.append({
                        "id": p.findtext(".//{*}id") or "?",
                        "name": p.findtext(".//{*}presetName") or "?",
                    })
            return presets
        except Exception:
            return []

    # ==================== snapshots ====================
    def snapshot(self, channel: int = 101, save_path: str = None) -> dict:
        """يأخذ snapshot من القناة"""
        if not save_path:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            safe_ip = self.ip.replace(".", "_")
            save_path = f"loot/cctv_snapshots/hik_{safe_ip}_{timestamp}.jpg"
            os.makedirs(os.path.dirname(save_path), exist_ok=True)

        try:
            r = self.client.get(
                f"{self.base_url}/ISAPI/Streaming/channels/{channel}/picture")
            if r.status_code == 200 and len(r.content) > 1000:
                with open(save_path, "wb") as f:
                    f.write(r.content)
                return {
                    "success": True,
                    "path": save_path,
                    "size": len(r.content),
                }
            return {"error": f"HTTP {r.status_code}"}
        except Exception as e:
            return {"error": str(e)}

    # ==================== users ====================
    def list_users(self) -> list:
        """قائمة المستخدمين"""
        try:
            r = self.client.get(
                f"{self.base_url}/ISAPI/Security/users")
            if r.status_code != 200:
                return []
            root = ET.fromstring(r.text)
            users = []
            for u in root.iter():
                if u.tag.endswith("User"):
                    users.append({
                        "id": u.findtext(".//{*}id") or "?",
                        "name": u.findtext(".//{*}userName") or "?",
                        "level": u.findtext(".//{*}userLevel") or "?",
                    })
            return users
        except Exception:
            return []

    def add_user(self, username: str, password: str,
                  level: str = "Administrator") -> dict:
        """يضيف مستخدم admin جديد"""
        payload = f'''<?xml version="1.0" encoding="UTF-8"?>
<User>
  <userName>{username}</userName>
  <password>{password}</password>
  <userLevel>{level}</userLevel>
</User>'''
        try:
            r = self.client.post(
                f"{self.base_url}/ISAPI/Security/users",
                content=payload.encode(),
                headers={"Content-Type": "application/xml"})
            return {"status": r.status_code, "success": r.status_code == 200}
        except Exception as e:
            return {"error": str(e)}

    def delete_user(self, user_id: int) -> dict:
        try:
            r = self.client.delete(
                f"{self.base_url}/ISAPI/Security/users/{user_id}")
            return {"status": r.status_code, "success": r.status_code == 200}
        except Exception as e:
            return {"error": str(e)}

    # ==================== recording ====================
    def list_recordings(self) -> list:
        """قائمة التسجيلات"""
        try:
            r = self.client.get(
                f"{self.base_url}/ISAPI/ContentMgmt/record/tracks")
            if r.status_code != 200:
                return []
            return [{"xml": r.text[:5000]}]
        except Exception:
            return []

    def download_recording(self, track_id: int, start: str, end: str,
                            save_path: str) -> dict:
        """سحب تسجيل بفترة محددة"""
        payload = f'''<?xml version="1.0" encoding="UTF-8"?>
<downloadRequest>
  <trackId>{track_id}</trackId>
  <playbackURI>rtsp://{self.ip}/Streaming/tracks/{track_id}?starttime={start}&amp;endtime={end}</playbackURI>
</downloadRequest>'''
        try:
            r = self.client.post(
                f"{self.base_url}/ISAPI/ContentMgmt/download",
                content=payload.encode(),
                headers={"Content-Type": "application/xml"})
            if r.status_code == 200 and len(r.content) > 1000:
                with open(save_path, "wb") as f:
                    f.write(r.content)
                return {"success": True, "path": save_path,
                          "size": len(r.content)}
            return {"error": f"HTTP {r.status_code}"}
        except Exception as e:
            return {"error": str(e)}

    # ==================== alarms ====================
    def list_alarms(self) -> list:
        """قائمة أجهزة الإنذار"""
        try:
            r = self.client.get(
                f"{self.base_url}/ISAPI/Event/notification/alertStream")
            return [{"data": r.text[:1000]}]
        except Exception:
            return []

    # ==================== firmware backdoor check ====================
    def check_backdoor_user(self) -> dict:
        """
        يبحث عن مستخدمين backdoor (مثل "admin" بكلمة مرور مضمّنة).
        بعض firmware Hikvision فيها مستخدمين مخفيين.
        """
        users = self.list_users()
        backdoor_usernames = ["support", "debug", "root", "system"]
        found = []
        for u in users:
            if u.get("name", "").lower() in backdoor_usernames:
                found.append(u)
        return {
            "backdoor_users": found,
            "total_users": len(users),
        }
