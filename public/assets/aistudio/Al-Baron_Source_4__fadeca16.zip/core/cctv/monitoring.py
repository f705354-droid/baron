# language: Python, file: core/cctv/monitoring.py
# Network-wide CCTV monitoring — real-time dashboard
import threading
import time
import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Callable
from collections import deque


class CCTVMonitor:
    """
    يراقب كل الكاميرات في الوقت الحقيقي:
      - حالة الاتصال (up/down)
      - RTSP responsive
      - snapshot كل X ثانية
      - alerts عند down/up
      - history
    """

    def __init__(self, log_queue=None,
                  check_interval: int = 30,
                  snapshot_interval: int = 300):
        self.log = log_queue
        self.cameras: Dict[str, dict] = {}  # ip → config + status
        self.check_interval = check_interval  # seconds
        self.snapshot_interval = snapshot_interval
        self.history: Dict[str, deque] = {}  # ip → deque of events
        self.events = []                     # global event log
        self.running = False
        self.thread = None
        self.on_event = None

    def _out(self, text):
        if self.log:
            self.log.put(f"[monitor] {text}")

    def add_camera(self, ip: str, name: str = "",
                    vendor: str = "",
                    credentials: dict = None):
        """يضيف كاميرا للمراقبة"""
        self.cameras[ip] = {
            "ip": ip,
            "name": name or ip,
            "vendor": vendor,
            "credentials": credentials or {},
            "status": "unknown",
            "last_check": None,
            "last_up": None,
            "uptime_pct": 100.0,
            "checks": 0,
            "failures": 0,
            "snapshots": [],
        }
        if ip not in self.history:
            self.history[ip] = deque(maxlen=100)
        self._out(f"added {ip} to monitoring")

    def remove_camera(self, ip: str):
        if ip in self.cameras:
            del self.cameras[ip]
            self._out(f"removed {ip}")

    def start(self):
        """يبدأ المراقبة في thread"""
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()
        self._out(f"monitoring started ({len(self.cameras)} cameras)")

    def stop(self):
        self.running = False

    def _loop(self):
        last_snapshot = {}
        while self.running:
            for ip, cam in list(self.cameras.items()):
                try:
                    self._check_camera(ip, cam)
                    self._maybe_snapshot(ip, cam, last_snapshot)
                except Exception as e:
                    self._out(f"{ip} error: {e}")

            # sleep check_interval (with early stop)
            for _ in range(self.check_interval):
                if not self.running:
                    return
                time.sleep(1)

    def _check_camera(self, ip: str, cam: dict):
        """فحص واحد للكاميرا"""
        import socket
        cam["checks"] += 1
        cam["last_check"] = datetime.now().isoformat()

        # TCP check ports
        ports_to_check = [80, 554, 8080, 443, 8000]
        any_open = False
        for port in ports_to_check:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(2)
                if sock.connect_ex((ip, port)) == 0:
                    any_open = True
                sock.close()
            except Exception:
                pass

        prev_status = cam["status"]
        if any_open:
            cam["status"] = "online"
            cam["last_up"] = cam["last_check"]

            # log event if changed
            if prev_status != "online":
                self._emit_event({
                    "type": "camera_online",
                    "severity": "info",
                    "ip": ip,
                    "name": cam["name"],
                    "time": cam["last_check"],
                })
        else:
            cam["status"] = "offline"
            cam["failures"] += 1

            if prev_status != "offline":
                self._emit_event({
                    "type": "camera_offline",
                    "severity": "high",
                    "ip": ip,
                    "name": cam["name"],
                    "time": cam["last_check"],
                })

        # uptime %
        cam["uptime_pct"] = round(
            (1 - cam["failures"] / max(cam["checks"], 1)) * 100, 1)

        # history
        self.history[ip].append({
            "time": cam["last_check"],
            "status": cam["status"],
        })

    def _maybe_snapshot(self, ip: str, cam: dict,
                          last_snapshot: dict):
        """snapshot كل X ثانية إذا online"""
        if cam["status"] != "online":
            return
        if not cam["credentials"]:
            return

        now = time.time()
        last = last_snapshot.get(ip, 0)
        if now - last < self.snapshot_interval:
            return
        last_snapshot[ip] = now

        # do snapshot
        try:
            from core.cctv.stream import StreamCapture
            capture = StreamCapture()
            result = capture.capture_snapshot(
                ip, 554,
                "/Streaming/Channels/101",
                cam["credentials"].get("user"),
                cam["credentials"].get("password"),
                timeout=10)
            if result["success"]:
                cam["snapshots"].append({
                    "time": datetime.now().isoformat(),
                    "path": result["output"],
                    "size": result["size"],
                })
                # keep only last 10
                cam["snapshots"] = cam["snapshots"][-10:]
        except Exception as e:
            self._out(f"snapshot {ip}: {e}")

    def _emit_event(self, event: dict):
        self.events.append(event)
        self._out(f"{event['type']}: {event['ip']}")
        if self.on_event:
            try:
                self.on_event(event)
            except Exception:
                pass

    def get_status(self) -> dict:
        """حالة كل الكاميرات"""
        total = len(self.cameras)
        online = sum(1 for c in self.cameras.values()
                      if c["status"] == "online")
        offline = sum(1 for c in self.cameras.values()
                       if c["status"] == "offline")

        return {
            "total": total,
            "online": online,
            "offline": offline,
            "unknown": total - online - offline,
            "cameras": self.cameras,
            "recent_events": self.events[-20:],
            "timestamp": datetime.now().isoformat(),
        }

    def export_status(self, path: str) -> str:
        with open(path, "w") as f:
            json.dump(self.get_status(), f, indent=2, default=str)
        return path
