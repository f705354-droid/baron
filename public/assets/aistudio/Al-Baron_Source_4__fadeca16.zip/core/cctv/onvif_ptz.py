# language: Python, file: core/cctv/onvif_ptz.py
# ONVIF PTZ — camera control via SOAP
import httpx
import xml.etree.ElementTree as ET
from typing import Optional
from datetime import datetime


class ONVIFPTZ:
    """
    ONVIF PTZ — تحريك الكاميرا عبر SOAP.
    Endpoints:
      /onvif/ptz_service — PTZ
      /onvif/device_service — Device
    """

    def __init__(self, ip: str, port: int = 80,
                  user: str = "", password: str = ""):
        self.ip = ip
        self.port = port
        self.user = user
        self.password = password
        self.client = httpx.Client(timeout=10, verify=False,
                                    auth=(user, password) if user else None)
        self.device_url = f"http://{ip}:{port}/onvif/device_service"
        self.ptz_url = f"http://{ip}:{port}/onvif/ptz_service"
        self.profile_token = None

    def _soap(self, url: str, body: str,
               action: str = "") -> Optional[str]:
        """SOAP request"""
        envelope = f'''<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"
            xmlns:tds="http://www.onvif.org/ver10/device/wsdl"
            xmlns:tptz="http://www.onvif.org/ver20/ptz/wsdl"
            xmlns:tt="http://www.onvif.org/ver10/schema"
            xmlns:timg="http://www.onvif.org/ver20/imaging/wsdl">
  <s:Body>
    {body}
  </s:Body>
</s:Envelope>'''
        try:
            r = self.client.post(url, content=envelope.encode(),
                                  headers={
                                      "Content-Type": "application/soap+xml; charset=utf-8",
                                      "SOAPAction": action,
                                  })
            return r.text
        except Exception as e:
            return f"<error>{e}</error>"

    # ==================== discovery ====================
    def get_profiles(self) -> list:
        """جلب profiles (تحتوي على tokens للـPTZ)"""
        body = '''<tds:GetProfiles/>'''
        response = self._soap(self.device_url, body,
                                "http://www.onvif.org/ver10/device/wsdl/GetProfiles")
        if not response:
            return []

        try:
            root = ET.fromstring(response)
            profiles = []
            for p in root.iter():
                if p.tag.endswith("Profiles"):
                    token = p.get("token", "")
                    name = p.findtext(".//{*}Name") or ""
                    if token:
                        profiles.append({"token": token, "name": name})
            if profiles:
                self.profile_token = profiles[0]["token"]
            return profiles
        except Exception:
            return []

    def get_ptz_nodes(self) -> list:
        """PTZ nodes"""
        body = '''<tptz:GetNodes/>'''
        response = self._soap(self.ptz_url, body,
                                "http://www.onvif.org/ver20/ptz/wsdl/GetNodes")
        try:
            root = ET.fromstring(response)
            nodes = []
            for n in root.iter():
                if n.tag.endswith("PTZNode"):
                    nodes.append({
                        "token": n.get("token", ""),
                        "name": n.findtext(".//{*}Name") or "",
                    })
            return nodes
        except Exception:
            return []

    def get_configurations(self) -> list:
        """PTZ configurations"""
        body = '''<tptz:GetConfigurations/>'''
        response = self._soap(self.ptz_url, body,
                                "http://www.onvif.org/ver20/ptz/wsdl/GetConfigurations")
        try:
            root = ET.fromstring(response)
            configs = []
            for c in root.iter():
                if c.tag.endswith("PTZConfiguration"):
                    configs.append({
                        "token": c.get("token", ""),
                        "name": c.findtext(".//{*}Name") or "",
                    })
            return configs
        except Exception:
            return []

    # ==================== movement ====================
    def continuous_move(self, pan: float = 0.0, tilt: float = 0.0,
                          zoom: float = 0.0) -> dict:
        """
        Continuous move. pan/tilt بين -1.0 و1.0، zoom بين -1.0 و1.0.
        """
        if not self.profile_token:
            profiles = self.get_profiles()
            if not profiles:
                return {"error": "no profile"}

        body = f'''<tptz:ContinuousMove>
  <tptz:ProfileToken>{self.profile_token}</tptz:ProfileToken>
  <tptz:Velocity>
    <tt:PanTilt x="{pan}" y="{tilt}"/>
    <tt:Zoom x="{zoom}"/>
  </tptz:Velocity>
</tptz:ContinuousMove>'''
        response = self._soap(self.ptz_url, body,
                                "http://www.onvif.org/ver20/ptz/wsdl/ContinuousMove")
        success = response and "Fault" not in response
        return {"success": success, "response": response[:500] if response else ""}

    def stop(self) -> dict:
        if not self.profile_token:
            profiles = self.get_profiles()
            if profiles:
                self.profile_token = profiles[0]["token"]
            else:
                return {"error": "no profile"}

        body = f'''<tptz:Stop>
  <tptz:ProfileToken>{self.profile_token}</tptz:ProfileToken>
  <tptz:PanTilt>true</tptz:PanTilt>
  <tptz:Zoom>true</tptz:Zoom>
</tptz:Stop>'''
        response = self._soap(self.ptz_url, body,
                                "http://www.onvif.org/ver20/ptz/wsdl/Stop")
        return {"success": response and "Fault" not in response}

    def absolute_move(self, pan: float, tilt: float,
                       zoom: float = 0.0) -> dict:
        """
        Absolute position. pan/tilt بين -180 و180.
        """
        if not self.profile_token:
            self.get_profiles()

        body = f'''<tptz:AbsoluteMove>
  <tptz:ProfileToken>{self.profile_token}</tptz:ProfileToken>
  <tptz:Position>
    <tt:PanTilt x="{pan}" y="{tilt}"/>
    <tt:Zoom x="{zoom}"/>
  </tptz:Position>
</tptz:AbsoluteMove>'''
        response = self._soap(self.ptz_url, body,
                                "http://www.onvif.org/ver20/ptz/wsdl/AbsoluteMove")
        return {"success": response and "Fault" not in response}

    def relative_move(self, pan: float, tilt: float,
                       zoom: float = 0.0) -> dict:
        """Relative move"""
        if not self.profile_token:
            self.get_profiles()

        body = f'''<tptz:RelativeMove>
  <tptz:ProfileToken>{self.profile_token}</tptz:ProfileToken>
  <tptz:Translation>
    <tt:PanTilt x="{pan}" y="{tilt}"/>
    <tt:Zoom x="{zoom}"/>
  </tptz:Translation>
</tptz:RelativeMove>'''
        response = self._soap(self.ptz_url, body,
                                "http://www.onvif.org/ver20/ptz/wsdl/RelativeMove")
        return {"success": response and "Fault" not in response}

    # ==================== presets ====================
    def get_presets(self) -> list:
        if not self.profile_token:
            self.get_profiles()

        body = f'''<tptz:GetPresets>
  <tptz:ProfileToken>{self.profile_token}</tptz:ProfileToken>
</tptz:GetPresets>'''
        response = self._soap(self.ptz_url, body,
                                "http://www.onvif.org/ver20/ptz/wsdl/GetPresets")
        try:
            root = ET.fromstring(response)
            presets = []
            for p in root.iter():
                if p.tag.endswith("Preset"):
                    presets.append({
                        "token": p.get("token", ""),
                        "name": p.findtext(".//{*}Name") or "",
                    })
            return presets
        except Exception:
            return []

    def goto_preset(self, preset_token: str) -> dict:
        if not self.profile_token:
            self.get_profiles()

        body = f'''<tptz:GotoPreset>
  <tptz:ProfileToken>{self.profile_token}</tptz:ProfileToken>
  <tptz:PresetToken>{preset_token}</tptz:PresetToken>
</tptz:GotoPreset>'''
        response = self._soap(self.ptz_url, body,
                                "http://www.onvif.org/ver20/ptz/wsdl/GotoPreset")
        return {"success": response and "Fault" not in response}

    def set_preset(self, preset_name: str, preset_token: str = "") -> dict:
        if not self.profile_token:
            self.get_profiles()

        token_elem = f"<tptz:PresetToken>{preset_token}</tptz:PresetToken>" if preset_token else ""
        body = f'''<tptz:SetPreset>
  <tptz:ProfileToken>{self.profile_token}</tptz:ProfileToken>
  {token_elem}
  <tptz:PresetName>{preset_name}</tptz:PresetName>
</tptz:SetPreset>'''
        response = self._soap(self.ptz_url, body,
                                "http://www.onvif.org/ver20/ptz/wsdl/SetPreset")
        return {"success": response and "Fault" not in response}
