# language: Python, file: core/graph/graph_db.py
# Unified Graph — SQLite-backed graph DB for engagement knowledge
import sqlite3
import json
import os
import time
from datetime import datetime
from typing import Optional, List, Dict, Any


class UnifiedGraph:
    """
    كل شيء في المنصة يُسجَّل هنا كـ node أو edge.
    Nodes: host, session, credential, vulnerability, technique, task, artifact
    Edges: connects_to, has_session, has_cred, exploits, uses_technique, yields
    """
    NODE_TYPES = ["host", "session", "credential", "vulnerability",
                    "technique", "task", "artifact", "subnet", "user"]
    EDGE_TYPES = ["connects_to", "has_session", "has_cred", "exploits",
                    "uses_technique", "yields", "triggers", "part_of"]

    def __init__(self, path: str = "~/.albaron/graph.db"):
        self.path = os.path.expanduser(path)
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self.db = sqlite3.connect(self.path, check_same_thread=False)
        self._init_schema()

    def _init_schema(self):
        c = self.db.cursor()
        c.executescript("""
        CREATE TABLE IF NOT EXISTS nodes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            node_type TEXT NOT NULL,
            key TEXT NOT NULL UNIQUE,
            properties TEXT,
            created REAL,
            updated REAL
        );
        CREATE INDEX IF NOT EXISTS idx_nodes_type ON nodes(node_type);
        CREATE INDEX IF NOT EXISTS idx_nodes_key ON nodes(key);

        CREATE TABLE IF NOT EXISTS edges (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            src_id INTEGER NOT NULL,
            dst_id INTEGER NOT NULL,
            edge_type TEXT NOT NULL,
            properties TEXT,
            created REAL,
            FOREIGN KEY(src_id) REFERENCES nodes(id),
            FOREIGN KEY(dst_id) REFERENCES nodes(id)
        );
        CREATE INDEX IF NOT EXISTS idx_edges_src ON edges(src_id);
        CREATE INDEX IF NOT EXISTS idx_edges_dst ON edges(dst_id);
        CREATE INDEX IF NOT EXISTS idx_edges_type ON edges(edge_type);
        """)
        self.db.commit()

    # ==================== nodes ====================
    def upsert_node(self, node_type: str, key: str,
                      properties: dict = None) -> int:
        """ينشئ أو يحدّث عقدة. key فريد. يعيد id."""
        props = json.dumps(properties or {}, default=str)
        now = time.time()
        c = self.db.cursor()
        row = c.execute(
            "SELECT id, properties FROM nodes WHERE key=? AND node_type=?",
            (key, node_type)).fetchone()
        if row:
            nid, existing = row
            merged = {**json.loads(existing or "{}"),
                       **json.loads(props)}
            c.execute(
                "UPDATE nodes SET properties=?, updated=? WHERE id=?",
                (json.dumps(merged, default=str), now, nid))
            self.db.commit()
            return nid
        c.execute(
            "INSERT INTO nodes(node_type, key, properties, created, updated) "
            "VALUES(?, ?, ?, ?, ?)",
            (node_type, key, props, now, now))
        self.db.commit()
        return c.lastrowid

    def get_node(self, node_type: str, key: str) -> Optional[dict]:
        row = self.db.execute(
            "SELECT id, properties, created, updated FROM nodes "
            "WHERE node_type=? AND key=?",
            (node_type, key)).fetchone()
        if not row:
            return None
        return {
            "id": row[0], "type": node_type, "key": key,
            "properties": json.loads(row[1] or "{}"),
            "created": row[2], "updated": row[3],
        }

    def list_nodes(self, node_type: str = None) -> List[dict]:
        if node_type:
            rows = self.db.execute(
                "SELECT id, node_type, key, properties, created "
                "FROM nodes WHERE node_type=? ORDER BY created DESC",
                (node_type,)).fetchall()
        else:
            rows = self.db.execute(
                "SELECT id, node_type, key, properties, created "
                "FROM nodes ORDER BY created DESC").fetchall()
        return [
            {"id": r[0], "type": r[1], "key": r[2],
              "properties": json.loads(r[3] or "{}"),
              "created": r[4]}
            for r in rows
        ]

    # ==================== edges ====================
    def add_edge(self, src_type: str, src_key: str,
                  dst_type: str, dst_key: str,
                  edge_type: str, properties: dict = None) -> int:
        src = self.upsert_node(src_type, src_key)
        dst = self.upsert_node(dst_type, dst_key)
        props = json.dumps(properties or {}, default=str)
        c = self.db.cursor()
        # avoid duplicate edges
        row = c.execute(
            "SELECT id FROM edges WHERE src_id=? AND dst_id=? AND edge_type=?",
            (src, dst, edge_type)).fetchone()
        if row:
            c.execute("UPDATE edges SET properties=? WHERE id=?",
                       (props, row[0]))
            self.db.commit()
            return row[0]
        c.execute(
            "INSERT INTO edges(src_id, dst_id, edge_type, properties, created) "
            "VALUES(?, ?, ?, ?, ?)",
            (src, dst, edge_type, props, time.time()))
        self.db.commit()
        return c.lastrowid

    def neighbors(self, node_type: str, key: str,
                    edge_type: str = None, direction: str = "both") -> List[dict]:
        node = self.get_node(node_type, key)
        if not node:
            return []
        nid = node["id"]
        results = []

        def _resolve(src_or_dst_col: str, match_col: str):
            q = f"""
            SELECT n.node_type, n.key, n.properties, e.edge_type
            FROM edges e JOIN nodes n ON e.{src_or_dst_col}=n.id
            WHERE e.{match_col}=?
            """
            params = [nid]
            if edge_type:
                q += " AND e.edge_type=?"
                params.append(edge_type)
            for row in self.db.execute(q, params).fetchall():
                results.append({
                    "type": row[0], "key": row[1],
                    "properties": json.loads(row[2] or "{}"),
                    "edge": row[3],
                })

        if direction in ("out", "both"):
            _resolve("dst_id", "src_id")
        if direction in ("in", "both"):
            _resolve("src_id", "dst_id")

        # dedupe
        seen = set()
        uniq = []
        for r in results:
            k = (r["type"], r["key"], r["edge"])
            if k not in seen:
                seen.add(k)
                uniq.append(r)
        return uniq

    # ==================== domain helpers ====================
    def register_host(self, ip: str, **props) -> int:
        return self.upsert_node("host", ip, props)

    def register_session(self, sid: str, host_ip: str,
                          **props) -> int:
        self.upsert_node("host", host_ip)
        self.upsert_node("session", sid, props)
        self.add_edge("session", sid, "host", host_ip, "has_session")
        return self.get_node("session", sid)["id"]

    def register_credential(self, user: str, secret: str,
                             source: str, **props) -> int:
        key = f"{user}@{source}"
        self.upsert_node("credential", key,
                          {"user": user, "secret": secret, **props})
        return self.get_node("credential", key)["id"]

    def register_vuln(self, cve: str, host_ip: str, **props) -> int:
        self.upsert_node("vulnerability", cve, props)
        self.upsert_node("host", host_ip)
        self.add_edge("host", host_ip, "vulnerability", cve,
                       "vulnerable_to", props)
        return self.get_node("vulnerability", cve)["id"]

    def register_technique(self, tid: str, name: str,
                            tactic: str) -> int:
        return self.upsert_node("technique", tid,
                                 {"name": name, "tactic": tactic})

    def register_task(self, task_id: str, tool: str,
                       target: str, **props) -> int:
        return self.upsert_node("task", task_id,
                                 {"tool": tool, "target": target, **props})

    # ==================== graph queries ====================
    def attack_paths(self, from_host: str, to_host: str,
                      max_depth: int = 5) -> List[List[dict]]:
        """يبحث عن مسارات بين host و host آخر"""
        start = self.get_node("host", from_host)
        target = self.get_node("host", to_host)
        if not start or not target:
            return []

        # BFS
        queue = [(start["id"], [])]
        visited = {start["id"]}
        paths = []

        while queue and len(paths) < 10:
            nid, path = queue.pop(0)
            if len(path) >= max_depth:
                continue

            for edge_row in self.db.execute(
                "SELECT e.dst_id, e.edge_type, n.node_type, n.key "
                "FROM edges e JOIN nodes n ON e.dst_id=n.id "
                "WHERE e.src_id=?", (nid,)
            ).fetchall():
                dst_id, edge_type, dst_type, dst_key = edge_row
                new_path = path + [{
                    "type": dst_type, "key": dst_key, "edge": edge_type,
                }]
                if dst_id == target["id"]:
                    paths.append(new_path)
                elif dst_id not in visited:
                    visited.add(dst_id)
                    queue.append((dst_id, new_path))
        return paths

    def find_hosts_with_vuln(self, cve: str) -> List[str]:
        return [n["key"] for n in self.neighbors(
            "vulnerability", cve, edge_type="vulnerable_to",
            direction="in") if n["type"] == "host"]

    def get_attack_surface(self) -> dict:
        """ملخص عام لسطح الهجوم"""
        return {
            "hosts": len(self.list_nodes("host")),
            "sessions": len(self.list_nodes("session")),
            "creds": len(self.list_nodes("credential")),
            "vulns": len(self.list_nodes("vulnerability")),
            "techniques": len(self.list_nodes("technique")),
        }

    # ==================== export ====================
    def export_graphml(self, path: str = "graph.graphml"):
        """يصدّر كـ GraphML (متوافق مع Gephi، yEd، Neo4j)"""
        lines = ['<?xml version="1.0" encoding="UTF-8"?>']
        lines.append('<graphml xmlns="http://graphml.graphdrawing.org/xmlns">')
        lines.append('  <key id="type" for="node" attr.name="type" attr.type="string"/>')
        lines.append('  <key id="props" for="node" attr.name="props" attr.type="string"/>')
        lines.append('  <key id="edge" for="edge" attr.name="edge" attr.type="string"/>')
        lines.append('  <graph id="G" edgedefault="directed">')

        for n in self.list_nodes():
            props = json.dumps(n["properties"], default=str).replace('"', '&quot;')
            lines.append(f'    <node id="n{n["id"]}">')
            lines.append(f'      <data key="type">{n["type"]}</data>')
            lines.append(f'      <data key="props">{n["key"]} | {props}</data>')
            lines.append(f'    </node>')

        for e_row in self.db.execute(
            "SELECT e.id, e.src_id, e.dst_id, e.edge_type FROM edges e"
        ).fetchall():
            eid, src_id, dst_id, etype = e_row
            lines.append(f'    <edge id="e{eid}" source="n{src_id}" target="n{dst_id}">')
            lines.append(f'      <data key="edge">{etype}</data>')
            lines.append(f'    </edge>')

        lines.append('  </graph>')
        lines.append('</graphml>')
        with open(path, "w") as f:
            f.write("\n".join(lines))


# singleton
graph = UnifiedGraph()
