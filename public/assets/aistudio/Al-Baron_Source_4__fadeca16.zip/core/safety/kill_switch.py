# language: Python, file: core/safety/kill_switch.py
# Kill switch — يوقف كل العمليات فوراً (نافذة، hotkey، API)
import os
import signal
import threading
import subprocess
from typing import List, Callable
from datetime import datetime


class KillSwitch:
    """
    يستجيب لـ:
      - زر GUI
      - SIGINT (Ctrl+C)
      - ملف flag (~/.albaron/STOP)
      - hotkey (F12 في نافذة Tk)

    عند التفعيل:
      - يقتل كل الـsubprocesses
      - يغلق كل الـbeacons
      - يوقف autonomous loops
      - يسجل الحادثة
    """
    def __init__(self):
        self.active = False
        self.triggers: List[str] = []
        self.callbacks: List[Callable] = []
        self.log_path = os.path.expanduser(
            "~/.albaron/killswitch.log")
        os.makedirs(os.path.dirname(self.log_path), exist_ok=True)
        self._install_signal_handler()

    def register(self, cb: Callable):
        """كل module يسجل callback لتنظيف نفسه"""
        self.callbacks.append(cb)

    def _install_signal_handler(self):
        try:
            signal.signal(signal.SIGINT, self._on_signal)
        except Exception:
            pass

    def _on_signal(self, signum, frame):
        self.trigger("SIGINT")

    def trigger(self, source: str):
        if self.active:
            return
        self.active = True
        self.triggers.append(source)
        self._log(f"ACTIVATED via {source}")

        # 1. قتل كل subprocesses
        self._kill_subprocesses()

        # 2. callbacks (beacons, workers, threads)
        for cb in self.callbacks:
            try:
                cb()
            except Exception as e:
                self._log(f"callback error: {e}")

        # 3. كتابة flag
        try:
            with open(os.path.expanduser("~/.albaron/STOP"), "w") as f:
                f.write(f"{datetime.utcnow().isoformat()} {source}\n")
        except Exception:
            pass

    def reset(self):
        self.active = False
        self.triggers.clear()
        try:
            os.remove(os.path.expanduser("~/.albaron/STOP"))
        except FileNotFoundError:
            pass
        self._log("reset")

    def _kill_subprocesses(self):
        # استخدم pkill على عمليات nmap/metasploit/etc
        processes = ["nmap", "msfconsole", "msfvenom",
                      "responder", "bettercap", "ettercap",
                      "impacket-", "nxc", "certipy", "sliver"]
        for p in processes:
            try:
                subprocess.run(["pkill", "-f", p],
                                capture_output=True, timeout=2)
            except Exception:
                pass

    def _log(self, msg: str):
        try:
            with open(self.log_path, "a") as f:
                f.write(f"{datetime.utcnow().isoformat()} | {msg}\n")
        except Exception:
            pass

    def is_active(self) -> bool:
        # check flag file
        if os.path.exists(os.path.expanduser("~/.albaron/STOP")):
            self.active = True
        return self.active


kill_switch = KillSwitch()
