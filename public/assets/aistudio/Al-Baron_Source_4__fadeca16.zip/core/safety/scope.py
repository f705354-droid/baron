# language: Python, file: core/safety/scope.py
# Scope declaration — قبل engagement، يجب إعلان النطاق كتابياً
# يمنع تشغيل الأداة بدون تحديد الأهداف
import os
import json
from typing import List, Optional
from datetime import datetime, timedelta


class ScopeManager:
    """
    Scope = عقد engagement داخلي:
      - targets (IPs، domains، CIDRs)
      - excludes
      - time window
      - tester (اسمك)
      - acknowledgment (توقيع كتابي)

    الأداة ترفض التشغيل بدون scope active.
    """
    def __init__(self, path: str = "~/.albaron/scope.json"):
        self.path = os.path.expanduser(path)
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self.active_scope: Optional[dict] = None
        self._load()

    def _load(self):
        if not os.path.exists(self.path):
            return
        try:
            with open(self.path) as f:
                scope = json.load(f)
            end = datetime.fromisoformat(scope["end"])
            if end > datetime.utcnow() and scope.get("active"):
                self.active_scope = scope
        except Exception:
            pass

    def declare(self, targets: List[str], excludes: List[str] = None,
                 hours: int = 8, tester: str = None,
                 acknowledgment: str = None) -> dict:
        """
        يعلن scope، يتحقق من الحقول.
        acknowledgment يجب أن يكون: "I have authorization for these targets."
        """
        if acknowledgment != "I have authorization for these targets.":
            raise PermissionError(
                "You must acknowledge authorization before starting.")
        if not targets:
            raise ValueError("no targets specified")

        scope = {
            "targets": targets,
            "excludes": excludes or [],
            "start": datetime.utcnow().isoformat(),
            "end": (datetime.utcnow() + timedelta(hours=hours)).isoformat(),
            "hours": hours,
            "tester": tester or os.getenv("USER", "unknown"),
            "acknowledgment": acknowledgment,
            "active": True,
        }
        with open(self.path, "w") as f:
            json.dump(scope, f, indent=2)
        self.active_scope = scope
        return scope

    def is_active(self) -> bool:
        if not self.active_scope:
            return False
        end = datetime.fromisoformat(self.active_scope["end"])
        return end > datetime.utcnow()

    def check_target(self, target: str) -> tuple:
        if not self.is_active():
            return False, "no active scope — declare scope first"

        scope = self.active_scope
        # check excludes
        for ex in scope["excludes"]:
            if self._matches(target, ex):
                return False, f"target {target} excluded"

        # check targets
        for t in scope["targets"]:
            if self._matches(target, t):
                return True, "in scope"

        return False, f"target {target} not in declared scope"

    def _matches(self, target: str, pattern: str) -> bool:
        # simple match: exact، CIDR، أو subdomain
        if target == pattern:
            return True
        if "/" in pattern:
            import ipaddress
            try:
                net = ipaddress.ip_network(pattern, strict=False)
                return ipaddress.ip_address(target) in net
            except Exception:
                pass
        # subdomain match
        if pattern.startswith(".") and target.endswith(pattern):
            return True
        return False

    def end(self):
        if self.active_scope:
            self.active_scope["active"] = False
            with open(self.path, "w") as f:
                json.dump(self.active_scope, f, indent=2)
        self.active_scope = None

    def report(self) -> dict:
        if not self.active_scope:
            return {"status": "no active scope"}
        end = datetime.fromisoformat(self.active_scope["end"])
        remaining = (end - datetime.utcnow()).total_seconds() / 3600
        return {
            "status": "active" if remaining > 0 else "expired",
            "tester": self.active_scope["tester"],
            "targets": self.active_scope["targets"],
            "excludes": self.active_scope["excludes"],
            "hours_remaining": round(remaining, 2),
        }


scope_manager = ScopeManager()
