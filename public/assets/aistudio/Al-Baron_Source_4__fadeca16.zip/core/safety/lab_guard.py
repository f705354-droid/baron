# language: Python, file: core/safety/lab_guard.py
# Lab guard — يمنع تشغيل أي عملية ضد عنوان خارج نطاق المختبر
# هذا يحمي المستخدم قانونياً وعملياً
import os
import ipaddress
import re
import socket
import subprocess
from typing import List, Optional, Tuple
from dataclasses import dataclass


@dataclass
class LabConfig:
    allowed_cidrs: List[str]        # شبكات المختبر
    allowed_domains: List[str]      # نطاقات المختبر (.lab, .local, .test)
    blocked_cidrs: List[str]        # شبكات محظورة صراحة (مثل شبكة الشركة)
    blocked_domains: List[str]      # .gov, .mil, etc
    fail_closed: bool = True        # لو فشل التحقق، ارفض


DEFAULT_LAB_CONFIG = LabConfig(
    allowed_cidrs=[
        "127.0.0.0/8",
        "10.0.0.0/8",
        "172.16.0.0/12",
        "192.168.0.0/16",
        "100.64.0.0/10",     # CGNAT
    ],
    allowed_domains=[
        ".lab", ".local", ".test", ".internal", ".lan", ".localdomain"
    ],
    blocked_cidrs=[
        "0.0.0.0/8",
        "169.254.0.0/16",    # link-local
        "224.0.0.0/4",       # multicast
        "240.0.0.0/4",       # reserved
    ],
    blocked_domains=[
        ".gov", ".mil", ".edu",
    ],
)


class LabGuard:
    """
    يتحقق من كل target قبل التشغيل:
      1. IP داخل allowed_cidrs؟
      2. domain ينتهي بـallowed_domains؟
      3. ليس في blocked؟
      4. DNS resolution لا يخرج لـpublic IP؟

    يمنع catastrophic mistakes مثل bookmarks خاطئة أو typo في عنوان.
    """
    def __init__(self, config: Optional[LabConfig] = None,
                  audit_path: str = "~/.albaron/lab_audit.log"):
        self.config = config or DEFAULT_LAB_CONFIG
        self.audit_path = os.path.expanduser(audit_path)
        os.makedirs(os.path.dirname(self.audit_path), exist_ok=True)
        self.allowed_nets = [ipaddress.ip_network(c)
                              for c in self.config.allowed_cidrs]
        self.blocked_nets = [ipaddress.ip_network(c)
                              for c in self.config.blocked_cidrs]

    def _log(self, decision: str, target: str, reason: str):
        import time
        with open(self.audit_path, "a") as f:
            f.write(f"{time.time():.0f} | {decision} | {target} | {reason}\n")

    def check_ip(self, ip: str) -> Tuple[bool, str]:
        try:
            addr = ipaddress.ip_address(ip)
        except ValueError:
            return False, f"invalid ip: {ip}"

        for net in self.blocked_nets:
            if addr in net:
                self._log("DENY", ip, f"in blocked {net}")
                return False, f"blocked subnet {net}"

        for net in self.allowed_nets:
            if addr in net:
                self._log("ALLOW", ip, f"in allowed {net}")
                return True, f"allowed by {net}"

        self._log("DENY", ip, "not in any allowed cidr")
        return False, f"outside lab networks"

    def check_domain(self, domain: str) -> Tuple[bool, str]:
        d = domain.lower().strip(".")
        for b in self.config.blocked_domains:
            if d.endswith(b):
                self._log("DENY", domain, f"blocked domain {b}")
                return False, f"blocked {b}"
        for a in self.config.allowed_domains:
            if d.endswith(a):
                self._log("ALLOW", domain, f"allowed domain {a}")
                return True, f"allowed {a}"
        # اختياري: لو target.corp.local → .local ✓
        self._log("DENY", domain, "not in allowed domains")
        return False, "domain not in lab"

    def check_target(self, target: str) -> Tuple[bool, str]:
        """
        يقبل IP، CIDR، أو domain.
        يرجع (allowed, reason).
        """
        t = target.strip()
        if not t:
            return False, "empty"

        # CIDR
        if "/" in t:
            try:
                net = ipaddress.ip_network(t, strict=False)
                for host in net.hosts():
                    ok, _ = self.check_ip(str(host))
                    if ok:
                        return True, f"cidr inside {net}"
                return False, "cidr outside allowed"
            except ValueError:
                return False, "invalid cidr"

        # IP
        try:
            ipaddress.ip_address(t)
            return self.check_ip(t)
        except ValueError:
            pass

        # domain — تحقق DNS
        ok, reason = self.check_domain(t)
        if not ok:
            return False, reason

        # DNS resolution check
        try:
            ips = socket.getaddrinfo(t, None)
            for family, _, _, _, sockaddr in ips:
                ip = sockaddr[0]
                ip_ok, ip_reason = self.check_ip(ip)
                if not ip_ok:
                    self._log("DENY", target,
                              f"resolved to non-lab ip {ip}")
                    return False, f"resolves to {ip}, not lab"
        except socket.gaierror:
            return False, "dns resolution failed"

        return True, reason

    def enforce(self, target: str):
        """يرفع استثناء لو الهدف غير مسموح"""
        ok, reason = self.check_target(target)
        if not ok:
            raise PermissionError(
                f"LAB GUARD: refused target '{target}' — {reason}. "
                f"Edit ~/.albaron/lab_config.json to expand scope."
            )
        return True

    def check_command(self, cmd: str) -> Tuple[bool, str]:
        """
        يستخرج target من shell command ويعاير.
        يمنع تشغيل nmap 8.8.8.8 عبر الأداة.
        """
        # استخراج IPs و domains
        ips = re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}(?:/\d+)?" , cmd)
        domains = re.findall(
            r"\b[a-z0-9.-]+\.(?:com|net|org|io|gov|mil|edu|info|biz|xyz)\b",
            cmd.lower())

        for ip in ips:
            ok, reason = self.check_target(ip)
            if not ok:
                return False, f"command target {ip}: {reason}"

        for d in domains:
            ok, reason = self.check_target(d)
            if not ok:
                return False, f"command target {d}: {reason}"

        return True, "all targets in lab"

    def report(self) -> dict:
        return {
            "allowed_cidrs": self.config.allowed_cidrs,
            "allowed_domains": self.config.allowed_domains,
            "blocked_cidrs": self.config.blocked_cidrs,
            "blocked_domains": self.config.blocked_domains,
            "audit_path": self.audit_path,
        }


lab_guard = LabGuard()
