# language: Python, file: core/safety/audit_trail.py
# Audit trail — كل action مسجل بسلسلة hash غير قابلة للتلاعب
import os
import json
import hashlib
import time
import threading
from typing import Dict, List, Optional


class AuditTrail:
    """
    Append-only log بسلسلة hash:
      entry_i.hash = sha256(entry_i.data + entry_{i-1}.hash)
    أي تعديل في الوسط يكسر السلسلة → يكشف العبث.
    """
    def __init__(self, path: str = "~/.albaron/audit.jsonl"):
        self.path = os.path.expanduser(path)
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self._lock = threading.Lock()
        self._last_hash = "GENESIS"
        self._load_last_hash()

    def _load_last_hash(self):
        if not os.path.exists(self.path):
            return
        try:
            last_line = ""
            with open(self.path, "rb") as f:
                f.seek(0, 2)
                size = f.tell()
                f.seek(max(0, size - 4096))
                lines = f.read().decode(errors="ignore").strip().split("\n")
                if lines:
                    last_line = lines[-1]
            if last_line:
                data = json.loads(last_line)
                self._last_hash = data.get("chain_hash", "GENESIS")
        except Exception:
            pass

    def log(self, actor: str, action: str,
             target: str = "", details: dict = None,
             tenant: str = "default") -> str:
        """يكتب إدخالاً جديداً، يرجع الhash"""
        entry = {
            "ts": time.time(),
            "actor": actor,
            "action": action,
            "target": target,
            "tenant": tenant,
            "details": details or {},
            "prev_hash": self._last_hash,
        }
        data_str = json.dumps(entry, sort_keys=True)
        chain_hash = hashlib.sha256(
            (data_str + self._last_hash).encode()).hexdigest()

        full = {**entry, "chain_hash": chain_hash}
        with self._lock:
            try:
                with open(self.path, "a") as f:
                    f.write(json.dumps(full) + "\n")
            except Exception:
                pass
            self._last_hash = chain_hash
        return chain_hash

    def verify_integrity(self) -> dict:
        """
        يمشي عبر السلسلة، يتحقق من كل hash.
        أي عدم تطابق → tampered.
        """
        if not os.path.exists(self.path):
            return {"ok": True, "entries": 0}

        prev = "GENESIS"
        bad = []
        entries = 0
        try:
            with open(self.path) as f:
                for line_no, line in enumerate(f, 1):
                    line = line.strip()
                    if not line:
                        continue
                    entry = json.loads(line)
                    chain_hash = entry.pop("chain_hash", "")
                    prev_hash = entry.get("prev_hash", "")
                    if prev_hash != prev:
                        bad.append({
                            "line": line_no,
                            "reason": "prev_hash mismatch",
                            "expected": prev,
                            "found": prev_hash,
                        })
                    data_str = json.dumps(entry, sort_keys=True)
                    computed = hashlib.sha256(
                        (data_str + prev_hash).encode()).hexdigest()
                    if computed != chain_hash:
                        bad.append({
                            "line": line_no,
                            "reason": "chain_hash mismatch",
                            "expected": computed,
                            "found": chain_hash,
                        })
                    prev = chain_hash
                    entries += 1
        except Exception as e:
            return {"ok": False, "error": str(e)}

        return {
            "ok": len(bad) == 0,
            "entries": entries,
            "tampered": bad,
        }

    def tail(self, n: int = 50) -> List[dict]:
        if not os.path.exists(self.path):
            return []
        with open(self.path) as f:
            lines = f.readlines()
        return [json.loads(l) for l in lines[-n:] if l.strip()]


audit_trail = AuditTrail()
