# language: Python, file: core/soar/engine.py
# SOAR — security orchestration, automation, response
import json
import os
import time
import threading
import yaml
from datetime import datetime
from typing import Dict, List, Optional, Callable


class SOARAction:
    """إجراء واحد في playbook"""
    def __init__(self, action_type: str, params: dict = None,
                  condition: str = None, name: str = None):
        self.action_type = action_type
        self.params = params or {}
        self.condition = condition
        self.name = name or f"{action_type}_{int(time.time())}"

    def to_dict(self):
        return {
            "name": self.name,
            "action": self.action_type,
            "params": self.params,
            "condition": self.condition,
        }


class SOARPlaybook:
    """playbook كامل"""
    def __init__(self, name: str, description: str,
                  trigger: str, actions: List[SOARAction],
                  enabled: bool = True):
        self.name = name
        self.description = description
        self.trigger = trigger     # event name that triggers
        self.actions = actions
        self.enabled = enabled

    @classmethod
    def from_yaml(cls, path: str):
        with open(path) as f:
            data = yaml.safe_load(f)
        actions = [SOARAction(**a) for a in data.get("actions", [])]
        return cls(
            data.get("name", "unnamed"),
            data.get("description", ""),
            data.get("trigger", ""),
            actions,
            data.get("enabled", True),
        )

    def to_dict(self):
        return {
            "name": self.name,
            "description": self.description,
            "trigger": self.trigger,
            "enabled": self.enabled,
            "actions": [a.to_dict() for a in self.actions],
        }


class SOAREngine:
    """
    محرك تنفيذ playbooks.
    يتلقى events، يبحث عن playbooks مطابقة، ينفذها.
    """
    def __init__(self, log_queue=None):
        self.log = log_queue
        self.playbooks: List[SOARPlaybook] = []
        self.executions: List[dict] = []
        self.running = False
        self.event_queue = []
        self.lock = threading.Lock()

        # built-in actions
        self.action_handlers: Dict[str, Callable] = {}
        self._register_builtins()

    def _register_builtins(self):
        """يسجل actions المدمجة"""
        self.action_handlers = {
            "log": self._action_log,
            "webhook": self._action_webhook,
            "email": self._action_email,
            "slack": self._action_slack,
            "block_ip": self._action_block_ip,
            "isolate_host": self._action_isolate,
            "kill_process": self._action_kill_process,
            "quarantine_file": self._action_quarantine,
            "create_alert": self._action_alert,
            "run_command": self._action_command,
            "hunt": self._action_hunt,
            "notify": self._action_notify,
        }

    def register_action(self, name: str, handler: Callable):
        """يضيف action مخصص"""
        self.action_handlers[name] = handler

    def load_playbooks(self, dir_path: str = "soar_playbooks"):
        """يحمّل playbooks من مجلد"""
        os.makedirs(dir_path, exist_ok=True)
        self._write_default_playbooks(dir_path)

        for file in os.listdir(dir_path):
            if file.endswith(".yaml") or file.endswith(".yml"):
                try:
                    pb = SOARPlaybook.from_yaml(os.path.join(dir_path, file))
                    self.playbooks.append(pb)
                    if self.log:
                        self.log.put(f"[soar] loaded: {pb.name}")
                except Exception as e:
                    if self.log:
                        self.log.put(f"[soar] {file}: {e}")

    def _write_default_playbooks(self, dir_path: str):
        """يكتب 3 playbooks جاهزة"""
        templates = {
            "malware_detected.yaml": """name: Malware Detected
description: Isolate host and quarantine on malware detection
trigger: malware_detected
enabled: true
actions:
  - action: create_alert
    params:
      severity: critical
      title: "Malware detected on endpoint"
  - action: isolate_host
    params:
      host: "{{host}}"
      reason: "malware detected"
  - action: quarantine_file
    params:
      file: "{{file}}"
  - action: notify
    params:
      channel: "#security-incidents"
      message: "Host {{host}} isolated. Malware: {{file}}"
""",
            "brute_force.yaml": """name: Brute Force Detection
description: Block IP after 5 failed logins
trigger: brute_force_detected
enabled: true
actions:
  - action: block_ip
    params:
      ip: "{{source_ip}}"
      duration: 3600
  - action: log
    params:
      message: "Brute force from {{source_ip}} - blocked"
  - action: notify
    params:
      channel: "#security-incidents"
      message: "Brute force detected from {{source_ip}}"
""",
            "lateral_movement.yaml": """name: Lateral Movement
description: Respond to detected lateral movement
trigger: lateral_movement
enabled: true
actions:
  - action: create_alert
    params:
      severity: high
      title: "Lateral movement detected"
  - action: hunt
    params:
      hypothesis: "lateral_credentials"
  - action: notify
    params:
      channel: "#security-incidents"
      message: "Lateral movement on {{host}}"
""",
        }
        for name, content in templates.items():
            path = os.path.join(dir_path, name)
            if not os.path.exists(path):
                with open(path, "w") as f:
                    f.write(content)

    def emit_event(self, event_name: str, data: dict = None):
        """يرسل event ليتحقق من الـtriggers"""
        event_data = {
            "event": event_name,
            "data": data or {},
            "timestamp": datetime.now().isoformat(),
        }
        if self.log:
            self.log.put(f"[soar] event: {event_name}")

        # find matching playbooks
        for pb in self.playbooks:
            if not pb.enabled:
                continue
            if pb.trigger == event_name:
                threading.Thread(
                    target=self._execute_playbook,
                    args=(pb, event_data),
                    daemon=True).start()

    def _execute_playbook(self, playbook: SOARPlaybook,
                            event_data: dict) -> dict:
        """ينفذ playbook كامل"""
        execution = {
            "playbook": playbook.name,
            "event": event_data,
            "started": datetime.now().isoformat(),
            "actions_executed": [],
            "status": "running",
        }

        context = {**event_data["data"], **event_data}

        for action in playbook.actions:
            # check condition
            if action.condition:
                try:
                    if not eval(action.condition, {}, context):
                        continue
                except Exception:
                    continue

            # substitute variables
            params = {}
            for k, v in action.params.items():
                if isinstance(v, str) and "{{" in v:
                    for var, val in context.items():
                        v = v.replace("{{" + var + "}}", str(val))
                params[k] = v

            # execute
            handler = self.action_handlers.get(action.action_type)
            if not handler:
                execution["actions_executed"].append({
                    "action": action.action_type,
                    "status": "no_handler",
                })
                continue

            try:
                result = handler(**params)
                execution["actions_executed"].append({
                    "action": action.action_type,
                    "status": "success",
                    "result": result,
                })
                if self.log:
                    self.log.put(f"[soar] {action.action_type}: success")
            except Exception as e:
                execution["actions_executed"].append({
                    "action": action.action_type,
                    "status": "error",
                    "error": str(e),
                })

        execution["completed"] = datetime.now().isoformat()
        execution["status"] = "completed"
        self.executions.append(execution)
        return execution

    def start(self):
        """يشغل continuous mode"""
        self.running = True
        if self.log:
            self.log.put("[soar] engine started")

    def stop(self):
        self.running = False
        if self.log:
            self.log.put("[soar] engine stopped")

    def get_executions(self) -> list:
        return self.executions

    # ==================== built-in actions ====================
    def _action_log(self, message: str, **kwargs) -> dict:
        if self.log:
            self.log.put(f"[soar] {message}")
        return {"logged": message}

    def _action_webhook(self, url: str, payload: dict = None) -> dict:
        try:
            import httpx
            r = httpx.post(url, json=payload or {}, timeout=10)
            return {"status": r.status_code}
        except Exception as e:
            return {"error": str(e)}

    def _action_email(self, to: str, subject: str,
                        body: str) -> dict:
        # سجل فقط (real impl يحتاج SMTP)
        if self.log:
            self.log.put(f"[soar] email → {to}: {subject}")
        return {"queued": True}

    def _action_slack(self, webhook: str, message: str) -> dict:
        try:
            import httpx
            r = httpx.post(webhook, json={"text": message}, timeout=10)
            return {"status": r.status_code}
        except Exception as e:
            return {"error": str(e)}

    def _action_block_ip(self, ip: str, duration: int = 3600) -> dict:
        # iptables block
        try:
            import subprocess
            subprocess.run(
                ["sudo", "iptables", "-A", "INPUT", "-s", ip, "-j", "DROP"],
                capture_output=True, timeout=10)
            return {"blocked": ip, "duration": duration}
        except Exception as e:
            return {"error": str(e)}

    def _action_isolate(self, host: str, reason: str = "") -> dict:
        if self.log:
            self.log.put(f"[soar] isolating {host}: {reason}")
        return {"isolated": host}

    def _action_kill_process(self, host: str, process: str) -> dict:
        if self.log:
            self.log.put(f"[soar] kill {process} on {host}")
        return {"killed": process}

    def _action_quarantine(self, file: str) -> dict:
        if self.log:
            self.log.put(f"[soar] quarantined {file}")
        return {"quarantined": file}

    def _action_alert(self, severity: str, title: str,
                        details: str = "") -> dict:
        if self.log:
            self.log.put(f"[soar] ALERT [{severity}]: {title}")
        return {"alerted": True}

    def _action_command(self, cmd: str) -> dict:
        try:
            import subprocess
            r = subprocess.run(cmd, shell=True,
                                capture_output=True, text=True, timeout=30)
            return {"output": r.stdout[:500]}
        except Exception as e:
            return {"error": str(e)}

    def _action_hunt(self, hypothesis: str) -> dict:
        try:
            from core.hunting.hunter import hunter
            results = hunter.run_all()
            return {"hypothesis": hypothesis, "found": len(results)}
        except Exception as e:
            return {"error": str(e)}

    def _action_notify(self, channel: str, message: str) -> dict:
        if self.log:
            self.log.put(f"[soar] {channel}: {message}")
        return {"sent": True}


soar_engine = SOAREngine()
